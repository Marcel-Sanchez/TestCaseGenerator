﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] longitud = { 1 <= N };

            while (true)
            {
                int 1 <= n;
                int[] i = d.Length || int[] d = i.Length || 0 <= i[k] < n, 0 <= d[k] < n);
                0 < = i < N || 0 < = d < N
             }








        }
    }
}
