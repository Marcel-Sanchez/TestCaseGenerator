﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            //Borre la siguiente línea y escriba su código
            int[] start = Start(n);
          
            
            int pos1 = 0;
            int pos2 = 0;
            int[] result = new int[start.Length];
            for (int k = 0; k < i.Length; k++)
            {
                pos1 = i[k];
                pos2 = d[k];
                
                
            }
            int[] all = Arrayinter(start, pos1, pos2);
            for (int o = 0; o <result.Length; o++)
            {
                for (int m = 0; m < start.Length-pos2 ; m++)
                {


                    for (int x = 0; x < all.Length; x++)
                    {
                        result[o++] = start[m];
                        result[o++] = all[x];
                    }

                }
              
            }
            

            
            
           



            return result ;
        }
        static int[] Start(int a)
        {
            int[] start = new int[a];
            int num = 1;
            for (int o = 0; o < start.Length; o++)
            {
                start[o] = num;
                num++;
            }
            return start;
        }
        static int[] Intercambiar(int[] c)
        {
            int[] copia = new int[c.Length];
            int p = 0;

            for (int k = c.Length - 1; k >= 0; k--)
            {
                copia[p++] = c[k];
            }
            return copia;
        }
        static int[] Arrayinter(int[] a, int b, int c)
        {  
              
            if (b <= c)
            {

                int p = 0;
                int[] copia = new int[(c - b) + 1];
                int[] prime = new int[copia.Length];
                for (int i = b; b <= c; i++)
                {
                    copia[p++] = a[i];

                }
                prime = Intercambiar(copia);
               
              
                return prime;

            }
            else
            {  
                int k = (c - b) ;
                int p = 0;
                int[] copia = new int[b];
                int[] copy = new int[a.Length * 2];
                int[] prime = new int[copia.Length];
                int o = copy.Length - k;
                for (int i = 0; i < copy.Length; i++)
                {
                    copy[p++] = a[i];
                    copy[p++] = a[i];
                }

                for (int i =c; i <=o; i++)
                {
                    copia[p++] = copy[i];

                }
                prime = Intercambiar(copia);
                return prime;
            }
            
        }
       
        }


    }

