﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            
            int[] regalos = new int[n];
            for (int j = 0; j < n; j++)
            {

            }
            //int[] regalos_2 = new int[n];
            //for (int k = 0; k < n; k++)
            //{

            //}
            int[


            }
             
      
    }
}
