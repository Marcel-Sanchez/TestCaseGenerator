﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            //Borre la siguiente línea y escriba su código
            int[] valores = new int[n];
            int aux = 0;
            int valor = 0;
            for (int x = 0; x < valores.Length; x++)
            {
                valores[x] = valor + 1;
                valor++;
            }
            int left = 0;
            int right = 0;
            for (int k = 0; k < i.Length; k++)
            {

                        left = i[k];
                        right = d[k];
                    while (left != right)
                    {
                        aux = valores[right];
                        valores[right] = valores[left];
                        valores[left] = aux;
                        left++;
                        right--;
                        if (right < 0)
                            right = valores.Length - 1;
                        if (left >= valores.Length)
                    {
                        left = 0;
                    }
                    if ((left == 0) && (right == (valores.Length - 1))) break;
                    if ((left == valores.Length - 1) && (right == 0))
                    {
                        if (n == 2) break;
                        aux = valores[right];
                        valores[right] = valores[left];
                        valores[left] = aux;
                        break;
                    }
                        if ((left + 1) == right)
                    {
                        aux = valores[right];
                        valores[right] = valores[left];
                        valores[left] = aux;
                        break;
                    }
                    if ((left - 1) == right) break;
                }
            }
            return valores;
        }
    }
}
