﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
           
            int[] regalos = new int[n];
            while (true)
            {
                int [0] regalos = int [0] i;
                    
            }

         
        }
       
    }
}
