﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] organizado = new int[n];
            int contador = 0;
            int Gd;
            int Gi;
            int c;
             int f;
            int m;
            int sm;
            for (int k = n - 1; k >= 0; k--)  //para llenar el arrays inicial
            {    
                organizado[k] = (n - contador);
              
                contador++;
            }
            for (int j = 0; j < i.Length; j++)
            {
                if ((i[j] == 0 && d[j] == 1) || (i[j] == 1 && d[j] == 0))
                {


                    Gi = organizado[i[j]];
                    Gd = organizado[d[j]];
                    organizado[d[j]] = Gi;
                    organizado[i[j]] = Gd;
                }
                else
                if (i[j] <= d[j])
                {
                    c = i[j];
                    f = d[j];
                    while (c <= f)
                    {

                        Gi = organizado[c];
                        Gd = organizado[f];
                        organizado[f] = Gi;
                        organizado[c] = Gd;

                        c++;
                        f--;

                    }
                }
                else
                {
                    m = i[j];
                    sm = d[j];
                    while ((sm - m )!= -1 && (sm - m) != 0)
                    {
                        Gi = organizado[m];
                        Gd = organizado[sm];
                        organizado[sm] = Gi;
                        organizado[m] = Gd;
                        m++;
                        sm--;

                        if (sm < 0)
                        {
                            sm = n - 1;

                        }
                        if (m >= organizado.Length)
                        {
                            m = 0;


                        }
                       

                    }

                }


            }
            return organizado;

        }
    }
}
