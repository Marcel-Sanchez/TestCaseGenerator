﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = new int[n];
            List<int> list = new List<int>();
            for (int j = 0; j < n; j++)
            {
                regalos[j] = j + 1;
            }
            for (int j = 0; j < i.Length; j++)
            {
                int x = i[j];
                int y = d[j];
                list.Add(regalos[x]);
                int pos = x;
                for (int k = x; pos != y; k++)
                {
                    pos = (k + 1) % regalos.Length;
                    list.Add(regalos[pos]);
                }
                Invertir(list);
                regalos[x] = list[0];
                pos = x;
                for (int k = x, listPos = 1; pos != y; k++,listPos++)
                {
                    pos = (k + 1) % regalos.Length;
                    regalos[pos] = list[listPos];
                }
                list = new List<int>();
            }
            return regalos;
        }

        private static void Invertir(List<int> list)
        {
            for (int i = 0; i < list.Count/2; i++)
            {
                int temp = list[i];
                list[i] = list[list.Count - 1 - i];
                list[list.Count - 1 - i] = temp;
            }
        }
    }
}
