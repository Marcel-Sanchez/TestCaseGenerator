﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = new int[n];
            int k = 1;
            for (int j = 0; j < regalos.Length; j++)
            {
                regalos[j] = k;
                k++;
            }
            for (int j = 0; j < i.Length; j++)
            {
                int a = i[j];
                int b = d[j];
                int cont = 0;
                for (int h = a; a%n != b; a++)
                    cont++;
                int[] array = new int[cont+1];
                a = i[j];int p = 0;
                for (int h = a % n, z = 0; h != b; h = (++a) % n, z++,p++)
                {
                    array[z] = regalos[h];
                }
                array[p] = regalos[b] ;
                Invertir(array);
                a = i[j];
                for (int h = a % n, z = 0; h != b; h = (++a) % n, z++)
                {
                    regalos[h] = array[z];
                }
                regalos[b] = array[p];
            }
            return regalos;
        }
        static void Invertir(int[]a)
        {
            int[] b = new int[a.Length];
            b = a;
            for (int i = 0, j = a.Length - 1; j > i; i++, j--)
            {
                int x = b[i];
                int y = b[j];
                a[i] = y;
                a[j] = x;
            }
        }
    }
}
