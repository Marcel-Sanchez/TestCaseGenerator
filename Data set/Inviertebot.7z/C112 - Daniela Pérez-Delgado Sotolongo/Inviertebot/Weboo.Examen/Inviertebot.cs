﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {

        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int k = 0;
            int b = 1;
            int p1 = 0;
            int p2 = 0;

            int[] lista = new int[n];
            int[] pos1 = new int[i.Length];
            int[] pos2 = new int[d.Length];
            ///lista de regaloss
            for (int t = 0; t < n; t++)
            {
                lista[k++] = b;
                b++;
            }
            ///i
            for (int y = 0; y < i.Length; y++)
            {
                pos1[p1++] = i[y];
            }
            ////d
            for (int o = 0; o < d.Length; o++)
            {
                pos2[p2++] = d[o];
            }

            for (int j = 0; j < pos1.Length; j++)
            {

                int g = lista[pos1[j]];
                int v = lista[(1 + pos1[j]) % lista.Length];
                if (pos1[j] == pos2[j])
                {
                    lista[pos1[j]] = lista[pos2[j]];
                    lista[pos2[j]] = g;
                }
                if (pos2[j] - pos1[j] == 1)
                {

                    lista[pos1[j]] = lista[pos2[j]];
                    lista[pos2[j]] = g;

                }
               

                if (pos2[j] == 0)
                {
                    lista[pos1[j]] = lista[pos2[j]];
                    lista[pos2[j]] = g;

                    lista[(1 + pos1[j]) % lista.Length] = lista[ lista.Length-1];
                    lista[lista.Length - 1] = v;
                }
                if (pos1[j] == 1)
                {

                    lista[pos1[j]] = lista[pos2[j]];
                    lista[pos2[j]] = g;
                }

              else  if (pos1[j] != pos2[j] && pos2[j] != 0 && pos2[j] - pos1[j] != 1)
                {
                    lista[pos1[j]] = lista[pos2[j]];
                    lista[pos2[j]] = g;

                    lista[(1 + pos1[j]) % lista.Length] = lista[(pos2[j] - 1) % lista.Length];
                    lista[(pos2[j] - 1) % lista.Length] = v;
                }
                
                
            }
            return lista;
        }
    }
}

