﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        static int[] Changer2 (int[]a,int b,int c)
        {
            int medio = b - c;
            int bordes = a.Length - 1 - medio;
            int nm = bordes / 2;
            int counter = 0;
            while (counter<=nm)
            {
                int fijo = a[b];
                a[b] = a[c];
                a[c] = fijo;
                counter++;
                if (b == a.Length - 1 && c != 0) 
                {
                    b = 0;c--;
                }
                if (c == 0&&b!=a.Length-1)
                {
                    c = a.Length - 1;b++;
                }
                else { b++;c--; }
            }
            return a;
        }
        static int[] Changer1 (int[]a,int b,int c)
        {
            int medio = (b - c) / 2;
            for (int i= c,j= b; i <= c + medio && j >= b - medio; i++, j--)
            {
                int fijo = a[i];
                a[i] = a[j];
                a[j] = fijo;
            }
            return a;
        }
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] a = new int[n];
            for(int j=0;j< n; j++)
            {
                a[j] = j + 1;
            }
            for(int j = 0; j < i.Length; j++)
            {
                if (i[j] < d[j])
                {
                    a = Changer1(a, d[j], i[j]);
                }
                if (i[j] > d[j])
                {
                    a = Changer2(a, i[j], d[j]);
                }
            }
            return a;
            
        }
    }
}
