﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] solucion = new int[n];

            for (int k = 0, j=1; k < solucion.Length; k++, j++)
            {
                solucion[k] = j;
            }

            for (int k = 0, index1 = 0, index2 = 0, pivot = 0; k < i.Length; k++)
            {
                index1 = i[k];
                index2 = d[k];

                while (index1 - index2 != 0)
                {
                    pivot = solucion[index1];
                    solucion[index1] = solucion[index2];
                    solucion[index2] = pivot;

                    if (index1 == n - 1 && index2 == 0)
                        break;

                    if (index1 + 1 == index2)
                        break;

                    index1++;
                    index2--;

                    if (index1 >= n)
                        index1 = 0;
                    if (index2 < 0)
                        index2 = solucion.Length - 1;
                }
            }
            return solucion;
        }
    }
}
