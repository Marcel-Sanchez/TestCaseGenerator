﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos;
            regalos = new int[n];
            int aux;
            for (int m = 0, l = 1; l <= n; l++, m++)
            {
                regalos[m] = l;
            }
            for (int e = 0; e < i.Length; e++)
            {
                aux = regalos[i[e]];
                regalos[i[e]] = regalos[d[e]];
                regalos[d[e]] = aux;
                if (i[e] > d[e])
                {

                }
                if (i[e] < d[e])
                {

                }
            }
            return regalos;
        }
    }
}
