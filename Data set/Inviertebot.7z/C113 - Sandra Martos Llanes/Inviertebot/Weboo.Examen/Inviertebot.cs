﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            
            int temporal;           
            int[] regalos = new int[n];
            int a = 1;
            for (int j = 0; j < regalos.Length; j++)
            {
                regalos[j] = a;
                a++;
            }
            

            for (int k = 0, j = 0; k < i.Length && j < d.Length; k++, j++)
            {
               
                for (int h = i[k], l = d[j] ; h < regalos.Length && l >= 0;h++, l--)
                {
                    if (h== l)
                    {
                        break;
                    }
                 
                    if (Marcar(h, i[k], d[j]))
                    {
                        if (Marcar(l, d[j], i[k]))
                        {
                            temporal = regalos[h];
                            regalos[h] = regalos[l];
                            regalos[l] = temporal;

                        }

                    }
                    if (h + 1 == l && l - 1 == h)
                    {
                        break;
                    }
                    if (l == 0)
                    {
                        l = regalos.Length - 1;

                    }
                  
                }

            } return regalos;

        }


        static bool Marcar(int casilla, int pos1, int pos2)
        {
            if (casilla <= pos1 || casilla >= pos2)
                return true;
            else return false;
        }

    }
}
