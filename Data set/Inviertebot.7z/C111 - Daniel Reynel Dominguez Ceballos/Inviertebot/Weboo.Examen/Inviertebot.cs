﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            //variables utiles
            int posI;
            int posD;
            int[] regalos = new int[n];
            bool[] marca;

            //Crea regalos
            for (int indice = 0; indice < regalos.Length; indice++)
            {
                regalos[indice] = indice + 1;
            }
            //Metodo para hacer el cambio en intervalos
            for (int indice = 0; indice < i.Length; indice++)
            {
                posI = i[indice];
                posD = d[indice];
                marca = new bool[n];
                if (posI != posD)
                {
                    while (!(marca[posI] && marca[posD]))
                    {
                        int temp = regalos[posI];
                        regalos[posI] = regalos[posD];
                        regalos[posD] = temp;
                        marca[posD] = true;
                        marca[posI] = true;

                        posI++;
                        posD--;
                        if (posI >= regalos.Length) { posI = 0; }
                        if (posD < 0) { posD = regalos.Length - 1; }
                    }
                }
            }
            return regalos;
        }
    }
}
