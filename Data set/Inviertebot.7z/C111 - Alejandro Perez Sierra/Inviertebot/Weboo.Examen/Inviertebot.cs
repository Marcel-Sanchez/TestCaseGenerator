﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos_invertidos = new int[n];
            int[] regalos = new int[n];
            //Imprimiendo los regalos
            for (int j = 0; j < regalos.Length; j++)
            {
                regalos[j] = j + 1;
            }

            //Invirtiendo los regalos
            regalos_invertidos = Invetrir(i, d, regalos);
            return regalos_invertidos;

        }
        public static int[] Invetrir(int[] i, int[] d, int[] regalos)
        {
            for (int j = 0; j < i.Length; j++)
            {
                int isquierda = i[j];
                int derecha = d[j];
                int temp = regalos[isquierda];
                regalos[isquierda] = regalos[derecha];
                regalos[derecha] = temp;
            }
            return regalos;
        }



    }
}
