﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        static int[] arr;
        static void change(int a, int b)
        {
            while (a < b)
            {
                int temp = arr[a];
                arr[a] = arr[b];
                arr[b] = temp;
                a++;
                b--;
            }
        }
        static void robot(int a, int b)
        {
            int n = arr.Length;
            bool flag = true;
            if (a - b < 0)
            {
                change(a, b);
            }
            else if (a - b > 0)
            {
                while (a < n && b >= 0)
                {
                    int temp = arr[a];
                    arr[a] = arr[b];
                    arr[b] = temp;
                    a++;
                    b--;
                }
                if (a == n && b >= 0) { a = 0; flag = false; }
                if (b == -1 && a < n) { b = n - 1; flag = false; }
                if (flag == false) change(a, b);
            }
        }
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            arr = new int[n];
            for (int j = 0; j < n; j++)
            {
                arr[j] = j + 1;
            }
            int size=i.Length;
            for (int j = 0; j < size; j++)
            {               
                int left = i[j];
                int right = d[j];
                robot(left, right);
                //bool flag = true;
                //if (left - right < 0)
                //{
                //    change(left, right);
                //}
                //else if (left - right > 0)
                //{
                //    while (left < n && right >= 0)
                //    {
                //        int temp = arr[left];
                //        arr[left] = arr[right];
                //        arr[right] = temp;
                //        left++;
                //        right--;
                //    }
                //    if (left == n && right >= 0) { left = 0; flag = false; }
                //    if (right == -1 && left < n) { right = n - 1; flag = false; }
                //    if (flag==false) change(left, right);
                //}
            }
            return arr;
        }
    }
}
