﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int w;
            int[] regalos = new int[n];
            for (int j = 0; j < regalos.Length; j++)
            {
                regalos[j] = j + 1;
            }
            for (int j = 0; j < i.Length; j++)
            {
                if (i[j] <= d[j])
                {
                    w = d[j] - i[j] + 1;
                }
                else
                {
                    w = d[j] + regalos.Length - i[j] + 1;
                }
                int[] invertidor = new int[w];
                for (int k = 0, l = k + i[j]; k < invertidor.Length; k++)
                {
                    if (l == regalos.Length)
                        l = 0;
                    invertidor[k] = regalos[l];
                    l++;
                }
                for (int k = 0; k < w / 2; k++)
                {
                    int x = invertidor[k];
                    invertidor[k] = invertidor[invertidor.Length - k - 1];
                    invertidor[invertidor.Length - k - 1] = x;
                }
                for (int k = 0, l = k + i[j]; k < invertidor.Length; k++)
                {
                    if (l == regalos.Length)
                        l = 0;
                    regalos[l] = invertidor[k];
                    l++;
                }
            }
            return regalos;
        }
    }
}
