﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = new int[n];
            for (int m = 0; m < n; m++)
            {
                regalos[m] = m + 1;
            }
            int posini = 0;
            int posfin = 0;

            for (int k = 0, l = 0; k < i.Length; k++, l++)
            {
                posini = i[k];
                posfin = d[l];
                int[] nuevo = Mover(posini, posfin, regalos);
            
                int y = posini;
                if (posfin > posini)
                {
                    for (int x = 0; x < nuevo.Length; x++)
                    {
                        if (y >= regalos.Length) y = 0;
                        else if (y == posfin + 1) break;

                        regalos[y] = nuevo[x];
                        y++;

                    }
                }
                else if (posfin < posini)
                {
                    int t = posini;
                    for (int x = 0; x < nuevo.Length; x++)
                    {
                        if (t >= regalos.Length) t = 0;
                        else if (t == posfin + 1) break;

                        regalos[t] = nuevo[x];
                        t++;

                    }
                }
                else continue;
            }
            return regalos;

        }

        public static int[] Mover(int posini, int posfinal, int[] array)
        {
            int x = 0;
            if (posfinal > posini)
            {
                x = posfinal - posini + 1;
                int[] movido = new int[x];
                for (int i = 0, j = posfinal; i < movido.Length; i++, j--)
                {

                    if (j >= movido.Length) j = 0;
                    if (j < 0) break;
                    movido[i] = array[j];

                }
                return movido;
            }
            else if (posfinal < posini)
            {
                x = posini - posfinal - 1;
                int[] movido = new int[x];
                for (int j = posini, i = movido.Length - 1; i >= 0; i--, j++)
                {
                    if (j >= array.Length)
                    { j = 0; }
                    movido[i] = array[j];
                }
                return movido;
            }
        
           else return array;

        }
    }     
}

