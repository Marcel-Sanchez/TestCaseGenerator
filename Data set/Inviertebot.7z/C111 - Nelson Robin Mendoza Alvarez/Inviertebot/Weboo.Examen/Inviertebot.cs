﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] a = new int[n];
            for (int j = 0; j < a.Length; j++)
            {
                a[j] = j + 1;
            }
            for (int j = 0; j < i.Length; j++)
            {
                a = Invertir(i[j], d[j], a);
            }
            return(a);
        }
        public static int[] Invertir(int a, int b, int[] n) 
        {
            int x = 0;
            if (a > b)
            {
                    x = (b + n.Length - a + 1) / 2;
                for (int i = 0; i < x; i++)
                {
                    int h=b-i;
                    if (h < 0)
                        h += n.Length;
                    int y = n[(a+i) % n.Length];
                    n[(a+i) % n.Length] = n[h % n.Length];
                    n[h % n.Length] = y;
                }
            }
            else
            {
                x = (b - a + 1) / 2;
                for (int i = 0; i < x; i++)
                {
                    int y = n[a + i];
                    n[a + i] = n[b - i];
                    n[b - i] = y;
                }
            }
            return(n);
        }
    }
}
