﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int q = 0;
            //    int[] f = new int[n];
            int b = 0;
            int x = 0;
            int k = 1;
            int[] c = new int[n];
            int[] t = new int[n];
            for (int a = 0; a < c.Length; a++)
            {
                c[a] = k;
                k++;
            }
            //    for (int j = 0; j < i.Length; j++)
            //    {
            //        b = i[j];
            //        x = d[j];
            //        if (x == b)
            //            continue;
            //        //if (x > b)

            //        for (int z = b ; z % c.Length <= x; z++)
            //        {
            //            f[q] = c[z % c.Length];
            //            q++;
            //        }
            //        Array.Reverse(f);
            //        for (int h = b, m = f.Length - 1 - d[j]; h % c.Length <= x && m < f.Length; m++, h++)
            //        {
            //            c[h % c.Length] = f[m];
            //        }

            //        //else
            //        //{
            //        //    for (int z = x; z <= b; z++)
            //        //    {
            //        //        f[q] = c[z];
            //        //        q++;
            //        //    }
            //        //    Array.Reverse(f);
            //        //    for (int h = x, m = f.Length - 1 - i[j]; h <= b && m < f.Length; h++, m++)
            //        //    {
            //        //        c[h] = f[m];
            //        //    }


            //    q = 0;
            //}
            //    return c;
            for (int j = 0; j < i.Length; j++)
            {
                b = i[j];
                x = d[j];
                //if (b > x)
                //{
                    for (int z = x; z != b; z = (z + 1) % c.Length)
                    {
                        t[q] = c[z];
                        q++;
                    }
                //}
                //else
                //{
                //    for (int z = b; z != x; z = (z + 1) % c.Length)
                //    {
                //        t[q] = c[z];
                //        q++;
                //    }
                //}

                int[] r = new int[q];
                for (int U = 0; U < q; U++)
                {
                    r[U] = t[U];
                }
                for (int w = r.Length - 1, p = x; w >= 0 && p != b; w--, p = ((p + 1) % c.Length))
                    {
                        c[p]=r[w];

                    }

                q = 0;

            }


            return c;
        }
    }
}
