﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
      
        public static int[] Cambiar(int[]a,int i,int d)
        {
            int temp;
            
            for (int h = i;d>=0&& h<=a.Length-1 ; h++,d--)
            {
                
                if (h != d)
                {   
                    temp = a[h];
                    a[h] = a[d];
                    a[d] = temp;
                }
                else
                {
                    a[h] = a[d];
                        break;
                } 
                
            }
            return a;
        }
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            
            int[]Instrucciones = new int[n];
            for (int  j= 0, h=1; j < Instrucciones.Length;h++, j++)
            {
                Instrucciones[j] = h;
                
            }
            for (int k = 0; k < i.Length; k++)
            {
                Cambiar(Instrucciones,i[k],d[k]);

            }
            return Instrucciones;
           
        }
    }
}
