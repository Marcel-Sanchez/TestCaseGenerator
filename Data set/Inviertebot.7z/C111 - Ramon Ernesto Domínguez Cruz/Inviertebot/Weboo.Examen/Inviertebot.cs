﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{    
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] Answer = new int[n];
            for (int j = 0; j < Answer.Length; j++)
            {
                Answer[j] = j + 1;
            }

            for (int j = 0; j < i.Length; j++)
            {
                if (i[j] < d [j])
                {
                    for (int v = i[j], z = d[j]; true; v++, z--)
                    {
                        if (v == z)
                            break;
                        int temp = Answer[v];
                        Answer[v] = Answer[z];
                        Answer[z] = temp;
                        if (v == z - 1)
                            break;
                    }
                }
                else if (i[j] > d[j])
                {
                    for (int v = i[j], z = d[j]; true; v--, z++)
                    {
                        if (v == z)
                            break;
                        int temp = Answer[v];
                        Answer[v] = Answer[z];
                        Answer[z] = temp;
                        if (v == z + 1)
                            break;
                    }
                }            
            }
            return Answer;
        }
    }
}
