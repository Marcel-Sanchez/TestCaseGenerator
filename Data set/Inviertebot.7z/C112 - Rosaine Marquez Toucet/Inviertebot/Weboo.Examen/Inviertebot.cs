﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {

           /* int[] R = { }; este va a ser el array donde van a estar contenido la cantidad de regalos 
            R.Sort();  con esto organizo el array de manera creciente 
                     [i, d]=i[k],d[k];   el robot toma la posicion k  tanto en el array i como en el d

            for (int i[K] = 0; i[K]<i.Length; i++)   con este ciclo quiero que el robot comiense en la posicion 0 de ambos arrays (i y d) y me siga recorriendo
            {                                        dichos arrays al mismo tiempo 
            for (int d[K]=0; d[k]<d.Lenght;d++)
			{
               for (z=i[k],z<i.Length;z++)      cuando ya tengo el intervalo entre [i,d] quiero q me rote ese pedasito de array d[k]-1 veces
			}                                   a la izquierda ejemplo: b[i]=(i-n)%a.Length=a[i] 
                                       
                                               y por ultimo me devuelva el arrays de enteros ordenados con la disposicion final de los regalos  
            
            }
        }
}













   
            throw new NotImplementedException("Tiene que borrar esta línea: throw new NotImplementedException(...)");
}
    }
}
