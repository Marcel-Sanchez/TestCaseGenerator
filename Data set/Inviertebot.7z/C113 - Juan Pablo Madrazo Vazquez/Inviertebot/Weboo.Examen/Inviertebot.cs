﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = CreaArray(n);

            for (int j = 0; j < i.Length; j++)
            {
                InvierteHasta(regalos, i[j], d[j]);
            }
            return regalos;
        }
        static void InvierteHasta(int[] regalosmod, int i, int d)
        {
            int cant = Cuantos(regalosmod, i, d);
            int[] ainvertir = new int[cant];
            Asigna(ainvertir, regalosmod, cant, i, alreves: false);
            Invierte(ainvertir);
            Asigna(ainvertir, regalosmod, cant, i, alreves: true);
        }
        static void Asigna(int[] ainvertir, int[] regalosmod, int cant, int i, bool alreves)
        {
            for (int j = 0, k = i; j < cant; j++, k++)
            {
                if (alreves) regalosmod[k] = ainvertir[j];
                else ainvertir[j] = regalosmod[k];
                if (k + 1 == regalosmod.Length) k = -1;
            }
        }

        static int Cuantos(int[] arr, int i, int d)
        {
            int cant = 1;
            for (int j = i; j < arr.Length; j++)
            {
                if (j == d) break;
                if (j + 1 == arr.Length) j = -1;
                cant++;
            }
            return cant;
        }

        static void Invierte(int[] arr)
        {
            for (int i = 0; i < arr.Length / 2; i++)
            {
                int tmp = arr[arr.Length - 1 - i];
                arr[arr.Length - 1 - i] = arr[i];
                arr[i] = tmp;
            }
        }

        static int[] CreaArray(int n)
        {
            int[] arr = new int[n];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = i + 1;
            }
            return arr;
        }
    }
}
