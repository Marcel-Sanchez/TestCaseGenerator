﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = new int[n];
            int num = 1;
            for (int j = 0; j < regalos.Length; j++)
            {
                regalos[j] = num;
                num++;
            }
            for (int j = 0; j < i.Length; j++)
            {
                regalos = Rota(regalos, i[j], d[j]);
            }
            return regalos;
        }

        public static int[] Rota(int[] regalos, int manoDe, int manoIz)
        {
            int[] final;
            int a = manoDe;
            
            if (manoDe == manoIz)
            {
                return regalos;
                
            }
            if (manoDe < manoIz)
            {
                final = new int[manoIz - manoDe + 1];
                for (int i = 0; i < final.Length; i++)
                {
                    final[i] = regalos[a];
                    a++;
                }
            }
            else
            {
                final = new int[(regalos.Length -manoDe  + manoIz + 1)];
                for (int i = 0; i <final.Length ; i++)
                {
                    if (a >= regalos.Length)
                    {
                        a = 0;
                    }
                    final[i] = regalos[a];
                    a++;
                }
            }
            int c = final.Length-1;
            int neutro;

            for (int i = 0; i < final.Length/2; i++)
            {
                neutro = final[i];
                final[i] = final[c];
                final[c] = neutro;
                c--;
            }
            if (manoDe < manoIz)
            {
                for (int i = 0; i < final.Length; i++)
                {
                    regalos[manoDe] = final[i];
                    manoDe++;
                }
            }
            else
            {
                for (int i = 0; i < final.Length; i++)
                {
                    if (manoDe >= regalos.Length)
                    {
                        manoDe = 0;
                    }
                     regalos[manoDe]= final[i];
                    manoDe++;
                }
            }

            return regalos;
        }
    }
}
