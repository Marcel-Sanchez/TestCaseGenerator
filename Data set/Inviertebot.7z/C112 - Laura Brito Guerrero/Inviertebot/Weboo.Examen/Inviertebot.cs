﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            if (n <= 0 || i == null || d == null || i.Length != d.Length) throw new Exception("Parametros incorrectos");
            if (PosicionesIncorrectas(i, n) || PosicionesIncorrectas(d, n))
                throw new IndexOutOfRangeException("Existen posiciones mayores o iguales que la cantidad de regalos");

            if (n == 1) return CrearArray(n);

            var regalos = CrearArray(n);

            for (int j = 0; j < i.Length; j++)
            {
                CambiaOrden(ref regalos, i[j], d[j]);
            }
            return regalos;
        }

        private static void CambiaOrden(ref int[] regalos, int index0, int indexf)
        {
            var semicircunferencia = new List<int>();

            if (index0 <= indexf)
            {
                for (int i = index0; i <= indexf; i++)
                {
                    semicircunferencia.Add(regalos[i]);
                }
            }
            else
            {
                for (int i = index0; i < regalos.Length; i++)
                {
                    semicircunferencia.Add(regalos[i]);
                }
                for (int i = 0; i <= indexf; i++)
                {
                    semicircunferencia.Add(regalos[i]);
                }
            }
            for (int i = 0, j = semicircunferencia.Count - 1; i < j; i++, j--)
            {
                int temp = semicircunferencia[i];
                semicircunferencia[i] = semicircunferencia[j];
                semicircunferencia[j] = temp;
            }
            //modificando regalos
            for (int i = index0; i < regalos.Length; i++)
            {
                regalos[i] = semicircunferencia[0];
                semicircunferencia.RemoveAt(0);
                if(i == indexf) break;
            }
            if (semicircunferencia.Count != 0)
            {
                for (int i = 0; i <= indexf; i++)
                {
                    regalos[i] = semicircunferencia[0];
                    semicircunferencia.RemoveAt(0);
                }
            }
        }

        private static bool PosicionesIncorrectas(int[] x, int n)
        {
            for (int i = 0; i < x.Length; i++)
            {
                if (x[i] < 0 || x[i] >= n) return true;
            }
            return false;
        }

        private static int[] CrearArray(int n)
        {
            var regalos = new int[n];
            for (int i = 0; i < regalos.Length; i++)
            {
                regalos[i] = i + 1;
            }
            return regalos;
        }
        
    }
}
