﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            //int n = 0;
            int regalos = n;
            
            int[] invertido = new int [i.Length+1];

            for (int l = 0; l < regalos;l++ )
            {
              
                

                
                for (int j = 0; j < i.Length - 1; j++)
                {
                     
                     if(  i [l]==d[j])
                    {
                        n=l;

                    }
                     else
                    {
                        n[j] == n[l];
                    }
                                                                                                                                                                                                   
                }

           }
            
                
              
                   
                
            





               
                      
                        
        
    }
}
