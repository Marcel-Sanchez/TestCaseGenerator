﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int x,y=-1;
            int[] regalos = new int[n];
            for(int l=0,o=1;l<regalos.Length;l++,o++)
            {
                regalos[l] = o;
            }
            for (int contadorID = 0; contadorID < i.Length; contadorID++ )
            {
                if(i[contadorID]==d[contadorID])
                {
                    continue;
                }
             

                for (int brazoI = i[contadorID], brazoD = d[contadorID]; brazoI!=brazoD ; brazoI++, brazoD--)
                {
                    if(brazoD==y)
                    {
                        break;
                    }
                    y = brazoI;
                    x = regalos[brazoI];
                    regalos[brazoI] = regalos[brazoD];
                    regalos[brazoD] = x;
                    if (brazoD == 0)
                    {
                        brazoD = regalos.Length;
                    }
                    if (brazoI ==regalos.Length-1)
                    {
                        brazoI = -1;
                    }
                }

            }
            return regalos;
        }
    }
}
