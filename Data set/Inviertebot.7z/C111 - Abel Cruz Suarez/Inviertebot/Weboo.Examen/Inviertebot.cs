﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] GiftSort = new int[n];
            FillArray(GiftSort);
          

            for (int k = 0; k < d.Length; k++)
            {
                int inicio = i[k];
                int final = d[k];
                bool[] mark = new bool[n];

                Marca(mark, inicio, final);

                int temp = GiftSort[inicio];
                GiftSort[inicio] = GiftSort[final];
                GiftSort[final] = temp;

                if (inicio == final) continue;

                Change(GiftSort, mark,inicio,final);
            }
            return GiftSort;
        }

        public static void FillArray(int[] x)
        {
            int count = 1;

            for (int i = 0; i < x.Length; i++)
            {
                x[i] = count;
                count++;
            }
        }

        public static void Marca(bool[]REgalosACambiar,int x,int y)
        {
            int count = x + 1;

            if (x == y) return;

            while (true)
            {
                if (count > REgalosACambiar.Length - 1)
                    count = 0;

                if (count == y) { break; }

                else { REgalosACambiar[count] = true; }

                count++;

            }
        }

        public static bool Comprueba(bool[]marca)
        {
            int cant = 0;

            for (int i = 0; i < marca.Length; i++)
            {
                if (marca[i])
                    cant++;
            }

            if (cant > 1) return true;

            return false;

        }

        public static void Change(int[] Gifts,bool[]marca,int inicio,int final)
        {

            while (Comprueba(marca))
            {
                int x = inicio + 1;
                int y = final - 1;

                if (y < 0)
                    y = ((final - 1) % Gifts.Length) + Gifts.Length;

                if (x >= Gifts.Length)
                    x = (inicio + 1) % Gifts.Length;

                if (marca[x]&&marca[y])
                {
                    int temp = Gifts[x];
                    Gifts[x] = Gifts[y];
                    Gifts[y] = temp;
                }

                marca[x] = false;
                marca[y] = false;
                inicio = x;
                final = y;

            }

        }
    }
}
