﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int temp = 0;
            int[] regalos = new int[n];

           for (int j = 0; j < n; j++)
             regalos[j] = j + 1;

            for (int j = 0; j < i.Length; j++)
            {
                if(d[j]==i[j])
                    continue;

                while (d[j] != i[j])
                {

                    temp = regalos[i[j]];
                    regalos[i[j]] = regalos[d[j]];
                    regalos[d[j]] = temp;
                                        
                    i[j]++;

                    if (i[j] == d[j])
                        break;

                    d[j] --;

                    if (i[j] == d[j])
                        break;

                    if (i[j] == n && d[j] == -1)
                        break;

                    if (i[j] == n)
                        i[j] = 0;

                    if (d[j] == -1)
                        d[j] = n - 1;

                }

                }

            return regalos;
            
        }
    }
}
