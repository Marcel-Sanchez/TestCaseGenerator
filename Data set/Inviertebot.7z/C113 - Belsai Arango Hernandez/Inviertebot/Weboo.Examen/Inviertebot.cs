﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] r = new int[n];

            int c1 = 0;
            int c2 = 0;
            int c3 = 0;

            for (int k = 0, j = 0; k < i.Length && j < d.Length ; k++,j++)
            {
                c1 = i[k];
                c2 = d[j];
                c3 = r[c1];
                r[c1] = r[c2];
                r[c2] = c3;
            }
            return r;
            Console.ReadLine();
        }
        
        
    }
}
