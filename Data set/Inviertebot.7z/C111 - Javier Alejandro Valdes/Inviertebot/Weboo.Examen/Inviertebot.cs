﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {

        /*public static void swap(int a, int b)
        {
            var temp = a;
            a = b;
            b = temp;
        }*/

        public static void Revierte(int[] n, int i, int d)
        {
            int length = 0;
            if (i < d)
                length = d - i + 1;
            else if (i > d)
                length = n.Length - (i - d - 1);
            else if (i == d) return;
            for (int a = 0; a < length / 2; a++)
            {
                //swap(n[i + a], n[(i + length - 1 - a)%n.Length]);
                var temp = n[i + a];
                n[i + a] = n[(i + length - 1 - a) % n.Length];
                n[(i + length - 1 - a) % n.Length] = temp;
            }
        }

        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            //Borre la siguiente línea y escriba su código
            int[] regalos = new int[n];
            for (int j = 0; j < n; j++)
            {
                regalos[j] = j + 1;
            }
            for (int j = 0; j < i.Length; j++)
            {
                Revierte(regalos, i[j], d[j]);
            }
            return regalos;
        }
    }
}
