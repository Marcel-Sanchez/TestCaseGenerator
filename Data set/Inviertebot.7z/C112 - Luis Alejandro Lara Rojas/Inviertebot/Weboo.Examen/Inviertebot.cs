﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = new int[n];
            for (int j = 0; j < n; ++j)
                regalos[j] = j + 1;
            for (int j = 0; j < i.Length; ++j) {
                if (i[j] < d[j])
                {
                    for (int k = 0; k < (d[j] - i[j]) / 2 + 1; ++k)
                    {
                        int r = regalos[i[j] + k];
                        regalos[i[j] + k] = regalos[d[j] - k];
                        regalos[d[j] - k] = r;
                    }
                }
                else if(i[j] > d[j]){
                    int[] rotar = new int[n]; int count = 0;
                    for (int k = i[j]; k < n; ++k)
                        rotar[count++] = regalos[k];
                    for (int k = 0; k < i[j]; ++k)
                        rotar[count++] = regalos[k];
                    int max = n - i[j] + d[j];
                    for (int k = 0; k < max/2 + 1; ++k) {
                        int r = rotar[k];
                        rotar[k] = rotar[max - k];
                        rotar[max - k] = r;
                    }
                    count = 0;
                    for (int k = n - i[j]; k < n; ++k)
                        regalos[count++] = rotar[k];
                    for (int k = 0; k < n - i[j]; ++k)
                        regalos[count++] = rotar[k];
                }
            }
                return regalos;
        }
    }
}
