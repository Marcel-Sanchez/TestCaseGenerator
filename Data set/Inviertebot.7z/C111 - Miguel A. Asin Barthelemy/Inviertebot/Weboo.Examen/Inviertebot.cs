﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] Regalos2 = new int[2 * n];

            for (int j = 0; j < 2 * n; j++)
                Regalos2[j] = j % n + 1;

            for (int j = 0; j < i.Length; j++)
            {
                if (i[j] > d[j]) d[j] += n;

                for (int k = i[j]; k < 1 + (d[j] + i[j]) / 2; k++)
                {
                    int temp = Regalos2[k];
                    Regalos2[k] = Regalos2[d[j] + i[j] - k];
                    Regalos2[d[j] + i[j] - k] = temp;
                }

                if (d[j] >= n)
                    for (int k = 0; k <= d[j] - n; k++)
                        Regalos2[k] = Regalos2[k + n];

                for (int k = 0; k < n; k++)
                    Regalos2[k + n] = Regalos2[k];
            }

            int[] sol = new int[n];
            for (int j = 0; j < n; j++)
                sol[j] = Regalos2[j];

            return sol;
        }
    }
}
