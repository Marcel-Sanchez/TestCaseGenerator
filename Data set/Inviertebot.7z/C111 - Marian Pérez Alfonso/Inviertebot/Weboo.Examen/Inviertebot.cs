﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = new int[n];
            int temp = 0;
            for (int num = 0; num < regalos.Length; num++)
            {
                regalos[num] = num + 1;
            }
            for (int cont = 0; cont < i.Length; cont++)
            {
                temp = regalos[i[cont]];
                regalos[i[cont]] = regalos[d[cont]];
                regalos[d[cont]] = temp;
                int SucesorI = i[cont] + 1;
                int AntecesorD = d[cont] - 1;
                if (SucesorI == n)
                {
                    SucesorI = 0;
                }
                if (AntecesorD == -1)
                {
                    AntecesorD = n - 1;
                }
                if (SucesorI == d[cont] || SucesorI + 1 == d[cont] || i[cont] == d[cont])
                {
                    continue;
                }
                temp = regalos[SucesorI];
                regalos[SucesorI] = regalos[AntecesorD];
                regalos[AntecesorD] = temp;
            }
            return regalos;
        }
    }
}
