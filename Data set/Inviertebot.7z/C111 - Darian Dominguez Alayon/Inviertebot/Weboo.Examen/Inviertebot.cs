﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        static int[] Llenar(int n)
        {
            int[] regalos = new int[n];
            for (int i = 0; i < regalos.Length; i++)
            {
                regalos[i] = regalos.Length - n + 1;
                n--;
            }
            return regalos;
        }
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = Llenar(n);
            for (int t = 0; t < i.Length; t++)
            {
                int posi = i[t];
                int posd = d[t];
                if (posd > posi)
                {
                    while (posi != posd && posd - posi != 1)
                    {
                        int x = 0;
                        x = regalos[posi];
                        regalos[posi] = regalos[posd];
                        regalos[posd] = x;
                        posi++;
                        posd--;
                        if (posi == posd) break;
                   
 }
                }
                else if (posd < posi)
                {
                    while (posi != posd && posd - posi != 1)
                    {
                        if (posi == posd) break;
                        int y = 0;
                        if (posi >= n)
                        {
                            posi = 0;
                            y = regalos[posi];
                            if (posi == posd) break;
                            if (posd < 0)
                            {
                                posd = n-1;
                                y = regalos[posi];
                                regalos[posi] = regalos[posd];
                                regalos[posd] = y;
                                if (posi == posd) break;
                            }
                            else continue;
                        }
                        else
                        {
                            if (posd < 0)
                            {
                                posd = n-1;
                                if (posi == posd) break;
                                y = regalos[posi];
                                regalos[posi] = regalos[posd];
                                regalos[posd] = y;

                                
                                if (posi == posd) break;
                            }
                            else
                            {
                                y = regalos[posi];
                                regalos[posi] = regalos[posd];
                                regalos[posd] = y;

                               
                            }
                        }
                        
                        posi++;
                        posd--;
                        if (posi - posd == 1) break;
                    }

                }
                else
                {
                    regalos[posd] = regalos[posi];
                }
            }
            return regalos;

        }
    }
}
