﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] r = new int[n];
            LlenarArray(r);
            ReordenarArray(r, i, d);

            return r;
        }
        private static void LlenarArray(int[] r)
        {
            for (int j = 0; j < r.Length; j++)
            {
                r[j] = j + 1;
            }
        }
        private static void ReordenarArray(int[] r, int[] i, int[] d)
        {

            for (int k = 0; k < i.Length; k++)
            {
                //int[] a = CrearArrayIgual(r);
                bool z = true;

                int resta = 0;

                if (i[k] - d[k] < 0)
                {
                    resta = (d[k] - i[k]); z = true;
                }
                else
                {
                    resta = (i[k] - d[k]); z = false;
                }

                if (z)
                {
                    for (int p = 0; p < resta; p++)
                    {
                        int[] a = CrearArrayIgual(r);
                        int[] b = CrearArrayIgual(r);

                        int pt = p;
                        int pf = p;

                        if (i[k] + p >= r.Length)
                        {
                            pt = p - r.Length + 1;

                        }
                        if (d[k] - p < 0)
                        {
                            pf = p - r.Length + 1;
                        }
                        if (d[k] == i[k] || d[k] + pf == i[k] + pt) continue;


                        a[i[k] + pt] = r[d[k] - pf];
                        b[d[k] - pf] = r[i[k] + pt];

                        r[i[k] + pt] = a[i[k] + pt];
                        r[d[k] - pf] = b[d[k] - pf];




                    }
                }
                else
                {
                    for (int p = 0; p < resta; p++)
                    {
                        int[] a = CrearArrayIgual(r);
                        int[] b = CrearArrayIgual(r);

                        int pt = p;
                        int pf = p;

                        if (d[k] + p >= r.Length)
                        {
                            pt = p - r.Length + 1;

                        }
                        if (i[k] - p < 0)
                        {
                            pf = p - r.Length + 1;
                        }
                        if (d[k] == i[k] || d[k] + pf == i[k] + pt) continue;


                        a[d[k] + pf] = r[i[k] - pt];
                        b[i[k] - pt] = r[d[k] + pf];

                        r[d[k] + pf] = a[d[k] + pf];
                        r[i[k] - pt] = b[i[k] - pt];
                    }
                }

            }
        }

        private static int[] CrearArrayIgual(int[] r)
        {
            int[] g = new int[r.Length];
            for (int i = 0; i < r.Length; i++)
            {
                g[i] = r[i];
            }
            return g;
        }
       
        
    }
}
