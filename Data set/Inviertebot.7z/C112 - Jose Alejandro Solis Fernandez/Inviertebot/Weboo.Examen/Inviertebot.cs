﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int piv2;
            int pivo = i.Length;
            int[] regalos = new int[n];
            for (int j = n - 1; j >= 0; j--)
                regalos[j] = n--;
            for (int w = 0; w < pivo; w++)
            {
                int num = 0;               
                int pivo1 = i[w];
                piv2 = i[w];
                int pivo2 = d[w];
                int[] help = new int[CuantosEntre(i[w], d[w], regalos.Length)];
                help[help.Length - 1] = regalos[pivo2];
                while (pivo1!=pivo2)
                {
                    help[num] = regalos[pivo1];              
                    pivo1 = (pivo1 + 1) % regalos.Length;
                    num++;
                }
                help=Invierte(help);
                for (int r = 0; r < help.Length; r++)
                {
                    regalos[piv2] = help[r];
                    piv2 = (piv2 + 1) % regalos.Length;
                }
             
            }              
            return regalos;
            
        }
      
       
        static int[] Invierte(int[]a)
        {
            int[] b = new int[a.Length];
            for (int i = 0; i < a.Length; i++)
                b[b.Length - (1 + i)] = a[i];
            return b;
        }

        static int CuantosEntre(int a,int b, int max)
        {
            int count = 1;
            while (a!=b)
            {
                a = (a + 1) % max;
                count++;
            }
            return count;
        }
    }
}
