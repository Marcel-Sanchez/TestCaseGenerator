﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int num = 1;//-------------------------------------------creando el array de posiciones
            int[] pos = new int[n];
            for (int q = 0; q < pos.Length; q++)
            {
                pos[q] = num;
                num++;
            }
            int size = pos.Length;
            int[] result = new int[size];
            Array.Copy(pos, result, size);//--------------------------para copiar las posiciones no invertidas en la 1ra iteracion
            for (int p = 0; p < i.Length; p++)//----------------------buscando las posiciones para los brazos
            {
                int left = i[p];
                int rigth = d[p];
                while (true)//----------------------------------------algoritmo de intercambio
                {
                    if (left == size) left = 0;//----------------------si left se sale del rango del array
                    if (rigth < 0) rigth = size - 1;//-----------------si rigth sale del rango del array
                    result[left] = pos[rigth];
                    result[rigth] = pos[left];
                    if (left == rigth) break;//-----------------------si las posiciones derecha e izquierda son iguales termina la iteracion
                    left += 1;
                    rigth -= 1;
                    if (left - 1 == rigth) break;//-------------------en caso de cruzarse los valores y nunk ser iguales
                    if (left == size && rigth < 0) break;//-----------si posiciones coinciden fuera de los limites del array termia la iteracion
                }
                Array.Copy(result, pos, size);//----------------------copiando las posiciones no invertidas x iteracion
            }
            return result;
        }
    }
}
