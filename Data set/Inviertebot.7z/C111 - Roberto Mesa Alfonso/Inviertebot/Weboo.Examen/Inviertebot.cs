﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] result = { 1, 2, 3, 4, 5, 6 };
            
            return result;
        }   
        
        static int[] Cortado(int[]a, int i, int d) // OK
        {
            int[] result = new int[a.Length];
            return result;
        }

        static int[] Change ( int [] a)
        {
             
            //int temp;
            int[] result = new int[a.Length];
            /*for (int i = 0, j = a.Length-1; i < (a.Length-1)/2; i++, j--)
            {
                temp = result[i];
                result[i] = result[j];
                result[j] = result[i];
            }*/
            return result;
        }

        static int[] Re_Escritura(int[] a, int n)
        {
            int[] result = new int[a.Length];
            int temp;
            int j = n;
            int k = n;
            int i = 0;
            while (k !=0)
            {
                temp = result[n];
                result[n] = result[i];
                result[i] = temp;
                if (i == 0)
                {
                    i = a.Length-1;
                }
                if(j == 0)
                {
                    j = a.Length-1;
                }
                i--;
                j--;
                
            }
            return result;
            
        }
        
        
        
        

        

        
    }
}
