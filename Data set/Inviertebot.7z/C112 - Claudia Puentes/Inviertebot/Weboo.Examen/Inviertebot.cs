﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] PosFinal = new int[n];
            int regalo = 1;
            int pos = 0;
            int pos1 = 0;
            int cont1 = 0;
            int cont2 = 0;

            int[] a = new int[PosFinal.Length];
            int[] b = new int[PosFinal.Length];



            for (int j = 0; j < PosFinal.Length; j++)
            {
                PosFinal[j] = regalo;
                regalo++;
            }

            for (int k = 0; k < i.Length; k++)
            {
                pos = i[k];
                pos1 = d[k];

                if (pos > 0 || pos < (PosFinal.Length - 2) && pos1 > 0 || pos1 < (PosFinal.Length - 2))
                {
                    int pos2 = pos + 1;
                    int pos3 = pos1 - 1;
                    if (pos2 > PosFinal.Length - 1 || pos2 < 0)
                    {
                        pos2 = pos;
                    }
                    if (pos3 > PosFinal.Length - 1 || pos3 < 0)
                    {
                        pos3 = pos1;
                    }
                    b[k] = PosFinal[pos2];
                    PosFinal[pos2] = PosFinal[pos3];
                    PosFinal[pos3] = b[k];
                }

                a[k] = PosFinal[pos];
                PosFinal[pos] = PosFinal[pos1];
                PosFinal[pos1] = a[k];

            }

            return PosFinal;
        }
    }
}
