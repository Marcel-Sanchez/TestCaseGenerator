﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = new int[n];
            int aux1 = 0;
            int aux2 = 0;
            for (int j = 0, k = 1; j < n; j++, k++)
            {
                regalos[j] = k;
            }

            for (int k = 0; k < i.Length; k++)
            {
                aux1 = i[k];
                aux2 = d[k];
                Swapextrano(regalos, aux1, aux2);
            }
            return regalos;
        }
        public static void Swapextrano(int[] array,int n1,int n2)
        {
            if (array.Length - n1 + n2 <3)
            {
                int temp = array[n1];
                array[n1] = array[n2];
                array[n2] = temp;
            }
            else
            {
                int cant = array.Length - n1;
                int num1 = array[n1];
                int num2 = array[n2];
                Rotarderecha(array, cant);
                for(int i = Array.IndexOf(array, num1), j = Array.IndexOf(array, num2); i < j && j > i; i++, j--)
                {
                    swap(array, i, j);
                }
                Rotarizquierda(array, cant);
            }
        }
        public static void Rotarderecha(int[] a,int cant)
        {
            while (cant > 0)
            {
                for (int i = 0; i < a.Length; i++)
                {
                    swap(a, i, a.Length - 1 - i);
                    swap(a, a.Length - 1, i);
                    cant--;
                }
                
            }
        }

        public static void Rotarizquierda(int[]a,int cant)
        {
            while (cant > 0)
            {
                for (int i = a.Length -1; i >= 0; i--)
                {
                    swap(a, i, a.Length - 1 - i);
                    swap(a, a.Length - 1, i);
                    cant--;
                }
                
            }
        }

        public static void swap(int[]a,int i,int j)
        {
            int temp = a[i];
            a[i] = a[j];
            a[j] =  temp;
        }
    }
}
