﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] result = new int[n];
            for (int z = 0; z < n; z++) // para crear el arreglo
                result[z] = z + 1;

            for (int k = 0; k < i.Length; k++) // iterador de las posiciones de los extremos
            {
                int x = i[k], y = d[k]; // x --> brazo izkierdo // y --> brazo derecho
                if (x > y)
                {
                    while (true)
                    {
                        int temp = result[x];
                        result[x] = result[y];
                        result[y] = temp;
                        x++;
                        y--;
                        if (x > (n - 1))
                        {
                            x = 0;
                            break;
                        }
                        if (y < 0)
                        {
                            y = (n - 1);
                            break;
                        }
                    }
                }
                    while (y > x)
                    {
                        int temp = result[x];
                        result[x] = result[y];
                        result[y] = temp;
                        x++;
                        y--;
                    }
            }
            return result;
        }
    }
}
