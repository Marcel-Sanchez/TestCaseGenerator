﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] a = new int[n];
            
            for (int k = 0, primer = 1; k < n; k++, primer++)
            {
                a[k] = primer;
            }
            int[] c = CambiaRegalos(a, i, d);
            return c;
            
        }  
        
        public static int[] CambiaRegalos(int [] a, int[] i, int [] d)
        {
            int temp = 0;
            bool [] yafuiste = new bool[a.Length];
            for (int k = 0; k < i.Length; k++, temp = 0)
            {
                int n = i[k];
                int m = d[k];
                do
                {
                    
                    temp =a[n];
                    a[n] = a[m];
                    a[m] = temp;
                   
                    if (n == a.Length -1)
                        n = 0;
                    else
                    {
                        n++;
                    }
                    if (m == 0)
                        m = a.Length -1;
                    else
                    {
                        m--;
                    }
                    yafuiste[n] = true;
                    yafuiste[m] = true;

                } while (yafuiste[n] == false);

            }
            
              
            for (int p = 0; p < yafuiste.Length ; p++)
            {
                yafuiste[p] = false;
            }

                
                
            
                return a;
            }
        }
}




 
    
