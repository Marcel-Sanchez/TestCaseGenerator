﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        

        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {

            int[] regalos = new int[n];
            int size = i.Length;

            for (int a = 0; a < n; a++)
            {
                regalos[a] = a + 1;
            }


            for (int b = 0; b < size; b++)
            {
                if (i[b] == d[b])
                {
                    continue;
                }


                int [] changed = ShufleArray ( GetArrayToUse (n,i[b], d[b], regalos) );

                int x = i[b];

                for (int c = 0, e = 0; c < changed.Length; c++)
                {
                    if ((x + e) >= regalos.Length)
                    {
                        x = 0;
                        e = 0;
                    }

                    regalos[x + e] = changed[c];                   

                    e++;
                }              
            }

            return regalos;
        }

        static int[] GetArrayToUse(int n, int start, int end, int [] regalos)
        {
            int length = 0;
            if (start>end)
             length = (n - start + end + 1);

            if (start<end)
                length = (end - start + 1);

            int[] changeable = new int[length];

            for (int i = start, j = 0; j < length ; j++)
            {
                changeable[j] = regalos[i];

                if  ( (i+1) >= regalos.Length)
                    i = 0;
            
                else
                    i++;   
            }

            return changeable;
                   
        }

        static int[] ShufleArray (int [] cambiables)
        {
            int length = (cambiables.Length / 2);
            int max = cambiables.Length - 1;
   

            for (int i = 0; i < (cambiables.Length / 2); i++)
            {
                int temp = 0;
                temp = cambiables[i];
                cambiables[i] = cambiables[max - i];
                cambiables[max - i] = temp;
            }

            return cambiables;

        }

        
    }
}
