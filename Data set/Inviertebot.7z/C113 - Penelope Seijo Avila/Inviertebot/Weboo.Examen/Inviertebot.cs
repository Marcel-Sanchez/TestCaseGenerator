﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = new int[n];
            int[] devolver = new int[n];
            int s = 0;
            int l = 1;
            int k = 0;
            int o = 0;
            int t = 0;
            int q = 0;
            int h = 0;
           

            for (s = 0, l = 1; (s < n) && (l <= n); s++, l++)
            {
                regalos[s] = l;
            }
            for (k = 0; k < i.Length; k++)
            {
                o = i[k];
                t = d[k];
                if (o < t)

                {
                    for (o = i[k], t = d[k]; (o <= (d[k] / 2)) && (t >= (d[k] / 2)); o++, t--)

                    {
                        int w = regalos[o];
                        regalos[o] = regalos[t];
                        regalos[t] = w;

                    }
                }
                else
                if (o == t)
                    regalos[o] = regalos[t];

                else
                if (o > t)
                {
                    for (o = i[k], t = d[k]; o < (regalos.Length) && (t >= 0); o++, t--)
                    {
                        int p = regalos[o];
                        regalos[o] = regalos[t];
                        regalos[t] = p;
                        regalos[n - 1] = regalos[n - 1];
                        regalos[0] = regalos[0];
                    } }

                //if ((t == 0)
                //{
                //    int z = regalos[o];
                //    regalos[o] = regalos[t];
                //    regalos[t] = regalos[o];
                //    for (h = (o + 1), q = (n - 1); (h <= ((n - 1) + (o + 1)) / 2) && (k >= ((n - 1) + (o + 1)) / 2); h++, q--)
                //    {
                //        int g = regalos[h];
                //        regalos[h] = regalos[q];
                //        regalos[q] = g;
                //    }

                //}
                //if ((o == 0)) 
                //{
                //    int j = regalos[o];
                //    regalos[o] = regalos[t];
                //    regalos[t] = regalos[o];
                //    for (h = (t - 1), q = 0; (h <= ((t - 1) + 0) / 2) && (k >= ((t - 1) + (o) / 2)); h--, q++)
                //    {
                //        int a = regalos[h];
                //        regalos[h] = regalos[q];
                //        regalos[q] = a;
                //    }

              //  }




            }
            for (q = 0; q < regalos.Length; q++)
            {
                devolver[q] = regalos[q];

            }
            return devolver;





        }
    }
}
