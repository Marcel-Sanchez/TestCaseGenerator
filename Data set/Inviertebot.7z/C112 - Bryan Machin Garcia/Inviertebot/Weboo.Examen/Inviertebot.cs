﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = new int[n];
            int cont = 1;
            for (int a = 0; a < n; a++)
            {
                regalos[a] = cont;
                cont++;
            }

            for (int x = 0; x < i.Length; x++)
            {
                int z = 0;
                int Icont = 0;
                int Dcont = 0;
                
                for (int y = 0; y < regalos.Length; y++)
                {
                    
                    int difh = (d[x] - i[x]) / 2;


                    if (regalos[i[x] + y] > regalos.Length && regalos[d[x] - y] < 0)
                    {
                        Icont++;
                        Dcont++;
                        z = regalos[Icont];
                        regalos[Icont] = regalos[regalos.Length - Dcont];
                        regalos[regalos.Length - Dcont] = z;
                    }
                    else if (regalos[i[x] + y] > regalos.Length)
                    {
                        Icont++;
                        z = regalos[Icont];
                        regalos[Icont] = regalos[d[x] - y];
                        regalos[d[x] - y] = z;
                    }
                    else if (regalos[d[x] - y] < 0)
                    {
                        Dcont++;
                        z = regalos[i[x] + y];
                        regalos[i[x] + y] = regalos[regalos.Length - Dcont];
                        regalos[regalos.Length - Dcont] = z;
                    }
                    else if (!(regalos[i[x] + y] > regalos.Length) && !(regalos[d[x] - y] < 0) && !(regalos[i[x] + y] > regalos.Length && regalos[d[x] - y] < 0))
                    {
                        z = regalos[i[x] + y];
                        regalos[i[x] + y] = regalos[d[x] - y];
                        regalos[d[x] - y] = z;
                    }

                    if (i[x] < d[x] && difh == y + 1)
                    {
                        Icont = 0;
                        Dcont = 0;
                        break; }
                    if (i[x] > d[x] && regalos.Length - i[x] == y + 1)
                    {
                        Icont = 0;
                        Dcont = 0;
                        break; }
                }
                  
            }
            return regalos;

        }
    }
  }

