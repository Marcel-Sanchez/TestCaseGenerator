﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] gifts = new int[n];
            for (int p = 0; p < n; p++)
            {
                gifts[p] = p + 1;
            }

            for (int p = 0; p < i.Length; p++)
            {
                int len = ((d[p] - i[p] + n) % n) / 2;
                for (int l = i[p], r = d[p]; len >= 0; len--)
                {
                    int tmp = gifts[l];
                    gifts[l] = gifts[r];
                    gifts[r] = tmp;

                    l = (l + 1) % n;
                    r = (r - 1 + n) % n;
                }
            }

            return gifts;
        }
    }
}
