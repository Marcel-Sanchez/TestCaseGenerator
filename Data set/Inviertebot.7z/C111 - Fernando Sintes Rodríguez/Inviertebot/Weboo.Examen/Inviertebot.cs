﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] a = new int[n];
            int k = i.Length;
            k = d.Length;
            i = new int[k];
            d = new int[k];
            n(n >= 0);

            i[k] >= 0 && i[k] < n);
            d[k] >= 0 && d[k] < n);
           
            if d(k = 0, k < n, k++)==i(k = 0, k < n, k++){


                



            }

            int[] reg =[i, d];






            

        }
    }
}
