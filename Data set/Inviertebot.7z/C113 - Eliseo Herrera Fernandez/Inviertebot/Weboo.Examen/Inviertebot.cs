﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] tempi = { 0 };
            int posini = 0;
            int posifinal = 0;
            int[] regalos = new int[n];
            //Enumera los regalos
            for (int x = 0; x < regalos.Length; x++)
                regalos[x] = x + 1;
            //Recorre i y d
            for (int k = 0; k < i.Length; k++)
            {
                for (int h = 0; h < regalos.Length; h++)
                {
                    if (regalos[h] == (i[k] + 1))
                        posini = h;
                    if (regalos[h] == (d[k] + 1))
                        posifinal = h;
                }
                int cont = 1;
                //Establece un array con el tamano del intervalo
                if ((i[k] - d[k]) == 0)
                    continue;
                if (i[k] < d[k])
                {
                    tempi = new int[(d[k] - i[k]) + 1];
                }
                else
                {//Saca las posiciones                    
                    for (int x = posini; x != posifinal; x++)
                    {
                        cont++;
                        if (x == regalos.Length - 1)
                            x = -1;
                    }
                    tempi = new int[cont];
                }
                //asigna valores al nuevo array
                for (int pi = posini, pf = posifinal, c = 0; pi != pf; c++, pi++)
                {
                    tempi[c] = regalos[pi];
                    if (pi == regalos.Length - 1)
                        pi = -1;
                }
                tempi[tempi.Length - 1] = regalos[posifinal];

                //Invierte tempi
                int[] t = new int[tempi.Length];

                for (int q = 0, w = (tempi.Length - 1); q < tempi.Length; q++, w--)
                    t[w] = tempi[q];

                for (int p = 0; p < t.Length; p++)
                    tempi[p] = t[p];

                //Volver a poner el fragmento ya invertido
                for (int pi = posini, pf = posifinal, c = 0; pi != pf; pi++, c++)
                {
                    regalos[pi] = tempi[c];
                    if (pi == regalos.Length - 1)
                        pi = -1;
                }
                regalos[posifinal] = tempi[tempi.Length - 1];
            }
            return regalos;
        }
    }
}
