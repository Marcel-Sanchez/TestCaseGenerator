﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = new int[ n ];
            int[] regalos1 = ArrayRegalos(regalos);
            int[] regalos2 = Cambioenregalos(regalos1, i, d);
            return regalos2;
        }
        public static int[] ArrayRegalos(int[] regalos)
        {
            for (int i = 1; i <= regalos.Length; i++)
            {
                regalos[i-1] = i;
            }
            return regalos;
        }
        public static int[] Cambioenregalos(int[] regalos1, int[] i, int[] d)
        {
            int ni = 0;
            int nd = 0;
           
            for (int j = 0; j < i.Length; j++)
            {
               
                ni = i[j];
                nd = d[j];
                int temp = regalos1[nd];
                regalos1[nd ] =regalos1[ni];
                regalos1[ni] = temp;
                int mayor = Math.Max(nd,ni);
        //        if (ni + 1 != nd - 1)
        //        {
        //            for (int q = 0; q < mayor; q++)
        //            {
        //                if (ni != regalos1.Length)
        //                {
        //                    if (regalos1[nd - 1 - q] != regalos1[ni + 1 + q])
        //                    {
        //                        int temp2 = regalos1[nd - 1 - q];
        //                        regalos1[nd - 1 - q] = regalos1[ni + 1 + q];
        //                        regalos1[ni + 1 + q] = temp2;
        //                    }
        //                }

        //            }



        //}
        


            }
            return regalos1;
        }

    }
}
