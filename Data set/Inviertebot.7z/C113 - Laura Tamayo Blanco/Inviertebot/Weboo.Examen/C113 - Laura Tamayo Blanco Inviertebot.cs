﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = new int[n];
            int[] copia = new int[n];
           
            for (int j = 0; j < regalos.Length; j++)//Rellenando el array de regalos
            {
                regalos[j] = j + 1;
                copia[j] = j + 1;
               
            }
            for (int k = 0; k < i.Length; k++)
            {
                int p1 = i[k];
                int p2 = d[k];               
                int posinicio = i[k];
                int posfinal = d[k];
                //funciona con ejemplos 2,4,5
                int j = d[k];

           
                //int j = Math.Max(p1, p2);
                // Funciona con los ejemplos 2,4

                do
                {
                    
                   
                    int temp = regalos[posfinal];
                    regalos[posfinal] = regalos[posinicio];
                    regalos[posinicio] = temp;
                    if (posinicio == regalos.Length - 1)
                        posinicio = 0;
                    else
                        posinicio++;

                    if (posfinal == 0)
                        posfinal = regalos.Length - 1;
                    else
                        posfinal--;
                    

                    j--;
                }
                //funciona con ejemplos 2,4,5
                while (j <= p1 && j > p2);
                
                //Para el caso de que ya se hallan intercambiado 2 valores no es necesario volverlos a cambiar. No me dio tiempo a implementar la condicion.
               
             
                
                
                           }
            return regalos;
    
        }
        public static bool cambiado(int []copia, int[] rergalos,int pos ) 
        {
            if (copia[pos] == rergalos[pos])
                return false;
            else
                return true;
            
        }
    }
}
