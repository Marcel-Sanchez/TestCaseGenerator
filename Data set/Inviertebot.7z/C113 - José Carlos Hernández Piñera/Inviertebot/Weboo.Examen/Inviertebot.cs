﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] result = new int[n];

            for (int k = 0; k < result.Length; k++)
                result[k] = k + 1;

            for (int dd = 0; dd < i.Length; dd++)
            {
                int indexI = i[dd];
                int indexD = d[dd];

                Swap(indexI, indexD, result);
            }
            return result;
        }

        static void Swap(int indexI, int indexD, int[] result)
        {
            int[] temp = new int[2 * result.Length];

            int k = 0;
            for (int i = indexI; ; i = (i + 1) % result.Length, k++)
            {
                temp[k] = result[i];
                if (i == indexD) break;
            }

            for (int i = indexI; ; i = (i + 1) % result.Length, k--)
            {
                result[i] = temp[k];
                if (i == indexD) break;
            }
        }
    }
}
