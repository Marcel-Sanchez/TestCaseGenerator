﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = CrearArrayRegalos(n);
            for (int j = 0; j < i.Length; j++)
            {
                RotarEnIntervalos(regalos, i[j], d[j]);
            }
            return regalos;
        }

        public static int[] CrearArrayRegalos(int n)
        {
            int[] regalos = new int[n];
            for (int i = 0; i < regalos.Length; i++)
            {
                regalos[i] = i + 1;
            }
            return regalos;
        }

        public static void RotarEnIntervalos(int[] regalos, int pos1, int pos2)
        {
            int contador = 0;
            for (int i = pos1; i != pos2; i++)
            {
                if (i == regalos.Length)
                {
                    i = -1;
                }
                contador++;
            }

            int cantRotaciones = contador / 2;
            if (contador>0&&cantRotaciones==0)
            {
                cantRotaciones = 1;
            }
          

            for (int i = pos1, j = pos2, k= cantRotaciones; k!= 0; i++,j--,k--)
            {
                if (i==regalos.Length)
                {
                    i = 0;
                    if (i==j)
                    {
                        break;
                    }
                }
                if (j<0)
                {
                    j = regalos.Length - 1;
                    if (i == j)
                    {
                        break;
                    }
                }
                int temp = regalos[i];
                regalos[i] = regalos[j];
                regalos[j] = temp;
            }

        }
         

    }
}
