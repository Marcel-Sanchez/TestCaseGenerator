﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] posFinal = new int[n];
            
            //Para que los regalos queden ordenados de 1 a n
            int primeraPos = 1;
            for (int p = 0; p < n; p++)
            {
                posFinal[p] = primeraPos;
                primeraPos++;
            }

            //Para intercambiar
            for (int k = 0; k < i.Length ; k++)
            {
                int temp1 = posFinal[i[k]];
                posFinal[i[k]] = posFinal[d[k]];
                posFinal[d[k]] = temp1;
                
            }
            
            return posFinal;
        }

    }
}
