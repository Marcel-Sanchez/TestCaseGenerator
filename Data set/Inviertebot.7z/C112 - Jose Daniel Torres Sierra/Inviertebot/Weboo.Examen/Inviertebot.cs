﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] a = new int[n];
            for (int j = 1; j==n; j++)
            {
                for (int e = 0; e <a.Length; e++)
                {
                    a[e] = j;
                }
            }
            int[] b = new int[a.Length];
            for (int r = 0; r <b.Length; r++)
            {
                for (int t = 0; t <i.Length ; t++)
                {
                    for (int y = 0; y < d.Length; y++)
                    {
                        b[r] =(d[y] = i[t]);
                    }
                }
            }
            return b; 
        }    
     }
 }

