﻿using System.Collections.Generic;
///// C113.Rodovaldo González Morejón;
namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] gifts = Fill(n);

            for (int j = 0; j < i.Length; j++)
                gifts = Invert(gifts, i[j], d[j]);

            return gifts;
        }
        private static int[] Fill(int n)
        {
            int[] result = new int[n];

            for (int i = 0; i < n; i++)
                result[i] = i + 1;

            return result;
        }
        private static int[] Invert(int[] gifts, int start, int end)
        {
            Stack<int> elements = new Stack<int>();

            if (end >= start)
            {
                for (int i = start; i <= end; i++)
                    elements.Push(gifts[i]);

                for (int i = start; i <= end; i++)
                    gifts[i] = elements.Pop();
            }
            else
            {
                for (int i = start; i < gifts.Length; i++)
                    elements.Push(gifts[i]);

                for (int i = 0; i <= end; i++)
                    elements.Push(gifts[i]);

                for (int i = start; i < gifts.Length; i++)
                    gifts[i] = elements.Pop();

                for (int i = 0; i <= end; i++)
                    gifts[i] = elements.Pop();
            }
            return gifts;
        }
    }
}
