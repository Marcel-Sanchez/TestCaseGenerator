﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] result = new int[n];
            for (int k = 0,l=1; k < result.Length && l <= n; k++,l++)
            {
                result[k] = l;
            }

            for (int k = 0; k< i.Length;k++)
            {
                int b = i.Length;
                if (i.Length < i.Max())
                    b = i.Max();
                int iz = i[k];
                int de = d[k];
                while (iz > result.Length - 1)
                    iz = iz - result.Length - 1;
                while (de > result.Length - 1)
                    de = de - result.Length - 1;
                
                for (int m = iz, o= de,count=1; count <b/2; m++,o--,count ++)
                {
                 
                    if (m == result.Length - 1 && o == 0)
                    {
                        o = m;
                        m = 0;
                        
                    }
                   if (o ==0 && m!=result.Length-1)
                        {
                        int y = result[o];
                        result[o] = result[m];
                        result[m] = y;
                        m++;
                        o = result.Length - 1;
                        count++;
                        }


                    if (m == result.Length - 1 && o != 0) 
                    {
                        int Y = result[m];
                        result[m] = result[o];
                        result[o] = Y;
                        m = 0;
                        o--;
                        count++;
                        if (count == i.Length / 2)
                            break;
                    }
                    ////{if (m == 0)
                    ////    //{
                    ////    //    o = result.Length - 2;
                    ////    //    m = 1;
                    ////    //}

                    //////    //else
                    //        o = result.Length - 1;
                    
                    int f = result[iz];
                    result[iz] = result[de];
                    result[de] = f;
                }
            }
            return result;
        }
    }
}
