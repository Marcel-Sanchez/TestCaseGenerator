﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = new int[n];
            for (int j = 0; j < n; j++)
            {
                regalos[j] = j + 1;
            }

            for (int j = 0; j < i.Length; j++)
            {
                Rotar(regalos, i[j], d[j]);
            }
            return regalos;
        }
         private static void Rotar(int[] regalos, int i, int d)
         {
             int x = regalos[i];
             regalos[i] = regalos[d];
             regalos[d] = x;

             while ( i!=d && (i+1 != d && (i != regalos.Length - 1 || d != 0 )))
             {

                 if (i == regalos.Length - 1)
                     i = 0;
                 else
                     i += 1;

                 if (d == 0)
                     d = regalos.Length - 1;
                 else
                     d -= 1;

                 x = regalos[i];
                 regalos[i] = regalos[d];
                 regalos[d] = x;
             }
        }

            
     
    }
}
