﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        static int[] Regalos(int n)
        {
            int[] regalos = new int[n];
            int j = 1;
            for (int m = 0; m < regalos.Length; m++)
            {
                regalos[m] = j;
                j++;
            }
            return regalos;
        }

        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int regalito;
         //int posicion1 ;
         // int  posicion2 ;
            int[] regalos = new int[n];
            regalos = Regalos(n);
            //for (int x = 0; x < regalos.Length; x++)
            //{
            //    regalos[x] = Regalos(n)[x];
            //}
            for (int k =0; k<d.Length; k++)
            {  
                
                //posicion1 = d[k];
                //posicion2 = i[k];
                 regalito = regalos[d[k]];
                //if (posicion1 == posicion2)
                    //regalos[d[k]] = regalos[i[k]];
                //else
                //{
                    regalos[d[k]] = regalos[i[k]];
                    regalos[i[k]] = regalito;
                    regalito = 0;
                    //posicion1 = 0;
                    //posicion2 = 0;
                //}
            }
            return regalos;
        }

    }
}
