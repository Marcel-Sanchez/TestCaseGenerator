﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {

            int[] orden_inicial = new int[n];

            for (int j = 0; j < orden_inicial.Length; j++)
            {
                orden_inicial[j] = (j + 1);
            }



            for (int l = 0; l < i.Length; l++)




            {
                int de_i = 0;
                int de_d = 0;
                int temp = 0;
                int temp1 = 0;


                de_i = i[l];
                de_d = d[l];
                if (Math.Abs(de_i - de_d) >= 2)
                {
                    for (int o = 0; o < orden_inicial.Length; o++)
                    {


                        int resta = Math.Abs(de_i - de_d);
                        orden_inicial[(o+resta)%orden_inicial.Length] = orden_inicial[];


                    }


                }
                else

                {
                    temp = orden_inicial[de_i];

                    temp1 = orden_inicial[de_d];



                    orden_inicial[de_d] = temp;
                    orden_inicial[de_i] = temp1;
                }
            }

            return orden_inicial;

        }
    }
}

