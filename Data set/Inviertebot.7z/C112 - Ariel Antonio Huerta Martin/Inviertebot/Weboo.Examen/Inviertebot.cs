﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] gift = new int[n];
            for (int j = 0; j < n; j++)
            {
                gift[j] = j + 1;
            }

            for (int k = 0; k < i.Length; k++)
            {
                gift = Invierte(gift, i[k], d[k]);   
            }
            return gift;
        }

        private static int[] Invierte(int [] gift , int i, int d)
        {
            if (i == d)
            {
                return gift;
            }

            else if (i > d)
            {
                while (i <= gift.Length - 1 && d >= 0)
                {

                    int temp = 0;

                    if (i == gift.Length - 1 && d == 0)
                    {
                        temp = gift[i];
                        gift[i] = gift[d];
                        gift[d] = temp;
                        return gift;

                    }
                    else if (i == gift.Length - 1)
                    {
                        temp = gift[i];
                        gift[i] = gift[d];
                        gift[d] = temp;
                        d = d - 1;

                        for (int j = 0; j <= d; j++)
                        {
                            temp = gift[j];
                            gift[j] = gift[d];
                            gift[d] = temp;
                            d =  d - 1;
                        } return gift;


                    }

                    else if (d == 0)
                    {
                        temp = gift[d];
                        gift[d] = gift[i];
                        gift[i] = temp;
                        i = i + 1;

                        for (int j = gift.Length - 1; j >= i; j--)
                        {
                             temp = gift[j];
                            gift[j] = gift[i];
                            gift[i] = temp;
                            i++;
                        } return gift;
                    }
                        temp = gift[i];
                        gift[i] = gift[d];
                        gift[d] = temp;
                        i++;
                        d--;

                    
                } return gift;

            }

           
             if ((d - i) % 2 == 0)
             {
                 while (i < (d + i) / 2 && d > (d + i) / 2)
                 {
                     int temp = gift[i];
                     gift[i] = gift[d];
                     gift[d] = temp;
                     i = i + 1;
                     d = d - 1;
                 } return gift;
             }

             while (i <= (d + i) / 2 && d >= (d + i) / 2)
             {
                 int temp = gift[i];
                 gift[i] = gift[d];
                 gift[d] = temp;
                 i = i + 1;
                 d = d - 1;
             } return gift;
               

            }
                
               
            

        }
    }

