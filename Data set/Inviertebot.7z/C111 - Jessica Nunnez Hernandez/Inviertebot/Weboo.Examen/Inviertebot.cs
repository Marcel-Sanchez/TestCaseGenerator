﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = new int[n];
            for (int p = 0; p < regalos.Length; p++)
            {
                regalos[p] = p + 1;
            }   
                             
            int a = 0;
            int b = 0;
            for (int k = 0; k < i.Length; k++)
            {
                a = i[k];
                b = d[k];
                Invertir(a, b, regalos);                                          
                              
            }
            return regalos;
                           
        }
        public static void Invertir (int a,int b, int[] regalos)
        {
            int temp = regalos[b];
            regalos[b] = regalos[a];
            regalos[a] = temp;
        }
        
        
    }
}
