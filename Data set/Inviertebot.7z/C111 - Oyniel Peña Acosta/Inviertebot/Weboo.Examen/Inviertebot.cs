﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] a = new int[n];
            for (int j = 0; j < a.Length; j++)
            {
                a[j] = j + 1;
            }
            for (int j = 0; j < i.Length; j++)
            {
                a = Invertir(a[3], a[5], a);
            } return a;

        }
        public static int[] Invertir(int a, int b, int[] n)
        {    
           int x=0;
            int temp;
         if(a<b)
             x=a-b;
         else
             x=b-a;
            
            for (int i = 0; i < x ; i++) 
            {
                temp = n[a];
               n[ a] = b;
                n[b] = temp;

            } return n;
            
           }
    }


}


