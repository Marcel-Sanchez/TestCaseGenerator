﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] robot = new int[n];
            for (int r = 0; r < robot.Length; r++)
            {
                robot[r] = r + 1;
            }
            for (int k = 0; k < i.Length && k < d.Length; k++)
            {
                for (int z = 0; z < robot.Length; z++)
                {
                    if (i[k] != d[k])
                    {
                        if (Es_Valido(robot) == true)
                        {
                            if (robot[z] < 0)
                            {
                                k = robot.Length;
                                int temp = robot[i[k]];
                                robot[i[k]] = robot[d[k]];
                                robot[d[k]] = temp;
                                i[k]++;
                                d[k]--;
                            }
                            if (robot[z] >= robot.Length)
                            {
                                k = 0;
                                int temp = robot[i[k]];
                                robot[i[k]] = robot[d[k]];
                                robot[d[k]] = temp;
                                i[k]++;
                                d[k]--;
                            }
                        }

                        if (Es_Valido(robot) == false)
                        {
                            if (robot[z] < 0)
                            {
                                k = robot.Length;
                                int temp = robot[i[k]];
                                robot[i[k]] = robot[d[k]];
                                robot[d[k]] = temp;
                                i[k]++;
                                d[k]--;
                            }
                            if (robot[z] >= robot.Length)
                            {
                                k = 0;
                                int temp = robot[i[k]];
                                robot[i[k]] = robot[d[k]];
                                robot[d[k]] = temp;
                                i[k]++;
                                d[k]--;
                            }
                        }
                    }
                }
            }
            return robot;
        }
        public static bool Es_Valido(int[] robot)
        {
            for (int i = 0; i < robot.Length; i++)
            {
                if (robot[i] >= 0 && robot[i] <= robot.Length) return true;
            }
            return false;
        }
    }
}
