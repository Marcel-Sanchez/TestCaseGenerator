﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] ordenado = new int[n];
            for (int l = 0, r = 1; l < ordenado.Length; l++, r++)
                ordenado[l] = r;
            for (int k = 0; k < i.Length; k++)
            {
                if (d[k] == i[k]) continue;
                int m = 0;
                if (d[k] > i[k])
                    m = (d[k] - i[k] + 1) / 2;
                else
                    m = (ordenado.Length - i[k] + d[k] + 1) / 2;
                for (int j = 0; j < m; j++)
                {
                    int temp = ordenado[(i[k] + j) % ordenado.Length];
                    ordenado[(i[k] + j) % ordenado.Length] = ordenado[Math.Abs(ordenado.Length - j + d[k]) % ordenado.Length];
                    ordenado[Math.Abs(ordenado.Length - j + d[k]) % ordenado.Length] = temp;
                }
            }
            return ordenado;
        }
    }
}
