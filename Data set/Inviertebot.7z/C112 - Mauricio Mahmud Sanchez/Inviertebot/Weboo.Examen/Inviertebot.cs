﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = new int[n];
            EnumerarRegalos(regalos);

            for (int k = 0; k < i.Length; k++)
            {
                int I = i[k];
                int D = d[k];
                bool SeCruzaron = false;

                while (I != D ) 
                {
                    if (SeCruzaron && I >= D)
                        break;
                    int temp = regalos[I];
                        regalos[I] = regalos[D];
                        regalos[D] = temp;
                    
                    I++;
                    if (I == D) break;
                    D--;

                    if (I == regalos.Length)
                    {
                        I = 0;
                        SeCruzaron = true;
                    }
                    else if (D == -1)
                    {
                        D = regalos.Length - 1;
                        SeCruzaron = true;
                    }
                }
            }
            return regalos;
        }

        static void EnumerarRegalos(int[] regalos)
        {
            for (int i = 1; i <= regalos.Length; i++)
            {
                regalos[i-1] = i;
            }
        }
    }
}
