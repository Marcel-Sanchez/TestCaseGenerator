﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {

        public static void Invertir(int a, int b, int[] x)
        {
            int sz = x.Length;
            while(a != b)
            {
                /// swap
                int c = x[a];
                x[a] = x[b];
                x[b] = c;
                ///

                a++;
                if (a == sz) a = 0;
                if (a == b) return;

                b--;
                if (b == -1) b = sz - 1;
            }
        }

        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] arr = new int[n];
            for (int it = 0; it < n; it++)
                arr[it] = it + 1;

            for(int it = 0;it < i.Length; it++)
            {
                Invertir(i[it], d[it], arr);
            }
            return arr;
        }
    }
}
