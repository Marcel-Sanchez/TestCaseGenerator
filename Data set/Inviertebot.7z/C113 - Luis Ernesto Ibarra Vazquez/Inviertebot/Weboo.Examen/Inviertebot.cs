﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] PonerNumeros(int n)
        {
            int[] Regalos = new int[n];
            for (int i = 0; i < Regalos.Length; i++)
            {
                Regalos[i] = i + 1;
            }
            return Regalos;
        }
        public static void Reverse(int[] Regalos,int posIni, int posFin)
        {
            bool Primera = false;
            for (int i = posIni, k = posFin; i != k ; i++, k--)
            {
                if ((Primera && k == i - 1)) break;
                Primera = true;
                int temp;
                if (i == Regalos.Length)
                {
                    i = -1; // para que me empieze el array desed el principio
                    k++; // para que se acomode;
                    continue;
                }
                if (k == -1)
                {
                    k = Regalos.Length; // para hacer que empiece desde el final
                    i--; // para que se acomode
                    continue;
                }
                temp = Regalos[i];
                Regalos[i] = Regalos[k];
                Regalos[k] = temp;
                if (i == k - 1) break;
            }
        }
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] Regalos = PonerNumeros(n);
            for (int recorr = 0; recorr < i.Length; recorr++)
            {
                int posInic = i[recorr];
                int posFin = d[recorr];
                Reverse(Regalos, posInic, posFin);
            }
            return Regalos;
        }
    }
}
