﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            //return new int[] { };
            int[] k = new int[n];
            int t = 1;

            for (int m = 0; m < k.Length; m++)
            {
                k[m] = t;
                t++;
            }
            for (int r = 0; r < k.Length; r++)
            {
                k[i[r]] = k[d[r]];
                    i[r]++;
                    d[r]--;
                    if (i[r] > k.Length)
                    {
                        i[r] -= k.Length;
                    }
                    if (d[r] < 0)
                    {
                        d[r] += k.Length;
                    }
            }
            return k;
        }
    }
}

