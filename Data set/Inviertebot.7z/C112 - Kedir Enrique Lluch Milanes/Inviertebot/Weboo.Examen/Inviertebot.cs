﻿/* 
BY Kedir Enrique Lluch Milanes
Grupo: C-112
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] L, int[] R)
        {
            int[] A = new int[n];
            for (int j = 0, cont = 1; j < n; cont++, j++) A[j] = cont;

            for(int T = 0; T < L.Length; T++)
            {
                int i = L[T], j = R[T];
                while (true)
                {
                    if (i == j) break;

                    A[i] = A[i] + A[j];
                    A[j] = A[i] - A[j];
                    A[i] = A[i] - A[j];

                    if (j - i == 1 || (i == n - 1 && j == 0)) break;

                    i++; j--;
                    if (i == n) i = 0;
                    if (j == -1) j = n - 1;
                }
            }
            return A;
        }
    }
}
