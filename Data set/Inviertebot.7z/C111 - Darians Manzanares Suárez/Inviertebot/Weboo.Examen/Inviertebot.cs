﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = new int[n];
            for (int j = 0; j < regalos.Length; j++)
            {
                regalos[j] = j+1;
            }
            for (int p = 0; p < i.Length; p++)
            {
                Pedazo(regalos, i[p], d[p]);
            }
            return regalos;
        }
        static void Pedazo(int [] a, int i, int d)
        {
            int tamano = 0;
            if (i <= d)
            {
                tamano = d - i + 1;
            }
            else
            {
                tamano = d + (a.Length - i) + 1;
            }
            int[] Pedazos = new int[tamano];
            for (int p = 0; p < Pedazos.Length; p++)
            {
                int pos = p + i;
                while (pos>=a.Length)
                {
                    pos = pos % a.Length;
                }
                Pedazos[p] = a[pos];
            }
            Intercambiar(Pedazos);
            
            //Guardar Cambios en A
            for (int p = 0; p < Pedazos.Length; p++)
            {
                int pos = p + i;
                while (pos >= a.Length)
                {
                    pos = pos % a.Length;
                }
                a[pos] = Pedazos[p];
            }
        }
        
        static void Reemplazar(int[] inicio, int[] destino)
        {
            for (int i = 0; i < inicio.Length; i++)
            {
                destino[i] = inicio[i];
            }
        }
        static void Intercambiar(int [] Ped)
        {
            int[] N = new int[Ped.Length];
            for (int i = 0; i < Ped.Length/2+1; i++)
            {
                N[i] = Ped[Ped.Length-1-i];
                N[Ped.Length - 1 - i] = Ped[i];
            }
            Reemplazar(N, Ped);
        }

    }
}
