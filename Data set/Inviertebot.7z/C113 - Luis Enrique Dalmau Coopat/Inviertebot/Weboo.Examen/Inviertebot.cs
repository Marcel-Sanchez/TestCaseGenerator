﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int CantDePosiciones(int i, int d,int[]array)
        {
            int cont = 1;
            for (int k = i; ; k++)
            {
                if (k == array.Length) k = 0;
                if (k == d) break;
                cont++;
            }
            return cont;
        }
        public static void Swap(int i, int j,int[] a)
        {
            int temp = a[j];
            a[j] = a[i];
            a[i] = temp;
        }
        public static void Invierte( int desde ,int hasta,int []a)
        {
            int limite = CantDePosiciones(desde, hasta, a);

            for (int i = desde,j = hasta,k=0;k<(limite/2);j--,i++,k++)
            {
                if (j == -1) j = a.Length - 1;
                if (i == a.Length) i = 0;
                
                Swap(i, j, a);
            }
        }
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = new int[n];
            for (int j =0;j< n; j++)
                regalos[j] = j + 1;
            
            for (int j = 0; j < d.Length; j++)
            {
                Invierte(i[j], d[j], regalos);
                
            }
            return regalos;
        }
    }
}
