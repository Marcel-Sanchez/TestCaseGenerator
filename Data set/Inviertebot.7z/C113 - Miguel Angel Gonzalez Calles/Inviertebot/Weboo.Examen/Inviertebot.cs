﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] a = new int[n];
            int k = 1;
            //llenar array
            for (int j = 0; j < a.Length; j++)
            {
                a[j] = k;
                k++;
            }
            int t;
            for (int j = 0; j < i.Length; j++)
            {
                if (i[j] == d[j]) { }
                else
                {
                    if (i[j] < d[j]) { t = d[j] - i[j] + 1; }
                    else { t = (a.Length - (i[j] - d[j] - 1)); }
                    int[] b = new int[t];
                    //lenar array parcial
                    int inicio = i[j];
                    for (int l = 0; l < b.Length; l++)
                    {

                        b[l] = a[inicio];
                        inicio++;
                        if (inicio >= a.Length) inicio = 0;
                    }
                    //b.Reverse();
                    int s;
                    int m = b.Length - 1;
                    for (int l = 0; l < b.Length / 2; l++)
                    {                       
                        s = b[l];
                        b[l] = b[m];
                        b[m] = s;
                        m--;
                    }
                    inicio = i[j];
                    int p = 0;
                    while (true)
                    {
                        a[inicio] = b[p];
                        inicio++;
                        p++;
                        if (inicio - 1 == d[j]) break;
                        if (inicio >= a.Length) inicio = 0;
                    }
                }
            }
            return a;
        }
    }
}

 

