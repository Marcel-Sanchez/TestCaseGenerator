﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            //Borre la siguiente línea y escriba su código
            int[] regalosDisponibles = new int[n];
            int[] posicionesFinales = new int[n];
            int k=n-1;
         
            for (int j = n; j <= regalosDisponibles.Length; j--)
            {
                regalosDisponibles[k--] = j;
               
                if (j == 1) break;
            }
                for (int p = 0; p < i.Length; p++)
           
            {
                int copia1 = regalosDisponibles[i[p]];
                regalosDisponibles[i[p]] = regalosDisponibles[d[p]];
                regalosDisponibles[d[p]] = copia1;
                /* if(i[p]<d[p]){
                for (int q= i[p]; q < d[p]; q++)
                {
                   int copy = regalosDisponibles[i[p] - 1];
                    int copy3 = regalosDisponibles[d[p] + 1];
                    regalosDisponibles[d[p] + 1] = copy;
                    regalosDisponibles[i[p] - 1] = copy3;
                }
                  }
                
              */
                
            } 
            for (int p = 0; p < regalosDisponibles.Length; p++)
            {
                posicionesFinales[p] = regalosDisponibles[p];
            }
            return posicionesFinales;
        }
    }
}
