﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = new int[n];
            for (int l = 0; l < regalos.Length; l++)
                regalos[l] = l + 1;
            int cant = 0;
                for (int k = 0; k < i.Length; k++)
                {
                //int repetir = (d[k] - i[k])/2;
                //while (repetir > 0)
                //{
                //if (i[k] + cant == d[k] - cant)
                int swap = regalos[i[k] + cant];
                regalos[i[k] + cant] = regalos[d[k] - cant];
                regalos[d[k] - cant] = swap;
                //cant++;
                //repetir--;
                //}
                    
                }
            cant = 0;
            return regalos;
        }
    }
    //public class Inviertebot
    //{
    //    public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
    //    {
    //        int[] regalos = new int[n];
    //        for (int l = 0; l < regalos.Length; l++)
    //            regalos[l] = l + 1;

    //        for (int k = 0; k < i.Length; k++)
    //        {
    //            int cant = 0;
    //            if (regalos[i[k] + cant] == regalos[d[k] - cant])
    //                return regalos;
    //            do
    //            {
    //                int swap = regalos[i[k] + cant];
    //                regalos[i[k] + cant] = regalos[d[k] - cant];
    //                regalos[d[k] - cant] = swap;
    //                cant++;
    //                if (i[k] + cant == regalos.Length - 1)
    //                {
    //                    int cant1 = 0;
    //                    for (int m = 0; m < regalos.Length; m++)
    //                    {
    //                        do
    //                        {
    //                            int swap1 = regalos[i[m] + cant1];
    //                            regalos[i[m] + cant1] = regalos[d[k] - cant];
    //                            regalos[d[k] - cant] = swap1;
    //                            cant1++;
    //                            if (regalos[i[m] + cant1] == regalos[d[k] - cant])
    //                                return regalos;
    //                        }
    //                        while (regalos[i[m] + cant1] != regalos[d[k] - cant]);
    //                        cant1 = 0;
    //                    }
    //                }
    //                if (regalos[i[k] + cant] == regalos[d[k] - cant])
    //                    return regalos;
    //            }
    //            while (regalos[i[k] + cant] != regalos[d[k] - cant]);
    //            cant = 0;
    //        }

    //        return regalos;
    //    }
    //}

}




