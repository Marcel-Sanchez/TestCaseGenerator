﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] totalRegalos = CreaRegalos(n);
            int tr = 0;
            int[] regalos = null;
            for (int k = 0; k < i.Length; k++)
            {
                tr = i[k];
                if (i[k] > d[k])
                    regalos = new int[totalRegalos.Length + 1 - i[k] + d[k]];
                else
                    regalos = new int[d[k] - i[k] + 1];

                for (int j = 0; j < regalos.Length; j++)
                {
                    regalos[j] = totalRegalos[tr];
                    tr++;
                    if (tr == totalRegalos.Length) tr = 0;
                }
                InvierteArray(regalos);
                tr = i[k];
                for (int m = 0; m < regalos.Length; m++)
                {
                    totalRegalos[tr] = regalos[m];
                    tr++;
                    if (tr == totalRegalos.Length) tr = 0;
                }
            }
            return totalRegalos;
        }

        public static void InvierteArray(int[] a)
        {
            int temp = 0;
            int k = a.Length - 1;
            for (int i = 0; i < a.Length / 2; i++)
            {
                temp = a[i];
                a[i] = a[k];
                a[k] = temp;
                k--;
            }
        }
        public static int[] CreaRegalos(int n)
        {
            int[] regalos = new int[n];
            for (int i = regalos.Length - 1; i >= 0; i--)
            {
                regalos[i] = n;
                n--;
            }
            return regalos;
        }
    }
}