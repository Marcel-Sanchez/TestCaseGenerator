﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] regalos = new int[n];
            int posend = 0;
            int poseni = 0;

            for (int j = 0; j < regalos.Length; j++)
            {
                regalos[j] = j + 1;
            }

            for (int o = 0; o < i.Length; o++)
            {
                 poseni = i[o];
                 posend = d[o];
                 

                while (poseni != posend)
                { 
                    int aux= regalos[poseni];
                    regalos[poseni]= regalos[posend];
                    regalos[posend]=aux;

                    poseni++;
                    if (poseni == regalos.Length)
                    {
                        poseni = 0;
                    }

                    if (posend == poseni)
                    {
                        break;
                    }

                    posend--;

                    if (posend == -1)
                    {
                        posend = regalos.Length - 1;
                    }
                }
                
            
            }

            return regalos;
            
        }
    }
}
