﻿using System.Collections.Generic;
using System.Linq;
using Weboo.Assess.Tester;

namespace AntorchasTester
{
    public abstract class AntorchasTest : TestCase
    {
        public bool T => true;
        public bool F => false;

        public IEnumerable<int> Student(bool[,] map)
        {
            return ReflectionHelper.InvokeStatic<IEnumerable<int>>("Weboo.Examen.ProblemaAntorchas", "AsignaAntorchas", map);
        }

        public void Check(bool[,] map, int solutionSize)
        {
            var solution = Student(map);
            Assert.That(solution, Is.Not.Null);

            if (solution == null)
            {
                return;
            }

            for (int i = 0; i < map.GetLength(0); i++)
            {
                bool isLit = false;
                foreach (var t in solution)
                {
                    if (i == t || map[i, t])
                    {
                        isLit = true;
                        break;
                    }
                }

                if (!isLit)
                {
                    string output = $"{{ {string.Join(", ", solution)} }}";
                    Assert.Fail($"Region {i} is dark. (Output: {output})");
                }
            }

            Assert.That(solution.Count(), Is.EqualTo(solutionSize));
        }
    }

    public class ExampleTests : AntorchasTest
    {
        public void Ejemplo1()
        {
            bool[,] map = {
                {F, F, T, F, F, F},
                {F, F, F, T, F, F},
                {T, F, F, T, T, F},
                {F, T, T, F, F, T},
                {F, F, T, F, F, F},
                {F, F, F, T, F, F}
            };

            Assert.That(Student(map), Is.MultisetEqualTo(new[] { 2, 3 }));
        }

        public void Ejemplo2()
        {
            bool[,] map = {
                {F, F, T, F, F},
                {F, F, T, F, F},
                {T, T, F, T, T},
                {F, F, T, F, F},
                {F, F, T, F, F}
            };

            Assert.That(Student(map), Is.MultisetEqualTo(new[] { 2 }));
        }
    }

    public class FullOfTorches : AntorchasTest
    {
        public void Full1()
        {
            var map = new bool[2, 2];

            Check(map, 2);
        }

        public void Full2()
        {
            var map = new bool[15, 15];

            Check(map, 15);
        }
    }

    public class OneTorch : AntorchasTest
    {
        public void One1()
        {
            bool[,] map = {
                {F, T, T},
                {T, F, F},
                {T, F, F}
            };

            Check(map, 1);
        }

        public void One2()
        {
            bool[,] map = {
                {F, F, T, F, F},
                {F, F, T, F, F},
                {T, T, F, T, T},
                {F, F, T, F, F},
                {F, F, T, F, F}
            };

            Check(map, 1);
        }

        public void One3()
        {
            bool[,] map = new bool[30, 30];
            for (int i = 0; i < map.GetLength(0); i++)
            {
                for (int j = 0; j < map.GetLength(1); j++)
                {
                    map[i, j] = T;
                }
                map[i, i] = F;
            }

            Check(map, 1);
        }

        public void One4()
        {
            bool[,] map = new bool[12, 12];
            for (int i = 0; i < map.GetLength(0); i++)
            {
                map[0, i] = map[i, 0] = T;
                map[11, i] = map[i, 11] = T;
            }
            map[0, 0] = map[11, 11] = F;

            Check(map, 1);
        }
    }

    public class IsolatedRegions : AntorchasTest
    {
        public void Isolated1()
        {
            bool[,] map = {
                { F, T, T, F, F, F },
                { T, F, F, F, F, F },
                { T, F, F, F, F, F },
                { F, F, F, F, F, T },
                { F, F, F, F, F, T },
                { F, F, F, T, T, F }
            };

            Check(map, 2);
        }

        public void Isolated2()
        {
            bool[,] map = {
                { F, T, F, F, F, T },
                { T, F, T, F, F, F },
                { F, T, F, T, F, F },
                { F, F, T, F, T, F },
                { F, F, F, T, F, T },
                { T, F, F, F, T, F }
            };

            Check(map, 2);
        }
    }

    public class NoGreedy : AntorchasTest
    {
        public void AntiGreedy1()
        {
            bool[,] map = new bool[7, 7];
            map[0, 1] = map[1, 0] = T;
            map[1, 2] = map[2, 1] = T;
            map[1, 3] = map[3, 1] = T;
            map[2, 3] = map[3, 2] = T;
            map[3, 4] = map[4, 3] = T;
            map[3, 5] = map[5, 3] = T;
            map[4, 5] = map[5, 4] = T;
            map[4, 6] = map[6, 4] = T;

            Check(map, 2);
        }

        public void AntiGreedy2()
        {
            int n = 4;
            bool[,] map = new bool[2 * n + 1, 2 * n + 1];
            for (int i = 1; i <= n; i++)
            {
                map[0, i] = map[i, 0] = T;
                map[i, n + i] = map[n + i, i] = T;
            }

            Check(map, 4);
        }

        public void AntiGreedy3()
        {
            int n = 6;
            bool[,] map = new bool[2 * n + 1, 2 * n + 1];
            for (int i = 1; i <= n; i++)
            {
                map[0, i] = map[i, 0] = T;
                map[i, n + i] = map[n + i, i] = T;
            }

            Check(map, 6);
        }

        public void AntiGreedy4()
        {
            bool[,] map = {
                { F, F, F, F, F, F, T, F, F, T, F },
                { F, F, F, T, F, F, F, T, F, F, F },
                { F, F, F, F, F, F, F, T, F, T, T },
                { F, T, F, F, F, F, F, F, T, F, F },
                { F, F, F, F, F, F, F, F, T, F, F },
                { F, F, F, F, F, F, T, T, F, T, F },
                { T, F, F, F, F, T, F, F, T, F, T },
                { F, T, T, F, F, T, F, F, F, T, F },
                { F, F, F, T, T, F, T, F, F, T, F },
                { T, F, T, F, F, T, F, T, T, F, F },
                { F, F, T, F, F, F, T, F, F, F, F }
            };

            Check(map, 3);
        }

        public void AntiGreedy5()
        {
            bool[,] map = {
                { F, T, F, F, T, F },
                { T, F, T, F, F, F },
                { F, T, F, F, F, F },
                { F, F, F, F, F, T },
                { T, F, F, F, F, T },
                { F, F, F, T, T, F }
            };

            Check(map, 2);
        }

        public void AntiGreedy6()
        {
            bool[,] map = {
                { F, F, F, F, F, T, F },
                { F, F, F, F, F, F, F },
                { F, F, F, F, F, T, T },
                { F, F, F, F, F, F, F },
                { F, F, F, F, F, F, T },
                { T, F, T, F, F, F, F },
                { F, F, T, F, T, F, F }
            };

            Check(map, 4);
        }

        public void AntiGreedy7()
        {
            bool[,] map = {
                { F, F, F, T, F, F, T, F },
                { F, F, F, F, F, T, F, F },
                { F, F, F, F, F, F, T, T },
                { T, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, T },
                { F, T, F, F, F, F, F, F },
                { T, F, T, F, F, F, F, T },
                { F, F, T, F, T, F, T, F }
            };

            Check(map, 3);
        }

        public void AntiGreedy8()
        {
            bool[,] map = {
                { F, F, T, F, T, T, F, F, F, F, F, F, F },
                { F, F, F, F, T, T, T, T, F, F, F, F, F },
                { T, F, F, T, F, F, F, F, F, F, F, F, F },
                { F, F, T, F, F, F, F, F, F, F, F, T, F },
                { T, T, F, F, F, F, F, F, F, F, F, F, F },
                { T, T, F, F, F, F, F, F, F, F, F, T, F },
                { F, T, F, F, F, F, F, F, F, F, T, F, F },
                { F, T, F, F, F, F, F, F, F, T, F, T, T },
                { F, F, F, F, F, F, F, F, F, F, F, T, F },
                { F, F, F, F, F, F, F, T, F, F, F, F, F },
                { F, F, F, F, F, F, T, F, F, F, F, F, F },
                { F, F, F, T, F, T, F, T, T, F, F, F, F },
                { F, F, F, F, F, F, F, T, F, F, F, F, F }
            };

            Check(map, 4);
        }

        public void AntiGreedy9()
        {
            bool[,] map = {
                { F, F, T, F, F, F, T, T, F },
                { F, F, T, F, F, F, F, T, T },
                { T, T, F, F, F, F, F, T, F },
                { F, F, F, F, T, F, F, F, F },
                { F, F, F, T, F, T, F, F, F },
                { F, F, F, F, T, F, F, T, F },
                { T, F, F, F, F, F, F, F, F },
                { T, T, T, F, F, T, F, F, F },
                { F, T, F, F, F, F, F, F, F }
            };

            Check(map, 3);
        }

        public void AntiGreedy10()
        {
            bool[,] map = {
                { F, F, F, T, F, F, F, F, F },
                { F, F, F, T, T, F, F, F, F },
                { F, F, F, F, F, F, F, F, F },
                { T, T, F, F, F, F, F, F, F },
                { F, T, F, F, F, F, T, F, F },
                { F, F, F, F, F, F, F, F, F },
                { F, F, F, F, T, F, F, F, F },
                { F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F }
            };

            Check(map, 6);
        }

        public void AntiGreedy11()
        {
            bool[,] map = {
                { F, T, F, T, F, F, F, F, F, F, T },
                { T, F, F, F, T, T, F, T, F, F, F },
                { F, F, F, F, F, F, F, F, F, F, F },
                { T, F, F, F, T, T, F, F, F, F, F },
                { F, T, F, T, F, F, T, F, F, F, T },
                { F, T, F, T, F, F, F, F, F, T, F },
                { F, F, F, F, T, F, F, F, F, T, F },
                { F, T, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, T, T, F, F, F, F },
                { T, F, F, F, T, F, F, F, F, F, F }
            };

            Check(map, 5);
        }

        public void AntiGreedy12()
        {
            bool[,] map = {
                { F, F, F, T, T, F, F, F, F, F, F, T, F },
                { F, F, F, T, F, F, F, T, F, F, F, F, F },
                { F, F, F, T, F, F, F, F, F, F, F, T, F },
                { T, T, T, F, F, F, T, F, F, F, F, F, F },
                { T, F, F, F, F, T, F, T, F, F, F, T, T },
                { F, F, F, F, T, F, F, T, T, F, F, F, F },
                { F, F, F, T, F, F, F, F, F, F, F, F, T },
                { F, T, F, F, T, T, F, F, T, F, F, F, F },
                { F, F, F, F, F, T, F, T, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F, F, T, F },
                { F, F, F, F, F, F, F, F, F, F, F, F, F },
                { T, F, T, F, T, F, F, F, F, T, F, F, F },
                { F, F, F, F, T, F, T, F, F, F, F, F, F }
            };

            Check(map, 4);
        }

        public void AntiGreedy13()
        {
            bool[,] map = {
                { F, T, F, F, T, F, F, F, F, T, F },
                { T, F, T, F, F, F, T, F, F, F, F },
                { F, T, F, F, F, F, F, F, T, T, F },
                { F, F, F, F, F, F, F, T, F, F, F },
                { T, F, F, F, F, F, T, F, T, T, F },
                { F, F, F, F, F, F, F, F, F, F, F },
                { F, T, F, F, T, F, F, F, F, F, F },
                { F, F, F, T, F, F, F, F, F, F, F },
                { F, F, T, F, T, F, F, F, F, T, T },
                { T, F, T, F, T, F, F, F, T, F, F },
                { F, F, F, F, F, F, F, F, T, F, F }
            };

            Check(map, 4);
        }

        public void AntiGreedy14()
        {
            bool[,] map = {
                { F, F, F, F, T, F },
                { F, F, F, F, F, T },
                { F, F, F, F, T, T },
                { F, F, F, F, F, F },
                { T, F, T, F, F, F },
                { F, T, T, F, F, F }
            };

            Check(map, 3);
        }

        public void AntiGreedy15()
        {
            bool[,] map = {
                { F, F, T, T, F, F, F, F, F, T, F, T },
                { F, F, F, F, F, T, F, F, F, T, T, F },
                { T, F, F, F, F, F, F, F, T, F, F, F },
                { T, F, F, F, F, F, F, F, F, T, T, T },
                { F, F, F, F, F, F, F, F, F, F, F, F },
                { F, T, F, F, F, F, T, F, F, F, F, T },
                { F, F, F, F, F, T, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F, F, F },
                { F, F, T, F, F, F, F, F, F, T, T, T },
                { T, T, F, T, F, F, F, F, T, F, F, F },
                { F, T, F, T, F, F, F, F, T, F, F, F },
                { T, F, F, T, F, T, F, F, T, F, F, F }
            };

            Check(map, 5);
        }
    }

    public class RandomMaps : AntorchasTest
    {
        public void Random1()
        {
            bool[,] map = {
                { F, F, F, F, F, F, F, T, F, F },
                { F, F, T, F, F, F, F, F, F, F },
                { F, T, F, T, F, F, F, F, F, F },
                { F, F, T, F, T, T, F, F, F, F },
                { F, F, F, T, F, T, F, F, F, F },
                { F, F, F, T, T, F, T, F, F, F },
                { F, F, F, F, F, T, F, F, T, F },
                { T, F, F, F, F, F, F, F, T, F },
                { F, F, F, F, F, F, T, T, F, F },
                { F, F, F, F, F, F, F, F, F, F }
            };

            Check(map, 4);
        }

        public void Random2()
        {
            bool[,] map = {
                { F, F, F, F, F, F },
                { F, F, F, F, T, F },
                { F, F, F, F, F, F },
                { F, F, F, F, F, F },
                { F, T, F, F, F, F },
                { F, F, F, F, F, F }
            };

            Check(map, 5);
        }

        public void Random3()
        {
            bool[,] map = {
                { F, F, F, T, F, F, F, F },
                { F, F, F, F, F, F, F, T },
                { F, F, F, T, F, F, F, F },
                { T, F, T, F, T, F, F, F },
                { F, F, F, T, F, T, F, F },
                { F, F, F, F, T, F, T, F },
                { F, F, F, F, F, T, F, F },
                { F, T, F, F, F, F, F, F }
            };

            Check(map, 3);
        }

        public void Random4()
        {
            bool[,] map = {
                { F, T, F, T, T, T, F, F, F, F, T, T },
                { T, F, F, F, F, F, F, T, F, F, F, T },
                { F, F, F, T, F, F, F, F, F, T, T, T },
                { T, F, T, F, F, F, F, F, T, F, F, F },
                { T, F, F, F, F, F, T, F, F, F, F, T },
                { T, F, F, F, F, F, T, T, F, F, F, F },
                { F, F, F, F, T, T, F, F, F, F, T, F },
                { F, T, F, F, F, T, F, F, F, F, T, T },
                { F, F, F, T, F, F, F, F, F, T, F, T },
                { F, F, T, F, F, F, F, F, T, F, F, F },
                { T, F, T, F, F, F, T, T, F, F, F, T },
                { T, T, T, F, T, F, F, T, T, F, T, F }
            };

            Check(map, 3);
        }

        public void Random5()
        {
            bool[,] map = {
                { F, F, F, F, F, F, F, F, F, T, F, T, F },
                { F, F, F, F, F, F, T, F, F, F, F, F, F },
                { F, F, F, F, F, F, T, T, F, F, F, F, F },
                { F, F, F, F, F, F, F, T, F, F, T, F, F },
                { F, F, F, F, F, F, F, F, F, T, F, F, F },
                { F, F, F, F, F, F, F, F, T, F, F, F, F },
                { F, T, T, F, F, F, F, F, F, F, F, F, F },
                { F, F, T, T, F, F, F, F, T, F, F, F, F },
                { F, F, F, F, F, T, F, T, F, F, F, F, F },
                { T, F, F, F, T, F, F, F, F, F, F, F, T },
                { F, F, F, T, F, F, F, F, F, F, F, T, F },
                { T, F, F, F, F, F, F, F, F, F, T, F, F },
                { F, F, F, F, F, F, F, F, F, T, F, F, F }
            };

            Check(map, 4);
        }

        public void Random6()
        {
            bool[,] map = {
                { F, F, T, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, T, F, F, T, T, F, T },
                { T, F, F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, T, F, F },
                { F, F, F, F, F, F, T, F, F, F, F, F },
                { F, T, F, F, F, F, F, F, F, F, F, T },
                { F, F, F, F, T, F, F, F, F, F, T, T },
                { F, F, F, F, F, F, F, F, T, F, F, F },
                { F, T, F, F, F, F, F, T, F, F, T, F },
                { F, T, F, T, F, F, F, F, F, F, T, F },
                { F, F, F, F, F, F, T, F, T, T, F, F },
                { F, T, F, F, F, T, T, F, F, F, F, F }
            };

            Check(map, 5);
        }

        public void Random7()
        {
            bool[,] map = {
                { F, F, F, T, F, F, F },
                { F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F },
                { T, F, F, F, F, F, F },
                { F, F, F, F, F, F, F },
                { F, F, F, F, F, F, T },
                { F, F, F, F, F, T, F }
            };

            Check(map, 5);
        }

        public void Random8()
        {
            bool[,] map = {
                { F, F, F, T, F, F, F },
                { F, F, F, F, F, F, T },
                { F, F, F, F, T, T, F },
                { T, F, F, F, F, F, F },
                { F, F, T, F, F, F, T },
                { F, F, T, F, F, F, T },
                { F, T, F, F, T, T, F }
            };

            Check(map, 3);
        }

        public void Random9()
        {
            bool[,] map = {
                { F, F, F, F, F, F, T, F, F, F },
                { F, F, F, F, T, F, F, F, F, F },
                { F, F, F, F, T, F, F, F, F, F },
                { F, F, F, F, F, F, T, F, F, F },
                { F, T, T, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, T, F },
                { T, F, F, T, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, T, F, F, F, T },
                { F, F, F, F, F, F, F, F, T, F }
            };

            Check(map, 4);
        }

        public void Random10()
        {
            bool[,] map = {
                { F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, T, F, F, F, F, F },
                { F, F, F, F, T, T, T, T, F, F },
                { F, F, T, T, F, F, F, T, T, F },
                { F, F, F, T, F, F, T, F, F, F },
                { F, F, F, T, F, T, F, F, F, F },
                { F, F, F, T, T, F, F, F, F, F },
                { F, F, F, F, T, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F }
            };

            Check(map, 5);
        }

        public void Random11()
        {
            bool[,] map = {
                { F, F, T, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F, F, F },
                { T, F, F, T, F, F, F, F, F, F, F, F },
                { F, F, T, F, T, F, T, F, T, T, F, F },
                { F, F, F, T, F, F, F, T, F, F, T, F },
                { F, F, F, F, F, F, F, T, F, F, F, T },
                { F, F, F, T, F, F, F, F, F, F, F, F },
                { F, F, F, F, T, T, F, F, F, T, T, F },
                { F, F, F, T, F, F, F, F, F, F, F, F },
                { F, F, F, T, F, F, F, T, F, F, T, F },
                { F, F, F, F, T, F, F, T, F, T, F, F },
                { F, F, F, F, F, T, F, F, F, F, F, F }
            };

            Check(map, 5);
        }

        public void Random12()
        {
            bool[,] map = {
                { F, T, F, T, F, F, F, F, F, F, F, F },
                { T, F, T, F, F, F, F, F, F, F, F, F },
                { F, T, F, F, F, F, F, F, F, F, F, F },
                { T, F, F, F, T, F, F, F, F, F, F, F },
                { F, F, F, T, F, F, T, F, F, T, F, F },
                { F, F, F, F, F, F, F, F, F, F, F, T },
                { F, F, F, F, T, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F, F, T },
                { F, F, F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, T, F, F, F, F, F, F, T },
                { F, F, F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, T, F, T, F, T, F, F }
            };

            Check(map, 5);
        }

        public void Random13()
        {
            bool[,] map = {
                { F, F, F, F, T, F, F, F, T },
                { F, F, F, T, T, F, F, F, F },
                { F, F, F, T, T, F, F, F, F },
                { F, T, T, F, F, F, T, F, F },
                { T, T, T, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F },
                { F, F, F, T, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F },
                { T, F, F, F, F, F, F, F, F }
            };

            Check(map, 4);
        }

        public void Random14()
        {
            bool[,] map = {
                { F, T, F, F, F, T, F, F, F, F, F, F },
                { T, F, F, F, F, F, T, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, T, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F, F, F },
                { T, F, F, F, F, F, T, F, T, F, F, F },
                { F, T, F, T, F, T, F, F, F, F, T, F },
                { F, F, F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, T, F, F, F, F, T, F },
                { F, F, F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, T, F, T, F, F, F },
                { F, F, F, F, F, F, F, F, F, F, F, F }
            };

            Check(map, 7);
        }

        public void Random15()
        {
            bool[,] map = {
                { F, T, F, F, F, F, T, F },
                { T, F, T, F, F, T, F, F },
                { F, T, F, F, F, T, F, F },
                { F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F },
                { F, T, T, F, F, F, F, F },
                { T, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F }
            };

            Check(map, 5);
        }

        public void Random16()
        {
            bool[,] map = {
                { F, F, T, F, F, F, F, F },
                { F, F, F, F, F, F, F, T },
                { T, F, F, T, F, T, F, F },
                { F, F, T, F, F, F, F, F },
                { F, F, F, F, F, F, F, F },
                { F, F, T, F, F, F, F, F },
                { F, F, F, F, F, F, F, F },
                { F, T, F, F, F, F, F, F }
            };

            Check(map, 4);
        }

        public void Random17()
        {
            bool[,] map = {
                { F, F, F, F, T, F, F },
                { F, F, T, F, T, F, F },
                { F, T, F, T, F, F, F },
                { F, F, T, F, F, F, F },
                { T, T, F, F, F, F, F },
                { F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F }
            };

            Check(map, 4);
        }

        public void Random18()
        {
            bool[,] map = {
                { F, F, F, F, T, F, F, T, F, F },
                { F, F, F, F, T, T, F, F, F, F },
                { F, F, F, F, F, T, F, F, F, F },
                { F, F, F, F, F, F, F, F, T, F },
                { T, T, F, F, F, F, F, F, F, F },
                { F, T, T, F, F, F, T, F, T, F },
                { F, F, F, F, F, T, F, F, F, F },
                { T, F, F, F, F, F, F, F, F, F },
                { F, F, F, T, F, T, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F }
            };

            Check(map, 4);
        }

        public void Random19()
        {
            bool[,] map = {
                { F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, T },
                { F, F, F, F, F, T, F, F, F },
                { F, F, F, F, F, F, F, F, F },
                { F, F, F, T, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F },
                { F, F, T, F, F, F, F, F, F }
            };

            Check(map, 7);
        }

        public void Random20()
        {
            bool[,] map = {
                { F, F, T, F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, T, F, F, F },
                { T, F, F, F, F, T, F, F, T, T, T, F, F },
                { F, F, F, F, F, F, T, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, T, F, F, F, F },
                { F, F, T, F, F, F, F, T, F, F, F, F, F },
                { F, F, F, T, F, F, F, F, F, F, T, F, F },
                { F, F, F, F, F, T, F, F, F, F, F, F, T },
                { F, F, T, F, T, F, F, F, F, F, F, T, F },
                { F, T, T, F, F, F, F, F, F, F, F, F, F },
                { F, F, T, F, F, F, T, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, T, F, F, F, F },
                { F, F, F, F, F, F, F, T, F, F, F, F, F }
            };

            Check(map, 5);
        }

        public void Random21()
        {
            bool[,] map = {
                { F, F, F, F, F, F, F, F },
                { F, F, F, F, F, T, F, F },
                { F, F, F, F, F, F, F, F },
                { F, F, F, F, T, T, F, T },
                { F, F, F, T, F, F, F, F },
                { F, T, F, T, F, F, F, F },
                { F, F, F, F, F, F, F, F },
                { F, F, F, T, F, F, F, F }
            };

            Check(map, 5);
        }

        public void Random22()
        {
            bool[,] map = {
                { F, F, F, F, F, F, F, F, F, T, F, F, T },
                { F, F, F, F, F, F, F, F, F, F, F, T, F },
                { F, F, F, F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, T, T, F, F, T, F, F, T },
                { F, F, F, F, F, T, T, F, F, T, F, F, F },
                { F, F, F, T, T, F, T, F, F, F, F, F, F },
                { F, F, F, T, T, T, F, T, T, F, T, T, F },
                { F, F, F, F, F, F, T, F, T, F, T, T, T },
                { F, F, F, F, F, F, T, T, F, F, F, F, F },
                { T, F, F, T, T, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, T, T, F, F, F, F, T },
                { F, T, F, F, F, F, T, T, F, F, F, F, F },
                { T, F, F, T, F, F, F, T, F, F, T, F, F }
            };

            Check(map, 4);
        }

        public void Random23()
        {
            bool[,] map = {
                { F, T, F, F, F, T, F, F },
                { T, F, F, T, F, F, F, F },
                { F, F, F, T, F, F, F, F },
                { F, T, T, F, F, F, F, F },
                { F, F, F, F, F, F, T, F },
                { T, F, F, F, F, F, F, F },
                { F, F, F, F, T, F, F, F },
                { F, F, F, F, F, F, F, F }
            };

            Check(map, 4);
        }

        public void Random24()
        {
            bool[,] map = {
                { F, F, F, F, F, F, F },
                { F, F, F, F, F, T, F },
                { F, F, F, F, F, T, F },
                { F, F, F, F, T, F, F },
                { F, F, F, T, F, F, F },
                { F, T, T, F, F, F, F },
                { F, F, F, F, F, F, F }
            };

            Check(map, 4);
        }

        public void Random25()
        {
            bool[,] map = {
                { F, T, F, F, T, F, F, F, F, F, T, F, F },
                { T, F, F, F, F, T, T, F, F, F, F, F, T },
                { F, F, F, F, F, F, T, F, F, F, F, F, T },
                { F, F, F, F, F, F, F, F, F, F, F, F, F },
                { T, F, F, F, F, T, F, F, F, F, T, F, F },
                { F, T, F, F, T, F, F, F, F, F, F, T, F },
                { F, T, T, F, F, F, F, F, T, F, F, T, F },
                { F, F, F, F, F, F, F, F, F, F, F, T, F },
                { F, F, F, F, F, F, T, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F, T, F, F },
                { T, F, F, F, T, F, F, F, F, T, F, F, F },
                { F, F, F, F, F, T, T, T, F, F, F, F, F },
                { F, T, T, F, F, F, F, F, F, F, F, F, F }
            };

            Check(map, 5);
        }

        public void Random26()
        {
            bool[,] map = {
                { F, T, F, F, F, F, F, F },
                { T, F, F, F, F, T, F, F },
                { F, F, F, F, T, F, F, F },
                { F, F, F, F, T, F, F, F },
                { F, F, T, T, F, F, F, F },
                { F, T, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F }
            };

            Check(map, 4);
        }

        public void Random27()
        {
            bool[,] map = {
                { F, T, F, F, F, F, T, T },
                { T, F, F, F, F, T, F, F },
                { F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F },
                { F, T, F, F, F, F, F, F },
                { T, F, F, F, F, F, F, F },
                { T, F, F, F, F, F, F, F }
            };

            Check(map, 5);
        }

        public void Random28()
        {
            bool[,] map = {
                { F, T, F, F, F, F, F },
                { T, F, F, F, F, T, T },
                { F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F },
                { F, F, F, F, F, T, F },
                { F, T, F, F, T, F, F },
                { F, T, F, F, F, F, F }
            };

            Check(map, 4);
        }

        public void Random29()
        {
            bool[,] map = {
                { F, F, F, T, F, F, F, F, F, F, F, T },
                { F, F, F, F, F, T, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, T, F, F, F, F },
                { T, F, F, F, T, F, F, F, F, T, F, T },
                { F, F, F, T, F, F, F, F, T, F, F, F },
                { F, T, F, F, F, F, F, T, F, T, T, F },
                { F, F, F, F, F, F, F, T, F, F, F, F },
                { F, F, T, F, F, T, T, F, F, F, T, F },
                { F, F, F, F, T, F, F, F, F, F, F, F },
                { F, F, F, T, F, T, F, F, F, F, F, F },
                { F, F, F, F, F, T, F, T, F, F, F, F },
                { T, F, F, T, F, F, F, F, F, F, F, F }
            };

            Check(map, 4);
        }

        public void Random30()
        {
            bool[,] map = {
                { F, F, F, T, T, F, F, T, F, F, F, F, F },
                { F, F, T, F, F, F, T, T, F, T, F, F, T },
                { F, T, F, T, F, F, F, F, F, F, F, F, F },
                { T, F, T, F, F, F, F, T, F, F, T, F, F },
                { T, F, F, F, F, T, F, F, F, F, F, F, F },
                { F, F, F, F, T, F, T, F, F, F, F, F, F },
                { F, T, F, F, F, T, F, F, F, F, F, F, F },
                { T, T, F, T, F, F, F, F, F, F, F, F, T },
                { F, F, F, F, F, F, F, F, F, F, F, F, F },
                { F, T, F, F, F, F, F, F, F, F, F, F, F },
                { F, F, F, T, F, F, F, F, F, F, F, T, F },
                { F, F, F, F, F, F, F, F, F, F, T, F, F },
                { F, T, F, F, F, F, F, T, F, F, F, F, F }
            };

            Check(map, 4);
        }

        public void Random31()
        {
            bool[,] map = {
                { F, T, F, F, F, F },
                { T, F, F, F, F, F },
                { F, F, F, F, F, T },
                { F, F, F, F, F, F },
                { F, F, F, F, F, T },
                { F, F, T, F, T, F }
            };

            Check(map, 3);
        }

        public void Random32()
        {
            bool[,] map = {
                { F, T, F, F, F, F, F, F, F, F, F, F },
                { T, F, F, F, F, F, F, T, F, T, F, T },
                { F, F, F, T, T, F, F, F, F, F, F, F },
                { F, F, T, F, F, F, F, F, F, F, F, F },
                { F, F, T, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, T, F, F },
                { F, T, F, F, F, F, F, F, T, F, F, F },
                { F, F, F, F, F, F, F, T, F, F, F, T },
                { F, T, F, F, F, F, T, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F, F, F },
                { F, T, F, F, F, F, F, F, T, F, F, F }
            };

            Check(map, 6);
        }

        public void Random33()
        {
            bool[,] map = {
                { F, F, F, T, F, F, F, T, F, F, F },
                { F, F, F, F, F, F, F, F, T, T, F },
                { F, F, F, F, F, F, T, F, F, T, F },
                { T, F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, T, F, F, F },
                { F, F, T, F, F, F, F, F, T, F, F },
                { T, F, F, F, F, T, F, F, F, F, F },
                { F, T, F, F, F, F, T, F, F, T, T },
                { F, T, T, F, F, F, F, F, T, F, T },
                { F, F, F, F, F, F, F, F, T, T, F }
            };

            Check(map, 5);
        }

        public void Random34()
        {
            bool[,] map = {
                { F, F, F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, T, T, F, T, F },
                { F, F, F, T, F, F, F, F, F, T, F, F },
                { F, F, T, F, F, T, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F, F, T },
                { F, F, F, T, F, F, F, F, T, F, F, F },
                { F, F, F, F, F, F, F, T, F, F, F, F },
                { F, T, F, F, F, F, T, F, F, T, F, F },
                { F, T, F, F, F, T, F, F, F, F, T, F },
                { F, F, T, F, F, F, F, T, F, F, F, F },
                { F, T, F, F, F, F, F, F, T, F, F, F },
                { F, F, F, F, T, F, F, F, F, F, F, F }
            };

            Check(map, 5);
        }

        public void Random35()
        {
            bool[,] map = {
                { F, F, F, T, T, T },
                { F, F, F, T, F, T },
                { F, F, F, F, F, T },
                { T, T, F, F, F, T },
                { T, F, F, F, F, F },
                { T, T, T, T, F, F }
            };

            Check(map, 2);
        }

        public void Random36()
        {
            bool[,] map = {
                { F, F, F, F, F, T, T },
                { F, F, F, F, F, F, T },
                { F, F, F, F, F, F, F },
                { F, F, F, F, F, F, T },
                { F, F, F, F, F, F, T },
                { T, F, F, F, F, F, F },
                { T, T, F, T, T, F, F }
            };

            Check(map, 3);
        }

        public void Random37()
        {
            bool[,] map = {
                { F, F, T, T, F, F, F, F, F },
                { F, F, F, F, F, T, F, T, F },
                { T, F, F, F, F, T, F, T, F },
                { T, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, T },
                { F, T, T, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F },
                { F, T, T, F, F, F, F, F, F },
                { F, F, F, F, T, F, F, F, F }
            };

            Check(map, 4);
        }

        public void Random38()
        {
            bool[,] map = {
                { F, F, F, F, T, F },
                { F, F, F, F, F, F },
                { F, F, F, F, F, F },
                { F, F, F, F, F, F },
                { T, F, F, F, F, F },
                { F, F, F, F, F, F }
            };

            Check(map, 5);
        }

        public void Random39()
        {
            bool[,] map = {
                { F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, T, F, T },
                { F, F, F, F, F, F, F, F, T, F },
                { F, F, F, F, T, T, F, F, F, F },
                { F, F, F, T, F, F, T, F, F, T },
                { F, F, F, T, F, F, T, F, T, T },
                { F, F, F, F, T, T, F, T, F, F },
                { F, T, F, F, F, F, T, F, F, T },
                { F, F, T, F, F, T, F, F, F, F },
                { F, T, F, F, T, T, F, T, F, F }
            };

            Check(map, 4);
        }

        public void Random40()
        {
            bool[,] map = {
                { F, F, F, T, T, T, T, T },
                { F, F, F, F, F, F, T, F },
                { F, F, F, T, F, F, T, F },
                { T, F, T, F, F, F, F, T },
                { T, F, F, F, F, F, F, F },
                { T, F, F, F, F, F, F, F },
                { T, T, T, F, F, F, F, T },
                { T, F, F, T, F, F, T, F }
            };

            Check(map, 2);
        }

        public void Random41()
        {
            bool[,] map = {
                { F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, T, F, T, F },
                { F, F, F, F, F, T, F, T, F },
                { F, F, F, F, F, T, F, F, F },
                { F, F, F, F, F, T, F, F, T },
                { F, T, T, T, T, F, F, F, F },
                { F, F, F, F, F, F, F, F, F },
                { F, T, T, F, F, F, F, F, T },
                { F, F, F, F, T, F, F, T, F }
            };

            Check(map, 4);
        }

        public void Random42()
        {
            bool[,] map = {
                { F, F, F, F, T, T, T, F, T, F, F, F },
                { F, F, F, F, F, F, F, F, T, F, F, F },
                { F, F, F, F, F, F, F, F, T, F, F, F },
                { F, F, F, F, F, T, T, F, F, T, F, F },
                { T, F, F, F, F, F, F, T, F, T, F, F },
                { T, F, F, T, F, F, F, F, F, F, F, F },
                { T, F, F, T, F, F, F, T, F, F, F, F },
                { F, F, F, F, T, F, T, F, F, F, F, F },
                { T, T, T, F, F, F, F, F, F, F, F, F },
                { F, F, F, T, T, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F, F, F }
            };

            Check(map, 5);
        }

        public void Random43()
        {
            bool[,] map = {
                { F, F, F, F, T, F, F, T, F, F, F, F, F },
                { F, F, F, F, F, T, F, F, F, T, F, T, T },
                { F, F, F, F, F, F, T, F, F, F, F, F, F },
                { F, F, F, F, T, T, F, T, F, F, F, F, T },
                { T, F, F, T, F, F, T, F, F, T, T, F, T },
                { F, T, F, T, F, F, F, T, F, T, F, T, F },
                { F, F, T, F, T, F, F, F, F, F, F, F, F },
                { T, F, F, T, F, T, F, F, F, F, T, F, F },
                { F, F, F, F, F, F, F, F, F, F, F, F, F },
                { F, T, F, F, T, T, F, F, F, F, F, F, F },
                { F, F, F, F, T, F, F, T, F, F, F, F, F },
                { F, T, F, F, F, T, F, F, F, F, F, F, F },
                { F, T, F, T, T, F, F, F, F, F, F, F, F }
            };

            Check(map, 4);
        }

        public void Random44()
        {
            bool[,] map = {
                { F, T, F, F, T, F, F, F, T, F },
                { T, F, T, F, F, F, F, F, F, T },
                { F, T, F, F, T, F, F, F, F, F },
                { F, F, F, F, T, F, T, F, F, F },
                { T, F, T, T, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F },
                { F, F, F, T, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F },
                { T, F, F, F, F, F, F, F, F, F },
                { F, T, F, F, F, F, F, F, F, F }
            };

            Check(map, 5);
        }

        public void Random45()
        {
            bool[,] map = {
                { F, F, F, F, F, T },
                { F, F, T, T, T, T },
                { F, T, F, F, F, F },
                { F, T, F, F, F, F },
                { F, T, F, F, F, F },
                { T, T, F, F, F, F }
            };

            Check(map, 2);
        }

        public void Random46()
        {
            bool[,] map = {
                { F, F, F, F, F, F, F },
                { F, F, F, F, F, T, F },
                { F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F },
                { F, F, F, F, F, F, T },
                { F, T, F, F, F, F, F },
                { F, F, F, F, T, F, F }
            };

            Check(map, 5);
        }

        public void Random47()
        {
            bool[,] map = {
                { F, F, T, F, F, F, F },
                { F, F, F, F, F, T, F },
                { T, F, F, T, F, T, F },
                { F, F, T, F, F, F, F },
                { F, F, F, F, F, F, T },
                { F, T, T, F, F, F, F },
                { F, F, F, F, T, F, F }
            };

            Check(map, 3);
        }

        public void Random48()
        {
            bool[,] map = {
                { F, F, F, T, F, F, T },
                { F, F, F, F, F, T, F },
                { F, F, F, F, F, F, T },
                { T, F, F, F, F, F, T },
                { F, F, F, F, F, F, F },
                { F, T, F, F, F, F, F },
                { T, F, T, T, F, F, F }
            };

            Check(map, 3);
        }

        public void Random49()
        {
            bool[,] map = {
                { F, F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, T, F, T },
                { F, F, F, T, F, F, F, F, T, T, F },
                { F, F, T, F, F, F, T, F, F, T, F },
                { F, F, F, F, F, F, F, F, F, F, T },
                { F, F, F, F, F, F, F, F, T, F, T },
                { F, F, F, T, F, F, F, T, F, F, F },
                { F, F, F, F, F, F, T, F, F, F, F },
                { F, T, T, F, F, T, F, F, F, F, T },
                { F, F, T, T, F, F, F, F, F, F, F },
                { F, T, F, F, T, T, F, F, T, F, F }
            };

            Check(map, 4);
        }

        public void Random50()
        {
            bool[,] map = {
                { F, T, F, F, F, F },
                { T, F, F, T, F, F },
                { F, F, F, F, F, F },
                { F, T, F, F, F, F },
                { F, F, F, F, F, F },
                { F, F, F, F, F, F }
            };

            Check(map, 4);
        }
    }
}