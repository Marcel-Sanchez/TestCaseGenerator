﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using TestRunnerGUI.Properties;
using Weboo.Assess.Tester;

namespace TestRunnerGUI
{
    public partial class FormMain : Form
    {
        public Assembly TesterAssembly;
        public DirectoryInfo SolutionsFolder;
        public List<string> Assemblies;

        public FormMain()
        {
            Api.MaxPrintCount = 100;
            InitializeComponent();
        }

        private void LinkAssemblyClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (ofAssembly.ShowDialog(this) == DialogResult.OK)
            {
                try
                {
                    TesterAssembly = Assembly.LoadFile(ofAssembly.FileName);
                    linkTesterAssembly.Text = ofAssembly.FileName;
                }
                catch (Exception exc)
                {
                    linkTesterAssembly.Text = Resources.Ellipsis;
                    TesterAssembly = null;
                    MessageBox.Show(this, exc.Message, Resources.ErrorString, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            UpdateRunButton();
        }

        private void LinkSolutionsClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (fbSolutions.ShowDialog(this) == DialogResult.OK)
            {
                try
                {
                    SolutionsFolder = new DirectoryInfo(fbSolutions.SelectedPath);
                    linkSolutionsFolder.Text = fbSolutions.SelectedPath;
                    PopulateTests();
                }
                catch (Exception exc)
                {
                    linkSolutionsFolder.Text = Resources.Ellipsis;
                    SolutionsFolder = null;
                    Assemblies = null;
                    MessageBox.Show(this, exc.Message, Resources.ErrorString, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            UpdateRunButton();
        }

        private void PopulateTests()
        {
            Assemblies = new List<string>();
            gridResults.Rows.Clear();

            foreach (var directory in SolutionsFolder.EnumerateDirectories())
            {
                string assembly = LocateAssembly(directory, txtSolutionsPattern.Text);
                Assemblies.Add(assembly);
                gridResults.Rows.Add(true, directory.Name, assembly, null);
            }
        }

        private static string LocateAssembly(DirectoryInfo directory, string pattern)
        {
            FileInfo bestFile = null;

            foreach (var fileInfo in DFS(directory, pattern))
            {
                if (bestFile == null || bestFile.LastWriteTime < fileInfo.LastWriteTime)
                    bestFile = fileInfo;
            }

            if (bestFile == null)
                return null;

            return bestFile.FullName;
        }

        private static IEnumerable<FileInfo> DFS(DirectoryInfo directory, string pattern)
        {
            foreach (var file in directory.EnumerateFiles())
                if (Regex.IsMatch(file.FullName, pattern))
                    yield return file;

            foreach (var directoryInfo in directory.EnumerateDirectories())
                foreach (var fileInfo in DFS(directoryInfo, pattern))
                    yield return fileInfo;
        }

        private void UpdateRunButton()
        {
            btnRun.Enabled = (TesterAssembly != null && SolutionsFolder != null);
        }

        private void BtnRunClicked(object sender, EventArgs e)
        {
            progressBarTester.Maximum = TestSuite.AutoDiscover(TesterAssembly).CasesCount * Assemblies.Count(asm => asm != null);
            progressBarTester.Value = 0;

            btnRun.Enabled = false;

            var thread = new Thread(() =>
            {
                //for (int i = 0; i < Assemblies.Count; i++)
                Parallel.For(0, Assemblies.Count, new ParallelOptions { MaxDegreeOfParallelism = Environment.ProcessorCount }, i =>
                {
                    int index = i;

                    if (!(bool)(gridResults["EnabledColumn", index].Value)) return;

                    var asm = Assemblies[i];
                    if (asm == null) return;

                    var suite = TestSuite.AutoDiscover(TesterAssembly);

                    Invoke(new Action(() =>
                    {
                        gridResults["ResultColumn", index].Value = string.Format("Running... (0/{0})", suite.CasesCount);
                    }));

                    var totalResult = new TestSuiteResult();

                    for (int testCase = 0; testCase < suite.CasesCount; testCase++)
                    {
                        //var pThread = new Thread(() =>
                        //{

                        var pInfo = new ProcessStartInfo("TestRunner.exe",
                            string.Format("\"{0}\" \"{1}\" \"{2}\"", TesterAssembly.Location, asm, testCase))
                        {
                            RedirectStandardError = true,
                            UseShellExecute = false,
                            CreateNoWindow = true
                        };

                        var p = Process.Start(pInfo);

                        try
                        {
                            var formatter = new XmlSerializer(typeof(TestCaseResult));
                            var result = formatter.Deserialize(p.StandardError) as TestCaseResult;

                            //lock (totalResult)
                            //{
                            
                            totalResult.Add(result);
                            //}
                        }
                        catch (Exception)
                        {
                            //lock (totalResult)
                            //{
                            totalResult.Add(new TestCaseResult(1, 0, 1, new string[0], new[] { "Stack overflow" }));
                            //}
                        }

                        p.WaitForExit();

                        int caseId = testCase + 1;

                        Invoke(new Action(() =>
                        {
                            gridResults["ResultColumn", index].Value = string.Format("Running... ({0}/{1}) - {2}",
                                caseId, suite.CasesCount, totalResult);

                            progressBarTester.Value += 1;
                        }));

                        //});

                        //pThread.IsBackground = true;
                        //pThread.Start();
                    }

                    //while (totalResult.CasesCount < suite.CasesCount)
                    //{
                    //    Thread.Sleep(100);
                    //}

                    Invoke(new Action(() =>
                    {
                        gridResults["ResultColumn", index].Value = totalResult;
                        gridResults["ResultColumn", index].ToolTipText = GetTooltip(totalResult);
                    }));
                });

                Invoke(new Action(() => btnRun.Enabled = true));

            })
            {
                IsBackground = true,
            };

            thread.Start();
        }

        private string GetTooltip(TestSuiteResult result)
        {
            var sb = new StringBuilder();

            //sb.AppendLine("Passed assertions:");

            //foreach (var testCase in result.TestCases)
            //    foreach (var assertion in testCase.PassedAssertions)
            //        sb.AppendLine(string.Format("  {0}: {1}", testCase, assertion));

            sb.AppendLine("Failed assertions:");

            foreach (var testCase in result.TestCases)
                foreach (var assertion in testCase.FailedAssertions)
                    sb.AppendLine(string.Format("  {0}: {1}", testCase, assertion));

            return sb.ToString();
        }

        private void BtnExportClick(object sender, EventArgs e)
        {
            if (sfReport.ShowDialog(this) == DialogResult.OK)
                using (var writer = new StreamWriter(sfReport.FileName))
                    for (int i = 0; i < gridResults.RowCount; i++)
                        writer.WriteLine("{0},{1}", gridResults["NameColumn", i].Value, gridResults["ResultColumn", i].Value);
        }

        private void BtnGetFailedCases(object sender, EventArgs e)
        {
            Dictionary<string, int> failedCases = new Dictionary<string, int>();
            for (int i = 0; i < gridResults.RowCount; i++)
            {
                var testSuite = (gridResults["ResultColumn", i].Value as TestSuiteResult);
                foreach (var testCase in testSuite.TestCases)
                {
                    foreach (var failedAssertion in testCase.FailedAssertions)
                    {
                        var split = failedAssertion.Split(new[] { '[', ']' }, StringSplitOptions.RemoveEmptyEntries);
                        if (split.Length < 2)
                            continue;

                        var key = split[1];

                        int value;
                        if (failedCases.TryGetValue(key, out value))
                        {
                            failedCases[key] = value + 1;
                        }
                        else
                        {
                            failedCases[key] = 1;
                        }
                    }
                }
            }
            if (sfFailedCases.ShowDialog(this) == DialogResult.OK)
                using (var writer = new StreamWriter(sfFailedCases.FileName))
                {
                    foreach (var kvp in failedCases.OrderByDescending(k => k.Value))
                    {
                        writer.WriteLine("{0},{1}", kvp.Key, kvp.Value);
                    }
                }
        }

        private void BtnDetailsClick(object sender, EventArgs e)
        {
            if (TesterAssembly == null) return;

            var suite = TestSuite.AutoDiscover(TesterAssembly);

            if (sfDetails.ShowDialog() == DialogResult.OK)
                using (var sw = new StreamWriter(sfDetails.FileName))
                    foreach (var testCase in suite.Cases)
                        sw.WriteLine(testCase);
        }
    }
}