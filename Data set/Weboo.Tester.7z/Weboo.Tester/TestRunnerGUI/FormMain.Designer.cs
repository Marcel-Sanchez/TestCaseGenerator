﻿namespace TestRunnerGUI {
    partial class FormMain {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.linkTesterAssembly = new System.Windows.Forms.LinkLabel();
            this.lblTesterAssembly = new System.Windows.Forms.Label();
            this.lblSolutionsFolder = new System.Windows.Forms.Label();
            this.linkSolutionsFolder = new System.Windows.Forms.LinkLabel();
            this.lblSolutionsPattern = new System.Windows.Forms.Label();
            this.txtSolutionsPattern = new System.Windows.Forms.TextBox();
            this.btnRun = new System.Windows.Forms.Button();
            this.ofAssembly = new System.Windows.Forms.OpenFileDialog();
            this.fbSolutions = new System.Windows.Forms.FolderBrowserDialog();
            this.progressBarTester = new System.Windows.Forms.ProgressBar();
            this.gridResults = new System.Windows.Forms.DataGridView();
            this.EnabledColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.NameColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssemblyColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ResultColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnExport = new System.Windows.Forms.Button();
            this.sfReport = new System.Windows.Forms.SaveFileDialog();
            this.btnDetails = new System.Windows.Forms.Button();
            this.sfDetails = new System.Windows.Forms.SaveFileDialog();
            this.sfFailedCases = new System.Windows.Forms.SaveFileDialog();
            this.btnTopTenCases = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gridResults)).BeginInit();
            this.SuspendLayout();
            // 
            // linkTesterAssembly
            // 
            this.linkTesterAssembly.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.linkTesterAssembly.AutoEllipsis = true;
            this.linkTesterAssembly.Location = new System.Drawing.Point(102, 9);
            this.linkTesterAssembly.Name = "linkTesterAssembly";
            this.linkTesterAssembly.Size = new System.Drawing.Size(550, 13);
            this.linkTesterAssembly.TabIndex = 0;
            this.linkTesterAssembly.TabStop = true;
            this.linkTesterAssembly.Text = "...";
            this.linkTesterAssembly.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkAssemblyClicked);
            // 
            // lblTesterAssembly
            // 
            this.lblTesterAssembly.AutoSize = true;
            this.lblTesterAssembly.Location = new System.Drawing.Point(12, 9);
            this.lblTesterAssembly.Name = "lblTesterAssembly";
            this.lblTesterAssembly.Size = new System.Drawing.Size(84, 13);
            this.lblTesterAssembly.TabIndex = 1;
            this.lblTesterAssembly.Text = "Tester &Assembly";
            // 
            // lblSolutionsFolder
            // 
            this.lblSolutionsFolder.AutoSize = true;
            this.lblSolutionsFolder.Location = new System.Drawing.Point(12, 34);
            this.lblSolutionsFolder.Name = "lblSolutionsFolder";
            this.lblSolutionsFolder.Size = new System.Drawing.Size(82, 13);
            this.lblSolutionsFolder.TabIndex = 3;
            this.lblSolutionsFolder.Text = "Solutions &Folder";
            // 
            // linkSolutionsFolder
            // 
            this.linkSolutionsFolder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.linkSolutionsFolder.AutoEllipsis = true;
            this.linkSolutionsFolder.Location = new System.Drawing.Point(102, 34);
            this.linkSolutionsFolder.Name = "linkSolutionsFolder";
            this.linkSolutionsFolder.Size = new System.Drawing.Size(550, 13);
            this.linkSolutionsFolder.TabIndex = 2;
            this.linkSolutionsFolder.TabStop = true;
            this.linkSolutionsFolder.Text = "...";
            this.linkSolutionsFolder.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkSolutionsClicked);
            // 
            // lblSolutionsPattern
            // 
            this.lblSolutionsPattern.AutoSize = true;
            this.lblSolutionsPattern.Location = new System.Drawing.Point(12, 61);
            this.lblSolutionsPattern.Name = "lblSolutionsPattern";
            this.lblSolutionsPattern.Size = new System.Drawing.Size(82, 13);
            this.lblSolutionsPattern.TabIndex = 4;
            this.lblSolutionsPattern.Text = "Solution &Pattern";
            // 
            // txtSolutionsPattern
            // 
            this.txtSolutionsPattern.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSolutionsPattern.Location = new System.Drawing.Point(105, 58);
            this.txtSolutionsPattern.Name = "txtSolutionsPattern";
            this.txtSolutionsPattern.Size = new System.Drawing.Size(547, 20);
            this.txtSolutionsPattern.TabIndex = 5;
            this.txtSolutionsPattern.Text = ".dll";
            // 
            // btnRun
            // 
            this.btnRun.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRun.Enabled = false;
            this.btnRun.Location = new System.Drawing.Point(556, 84);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(96, 32);
            this.btnRun.TabIndex = 6;
            this.btnRun.Text = "&Run";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.BtnRunClicked);
            // 
            // ofAssembly
            // 
            this.ofAssembly.Filter = "Assemblies|*.dll|All files|*.*";
            this.ofAssembly.Title = "Locate Tester Assembly";
            // 
            // fbSolutions
            // 
            this.fbSolutions.SelectedPath = "D:\\!University\\Docencia\\2019 - 2020";
            this.fbSolutions.ShowNewFolderButton = false;
            // 
            // progressBarTester
            // 
            this.progressBarTester.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBarTester.Location = new System.Drawing.Point(15, 95);
            this.progressBarTester.Name = "progressBarTester";
            this.progressBarTester.Size = new System.Drawing.Size(535, 11);
            this.progressBarTester.TabIndex = 7;
            // 
            // gridResults
            // 
            this.gridResults.AllowUserToAddRows = false;
            this.gridResults.AllowUserToDeleteRows = false;
            this.gridResults.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridResults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridResults.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EnabledColumn,
            this.NameColumn,
            this.AssemblyColumn,
            this.ResultColumn});
            this.gridResults.Location = new System.Drawing.Point(15, 122);
            this.gridResults.Name = "gridResults";
            this.gridResults.Size = new System.Drawing.Size(637, 326);
            this.gridResults.TabIndex = 8;
            // 
            // EnabledColumn
            // 
            this.EnabledColumn.HeaderText = "Enabled";
            this.EnabledColumn.Name = "EnabledColumn";
            // 
            // NameColumn
            // 
            this.NameColumn.HeaderText = "Name";
            this.NameColumn.Name = "NameColumn";
            this.NameColumn.ReadOnly = true;
            this.NameColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // AssemblyColumn
            // 
            this.AssemblyColumn.HeaderText = "Assembly";
            this.AssemblyColumn.Name = "AssemblyColumn";
            this.AssemblyColumn.ReadOnly = true;
            // 
            // ResultColumn
            // 
            this.ResultColumn.HeaderText = "Result";
            this.ResultColumn.Name = "ResultColumn";
            this.ResultColumn.ReadOnly = true;
            // 
            // btnExport
            // 
            this.btnExport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExport.Location = new System.Drawing.Point(556, 453);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(96, 23);
            this.btnExport.TabIndex = 9;
            this.btnExport.Text = "&Export";
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.BtnExportClick);
            // 
            // sfReport
            // 
            this.sfReport.DefaultExt = "csv";
            this.sfReport.FileName = "report.csv";
            this.sfReport.Filter = "CSV File|*.csv";
            this.sfReport.Title = "Save report file";
            // 
            // btnDetails
            // 
            this.btnDetails.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDetails.Location = new System.Drawing.Point(454, 453);
            this.btnDetails.Name = "btnDetails";
            this.btnDetails.Size = new System.Drawing.Size(96, 23);
            this.btnDetails.TabIndex = 10;
            this.btnDetails.Text = "&Details";
            this.btnDetails.UseVisualStyleBackColor = true;
            this.btnDetails.Click += new System.EventHandler(this.BtnDetailsClick);
            // 
            // sfDetails
            // 
            this.sfDetails.DefaultExt = "csv";
            this.sfDetails.FileName = "cases.txt";
            this.sfDetails.Filter = "Text File|*.txt";
            this.sfDetails.Title = "Save test cases file";
            // 
            // sfFailedCases
            // 
            this.sfFailedCases.DefaultExt = "csv";
            this.sfFailedCases.FileName = "globalFailedCases.csv";
            this.sfFailedCases.Filter = "CSV File|*.csv";
            this.sfFailedCases.Title = "Save global failed cases";
            // 
            // btnTopTenCases
            // 
            this.btnTopTenCases.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnTopTenCases.Location = new System.Drawing.Point(15, 454);
            this.btnTopTenCases.Name = "btnTopTenCases";
            this.btnTopTenCases.Size = new System.Drawing.Size(103, 23);
            this.btnTopTenCases.TabIndex = 11;
            this.btnTopTenCases.Text = "&Save Failed Cases";
            this.btnTopTenCases.UseVisualStyleBackColor = true;
            this.btnTopTenCases.Click += new System.EventHandler(this.BtnGetFailedCases);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(664, 488);
            this.Controls.Add(this.btnTopTenCases);
            this.Controls.Add(this.btnDetails);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.gridResults);
            this.Controls.Add(this.progressBarTester);
            this.Controls.Add(this.btnRun);
            this.Controls.Add(this.txtSolutionsPattern);
            this.Controls.Add(this.lblSolutionsPattern);
            this.Controls.Add(this.lblSolutionsFolder);
            this.Controls.Add(this.linkSolutionsFolder);
            this.Controls.Add(this.lblTesterAssembly);
            this.Controls.Add(this.linkTesterAssembly);
            this.Name = "FormMain";
            this.Text = "Test Runner";
            ((System.ComponentModel.ISupportInitialize)(this.gridResults)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel linkTesterAssembly;
        private System.Windows.Forms.Label lblTesterAssembly;
        private System.Windows.Forms.Label lblSolutionsFolder;
        private System.Windows.Forms.LinkLabel linkSolutionsFolder;
        private System.Windows.Forms.Label lblSolutionsPattern;
        private System.Windows.Forms.TextBox txtSolutionsPattern;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.OpenFileDialog ofAssembly;
        private System.Windows.Forms.FolderBrowserDialog fbSolutions;
        private System.Windows.Forms.ProgressBar progressBarTester;
        private System.Windows.Forms.DataGridView gridResults;
        private System.Windows.Forms.DataGridViewCheckBoxColumn EnabledColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn AssemblyColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ResultColumn;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.SaveFileDialog sfReport;
        private System.Windows.Forms.Button btnDetails;
        private System.Windows.Forms.SaveFileDialog sfDetails;
        private System.Windows.Forms.SaveFileDialog sfFailedCases;
        private System.Windows.Forms.Button btnTopTenCases;
    }
}

