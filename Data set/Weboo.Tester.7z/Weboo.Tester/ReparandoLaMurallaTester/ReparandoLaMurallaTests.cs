﻿using Weboo.Assess.Tester;

namespace ReparandoLaMurallaTester
{
    public abstract class ReparandoLaMurallaTest : TestCase
    {
        public static int Student(int[] secciones, int posiciones)
        {
            return ReflectionHelper.InvokeStatic<int>("Weboo.Examen.Muralla", "Repara", secciones, posiciones);
        }
    }

    public class Ejemplo1Test : ReparandoLaMurallaTest
    {
        public void Ejemplo1()
        {
            int[] secciones = { 10, 10, 10, 10 };
            int constructores = 2;
            int sol = 20;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class Ejemplo2Test : ReparandoLaMurallaTest
    {
        public void Ejemplo2()
        {
            int[] secciones = { 10, 20, 30, 40 };
            int constructores = 2;
            int sol = 60;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class PocosConstructores1Test : ReparandoLaMurallaTest
    {
        public void PocosConstructores1()
        {
            int[] secciones = { 10 };
            int constructores = 1;
            int sol = 10;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class PocosConstructores2Test : ReparandoLaMurallaTest
    {
        public void PocosConstructores2()
        {
            int[] secciones = { 10, 10, 20, 20, 10, 10, 1, 2, 3, 4, 5, 6, 8, 1000 };
            int constructores = 1;
            int sol = 1109;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class PocosConstructores3Test : ReparandoLaMurallaTest
    {
        public void PocosConstructores3()
        {
            int[] secciones = { 179, 119, 258, 294, 107, 307, 138, 224, 342, 469, 106, 163, 301, 66, 47, 208, 457, 101, 52, 207 };
            int constructores = 2;
            int sol = 2177;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class PocosConstructores4Test : ReparandoLaMurallaTest
    {
        public void PocosConstructores4()
        {
            int[] secciones = { 95, 177, 77, 152, 187, 128, 87, 76, 83, 54, 131, 192, 87, 175, 154 };
            int constructores = 2;
            int sol = 952;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class PocosConstructores5Test : ReparandoLaMurallaTest
    {
        public void PocosConstructores5()
        {
            int[] secciones = { 87, 164, 195, 54, 141, 123, 110, 113, 128, 128, 121, 185, 72, 193, 90 };
            int constructores = 3;
            int sol = 661;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class PocosConstructores6Test : ReparandoLaMurallaTest
    {
        public void PocosConstructores6()
        {
            int[] secciones = { 30, 90, 70, 60, 50, 10, 70, 70, 30, 20, 30, 40, 30, 10, 90, 80, 80, 90, 20, 50, 10, 30, 90, 50, 70, 10, 70, 20, 10, 60 };
            int constructores = 3;
            int sol = 490;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class PocosConstructores7Test : ReparandoLaMurallaTest
    {
        public void PocosConstructores7()
        {
            int[] secciones = { 18, 17, 27, 98, 50, 37, 15, 49, 22, 27, 47, 88, 80, 77, 13, 54, 42, 51, 83, 26, 34, 89, 26, 25, 93, 64, 66, 46, 61, 83 };
            int constructores = 4;
            int sol = 407;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class PocosConstructores8Test : ReparandoLaMurallaTest
    {
        public void PocosConstructores8()
        {
            int[] secciones = { 109, 105, 118, 102, 118, 100, 109, 114, 105, 112, 104, 117, 108, 110, 103, 110, 115, 114, 104, 105, 109, 116, 112, 108, 119, 109, 115, 116, 118, 114, 107, 111, 119, 113, 103, 109, 109, 113, 117, 111, 116, 115, 103, 108, 100, 105, 109, 119, 103, 104 };
            int constructores = 6;
            int sol = 980;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class PocosConstructores9Test : ReparandoLaMurallaTest
    {
        public void PocosConstructores9()
        {
            int[] secciones = { 106, 106, 107, 104, 118, 107, 106, 102, 107, 118, 115, 101, 102, 109, 118, 111, 110, 117, 108, 115, 119, 115, 107, 111, 112, 112, 114, 117, 117, 108, 109, 109, 108, 117, 114, 105, 116, 103, 112, 110 };
            int constructores = 8;
            int sol = 568;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class PocosConstructores10Test : ReparandoLaMurallaTest
    {
        public void PocosConstructores10()
        {
            int[] secciones = { 102, 110, 118, 105, 103, 113, 106, 100, 109, 112, 115, 102, 117, 114, 114, 101, 115, 114, 109, 102, 109, 117, 112, 116, 117, 104, 101, 112, 106, 119 };
            int constructores = 10;
            int sol = 345;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class MuchosConstructores1Test : ReparandoLaMurallaTest
    {
        public void MuchosConstructores1()
        {
            int[] secciones = { 105, 103, 115, 112, 113, 119, 113, 109, 115, 110, 106, 115, 111, 119, 102, 116, 118, 100, 104, 112, 114, 111, 113, 106, 100, 114, 110, 100 };
            int constructores = 15;
            int sol = 230;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class MuchosConstructores2Test : ReparandoLaMurallaTest
    {
        public void MuchosConstructores2()
        {
            int[] secciones = { 70, 80, 50, 140, 90, 140, 80, 110, 180, 10, 160, 150, 140, 160, 150, 120, 40, 130, 80, 60, 60, 70, 10, 110, 60, 20, 70, 100, 40, 70 };
            int constructores = 20;
            int sol = 190;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class MuchosConstructores3Test : ReparandoLaMurallaTest
    {
        public void MuchosConstructores3()
        {
            int[] secciones = { 60, 20, 55, 15, 35, 15, 65, 60, 65, 35, 50, 25, 10, 65, 20, 50, 70, 5, 50, 60, 70, 55, 60, 5, 55, 5, 15, 5, 30, 5 };
            int constructores = 20;
            int sol = 70;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class MuchosConstructores4Test : ReparandoLaMurallaTest
    {
        public void MuchosConstructores4()
        {
            int[] secciones = { 65, 25, 25, 40, 45, 30, 50, 10, 35, 70, 60, 45, 25, 30, 15, 50, 70, 30, 55, 15 };
            int constructores = 10;
            int sol = 100;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class MuchosConstructores5Test : ReparandoLaMurallaTest
    {
        public void MuchosConstructores5()
        {
            int[] secciones = { 20, 15, 30, 45, 65, 30, 55, 30, 30, 50, 20, 15, 5, 50, 55, 25, 25, 50, 15, 5, 20, 15, 65, 10, 30, 55, 60, 45, 70, 60, 60, 65, 40, 15, 40, 25, 20, 40, 45, 45 };
            int constructores = 35;
            int sol = 70;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class MuchosConstructores6Test : ReparandoLaMurallaTest
    {
        public void MuchosConstructores6()
        {
            int[] secciones = { 65, 65, 55, 5, 40, 30, 50, 60, 45, 25, 5, 55, 40, 70, 20, 25, 5, 55, 15, 60, 35, 25, 65, 60, 40, 50, 30, 50, 40, 55 };
            int constructores = 18;
            int sol = 95;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class MuchosConstructores7Test : ReparandoLaMurallaTest
    {
        public void MuchosConstructores7()
        {
            int[] secciones = { 30, 15, 40, 35, 70, 40, 40, 45, 15, 10, 50, 10, 35, 60, 25, 50, 5, 20, 15, 55, 65, 45, 40, 5, 10, 10, 25, 45, 30, 10, 10, 35, 20, 25, 35, 45, 40, 40, 20, 30 };
            int constructores = 38;
            int sol = 70;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class MuchosConstructores8Test : ReparandoLaMurallaTest
    {
        public void MuchosConstructores8()
        {
            int[] secciones = { 24, 27, 42, 33, 24, 33, 36, 36, 27, 24, 15, 42, 33, 21, 27, 30, 27, 33, 27, 42, 42, 27, 27, 15, 33, 27, 15, 15, 24, 27 };
            int constructores = 20;
            int sol = 57;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class MuchosConstructores9Test : ReparandoLaMurallaTest
    {
        public void MuchosConstructores9()
        {
            int[] secciones = { 72, 72, 56, 56, 48, 68, 52, 72, 76, 76, 40, 48, 64, 64, 76, 44, 44, 40, 64, 56, 76, 72, 72, 64, 60, 40, 68, 72, 44, 48, 68, 40, 68, 72, 48, 44, 40, 48, 48, 68 };
            int constructores = 8;
            int sol = 324;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class MuchosConstructores10Test : ReparandoLaMurallaTest
    {
        public void MuchosConstructores10()
        {
            int[] secciones = { 120, 152, 104, 96, 112, 128, 144, 96, 152, 120, 88, 120, 128, 136, 128, 136, 120, 88, 80, 104, 104, 128, 112, 80, 136, 152, 96, 104, 80, 128, 96, 80, 144, 128, 80, 96, 144, 88, 128, 112, 104, 120, 120, 112, 96, 88, 128, 128, 144, 112, 144, 88, 112, 136, 128, 152, 112, 96, 112, 120, 112, 112, 96, 104, 96, 88, 136, 152, 136, 112, 144, 104, 120, 120, 152, 144, 80, 80, 136, 128, 104, 120, 112, 128, 136, 80, 120, 80, 80, 88, 136, 120, 136, 80, 80, 152, 96, 96, 96, 88 };
            int constructores = 100;
            int sol = 152;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class CornerCase1Test : ReparandoLaMurallaTest
    {
        public void CornerCase1()
        {
            int[] secciones = { 1, 1, 1 };
            int constructores = 3;
            int sol = 1;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class CornerCase2Test : ReparandoLaMurallaTest
    {
        public void CornerCase2()
        {
            int[] secciones = { 10, 1, 1 };
            int constructores = 2;
            int sol = 10;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class CornerCase3Test : ReparandoLaMurallaTest
    {
        public void CornerCase3()
        {
            int[] secciones = { 1, 1, 10 };
            int constructores = 2;
            int sol = 10;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class CornerCase4Test : ReparandoLaMurallaTest
    {
        public void CornerCase4()
        {
            int[] secciones = { 13, 8, 21, 1 };
            int constructores = 2;
            int sol = 22;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class CornerCase5Test : ReparandoLaMurallaTest
    {
        public void CornerCase5()
        {
            int[] secciones = { 13, 8, 1, 1, 1, 1, 21, 1 };
            int constructores = 3;
            int sol = 22;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class Random1Test : ReparandoLaMurallaTest
    {
        public void Random1()
        {
            int[] secciones = { 152, 128, 80, 88, 128, 88, 128, 104, 144, 120, 120, 96, 104, 120, 96, 96, 128, 136, 120, 144, 112, 152, 88, 136, 88 };
            int constructores = 16;
            int sol = 240;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class Random2Test : ReparandoLaMurallaTest
    {
        public void Random2()
        {
            int[] secciones = { 96, 128, 80, 120, 80, 112, 128, 152, 144, 88, 104, 96, 152, 104, 128, 136, 88, 144, 96, 112, 88, 104, 120, 112, 120 };
            int constructores = 12;
            int sol = 296;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class Random3Test : ReparandoLaMurallaTest
    {
        public void Random3()
        {
            int[] secciones = { 120, 88, 144, 104, 104, 128, 88, 120, 128, 152, 80, 144, 128, 136, 120, 152, 112, 80, 120, 144, 80, 80, 112, 128, 136, 144, 136, 120, 136, 144 };
            int constructores = 19;
            int sol = 264;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class Random4Test : ReparandoLaMurallaTest
    {
        public void Random4()
        {
            int[] secciones = { 128, 120, 96, 80, 88, 80, 88, 112, 104, 136, 128, 120, 152, 96, 144, 80, 112, 136, 128, 88, 88, 96, 152, 152, 152, 120, 96, 96 };
            int constructores = 12;
            int sol = 312;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class Random5Test : ReparandoLaMurallaTest
    {
        public void Random5()
        {
            int[] secciones = { 144, 144, 128, 144, 96, 104, 136, 112, 120, 128, 96, 80, 120, 104, 136, 104, 104, 104, 128, 96, 128, 112, 120, 152, 80, 96, 80, 152 };
            int constructores = 14;
            int sol = 288;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class Random6Test : ReparandoLaMurallaTest
    {
        public void Random6()
        {
            int[] secciones = { 25, 58, 42, 58, 11, 28, 47, 42, 53, 26, 58, 26, 17, 29, 40, 13, 43, 21, 19, 24, 48, 32, 40, 45, 13 };
            int constructores = 12;
            int sol = 91;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class Random7Test : ReparandoLaMurallaTest
    {
        public void Random7()
        {
            int[] secciones = { 43, 53, 56, 14, 10, 36, 38, 46, 25, 40, 21, 24, 55, 12, 45, 56, 59, 44, 38, 26, 33, 24, 33, 10, 39, 22, 45, 55, 27, 14 };
            int constructores = 18;
            int sol = 80;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class Random8Test : ReparandoLaMurallaTest
    {
        public void Random8()
        {
            int[] secciones = { 36, 37, 39, 11, 44, 30, 28, 13, 22, 51, 11, 27, 56, 58, 55, 27, 25, 34, 25, 11, 15, 48, 24, 37, 14, 43, 11, 25, 27, 40, 25, 10, 32, 51, 52, 55, 37, 53, 49, 36 };
            int constructores = 38;
            int sol = 58;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class Random9Test : ReparandoLaMurallaTest
    {
        public void Random9()
        {
            int[] secciones = { 27, 55, 20, 39, 27, 16, 15, 42, 46, 13, 23, 24, 48, 20, 55, 11, 17, 47, 16, 38, 41, 23, 14, 14, 57, 41, 14, 24, 32, 30, 53, 46, 25, 58, 38, 58, 33, 10, 29, 22 };
            int constructores = 33;
            int sol = 58;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }

    public class Random10Test : ReparandoLaMurallaTest
    {
        public void Random10()
        {
            int[] secciones = { 54, 20, 39, 46, 49, 53, 55, 39, 40, 45, 52, 51, 28, 26, 49, 16, 33, 41, 38, 59, 11, 10, 23, 55, 24, 16, 59, 13, 45, 18 };
            int constructores = 22;
            int sol = 72;

            Assert.That(Student(secciones, constructores), Is.EqualTo(sol));
        }
    }
}
