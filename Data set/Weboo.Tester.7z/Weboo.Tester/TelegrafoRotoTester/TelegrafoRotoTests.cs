﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Assess.Tester;

namespace TelegrafoRotoTester
{
    public abstract class TelegrafoRotoTest : TestCase
    {
        public IEnumerable<string> Student(Dictionary<char, string> alfabeto, string mensaje)
        {
            return ReflectionHelper.InvokeStatic<IEnumerable<string>>("Weboo.Examen.TelegrafoRoto", "DecodificarMensaje", alfabeto, mensaje);
        }

        public void IsNullOrEmpty(IEnumerable<string> solution)
        {
            Assert.That(solution, new NullOrEmpty());
        }

        internal class NullOrEmpty : IAssertion<IEnumerable>
        {
            public bool Assert(IEnumerable item)
            {
                return item == null || !item.GetEnumerator().MoveNext();
            }

            public override string ToString()
            {
                return "is null or empty";
            }
        }
    }

    public class Test1 : TelegrafoRotoTest
    {
        public void Ejemplo1()
        {
            Dictionary<char, string> alfabetoMorse = new Dictionary<char, string>
            {
                { 'a',".-"},    {'b',"-..."}, {'c',"-.-."},  {'d',"-.."},   {'e',"."},
                { 'f',"..-."},  {'g',"--."},  {'h',"...."},  {'i',".."},    {'j',".---"},
                { 'k',"-.-"},   {'l',".-.."}, {'m',"--"},    {'n',"-."},    {'o',"---"},
                { 'p',".--."},  {'q',"--.-"}, {'r',".-."},   {'s',"..."},   {'t',"-"},
                { 'u',"..-"},   {'v',"...-"}, {'w',".--"},   {'x',"-..-"},  {'y',"-.--"},
                { 'z',"--.."}
            };

            string mensaje = "..-";
            Assert.That(Student(alfabetoMorse, mensaje), Is.MultisetEqualTo(new[] { "u", "ea", "it", "eet" }));
        }
    }

    public class Test2 : TelegrafoRotoTest
    {
        public void Ejemplo2()
        {
            Dictionary<char, string> alfabetoMorse = new Dictionary<char, string>
            {
                { 'a',".-"},    {'b',"-..."}, {'c',"-.-."},  {'d',"-.."},   {'e',"."},
                { 'f',"..-."},  {'g',"--."},  {'h',"...."},  {'i',".."},    {'j',".---"},
                { 'k',"-.-"},   {'l',".-.."}, {'m',"--"},    {'n',"-."},    {'o',"---"},
                { 'p',".--."},  {'q',"--.-"}, {'r',".-."},   {'s',"..."},   {'t',"-"},
                { 'u',"..-"},   {'v',"...-"}, {'w',".--"},   {'x',"-..-"},  {'y',"-.--"},
                { 'z',"--.."}
            };

            string mensaje = "...";
            Assert.That(Student(alfabetoMorse, mensaje), Is.MultisetEqualTo(new[] { "eee", "ei", "ie", "s" }));
        }
    }

    public class Test3 : TelegrafoRotoTest
    {
        public void Ejemplo3()
        {
            Dictionary<char, string> alfabetoHawaiano = new Dictionary<char, string>
            {
                { 'a', "..-" }, { 'e', ".-.-." }, { 'h', "--.-" }, { 'i', ".-" },
                { 'k', "--." }, { 'l', "--" }, { 'm', "-.-.-" }, { 'n', "-.-" },
                { 'o', "." }, { 'p', "-.." }, { 'u', ".-." }, { 'w', ".-.-." }
            };

            string mensaje = "-";
            IsNullOrEmpty(Student(alfabetoHawaiano, mensaje));
        }
    }


    public class Test4 : TelegrafoRotoTest
    {
        public void Vacio1()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', "." }, { 'e', ".." }, { 'h', "...." }
            };

            string mensaje = "-";
            IsNullOrEmpty(Student(alfabeto, mensaje));
        }
    }

    public class Test5 : TelegrafoRotoTest
    {
        public void Vacio2()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', "." }, { 'e', ".." }, { 'i', ".-" }
            };

            string mensaje = "-.";
            IsNullOrEmpty(Student(alfabeto, mensaje));
        }
    }

    public class Test6 : TelegrafoRotoTest
    {
        public void Vacio3()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', "." }, { 'e', ".." }, { 'i', ".-" }
            };

            string mensaje = "--";
            IsNullOrEmpty(Student(alfabeto, mensaje));
        }
    }

    public class Test7 : TelegrafoRotoTest
    {
        public void Vacio4()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', "." }, { 'e', ".." }, { 'i', ".--" }
            };

            string mensaje = ".---";
            IsNullOrEmpty(Student(alfabeto, mensaje));
        }
    }

    public class Test8 : TelegrafoRotoTest
    {
        public void Vacio5()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', "." }, { 'e', ".." }, { 'i', ".--" }
            };

            string mensaje = "..---";
            IsNullOrEmpty(Student(alfabeto, mensaje));
        }
    }

    public class Test9 : TelegrafoRotoTest
    {
        public void Vacio6()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', "." }, { 'e', ".." }, { 'i', ".--" }
            };

            string mensaje = "..--..-";
            IsNullOrEmpty(Student(alfabeto, mensaje));
        }
    }

    public class Test10 : TelegrafoRotoTest
    {
        public void Vacio7()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', "." }, { 'e', ".." }, { 'i', "--" }
            };

            string mensaje = "-..--";
            IsNullOrEmpty(Student(alfabeto, mensaje));
        }
    }

    public class Test11 : TelegrafoRotoTest
    {
        public void Vacio8()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', "-" }
            };

            string mensaje = ".";
            IsNullOrEmpty(Student(alfabeto, mensaje));
        }
    }

    public class Test12 : TelegrafoRotoTest
    {
        public void Vacio9()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
            };

            string mensaje = ".";
            IsNullOrEmpty(Student(alfabeto, mensaje));
        }
    }

    public class Test13 : TelegrafoRotoTest
    {
        public void Vacio10()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a',".-"},    {'b',"-..."}, {'c',"-.-."},  {'d',"-.."},   {'e',"."},
                { 'f',"..-."},  {'g',"--."},  {'h',"...."},  {'i',".."},    {'j',".---"},
                { 'k',"-.-"},   {'l',".-.."}, {'m',"--"},    {'n',"-."},    {'o',"---"},
                { 'p',".--."},  {'q',"--.-"}, {'r',".-."},   {'s',"..."},   {'t',"-"},
                { 'u',"..-"},   {'v',"...-"}, {'w',".--"},   {'x',"-..-"},  {'y',"-.--"},
                { 'z',"--.."}
            };

            string mensaje = "";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "" }));
        }
    }

    public class Test14 : TelegrafoRotoTest
    {
        public void Vacio11()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
            };

            string mensaje = "";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "" }));
        }
    }

    public class Test15 : TelegrafoRotoTest
    {
        public void CodigosRepetidos1()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', "." }, { 'b', "." }
            };

            string mensaje = "..";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "aa", "ab", "ba", "bb" }));
        }
    }

    public class Test16 : TelegrafoRotoTest
    {
        public void CodigosRepetidos2()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', ".-." }, { 'b', "-" }, { 'c', ".-." }, { 'd', ".-" }
            };

            string mensaje = "..";
            IsNullOrEmpty(Student(alfabeto, mensaje));
        }
    }

    public class Test17 : TelegrafoRotoTest
    {
        public void CodigosRepetidos3()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', ".-." }, { 'b', ".-." }, { 'c', ".-." }, { 'd', ".-" }
            };

            string mensaje = ".-.-";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "dd" }));
        }
    }

    public class Test18 : TelegrafoRotoTest
    {
        public void CodigosRepetidos4()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', ".-." }, { 'b', "-" }, { 'c', "." }, { 'd', ".-" }, { 'e', "." }
            };

            string mensaje = ".-.-.";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "abc", "abe", "cba", "cbcbc", "cbcbe", "cbdc", "cbde", "cbebc", "cbebe", "da", "dcbc", "dcbe", "ddc", "dde", "debc", "debe", "eba", "ebcbc", "ebcbe", "ebdc", "ebde", "ebebc", "ebebe" }));
        }
    }

    public class Test19 : TelegrafoRotoTest
    {
        public void CodigosRepetidos5()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', ".-." }, { 'b', ".-" }, { 'c', "." }, { 'd', ".-" }, { 'e', "." }
            };

            string mensaje = ".-.-.";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "ba", "bbc", "bbe", "bdc", "bde", "da", "dbc", "dbe", "ddc", "dde" }));
        }
    }

    public class Test20 : TelegrafoRotoTest
    {
        public void Regular1()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', "." }, { 'b', "-" }
            };

            string mensaje = "-.-.--...-----........-------";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "bababbaaabbbbbaaaaaaaabbbbbbb" }));
        }
    }

    public class Test21 : TelegrafoRotoTest
    {
        public void Regular2()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', "." }, { 'b', "-" }, { 'c', ".-" }, { 'd', "-." }, { 'e', "---" }
            };

            string mensaje = "---";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "bbb", "e" }));
        }
    }

    public class Test22 : TelegrafoRotoTest
    {
        public void Regular3()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', "." }, { 'b', "-" }, { 'c', ".-" }, { 'd', "--" }, { 'e', "---" }
            };

            string mensaje = "---";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "bbb", "bd", "db", "e" }));
        }
    }

    public class Test23 : TelegrafoRotoTest
    {
        public void Regular4()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', "." }, { 'b', "-" }, { 'c', ".-" }, { 'd', "--" }, { 'e', "---" }
            };

            string mensaje = "---";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "bbb", "bd", "db", "e" }));
        }
    }

    public class Test24 : TelegrafoRotoTest
    {
        public void Regular5()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', "." }, { 'b', "-" }, { 'c', ".-..-.-." }, { 'd', ".." }, { 'e', "---" }
            };

            string mensaje = ".-..-.-.";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "abaababa", "abdbaba", "c" }));
        }
    }

    public class Test25 : TelegrafoRotoTest
    {
        public void Regular6()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', "." }, { 'b', "..-" }, { 'c', ".-..-.-." }, { 'd', ".." }, { 'e', "-" }
            };

            string mensaje = ".-..-.-.-";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "aeaaeaeae", "aebaeae", "aedeaeae", "ce" }));
        }
    }

    public class Test26 : TelegrafoRotoTest
    {
        public void Regular7()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', ".." }, { 'b', ".-" }, { 'c', ".-..-.-." }, { 'd', ".-." }, { 'e', "-" }
            };

            string mensaje = "..-..-.-..-";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "aeaebae", "aeaedb" }));
        }
    }

    public class Test27 : TelegrafoRotoTest
    {
        public void Grande1()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', "." }, { 'b', ".-" }, { 'c', ".-..-.-." }, { 'd', ".-." }, { 'e', "-" },
                { 'f', ".." }, { 'g', "-.-" }, { 'h', "-." }
            };

            string mensaje = "..-..-.";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "aaeaaea", "aaeaah", "aaeaba", "aaead", "aaefea", "aaefh", "aahaea", "aahah", "aahba", "aahd", "abaaea", "abaah", "ababa", "abad", "abfea", "abfh", "adaea", "adah", "adba", "add", "feaaea", "feaah", "feaba", "fead", "fefea", "fefh", "fhaea", "fhah", "fhba", "fhd" }));
        }
    }

    public class Test28 : TelegrafoRotoTest
    {
        public void Grande2()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', "." }, { 'b', ".-" }, { 'c', ".-..-.-." }, { 'd', ".-." }, { 'e', "-" },
                { 'f', ".." }, { 'g', "-.-" }, { 'h', "-." }
            };

            string mensaje = ".-.-----.--";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "aeaeeeeeaee", "aeaeeeeebe", "aeaeeeege", "aeaeeeehee", "aebeeeeaee", "aebeeeebe", "aebeeege", "aebeeehee", "ageeeeaee", "ageeeebe", "ageeege", "ageeehee", "aheeeeeaee", "aheeeeebe", "aheeeege", "aheeeehee", "baeeeeeaee", "baeeeeebe", "baeeeege", "baeeeehee", "bbeeeeaee", "bbeeeebe", "bbeeege", "bbeeehee", "deeeeeaee", "deeeeebe", "deeeege", "deeeehee" }));
        }
    }

    public class Test29 : TelegrafoRotoTest
    {
        public void Grande3()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a', "." }, { 'b', ".-" }, { 'c', ".-..-.-." }, { 'd', ".-." }, { 'e', "-" },
                { 'f', ".." }, { 'g', "-.-" }, { 'h', "-." }, { 'z', ".-.--"}
            };

            string mensaje = ".-.--.--";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "aeaeeaee", "aeaeebe", "aeaege", "aeaehee", "aebeaee", "aebebe", "aebge", "aebhee", "ageaee", "agebe", "agge", "aghee", "aheeaee", "aheebe", "ahege", "ahehee", "baeeaee", "baeebe", "baege", "baehee", "bbeaee", "bbebe", "bbge", "bbhee", "deeaee", "deebe", "dege", "dehee", "zaee", "zbe" }));
        }
    }

    public class Test30 : TelegrafoRotoTest
    {
        public void Grande4()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a',".-"},    {'b',"-..."}, {'c',"-.-."},  {'d',"-.."},   {'e',"."},
                { 'f',"..-."},  {'g',"--."},  {'h',"...."},  {'i',".."},    {'j',".---"},
                { 'k',"-.-"},   {'l',".-.."}, {'m',"--"},    {'n',"-."},    {'o',"---"},
                { 'p',".--."},  {'q',"--.-"}, {'r',".-."},   {'s',"..."},   {'t',"-"},
                { 'u',"..-"},   {'v',"...-"}, {'w',".--"},   {'x',"-..-"},  {'y',"-.--"},
                { 'z',"--.."}
            };

            string mensaje = ".-.--.--";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "aakt", "aanm", "aantt", "aatat", "aatem", "aatett", "aatw", "aay", "aegm", "aegtt", "aemat", "aemem", "aemett", "aemw", "aeqt", "aetkt", "aetnm", "aetntt", "aettat", "aettem", "aettett", "aettw", "aety", "apm", "aptt", "awat", "awem", "awett", "aww", "ekkt", "eknm", "ekntt", "ektat", "ektem", "ektett", "ektw", "eky", "engm", "engtt", "enmat", "enmem", "enmett", "enmw", "enqt", "entkt", "entnm", "entntt", "enttat", "enttem", "enttett", "enttw", "enty", "etakt", "etanm", "etantt", "etatat", "etatem", "etatett", "etatw", "etay", "etegm", "etegtt", "etemat", "etemem", "etemett", "etemw", "eteqt", "etetkt", "etetnm", "etetntt", "etettat", "etettem", "etettett", "etettw", "etety", "etpm", "etptt", "etwat", "etwem", "etwett", "etww", "eyat", "eyem", "eyett", "eyw", "rgm", "rgtt", "rmat", "rmem", "rmett", "rmw", "rqt", "rtkt", "rtnm", "rtntt", "rttat", "rttem", "rttett", "rttw", "rty" }));
        }
    }

    public class Test31 : TelegrafoRotoTest
    {
        public void Grande5()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a',".-"},    {'b',"-..."}, {'c',"-.-."},  {'d',"-.."},   {'e',"."},
                { 'f',"..-."},  {'g',"--."},  {'h',"...."},  {'i',".."},    {'j',".---"},
                { 'k',"-.-"},   {'l',".-.."}, {'m',"--"},    {'n',"-."},    {'o',"---"},
                { 'p',".--."},  {'q',"--.-"}, {'r',".-."},   {'s',"..."},   {'t',"-"},
                { 'u',"..-"},   {'v',"...-"}, {'w',".--"},   {'x',"-..-"},  {'y',"-.--"},
                { 'z',"--.."}
            };

            string mensaje = "--.-..--..";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "gdge", "gdmee", "gdmi", "gdtd", "gdtne", "gdttee", "gdtti", "gdz", "gnad", "gnane", "gnatee", "gnati", "gnege", "gnemee", "gnemi", "gnetd", "gnetne", "gnettee", "gnetti", "gnez", "gnpe", "gnwee", "gnwi", "gtead", "gteane", "gteatee", "gteati", "gteege", "gteemee", "gteemi", "gteetd", "gteetne", "gteettee", "gteetti", "gteez", "gtepe", "gtewee", "gtewi", "gtige", "gtimee", "gtimi", "gtitd", "gtitne", "gtittee", "gtitti", "gtiz", "gtud", "gtune", "gtutee", "gtuti", "gxd", "gxne", "gxtee", "gxti", "maead", "maeane", "maeatee", "maeati", "maeege", "maeemee", "maeemi", "maeetd", "maeetne", "maeettee", "maeetti", "maeez", "maepe", "maewee", "maewi", "maige", "maimee", "maimi", "maitd", "maitne", "maittee", "maitti", "maiz", "maud", "maune", "mautee", "mauti", "medge", "medmee", "medmi", "medtd", "medtne", "medttee", "medtti", "medz", "menad", "menane", "menatee", "menati", "menege", "menemee", "menemi", "menetd", "menetne", "menettee", "menetti", "menez", "menpe", "menwee", "menwi", "metead", "meteane", "meteatee", "meteati", "meteege", "meteemee", "meteemi", "meteetd", "meteetne", "meteettee", "meteetti", "meteez", "metepe", "metewee", "metewi", "metige", "metimee", "metimi", "metitd", "metitne", "metittee", "metitti", "metiz", "metud", "metune", "metutee", "metuti", "mexd", "mexne", "mextee", "mexti", "mlge", "mlmee", "mlmi", "mltd", "mltne", "mlttee", "mltti", "mlz", "mrad", "mrane", "mratee", "mrati", "mrege", "mremee", "mremi", "mretd", "mretne", "mrettee", "mretti", "mrez", "mrpe", "mrwee", "mrwi", "qead", "qeane", "qeatee", "qeati", "qeege", "qeemee", "qeemi", "qeetd", "qeetne", "qeettee", "qeetti", "qeez", "qepe", "qewee", "qewi", "qige", "qimee", "qimi", "qitd", "qitne", "qittee", "qitti", "qiz", "qud", "qune", "qutee", "quti", "tcad", "tcane", "tcatee", "tcati", "tcege", "tcemee", "tcemi", "tcetd", "tcetne", "tcettee", "tcetti", "tcez", "tcpe", "tcwee", "tcwi", "tkead", "tkeane", "tkeatee", "tkeati", "tkeege", "tkeemee", "tkeemi", "tkeetd", "tkeetne", "tkeettee", "tkeetti", "tkeez", "tkepe", "tkewee", "tkewi", "tkige", "tkimee", "tkimi", "tkitd", "tkitne", "tkittee", "tkitti", "tkiz", "tkud", "tkune", "tkutee", "tkuti", "tndge", "tndmee", "tndmi", "tndtd", "tndtne", "tndttee", "tndtti", "tndz", "tnnad", "tnnane", "tnnatee", "tnnati", "tnnege", "tnnemee", "tnnemi", "tnnetd", "tnnetne", "tnnettee", "tnnetti", "tnnez", "tnnpe", "tnnwee", "tnnwi", "tntead", "tnteane", "tnteatee", "tnteati", "tnteege", "tnteemee", "tnteemi", "tnteetd", "tnteetne", "tnteettee", "tnteetti", "tnteez", "tntepe", "tntewee", "tntewi", "tntige", "tntimee", "tntimi", "tntitd", "tntitne", "tntittee", "tntitti", "tntiz", "tntud", "tntune", "tntutee", "tntuti", "tnxd", "tnxne", "tnxtee", "tnxti", "ttaead", "ttaeane", "ttaeatee", "ttaeati", "ttaeege", "ttaeemee", "ttaeemi", "ttaeetd", "ttaeetne", "ttaeettee", "ttaeetti", "ttaeez", "ttaepe", "ttaewee", "ttaewi", "ttaige", "ttaimee", "ttaimi", "ttaitd", "ttaitne", "ttaittee", "ttaitti", "ttaiz", "ttaud", "ttaune", "ttautee", "ttauti", "ttedge", "ttedmee", "ttedmi", "ttedtd", "ttedtne", "ttedttee", "ttedtti", "ttedz", "ttenad", "ttenane", "ttenatee", "ttenati", "ttenege", "ttenemee", "ttenemi", "ttenetd", "ttenetne", "ttenettee", "ttenetti", "ttenez", "ttenpe", "ttenwee", "ttenwi", "ttetead", "tteteane", "tteteatee", "tteteati", "tteteege", "tteteemee", "tteteemi", "tteteetd", "tteteetne", "tteteettee", "tteteetti", "tteteez", "ttetepe", "ttetewee", "ttetewi", "ttetige", "ttetimee", "ttetimi", "ttetitd", "ttetitne", "ttetittee", "ttetitti", "ttetiz", "ttetud", "ttetune", "ttetutee", "ttetuti", "ttexd", "ttexne", "ttextee", "ttexti", "ttlge", "ttlmee", "ttlmi", "ttltd", "ttltne", "ttlttee", "ttltti", "ttlz", "ttrad", "ttrane", "ttratee", "ttrati", "ttrege", "ttremee", "ttremi", "ttretd", "ttretne", "ttrettee", "ttretti", "ttrez", "ttrpe", "ttrwee", "ttrwi" }));
        }
    }

    public class Test32 : TelegrafoRotoTest
    {
        public void Grande6()
        {
            Dictionary<char, string> alfabeto = new Dictionary<char, string>
            {
                { 'a',".-"},    {'b',"-..."}, {'c',"-.-."},  {'d',"-.."},   {'e',"."},
                { 'f',"..-."},  {'g',"--."},  {'h',"...."},  {'i',".."},    {'j',".---"},
                { 'k',"-.-"},   {'l',".-.."}, {'m',"--"},    {'n',"-."},    {'o',"---"},
                { 'p',".--."},  {'q',"--.-"}, {'r',".-."},   {'s',"..."},   {'t',"-"},
                { 'u',"..-"},   {'v',"...-"}, {'w',".--"},   {'x',"-..-"},  {'y',"-.--"},
                { 'z',"--.."}
            };

            string mensaje = "......-----";
            Assert.That(Student(alfabeto, mensaje), Is.MultisetEqualTo(new[] { "eeeeeamm", "eeeeeamtt", "eeeeeaot", "eeeeeatmt", "eeeeeato", "eeeeeattm", "eeeeeatttt", "eeeeeemmt", "eeeeeemo", "eeeeeemtm", "eeeeeemttt", "eeeeeeom", "eeeeeeott", "eeeeeetmm", "eeeeeetmtt", "eeeeeetot", "eeeeeettmt", "eeeeeetto", "eeeeeetttm", "eeeeeettttt", "eeeeejm", "eeeeejtt", "eeeeewmt", "eeeeewo", "eeeeewtm", "eeeeewttt", "eeeeimmt", "eeeeimo", "eeeeimtm", "eeeeimttt", "eeeeiom", "eeeeiott", "eeeeitmm", "eeeeitmtt", "eeeeitot", "eeeeittmt", "eeeeitto", "eeeeitttm", "eeeeittttt", "eeeeumm", "eeeeumtt", "eeeeuot", "eeeeutmt", "eeeeuto", "eeeeuttm", "eeeeutttt", "eeeiamm", "eeeiamtt", "eeeiaot", "eeeiatmt", "eeeiato", "eeeiattm", "eeeiatttt", "eeeiemmt", "eeeiemo", "eeeiemtm", "eeeiemttt", "eeeieom", "eeeieott", "eeeietmm", "eeeietmtt", "eeeietot", "eeeiettmt", "eeeietto", "eeeietttm", "eeeiettttt", "eeeijm", "eeeijtt", "eeeiwmt", "eeeiwo", "eeeiwtm", "eeeiwttt", "eeesmmt", "eeesmo", "eeesmtm", "eeesmttt", "eeesom", "eeesott", "eeestmm", "eeestmtt", "eeestot", "eeesttmt", "eeestto", "eeestttm", "eeesttttt", "eeevmm", "eeevmtt", "eeevot", "eeevtmt", "eeevto", "eeevttm", "eeevtttt", "eehmmt", "eehmo", "eehmtm", "eehmttt", "eehom", "eehott", "eehtmm", "eehtmtt", "eehtot", "eehttmt", "eehtto", "eehtttm", "eehttttt", "eeieamm", "eeieamtt", "eeieaot", "eeieatmt", "eeieato", "eeieattm", "eeieatttt", "eeieemmt", "eeieemo", "eeieemtm", "eeieemttt", "eeieeom", "eeieeott", "eeieetmm", "eeieetmtt", "eeieetot", "eeieettmt", "eeieetto", "eeieetttm", "eeieettttt", "eeiejm", "eeiejtt", "eeiewmt", "eeiewo", "eeiewtm", "eeiewttt", "eeiimmt", "eeiimo", "eeiimtm", "eeiimttt", "eeiiom", "eeiiott", "eeiitmm", "eeiitmtt", "eeiitot", "eeiittmt", "eeiitto", "eeiitttm", "eeiittttt", "eeiumm", "eeiumtt", "eeiuot", "eeiutmt", "eeiuto", "eeiuttm", "eeiutttt", "eesamm", "eesamtt", "eesaot", "eesatmt", "eesato", "eesattm", "eesatttt", "eesemmt", "eesemo", "eesemtm", "eesemttt", "eeseom", "eeseott", "eesetmm", "eesetmtt", "eesetot", "eesettmt", "eesetto", "eesetttm", "eesettttt", "eesjm", "eesjtt", "eeswmt", "eeswo", "eeswtm", "eeswttt", "ehamm", "ehamtt", "ehaot", "ehatmt", "ehato", "ehattm", "ehatttt", "ehemmt", "ehemo", "ehemtm", "ehemttt", "eheom", "eheott", "ehetmm", "ehetmtt", "ehetot", "ehettmt", "ehetto", "ehetttm", "ehettttt", "ehjm", "ehjtt", "ehwmt", "ehwo", "ehwtm", "ehwttt", "eieeamm", "eieeamtt", "eieeaot", "eieeatmt", "eieeato", "eieeattm", "eieeatttt", "eieeemmt", "eieeemo", "eieeemtm", "eieeemttt", "eieeeom", "eieeeott", "eieeetmm", "eieeetmtt", "eieeetot", "eieeettmt", "eieeetto", "eieeetttm", "eieeettttt", "eieejm", "eieejtt", "eieewmt", "eieewo", "eieewtm", "eieewttt", "eieimmt", "eieimo", "eieimtm", "eieimttt", "eieiom", "eieiott", "eieitmm", "eieitmtt", "eieitot", "eieittmt", "eieitto", "eieitttm", "eieittttt", "eieumm", "eieumtt", "eieuot", "eieutmt", "eieuto", "eieuttm", "eieutttt", "eiiamm", "eiiamtt", "eiiaot", "eiiatmt", "eiiato", "eiiattm", "eiiatttt", "eiiemmt", "eiiemo", "eiiemtm", "eiiemttt", "eiieom", "eiieott", "eiietmm", "eiietmtt", "eiietot", "eiiettmt", "eiietto", "eiietttm", "eiiettttt", "eiijm", "eiijtt", "eiiwmt", "eiiwo", "eiiwtm", "eiiwttt", "eismmt", "eismo", "eismtm", "eismttt", "eisom", "eisott", "eistmm", "eistmtt", "eistot", "eisttmt", "eistto", "eistttm", "eisttttt", "eivmm", "eivmtt", "eivot", "eivtmt", "eivto", "eivttm", "eivtttt", "eseamm", "eseamtt", "eseaot", "eseatmt", "eseato", "eseattm", "eseatttt", "eseemmt", "eseemo", "eseemtm", "eseemttt", "eseeom", "eseeott", "eseetmm", "eseetmtt", "eseetot", "eseettmt", "eseetto", "eseetttm", "eseettttt", "esejm", "esejtt", "esewmt", "esewo", "esewtm", "esewttt", "esimmt", "esimo", "esimtm", "esimttt", "esiom", "esiott", "esitmm", "esitmtt", "esitot", "esittmt", "esitto", "esitttm", "esittttt", "esumm", "esumtt", "esuot", "esutmt", "esuto", "esuttm", "esutttt", "heamm", "heamtt", "heaot", "heatmt", "heato", "heattm", "heatttt", "heemmt", "heemo", "heemtm", "heemttt", "heeom", "heeott", "heetmm", "heetmtt", "heetot", "heettmt", "heetto", "heetttm", "heettttt", "hejm", "hejtt", "hewmt", "hewo", "hewtm", "hewttt", "himmt", "himo", "himtm", "himttt", "hiom", "hiott", "hitmm", "hitmtt", "hitot", "hittmt", "hitto", "hitttm", "hittttt", "humm", "humtt", "huot", "hutmt", "huto", "huttm", "hutttt", "ieeeamm", "ieeeamtt", "ieeeaot", "ieeeatmt", "ieeeato", "ieeeattm", "ieeeatttt", "ieeeemmt", "ieeeemo", "ieeeemtm", "ieeeemttt", "ieeeeom", "ieeeeott", "ieeeetmm", "ieeeetmtt", "ieeeetot", "ieeeettmt", "ieeeetto", "ieeeetttm", "ieeeettttt", "ieeejm", "ieeejtt", "ieeewmt", "ieeewo", "ieeewtm", "ieeewttt", "ieeimmt", "ieeimo", "ieeimtm", "ieeimttt", "ieeiom", "ieeiott", "ieeitmm", "ieeitmtt", "ieeitot", "ieeittmt", "ieeitto", "ieeitttm", "ieeittttt", "ieeumm", "ieeumtt", "ieeuot", "ieeutmt", "ieeuto", "ieeuttm", "ieeutttt", "ieiamm", "ieiamtt", "ieiaot", "ieiatmt", "ieiato", "ieiattm", "ieiatttt", "ieiemmt", "ieiemo", "ieiemtm", "ieiemttt", "ieieom", "ieieott", "ieietmm", "ieietmtt", "ieietot", "ieiettmt", "ieietto", "ieietttm", "ieiettttt", "ieijm", "ieijtt", "ieiwmt", "ieiwo", "ieiwtm", "ieiwttt", "iesmmt", "iesmo", "iesmtm", "iesmttt", "iesom", "iesott", "iestmm", "iestmtt", "iestot", "iesttmt", "iestto", "iestttm", "iesttttt", "ievmm", "ievmtt", "ievot", "ievtmt", "ievto", "ievttm", "ievtttt", "ihmmt", "ihmo", "ihmtm", "ihmttt", "ihom", "ihott", "ihtmm", "ihtmtt", "ihtot", "ihttmt", "ihtto", "ihtttm", "ihttttt", "iieamm", "iieamtt", "iieaot", "iieatmt", "iieato", "iieattm", "iieatttt", "iieemmt", "iieemo", "iieemtm", "iieemttt", "iieeom", "iieeott", "iieetmm", "iieetmtt", "iieetot", "iieettmt", "iieetto", "iieetttm", "iieettttt", "iiejm", "iiejtt", "iiewmt", "iiewo", "iiewtm", "iiewttt", "iiimmt", "iiimo", "iiimtm", "iiimttt", "iiiom", "iiiott", "iiitmm", "iiitmtt", "iiitot", "iiittmt", "iiitto", "iiitttm", "iiittttt", "iiumm", "iiumtt", "iiuot", "iiutmt", "iiuto", "iiuttm", "iiutttt", "isamm", "isamtt", "isaot", "isatmt", "isato", "isattm", "isatttt", "isemmt", "isemo", "isemtm", "isemttt", "iseom", "iseott", "isetmm", "isetmtt", "isetot", "isettmt", "isetto", "isetttm", "isettttt", "isjm", "isjtt", "iswmt", "iswo", "iswtm", "iswttt", "seeamm", "seeamtt", "seeaot", "seeatmt", "seeato", "seeattm", "seeatttt", "seeemmt", "seeemo", "seeemtm", "seeemttt", "seeeom", "seeeott", "seeetmm", "seeetmtt", "seeetot", "seeettmt", "seeetto", "seeetttm", "seeettttt", "seejm", "seejtt", "seewmt", "seewo", "seewtm", "seewttt", "seimmt", "seimo", "seimtm", "seimttt", "seiom", "seiott", "seitmm", "seitmtt", "seitot", "seittmt", "seitto", "seitttm", "seittttt", "seumm", "seumtt", "seuot", "seutmt", "seuto", "seuttm", "seutttt", "siamm", "siamtt", "siaot", "siatmt", "siato", "siattm", "siatttt", "siemmt", "siemo", "siemtm", "siemttt", "sieom", "sieott", "sietmm", "sietmtt", "sietot", "siettmt", "sietto", "sietttm", "siettttt", "sijm", "sijtt", "siwmt", "siwo", "siwtm", "siwttt", "ssmmt", "ssmo", "ssmtm", "ssmttt", "ssom", "ssott", "sstmm", "sstmtt", "sstot", "ssttmt", "sstto", "sstttm", "ssttttt", "svmm", "svmtt", "svot", "svtmt", "svto", "svttm", "svtttt" }));
        }
    }
}