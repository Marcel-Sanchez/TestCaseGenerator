﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Assess.Tester;

namespace EstabilizarGenesTester
{
    public abstract class EstabilizarGenesTest : TestCase
    {
        public string Student(string gen)
        {
            return ReflectionHelper.InvokeStatic<string>("Weboo.Examen.EstabilizaGenes", "EstabilizarGen", gen);
        }

        private int ComputeExpectedLength(string gen)
        {
            char[] bases = { 'A', 'C', 'T', 'G' };
            int[,] acc = new int[4, gen.Length];
            for (int b = 0; b < bases.Length; b++)
            {
                acc[b, 0] = gen[0] == bases[b] ? 1 : 0;
                for (int i = 1; i < gen.Length; i++)
                    acc[b, i] = acc[b, i - 1] + (gen[i] == bases[b] ? 1 : 0);
            }

            for (int len = 0; len < gen.Length; len++)
            {
                for (int i = 0; i <= gen.Length - len; i++)
                {
                    bool ok = true;
                    for (int b = 0; b < bases.Length; b++)
                    {
                        int count = acc[b, gen.Length - 1] - (i + len > 0 ? acc[b, i + len - 1] : 0) + (i > 0 ? acc[b, i - 1] : 0);
                        if (count > gen.Length / 4)
                        {
                            ok = false;
                        }
                    }
                    if (ok)
                        return len;
                }
            }

            return gen.Length;
        }

        public bool Check(string gen, string solution)
        {
            if (solution.Length != ComputeExpectedLength(gen))
                return false;

            char[] bases = { 'A', 'C', 'T', 'G' };
            string newAdn = solution == string.Empty ? gen : gen.Replace(solution, "");
            for (int i = 0; i < bases.Length; i++)
            {
                int p = 0;
                for (int c = 0; c < newAdn.Length; c++)
                {
                    if (newAdn[c] == bases[i])
                        p++;
                }

                if (p > gen.Length / 4)
                {
                    return false;
                }
            }

            return true;
        }
    }

    public class TestCase1 : EstabilizarGenesTest
    {
        public void Ejemplo1()
        {
            string gen = "TTCG";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase2 : EstabilizarGenesTest
    {
        public void Ejemplo2()
        {
            string gen = "GAAA";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase3 : EstabilizarGenesTest
    {
        public void Ejemplo3()
        {
            string gen = "GAAATAAA";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase4 : EstabilizarGenesTest
    {
        public void Ejemplo4()
        {
            string gen = "ACTGCTAG";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase5 : EstabilizarGenesTest
    {
        public void Ejemplo5()
        {
            string gen = "ACTGAAAG";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase6 : EstabilizarGenesTest
    {
        public void Tricky1()
        {
            string gen = "ATCG";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase7 : EstabilizarGenesTest
    {
        public void Tricky2()
        {
            string gen = "ACTGGTCA";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase8 : EstabilizarGenesTest
    {
        public void Tricky3()
        {
            string gen = "AAAA";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase9 : EstabilizarGenesTest
    {
        public void Tricky4()
        {
            string gen = "TTTTAAAA";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase10 : EstabilizarGenesTest
    {
        public void Tricky5()
        {
            string gen = "AAAATTTTGGGGCCCC";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase11 : EstabilizarGenesTest
    {
        public void Random1()
        {
            string gen = "GCCAACCCAAATAGTCTTCTGTTGCCGGTTTTGTGCCCGGGATAGTGTCTAGACGGCGGAGACTGGTCGCAGGCTACATC";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase12 : EstabilizarGenesTest
    {
        public void Random2()
        {
            string gen = "CATGAATTGAAGTTTGTCCAGGCAAAATCAATCAGAGCAGGGGAGTTCATGGTTTATAGC";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase13 : EstabilizarGenesTest
    {
        public void Random3()
        {
            string gen = "CTGCACTT";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase14 : EstabilizarGenesTest
    {
        public void Random4()
        {
            string gen = "ACCATTAT";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase15 : EstabilizarGenesTest
    {
        public void Random5()
        {
            string gen = "ACGCGGTACACTCATTCAGT";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase16 : EstabilizarGenesTest
    {
        public void Random6()
        {
            string gen = "TTGTGGAATAGAATAACTCACTCC";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase17 : EstabilizarGenesTest
    {
        public void Random7()
        {
            string gen = "GGTGTAGTCACTGGTATGAACCATGTTCGAAGAAGCCCATTAGTTATCCTTA";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase18 : EstabilizarGenesTest
    {
        public void Random8()
        {
            string gen = "TTTGACCGCATCTGGTCATGGAAAACTAGTTATTCTAAGGAAGGCCCTAGACTAGACTTCTCGGTGAATATACTGTGGAC";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase19 : EstabilizarGenesTest
    {
        public void Random9()
        {
            string gen = "CTAACACATCGGTATCCTATAAAAACGAAGTGTTACAAAGTGGAAGTTCGTCCGCGAGAAGGCG";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase20 : EstabilizarGenesTest
    {
        public void Random10()
        {
            string gen = "CCAGGATGGTACATTGCTCAAGCGGATAGACACACATTGCGCTGCGGGCAGA";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase21 : EstabilizarGenesTest
    {
        public void Random11()
        {
            string gen = "AAGGATCGCAGCGTGTAATAGATGTAATAGCGTATCAGTGTGTCTATCCTAGAGGAAACGTTGCTTCG";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase22 : EstabilizarGenesTest
    {
        public void Random12()
        {
            string gen = "CACT";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase23 : EstabilizarGenesTest
    {
        public void Random13()
        {
            string gen = "CCGAGTCCGTTCCCTACCCCTAAAGCGTGTAGAACCGCTTGTCGCATGATAG";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase24 : EstabilizarGenesTest
    {
        public void Random14()
        {
            string gen = "AAAAGGGTGACGGATCGGTGTACACGACTGTTAGCTTAACAACGGGACAGCTTTTCTATCAACACTAGCCCTGATC";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase25 : EstabilizarGenesTest
    {
        public void Random15()
        {
            string gen = "TTGACATGTCGTACGTTCTTGGGACTGGCTAC";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase26 : EstabilizarGenesTest
    {
        public void Random16()
        {
            string gen = "TACGTCAT";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase27 : EstabilizarGenesTest
    {
        public void Random17()
        {
            string gen = "TCGTTGAACGGG";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase28 : EstabilizarGenesTest
    {
        public void Random18()
        {
            string gen = "GTGCAATGCCCAAGCATTCTACGATTCAGACCCGACAGCCACGCGCCTCGAA";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase29 : EstabilizarGenesTest
    {
        public void Random19()
        {
            string gen = "GGTTCTCACCCGACACGTGCGTCCTTCGAAGACCCTAGAGGTGGACGTGCCTCCCAACAGCATGTTACCCGGGGATAGTC";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase30 : EstabilizarGenesTest
    {
        public void Random20()
        {
            string gen = "ACCTTACGTACCCGCACATTGGGAAAAGATGACAACTTAATGACCAGCACCTACGA";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase31 : EstabilizarGenesTest
    {
        public void Random21()
        {
            string gen = "CCTGTTGCCTCTCTCGACAGCCACCCAACAATGACTGGGCGCAGAGTACTGCACGGAGAT";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase32 : EstabilizarGenesTest
    {
        public void Random22()
        {
            string gen = "TCAGGCTTTTGTTGGGTAGCTCTTAACTGATGCAGC";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase33 : EstabilizarGenesTest
    {
        public void Random23()
        {
            string gen = "CTCCTACTCTCACAGC";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase34 : EstabilizarGenesTest
    {
        public void Random24()
        {
            string gen = "CAAACCGTAGGGGTCTTTCCAACCGTGGACAACGTGTCGATGTTGTCGTCCT";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase35 : EstabilizarGenesTest
    {
        public void Random25()
        {
            string gen = "GGTATCCGCTTCGGGCTTGCCGTGAGACTTCTACGCATTAGTATACCGCTCATAGCGACCCCCCGTTGGCCCTAGAACTT";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase36 : EstabilizarGenesTest
    {
        public void Random26()
        {
            string gen = "CAGTCCGTTGAT";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase37 : EstabilizarGenesTest
    {
        public void Random27()
        {
            string gen = "TATAAGTTGTCAATTCGACGATTCGGGAGCAACAGTCACTGAAGCGGC";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase38 : EstabilizarGenesTest
    {
        public void Random28()
        {
            string gen = "CATCGCAACGCCTCCTACTATTACAACAATTACTGGGGAAAGGACTTA";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase39 : EstabilizarGenesTest
    {
        public void Random29()
        {
            string gen = "TTTGCCGGCAGCTCGTGTCCAAGTGGCAAACGTTAGTCATGCCAGGCTGATTCATGTGGGCACAAACC";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase40 : EstabilizarGenesTest
    {
        public void Random30()
        {
            string gen = "CCGCTTGCCTCCACATGGGACACACACAGGAG";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase41 : EstabilizarGenesTest
    {
        public void Random31()
        {
            string gen = "GTATGCTATACGAAAAGGATCCTACTTTGGTAGGTCATGTCGAACCCAGCTCGCCA";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase42 : EstabilizarGenesTest
    {
        public void Random32()
        {
            string gen = "GAATGCCTATAGACCGAAATGGCTGCGACGTGGGACGGTTTCCATACTCATTATAC";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase43 : EstabilizarGenesTest
    {
        public void Random33()
        {
            string gen = "GTGTTGCCTACGTGGGCGCGTTAGTCGGGGCACATCTTTATTGAGGAAGCCAGTCACTCAAGGTTTCACTGTATGCTGAC";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase44 : EstabilizarGenesTest
    {
        public void Random34()
        {
            string gen = "AGCTCTTACTTCGTGTCTTCCGTTCGAAGCTTTTGACCGATCGGTTCGAGGACTCGTTTCGGGTGACACAAT";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase45 : EstabilizarGenesTest
    {
        public void Random35()
        {
            string gen = "GAGATAATATGACAAAGAGTCTCCGGCGCGTTGCGGGCAAACGCTCGCGGACTTCAATTAGTTAGTGTGAGC";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase46 : EstabilizarGenesTest
    {
        public void Random36()
        {
            string gen = "GACA";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase47 : EstabilizarGenesTest
    {
        public void Random37()
        {
            string gen = "TACCACTCGGGCAAGCTCGGACGCAACGCCCCCAAACGGAAAGGTTAGCCGTCATACACCGGGTGTCCTAAACGCC";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase48 : EstabilizarGenesTest
    {
        public void Random38()
        {
            string gen = "ACGCTTACTTAGAGAACTAAAAGTGTTTATAAGACCATTCTTTATGGTAGTGCCCAGAACTGCT";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase49 : EstabilizarGenesTest
    {
        public void Random39()
        {
            string gen = "CCACTATCACGTATATGGCTCCAGTTGTGGGACCAGTTAGGTATATAAGGTC";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
    public class TestCase50 : EstabilizarGenesTest
    {
        public void Random40()
        {
            string gen = "TAAGAACCGCGACCCCTCAACAACTGCCGAAGCTTATGCTCGCAGAGGAAGATCGGGGTA";
            string solution = Student(gen);
            Assert.That(Check(gen, solution), Is.True);
        }
    }
}
