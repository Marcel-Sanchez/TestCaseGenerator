﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Assess.Tester;

namespace ZumaTester
{
    public abstract class ZumaTest : TestCase
    {
        public int[] Student(int[] colors, int[] positions, int[] line)
        {
            return ReflectionHelper.InvokeStatic<int[]>("Weboo.Examen.Zuma", "Simula", colors, positions, line);
        }

        public int[] Benchmark(int[] colors, int[] positions, int[] line)
        {
            for (int k = 0; k < colors.Length; k++)
            {
                int color = colors[k];
                int position = Math.Max(0, Math.Min(line.Length, positions[k]));
                int left = position - 1;
                int right = position;
                int count = 1;

                while (true)
                {
                    int t1 = EqualsInRow(line, color, left, -1);
                    int t2 = EqualsInRow(line, color, right, 1);
                    count += t1 + t2;

                    if (count < 3)
                        break;

                    left -= t1;
                    right += t2;
                    if (left == -1 || right == line.Length || line[left] != line[right])
                        break;
                    color = line[left];
                    count = 0;
                }

                if (right - left < 3)
                {
                    int[] newLine = new int[line.Length + 1];
                    Array.Copy(line, 0, newLine, 0, position);
                    newLine[position] = color;
                    Array.Copy(line, position, newLine, position + 1, line.Length - position);
                    line = newLine;
                }
                else
                {
                    int[] newPista = new int[left + 1 + line.Length - right];
                    Array.Copy(line, 0, newPista, 0, left + 1);
                    Array.Copy(line, right, newPista, left + 1, line.Length - right);
                    line = newPista;
                }
            }

            return line;
        }

        private int EqualsInRow(int[] array, int value, int position, int step)
        {
            int startPosition = position;
            while (-1 < position && position < array.Length && array[position] == value)
            {
                position += step;
            }

            return Math.Abs(startPosition - position);
        }

        public void Check(int[] colors, int[] positions, int[] line)
        {
            int[] studentColors = (int[])colors.Clone();
            int[] studentPositions = (int[])positions.Clone();
            int[] studentLine = (int[])line.Clone();

            int[] benchmarkColors = (int[])colors.Clone();
            int[] benchmarkPositions = (int[])positions.Clone();
            int[] benchmarkLine = (int[])line.Clone();

            Assert.That(Student(studentColors, studentPositions, studentLine), Is.SequenceEqualTo(Benchmark(benchmarkColors, benchmarkPositions, benchmarkLine)));
        }
    }

    public class ExampleTests : ZumaTest
    {
        public void Example1()
        {
            int[] colors = { 1, 1, 2, 1 };
            int[] positions = { 3, 0, 2, 0 };
            int[] line = { };
            Check(colors, positions, line);
        }

        public void Example2()
        {
            int[] colors = { 3 };
            int[] positions = { 2 };
            int[] line = { 1, 2, 3, 3, 2, 2, 1, 1 };
            Check(colors, positions, line);
        }

        public void Example3()
        {
            int[] colors = { };
            int[] positions = { };
            int[] line = { 1, 2, 1, 3, 4 };
            Check(colors, positions, line);
        }

        public void Example4()
        {
            int[] colors = { 4 };
            int[] positions = { 2 };
            int[] line = { 1, 4, 4, 3, 3, 3 };
            Check(colors, positions, line);
        }
    }

    public class BasicTests : ZumaTest
    {
        public void Basic1()
        {
            int[] colors = { 1 };
            int[] positions = { 0 };
            int[] line = { };
            Check(colors, positions, line);
        }

        public void Basic2()
        {
            int[] colors = { 1, 1 };
            int[] positions = { 0, 1 };
            int[] line = { };
            Check(colors, positions, line);
        }

        public void Basic3()
        {
            int[] colors = { 1, 1, 1 };
            int[] positions = { 0, 1, 2 };
            int[] line = { };
            Check(colors, positions, line);
        }

        public void Basic4()
        {
            int[] colors = { 1, 3, 2 };
            int[] positions = { 0, 1, 2 };
            int[] line = { };
            Check(colors, positions, line);
        }

        public void Basic5()
        {
            int[] colors = { 1, 3, 2 };
            int[] positions = { 0, 0, 0 };
            int[] line = { };
            Check(colors, positions, line);
        }

        public void Basic6()
        {
            int[] colors = { 1, 3, 2 };
            int[] positions = { 0, 1, 2 };
            int[] line = { 4 };
            Check(colors, positions, line);
        }

        public void Basic7()
        {
            int[] colors = { 1, 3, 2 };
            int[] positions = { 0, 0, 0 };
            int[] line = { 4 };
            Check(colors, positions, line);
        }

        public void Basic8()
        {
            int[] colors = { 1 };
            int[] positions = { 1 };
            int[] line = { 1, 1 };
            Check(colors, positions, line);
        }

        public void Basic9()
        {
            int[] colors = { 1, 2, 1 };
            int[] positions = { 0, 0, 1 };
            int[] line = { 1 };
            Check(colors, positions, line);
        }

        public void Basic10()
        {
            int[] colors = { 1, 2, 1 };
            int[] positions = { 0, 0, 3 };
            int[] line = { 1 };
            Check(colors, positions, line);
        }

        public void Basic11()
        {
            int[] colors = { 1, 2, 1 };
            int[] positions = { 0, 2, 0 };
            int[] line = { 1 };
            Check(colors, positions, line);
        }

        public void Basic12()
        {
            int[] colors = { 2, 2, 2 };
            int[] positions = { 1, 2, 3 };
            int[] line = { 1, 1 };
            Check(colors, positions, line);
        }

        public void Basic13()
        {
            int[] colors = { 2, 2, 1 };
            int[] positions = { 1, 2, 3 };
            int[] line = { 1, 1 };
            Check(colors, positions, line);
        }

        public void Basic14()
        {
            int[] colors = { 2, 2, 1, 2 };
            int[] positions = { 1, 2, 3, 1 };
            int[] line = { 1, 1 };
            Check(colors, positions, line);
        }

        public void Basic15()
        {
            int[] colors = { 2, 2, 1, 2, 2 };
            int[] positions = { 1, 2, 3, 0, 0 };
            int[] line = { 1, 1 };
            Check(colors, positions, line);
        }

        public void Basic16()
        {
            int[] colors = { 1 };
            int[] positions = { 4 };
            int[] line = { 8, 2, 2, 1, 1, 2, 2, 8, 8 };
            Check(colors, positions, line);
        }

        public void Basic17()
        {
            int[] colors = { 1 };
            int[] positions = { 6 };
            int[] line = { 1, 1, 8, 8, 2, 2, 1, 1, 2, 2, 8, 1, 1 };
            Check(colors, positions, line);
        }

        public void Basic18()
        {
            int[] colors = { 1 };
            int[] positions = { 6 };
            int[] line = { 1, 8, 8, 2, 2, 1, 1, 2, 2, 8, 1 };
            Check(colors, positions, line);
        }

        public void Basic19()
        {
            int[] colors = { 1, 1, 1, 1, 1 };
            int[] positions = { 1, 3, 5, 7, 0 };
            int[] line = { 2, 3, 4, 3 };
            Check(colors, positions, line);
        }

        public void Basic20()
        {
            int[] colors = { 3, 2, 3 };
            int[] positions = { 0, 4, 2 };
            int[] line = { 2, 3, 3 };
            Check(colors, positions, line);
        }

        public void Basic21()
        {
            int[] colors = { 9, 9, 9, 9, 9, 9, 9, 9 };
            int[] positions = { 0, 2, 9, 3, 1, 3, 2, 3 };
            int[] line = { 2, 3, 3 };
            Check(colors, positions, line);
        }
    }

    public class CornerCases : ZumaTest
    {
        public void NoBalls1()
        {
            int[] colors = { };
            int[] positions = { };
            int[] line = { };
            Check(colors, positions, line);
        }

        public void NoBalls2()
        {
            int[] colors = { };
            int[] positions = { };
            int[] line = { 1, 5, 3 };
            Check(colors, positions, line);
        }

        public void PositionOutOfRange1()
        {
            int[] colors = { 1 };
            int[] positions = { -5 };
            int[] line = { };
            Check(colors, positions, line);
        }

        public void PositionOutOfRange2()
        {
            int[] colors = { 1 };
            int[] positions = { 10 };
            int[] line = { };
            Check(colors, positions, line);
        }

        public void PositionOutOfRange3()
        {
            int[] colors = { 1 };
            int[] positions = { 10 };
            int[] line = { 5 };
            Check(colors, positions, line);
        }

        public void PositionOutOfRange4()
        {
            int[] colors = { 1 };
            int[] positions = { -4 };
            int[] line = { 5 };
            Check(colors, positions, line);
        }

        public void PositionOutOfRange5()
        {
            int[] colors = { 5 };
            int[] positions = { 100 };
            int[] line = { 5, 5 };
            Check(colors, positions, line);
        }

        public void BrekeableBlock1()
        {
            int[] colors = { };
            int[] positions = { };
            int[] line = { 5, 5, 5 };
            Check(colors, positions, line);
        }

        public void BreakeableBlock2()
        {
            int[] colors = { 1 };
            int[] positions = { 0 };
            int[] line = { 5, 5, 5 };
            Check(colors, positions, line);
        }

        public void BreakeableBlock3()
        {
            int[] colors = { 5 };
            int[] positions = { 0 };
            int[] line = { 5, 5, 5 };
            Check(colors, positions, line);
        }

        public void BreakeableBlock4()
        {
            int[] colors = { 1 };
            int[] positions = { 0 };
            int[] line = { 1, 1, 5, 5, 5 };
            Check(colors, positions, line);
        }

        public void BreakeableBlock5()
        {
            int[] colors = { 1 };
            int[] positions = { 5 };
            int[] line = { 5, 5, 5, 1, 1 };
            Check(colors, positions, line);
        }

        public void BreakeableBlock6()
        {
            int[] colors = { 1 };
            int[] positions = { 5 };
            int[] line = { 5, 5, 5, 1, 1, 5 };
            Check(colors, positions, line);
        }

        public void BreakeableBlock7()
        {
            int[] colors = { 1 };
            int[] positions = { 5 };
            int[] line = { 5, 5, 5, 1, 1, 5, 5, 5 };
            Check(colors, positions, line);
        }

        public void BreakeableBlock8()
        {
            int[] colors = { 1 };
            int[] positions = { 5 };
            int[] line = { 5, 5, 5, 1, 1, 8, 8, 8 };
            Check(colors, positions, line);
        }

        public void BreakeableBlock9()
        {
            int[] colors = { 8 };
            int[] positions = { 5 };
            int[] line = { 5, 5, 5, 1, 1, 8, 8, 8, 1 };
            Check(colors, positions, line);
        }

        public void BreakeableBlock10()
        {
            int[] colors = { 8 };
            int[] positions = { 8 };
            int[] line = { 1, 1, 1, 5, 5, 5, 1, 1, 8, 8, 8, 1 };
            Check(colors, positions, line);
        }

        public void BreakeableBlock11()
        {
            int[] colors = { 3, 3, 3 };
            int[] positions = { 1, 1, 1 };
            int[] line = { 4, 4, 4 };
            Check(colors, positions, line);
        }

        public void BreakeableBlock12()
        {
            int[] colors = { 7, 3, 3, 3 };
            int[] positions = { 2, 1, 1, 1 };
            int[] line = { 4, 4, 4 };
            Check(colors, positions, line);
        }

        public void BreakeableBlock13()
        {
            int[] colors = { 7, 3, 3, 3 };
            int[] positions = { 1, 2, 2, 2 };
            int[] line = { 4, 4, 4 };
            Check(colors, positions, line);
        }

        public void BreakeableBlock14()
        {
            int[] colors = { 7, 7, 3, 3 };
            int[] positions = { 3, 4, 8, 8 };
            int[] line = { 4, 4, 4, 4, 4, 4, 4 };
            Check(colors, positions, line);
        }

        public void BreakeableBlock15()
        {
            int[] colors = { 3, 3 };
            int[] positions = { 3, 4 };
            int[] line = { 1, 1, 1, 3, 2 };
            Check(colors, positions, line);
        }

        public void NegativeValues1()
        {
            int[] colors = { -1 };
            int[] positions = { 0 };
            int[] line = { -1, -20, 0, 2 };
            Check(colors, positions, line);
        }

        public void NegativeValues2()
        {
            int[] colors = { -1 };
            int[] positions = { 3 };
            int[] line = { -1, -20, 0, 2 };
            Check(colors, positions, line);
        }

        public void NegativeValues3()
        {
            int[] colors = { -1, 38, -100 };
            int[] positions = { 3, -9, 6 };
            int[] line = { -1, 2000, -20, -393, 7 };
            Check(colors, positions, line);
        }
    }
}
