﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Assess.Tester;

namespace TarzanTester
{
    public abstract class TarzanTest : TestCase
    {
        public static int Student(int[,] tablas)
        {
            return ReflectionHelper.InvokeStatic<int>("Weboo.Examen.Tarzan", "ConstruyeEscaleras", tablas);
        }
    }

    public class ExampleTest : TarzanTest
    {
        public void Example1()
        {
            int[,] tablas = {
                { 2, 3, 2 },
                { 2, 3, 2 },
                { 2, 3, 2 }
            };
            int solution = 3;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void Example2()
        {
            int[,] tablas = {
                { 2, 4, 2, 3, 1 },
                { 1, 3, 3, 5, 3 },
                { 3, 4, 3, 4, 2 },
                { 2, 2, 5, 2, 2 },
                { 1, 5, 4, 4, 1 }
            };
            int solution = 4;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void Example3()
        {
            int[,] tablas = {
               { 1, 2, 2, 3, 3 },
               { 5, 2, 4, 5, 4 },
               { 2, 5, 2, 3, 1 },
               { 3, 2, 5, 1, 1 },
               { 2, 3, 4, 5, 1 }
            };
            int solution = 1;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void Example4()
        {
            int[,] tablas = {
               { 4, 5, 4, 5, 5 },
               { 3, 2, 1, 5, 2 },
               { 3, 3, 4, 1, 2 },
               { 5, 2, 4, 2, 5 },
               { 3, 2, 1, 4, 1 }
            };
            int solution = 0;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void Example5()
        {
            int[,] tablas = {
               { 2, 2, 1 },
               { 1, 1, 2 },
               { 3, 3, 3 },
               { 4, 4, 4 }
            };
            int solution = 3;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }
    }

    public class GreaterOrEqualInnerHoles : TarzanTest
    {
        public void GEInnerHoles1()
        {
            int[,] tablas = {
                { 1, 1, 1, 1 },
                { 2, 2, 2, 2 },
                { 1, 1, 1, 1 },
                { 3, 3, 3, 3 }
            };
            int solution = 4;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void GEInnerHoles2()
        {
            int[,] tablas = {
                { 1, 80, 1 },
                { 2, 20, 2 },
                { 4, 10, 4 }
            };
            int solution = 3;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void GEInnerHoles3()
        {
            int[,] tablas = {
                { 1, 4, 2, 1 },
                { 2, 5, 3, 2 },
                { 4, 6, 1, 4 },
                { 1, 3, 3, 1 }
            };
            int solution = 3;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void GEInnerHoles4()
        {
            int[,] tablas = {
                {  8,  4,  2,  7 },
                {  7,  7,  3,  7 },
                { 10,  6,  1,  7 },
                {  9,  9,  3,  7 }
            };
            int solution = 0;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void GEInnerHoles5()
        {
            int[,] tablas = {
                {  8,  4,  2,  8,  8 },
                {  7,  7,  3,  7,  7 },
                { 10,  6,  1, 20, 10 },
                {  9,  9,  3,  9,  9 }
            };
            int solution = 0;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void GEInnerHoles6()
        {
            int[,] tablas = {
                {  8,  4,  2,  4,  8 },
                {  7,  6,  3,  3,  7 },
                { 10,  8,  1,  7, 10 },
                {  9,  9, 13,  4,  9 }
            };
            int solution = 1;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void GEInnerHoles7()
        {
            int[,] tablas = {
                {  8,  1,  1,  1,  8 },
                {  7,  1, 10,  1,  7 },
                { 10,  1,  1,  1, 10 },
                {  9,  7,  1,  8,  9 }
            };
            int solution = 1;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void GEInnerHoles8() // No pueden ir dos por el mismo agujero
        {
            int[,] tablas = {
                {  8,  1,  1,  1,  8 },
                {  7,  1, 10,  1,  7 },
                { 10,  1,  1,  1, 10 },
                {  9,  9,  1,  9,  9 }
            };
            int solution = 1;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void GEInnerHoles9() // No pueden ir dos por el mismo agujero
        {
            int[,] tablas = {
                {  8,  1, 10,  8 },
                {  7, 10, 10,  7 },
                { 10,  1, 10, 10 },
                {  9,  1, 10,  9 }
            };
            int solution = 1;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void GEInnerHoles10()
        {
            int[,] tablas = {
                {  8,  1, 10,  1 },
                {  7, 10, 10,  1 },
                { 10,  9, 10,  8 },
                {  9,  1, 10,  9 }
            };
            int solution = 2;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }
    }

    public class EqualEnds : TarzanTest
    {
        public void EqualEnds1()
        {
            int[,] tablas = {
                { 1, 4, 2, 3 },
                { 2, 5, 3, 6 },
                { 4, 6, 1, 8 }
            };
            int solution = 0;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void EqualEnds2()
        {
            int[,] tablas = {
                { 1, 4, 2, 1 },
                { 2, 5, 3, 1 },
                { 4, 6, 1, 1 }
            };
            int solution = 1;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void EqualEnds3()
        {
            int[,] tablas = {
                { 5, 4, 7, 8 },
                { 8, 4, 8, 7 },
                { 4, 4, 1, 5 }
            };
            int solution = 0;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void EqualEnds4()
        {
            int[,] tablas = {
                { 5, 8, 7, 8 },
                { 8, 4, 8, 7 },
                { 4, 4, 5, 4 }
            };
            int solution = 2;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void EqualEnds5()
        {
            int[,] tablas = {
                {  5,  8,  7,  5 },
                {  8, 10,  8,  8 },
                {  4,  4,  5,  4 },
                {  2, 10,  7,  9 }
            };
            int solution = 3;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }
    }

    public class NotCross : TarzanTest
    {
        public void NotCross1()
        {
            int[,] tablas = {
                { 1, 4, 3 },
                { 3, 1, 1 }
            };
            int solution = 1;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void NotCross2()
        {
            int[,] tablas = {
                { 3, 1, 3, 3 },
                { 7, 2, 1, 1 },
                { 3, 4, 7, 7 },
                { 3, 8, 1, 4 }
            };
            int solution = 2;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void NotCross3()
        {
            int[,] tablas = {
                { 3, 1, 3, 1, 3 },
                { 7, 2, 1, 1, 1 },
                { 9, 4, 7, 4, 7 },
                { 9, 8, 1, 8, 4 }
            };
            int solution = 2;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void NotCross4()
        {
            int[,] tablas = {
                { 4, 8, 4 },
                { 9, 3, 9 },
                { 9, 1, 9 },
                { 8, 4, 8 }
            };
            int solution = 1;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void NotCross5()
        {
            int[,] tablas = {
                { 4, 8, 8 },
                { 9, 3, 9 },
                { 9, 8, 9 },
                { 8, 4, 4 }
            };
            int solution = 1;

            Assert.That(Student(tablas), Is.EqualTo(solution));
        }
    }

    public class Extremes : TarzanTest
    {
        public void Big1()
        {
            int[,] tablas = {
                { 5, 1, 1, 1, 1, 1, 1, 1 },
                { 4, 1, 1, 1, 1, 1, 1, 1 },
                { 3, 1, 1, 1, 1, 1, 1, 1 },
                { 9, 1, 1, 1, 1, 1, 1, 1 },
                { 1, 1, 1, 1, 1, 1, 1, 1 },
                { 3, 1, 1, 1, 1, 1, 1, 1 },
                { 4, 1, 1, 1, 1, 1, 1, 1 },
                { 2, 1, 1, 1, 1, 1, 1, 1 }
            };
            int solution = 1;
            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void Big2()
        {
            int[,] tablas = {
                { 1, 1, 1, 1, 1 },
                { 1, 1, 1, 1, 1 },
                { 1, 1, 1, 1, 1 },
                { 1, 1, 1, 1, 1 },
                { 1, 1, 1, 1, 1 },
            };
            int solution = 5;
            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void Short1()
        {
            int[,] tablas = {
                { 1, 1 }
            };
            int solution = 1;
            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void Short2()
        {
            int[,] tablas = {
                { 1, 8 }
            };
            int solution = 0;
            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void ManySticks1()
        {
            int[,] tablas = {
                { 4, 8, 5, 7, 8, 4, 5, 9, 7, 9, 5, 2, 4 }
            };
            int solution = 0;
            Assert.That(Student(tablas), Is.EqualTo(solution));
        }

        public void ManySticks2()
        {
            int[,] tablas = {
                { 4, 8, 5, 7, 6, 4, 8, 9, 7, 5, 5, 2, 4 },
                { 2, 8, 5, 7, 8, 4, 3, 9, 7, 9, 5, 1, 2 }
            };
            int solution = 1;
            Assert.That(Student(tablas), Is.EqualTo(solution));
        }
    }
}
