﻿using ConceptosSocraticos;
using System.Collections.Generic;
using System.Linq;
using Weboo.Assess.Tester;

namespace TorneoFilosoficoTester
{
    public abstract class TorneoFilosoficoTest : InterfaceTester<ITorneoFilosofico>
    {
        protected override ITorneoFilosofico BuildBenchmark(object[] args)
        {
            return new TorneoFilosofico();
        }

        protected override ITorneoFilosofico BuildTarget(object[] args)
        {
            return ReflectionHelper.CreateInstance<ITorneoFilosofico>();
        }

        protected int Comparison(Filosofo x, Filosofo y)
        {
            return y.Conocimiento - x.Conocimiento;
        }

        protected void CheckLeaders()
        {
            var leaderBySchool = Benchmark.DameEscuelas()
                .ToDictionary<string, string, string>(m => m, m => null);
            foreach (var leader in Target.FilosofosMasDestacados())
            {
                var schoolName = Benchmark.PerteneceAEscuela(leader);
                if (!leaderBySchool.ContainsKey(schoolName))
                {
                    Assert.Fail($"La escuela '{schoolName}' no está registrada o desapareció.");
                    return;
                }
                if (leaderBySchool[schoolName] != null)
                {
                    Assert.Fail($"Se devolvieron dos filósofos ({leaderBySchool[schoolName]}, {leader.Nombre}) de la escuela '{schoolName}'.");
                    return;
                }

                var schoolMembers = Benchmark.Miembros(schoolName);
                var greatestKnowledge = schoolMembers.Max(m => m.Conocimiento);
                if (leader.Conocimiento != greatestKnowledge)
                {
                    var realLeader = schoolMembers.First(m => m.Conocimiento == greatestKnowledge);
                    Assert.Fail($"El filósofo {realLeader} tiene más conocimiento que {leader}.");
                    return;
                }
                leaderBySchool[schoolName] = leader.Nombre;
            }

            foreach (var item in leaderBySchool)
            {
                if (item.Value == null)
                {
                    Assert.Fail($"No se devolvió un filósofo destacado para la escuela '{item.Key}'.");
                    return;
                }
            }
        }
    }

    public class Ejemplo1Test : TorneoFilosoficoTest
    {
        public void Ejemplo1()
        {
            Initialize();

            CheckMultiSet(m => m.DameEscuelas());
            Check(m => m.PerteneceAEscuela(new Filosofo("Tales")));
        }
    }

    public class Ejemplo2Test : TorneoFilosoficoTest
    {
        public void Ejemplo2()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Escuela de Mileto", new Filosofo[3] {
                new Filosofo("Tales", 5),
                new Filosofo("Anaximandro", 4),
                new Filosofo("Anaximenes", 3)
            }));
            Perform(m => m.RegistraEscuela("Escuela eleatica", new Filosofo[2] {
                new Filosofo("Parmenides", 6),
                new Filosofo("Zenon de Elea", 2),
            }));

            Check(m => m.PerteneceAEscuela(new Filosofo("Parmenides")));
            CheckMultiSet(m => m.DameEscuelas());
            CheckLeaders();
            CheckOrdering(m => m.Miembros("Escuela de Mileto"), Comparison);
            CheckOrdering(m => m.Miembros("Escuela eleatica"), Comparison);
        }
    }

    public class Ejemplo3Test : TorneoFilosoficoTest
    {
        public void Ejemplo3()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Escuela de Mileto", new Filosofo[3] {
                new Filosofo("Tales", 5),
                new Filosofo("Anaximandro", 4),
                new Filosofo("Anaximenes", 3)
            }));
            Perform(m => m.RegistraEscuela("Escuela eleatica", new Filosofo[2] {
                new Filosofo("Parmenides", 6),
                new Filosofo("Zenon de Elea", 2),
            }));

            Check(m => m.Compite("Escuela de Mileto", "Escuela eleatica"));
            CheckMultiSet(m => m.DameEscuelas());
            CheckLeaders();
            CheckOrdering(m => m.Miembros("Escuela eleatica"), Comparison);
            Check(m => m.PerteneceAEscuela(new Filosofo("Anaximenes")));
        }
    }

    public class Ejemplo4Test : TorneoFilosoficoTest
    {
        public void Ejemplo4()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Escuela de Mileto", new Filosofo[3] {
                new Filosofo("Tales", 5),
                new Filosofo("Anaximandro", 4),
                new Filosofo("Anaximenes", 3)
            }));
            Perform(m => m.RegistraEscuela("Escuela eleatica", new Filosofo[2] {
                new Filosofo("Parmenides", 6),
                new Filosofo("Zenon de Elea", 2),
            }));
            Perform(m => m.Compite("Escuela de Mileto", "Escuela eleatica"));
            Perform(m => m.RegistraEscuela("Escuela Pitagorica", new Filosofo[4] {
                new Filosofo("Pitagoras", 6),
                new Filosofo("Epicarmo", 5),
                new Filosofo("Alcmeon", 4),
                new Filosofo("Hipaso", 4)
            }));

            Check(m => m.PerteneceAEscuela(new Filosofo("Hipaso")));
            Check(m => m.PerteneceAEscuela(new Filosofo("Cuco")));
            CheckMultiSet(m => m.DameEscuelas());
            CheckLeaders();
        }
    }

    public class Ejemplo5Test : TorneoFilosoficoTest
    {
        public void Ejemplo5()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Escuela de Mileto", new Filosofo[3] {
                new Filosofo("Tales", 5),
                new Filosofo("Anaximandro", 4),
                new Filosofo("Anaximenes", 3)
            }));
            Perform(m => m.RegistraEscuela("Escuela eleatica", new Filosofo[2] {
                new Filosofo("Parmenides", 6),
                new Filosofo("Zenon de Elea", 2),
            }));
            Perform(m => m.Compite("Escuela de Mileto", "Escuela eleatica"));
            Perform(m => m.RegistraEscuela("Escuela Pitagorica", new Filosofo[4] {
                new Filosofo("Pitagoras", 6),
                new Filosofo("Epicarmo", 5),
                new Filosofo("Alcmeon", 4),
                new Filosofo("Hipaso", 4)
            }));

            Check(m => m.Compite("Escuela eleatica", "Escuela Pitagorica"));
            CheckMultiSet(m => m.DameEscuelas());
            CheckLeaders();
            CheckOrdering(m => m.Miembros("Escuela Pitagorica"), Comparison);
            CheckOrdering(m => m.Miembros("Escuela eleatica"), Comparison);
        }
    }

    public class Ejemplo6Test : TorneoFilosoficoTest
    {
        public void Ejemplo6()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Escuela de Mileto", new Filosofo[3] {
                new Filosofo("Tales", 5),
                new Filosofo("Anaximandro", 4),
                new Filosofo("Anaximenes", 3)
            }));
            Perform(m => m.RegistraEscuela("Escuela eleatica", new Filosofo[2] {
                new Filosofo("Parmenides", 6),
                new Filosofo("Zenon de Elea", 2),
            }));
            Perform(m => m.Compite("Escuela de Mileto", "Escuela eleatica"));
            Perform(m => m.RegistraEscuela("Escuela Pitagorica", new Filosofo[4] {
                new Filosofo("Pitagoras", 6),
                new Filosofo("Epicarmo", 5),
                new Filosofo("Alcmeon", 4),
                new Filosofo("Hipaso", 4)
            }));
            Perform(m => m.Compite("Escuela eleatica", "Escuela Pitagorica"));
            Perform(m => m.RegistraEscuela("Escuela peripatetica", new Filosofo[] {
                new Filosofo("Aristoteles", 7),
                new Filosofo("Teofrasto", 6),
                new Filosofo("Aristoxeno", 4),
            }));
            Perform(m => m.RegistraEscuela("Escuela del epicureismo", new Filosofo[] {
                new Filosofo("Epicuro", 7),
                new Filosofo("Filodemo", 6),
            }));

            CheckMultiSet(m => m.DameEscuelas());
            CheckLeaders();
            Check(m => m.PerteneceAEscuela(new Filosofo("Aristoxeno")));
            CheckOrdering(m => m.Miembros("Escuela peripatetica"), Comparison);
            CheckOrdering(m => m.Miembros("Escuela epicureismo"), Comparison);
        }
    }

    public class Ejemplo7Test : TorneoFilosoficoTest
    {
        public void Ejemplo7()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Escuela de Mileto", new Filosofo[3] {
                new Filosofo("Tales", 5),
                new Filosofo("Anaximandro", 4),
                new Filosofo("Anaximenes", 3)
            }));
            Perform(m => m.RegistraEscuela("Escuela eleatica", new Filosofo[2] {
                new Filosofo("Parmenides", 6),
                new Filosofo("Zenon de Elea", 2),
            }));
            Perform(m => m.Compite("Escuela de Mileto", "Escuela eleatica"));
            Perform(m => m.RegistraEscuela("Escuela Pitagorica", new Filosofo[4] {
                new Filosofo("Pitagoras", 6),
                new Filosofo("Epicarmo", 5),
                new Filosofo("Alcmeon", 4),
                new Filosofo("Hipaso", 4)
            }));
            Perform(m => m.Compite("Escuela eleatica", "Escuela Pitagorica"));
            Perform(m => m.RegistraEscuela("Escuela peripatetica", new Filosofo[] {
                new Filosofo("Aristoteles", 7),
                new Filosofo("Teofrasto", 6),
                new Filosofo("Aristoxeno", 4),
            }));
            Perform(m => m.RegistraEscuela("Escuela del epicureismo", new Filosofo[] {
                new Filosofo("Epicuro", 7),
                new Filosofo("Filodemo", 6),
            }));

            Check(m => m.Compite("Escuela peripatetica", "Escuela del epicureismo"));
            CheckMultiSet(m => m.DameEscuelas());
            CheckLeaders();
            Check(m => m.PerteneceAEscuela(new Filosofo("Epicuro")));
            CheckOrdering(m => m.Miembros("Escuela peripatetica"), Comparison);
        }
    }

    public class Ejemplo8Test : TorneoFilosoficoTest
    {
        public void Ejemplo8()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Escuela de Mileto", new Filosofo[3] {
                new Filosofo("Tales", 5),
                new Filosofo("Anaximandro", 4),
                new Filosofo("Anaximenes", 3)
            }));
            Perform(m => m.RegistraEscuela("Escuela eleatica", new Filosofo[2] {
                new Filosofo("Parmenides", 6),
                new Filosofo("Zenon de Elea", 2),
            }));
            Perform(m => m.Compite("Escuela de Mileto", "Escuela eleatica"));
            Perform(m => m.RegistraEscuela("Escuela Pitagorica", new Filosofo[4] {
                new Filosofo("Pitagoras", 6),
                new Filosofo("Epicarmo", 5),
                new Filosofo("Alcmeon", 4),
                new Filosofo("Hipaso", 4)
            }));
            Perform(m => m.Compite("Escuela eleatica", "Escuela Pitagorica"));
            Perform(m => m.RegistraEscuela("Escuela peripatetica", new Filosofo[] {
                new Filosofo("Aristoteles", 7),
                new Filosofo("Teofrasto", 6),
                new Filosofo("Aristoxeno", 4),
            }));
            Perform(m => m.RegistraEscuela("Escuela del epicureismo", new Filosofo[] {
                new Filosofo("Epicuro", 7),
                new Filosofo("Filodemo", 6),
            }));
            Perform(m => m.Compite("Escuela peripatetica", "Escuela del epicureismo"));
            Perform(m => m.RegistraEscuela("Escuela cinica", new Filosofo[] {
                new Filosofo("Antistenes ", 5),
                new Filosofo("Diogenes", 4),
            }));
            Perform(m => m.RegistraEscuela("Escuela del estoicismo", new Filosofo[] {
                new Filosofo("Zenon de Citio ", 5),
                new Filosofo("Cleantes", 4),
            }));

            CheckMultiSet(m => m.DameEscuelas());
            CheckLeaders();
            Check(m => m.PerteneceAEscuela(new Filosofo("Diogenes")));
            CheckOrdering(m => m.Miembros("Escuela Escuela de estoicismo"), Comparison);
        }
    }

    public class Ejemplo9Test : TorneoFilosoficoTest
    {
        public void Ejemplo9()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Escuela de Mileto", new Filosofo[3] {
                new Filosofo("Tales", 5),
                new Filosofo("Anaximandro", 4),
                new Filosofo("Anaximenes", 3)
            }));
            Perform(m => m.RegistraEscuela("Escuela eleatica", new Filosofo[2] {
                new Filosofo("Parmenides", 6),
                new Filosofo("Zenon de Elea", 2),
            }));
            Perform(m => m.Compite("Escuela de Mileto", "Escuela eleatica"));
            Perform(m => m.RegistraEscuela("Escuela Pitagorica", new Filosofo[4] {
                new Filosofo("Pitagoras", 6),
                new Filosofo("Epicarmo", 5),
                new Filosofo("Alcmeon", 4),
                new Filosofo("Hipaso", 4)
            }));
            Perform(m => m.Compite("Escuela eleatica", "Escuela Pitagorica"));
            Perform(m => m.RegistraEscuela("Escuela peripatetica", new Filosofo[] {
                new Filosofo("Aristoteles", 7),
                new Filosofo("Teofrasto", 6),
                new Filosofo("Aristoxeno", 4),
            }));
            Perform(m => m.RegistraEscuela("Escuela del epicureismo", new Filosofo[] {
                new Filosofo("Epicuro", 7),
                new Filosofo("Filodemo", 6),
            }));
            Perform(m => m.Compite("Escuela peripatetica", "Escuela del epicureismo"));
            Perform(m => m.RegistraEscuela("Escuela cinica", new Filosofo[] {
                new Filosofo("Antistenes ", 5),
                new Filosofo("Diogenes", 4),
            }));
            Perform(m => m.RegistraEscuela("Escuela del estoicismo", new Filosofo[] {
                new Filosofo("Zenon de Citio ", 5),
                new Filosofo("Cleantes", 4),
            }));

            Check(m => m.Compite("Escuela cinica", "Escuela del estoicismo"));
            CheckMultiSet(m => m.DameEscuelas());
            CheckLeaders();
            Check(m => m.PerteneceAEscuela(new Filosofo("Diogenes")));
            CheckOrdering(m => m.Miembros("Escuela Escuela de estoicismo"), Comparison);
        }
    }

    public class Miembros1Test : TorneoFilosoficoTest
    {
        public void Miembros1()
        {
            Initialize();

            CheckOrdering(m => m.Miembros("Jónica"), Comparison);
        }
    }

    public class Miembros2Test : TorneoFilosoficoTest
    {
        public void Miembros2()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));

            CheckOrdering(m => m.Miembros("Jónica"), Comparison);
        }
    }

    public class Miembros3Test : TorneoFilosoficoTest
    {
        public void Miembros3()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));

            CheckOrdering(m => m.Miembros("Eleática"), Comparison);
        }
    }

    public class Miembros4Test : TorneoFilosoficoTest
    {
        public void Miembros4()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));

            CheckOrdering(m => m.Miembros("Eleática"), Comparison);
        }
    }

    public class Miembros5Test : TorneoFilosoficoTest
    {
        public void Miembros5()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.Compite("Eleática", "Jónica"));

            CheckOrdering(m => m.Miembros("Pitagórica"), Comparison);
        }
    }

    public class Miembros6Test : TorneoFilosoficoTest
    {
        public void Miembros6()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.Compite("Eleática", "Jónica"));

            CheckOrdering(m => m.Miembros("Eleática"), Comparison);
        }
    }

    public class Miembros7Test : TorneoFilosoficoTest
    {
        public void Miembros7()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.Compite("Eleática", "Jónica"));

            CheckOrdering(m => m.Miembros("Jónica"), Comparison);
        }
    }

    public class Miembros8Test : TorneoFilosoficoTest
    {
        public void Miembros8()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.Compite("Eleática", "Cínica"));

            CheckOrdering(m => m.Miembros("Cínica"), Comparison);
        }
    }

    public class Miembros9Test : TorneoFilosoficoTest
    {
        public void Miembros9()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Jónica", "Megárica"));

            CheckOrdering(m => m.Miembros("Megárica"), Comparison);
        }
    }

    public class Miembros10Test : TorneoFilosoficoTest
    {
        public void Miembros10()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));
            Perform(m => m.Compite("Pitagórica", "Eleática"));

            CheckOrdering(m => m.Miembros("Pitagórica"), Comparison);
        }
    }

    public class Miembros11Test : TorneoFilosoficoTest
    {
        public void Miembros11()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));
            Perform(m => m.Compite("Pitagórica", "Eleática"));
            Perform(m => m.Compite("Cínica", "Megárica"));
            Perform(m => m.Compite("Pitagórica", "Megárica"));

            CheckOrdering(m => m.Miembros("Pitagórica"), Comparison);
        }
    }

    public class Miembros12Test : TorneoFilosoficoTest
    {
        public void Miembros12()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));
            Perform(m => m.Compite("Pitagórica", "Eleática"));
            Perform(m => m.Compite("Cínica", "Megárica"));
            Perform(m => m.Compite("Pitagórica", "Megárica"));
            Perform(m => m.RegistraEscuela("Aristotélica", new[] {
                new Filosofo("A1", 50)
            }));

            CheckOrdering(m => m.Miembros("Aristotélica"), Comparison);
        }
    }

    public class Miembros13Test : TorneoFilosoficoTest
    {
        public void Miembros13()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));
            Perform(m => m.Compite("Pitagórica", "Eleática"));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Cínica", "Megárica"));
            Perform(m => m.Compite("Pitagórica", "Megárica"));
            Perform(m => m.RegistraEscuela("Aristotélica", new[] {
                new Filosofo("A1", 50)
            }));
            Perform(m => m.Compite("Pitagórica", "Aristotélica"));

            CheckOrdering(m => m.Miembros("Aristotélica"), Comparison);
        }
    }

    public class DameEscuelas1Test : TorneoFilosoficoTest
    {
        public void DameEscuelas1()
        {
            Initialize();

            CheckMultiSet(m => m.DameEscuelas());
        }
    }

    public class DameEscuelas2Test : TorneoFilosoficoTest
    {
        public void DameEscuelas2()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));

            CheckMultiSet(m => m.DameEscuelas());
        }
    }

    public class DameEscuelas3Test : TorneoFilosoficoTest
    {
        public void DameEscuelas3()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));

            CheckMultiSet(m => m.DameEscuelas());
        }
    }

    public class DameEscuelas4Test : TorneoFilosoficoTest
    {
        public void DameEscuelas4()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.Compite("Eleática", "Jónica"));

            CheckMultiSet(m => m.DameEscuelas());
        }
    }

    public class DameEscuelas5Test : TorneoFilosoficoTest
    {
        public void DameEscuelas5()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.Compite("Eleática", "Cínica"));

            CheckMultiSet(m => m.DameEscuelas());
        }
    }

    public class DameEscuelas6Test : TorneoFilosoficoTest
    {
        public void DameEscuelas6()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Jónica", "Megárica"));

            CheckMultiSet(m => m.DameEscuelas());
        }
    }

    public class DameEscuelas7Test : TorneoFilosoficoTest
    {
        public void DameEscuelas7()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));
            Perform(m => m.Compite("Pitagórica", "Eleática"));

            CheckMultiSet(m => m.DameEscuelas());
        }
    }

    public class DameEscuelas8Test : TorneoFilosoficoTest
    {
        public void DameEscuelas8()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));
            Perform(m => m.Compite("Pitagórica", "Eleática"));
            Perform(m => m.Compite("Cínica", "Megárica"));
            Perform(m => m.Compite("Pitagórica", "Megárica"));

            CheckMultiSet(m => m.DameEscuelas());
        }
    }

    public class DameEscuelas9Test : TorneoFilosoficoTest
    {
        public void DameEscuelas12()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));
            Perform(m => m.Compite("Pitagórica", "Eleática"));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Cínica", "Megárica"));
            Perform(m => m.Compite("Pitagórica", "Megárica"));
            Perform(m => m.RegistraEscuela("Aristotélica", new[] {
                new Filosofo("A1", 50)
            }));
            Perform(m => m.Compite("Pitagórica", "Aristotélica"));

            CheckMultiSet(m => m.DameEscuelas());
        }
    }

    public class FilosofosMasDestacados1Test : TorneoFilosoficoTest
    {
        public void FilosofosMasDestacados1()
        {
            Initialize();

            CheckLeaders();
        }
    }

    public class FilosofosMasDestacados2Test : TorneoFilosoficoTest
    {
        public void FilosofosMasDestacados2()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));

            CheckLeaders();
        }
    }

    public class FilosofosMasDestacados3Test : TorneoFilosoficoTest
    {
        public void FilosofosMasDestacados3()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));

            CheckLeaders();
        }
    }

    public class FilosofosMasDestacados4Test : TorneoFilosoficoTest
    {
        public void FilosofosMasDestacados4()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));

            CheckLeaders();
        }
    }

    public class FilosofosMasDestacados5Test : TorneoFilosoficoTest
    {
        public void FilosofosMasDestacados5()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.Compite("Eleática", "Jónica"));

            CheckLeaders();
        }
    }

    public class FilosofosMasDestacados6Test : TorneoFilosoficoTest
    {
        public void FilosofosMasDestacados6()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.Compite("Eleática", "Jónica"));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));

            CheckLeaders();
        }
    }

    public class FilosofosMasDestacados7Test : TorneoFilosoficoTest
    {
        public void FilosofosMasDestacados7()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.Compite("Eleática", "Cínica"));

            CheckLeaders();
        }
    }

    public class FilosofosMasDestacados8Test : TorneoFilosoficoTest
    {
        public void FilosofosMasDestacados8()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Jónica", "Megárica"));

            CheckLeaders();
        }
    }

    public class FilosofosMasDestacados9Test : TorneoFilosoficoTest
    {
        public void FilosofosMasDestacados9()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));
            Perform(m => m.Compite("Pitagórica", "Eleática"));

            CheckLeaders();
        }
    }

    public class FilosofosMasDestacados10Test : TorneoFilosoficoTest
    {
        public void FilosofosMasDestacados10()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));
            Perform(m => m.Compite("Pitagórica", "Eleática"));
            Perform(m => m.Compite("Cínica", "Megárica"));
            Perform(m => m.Compite("Pitagórica", "Megárica"));

            CheckLeaders();
        }
    }

    public class FilosofosMasDestacados11Test : TorneoFilosoficoTest
    {
        public void FilosofosMasDestacados11()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));
            Perform(m => m.Compite("Pitagórica", "Eleática"));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Cínica", "Megárica"));
            Perform(m => m.Compite("Pitagórica", "Megárica"));
            Perform(m => m.RegistraEscuela("Aristotélica", new[] {
                new Filosofo("A1", 50)
            }));

            CheckLeaders();
        }
    }

    public class FilosofosMasDestacados12Test : TorneoFilosoficoTest
    {
        public void FilosofosMasDestacados12()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));
            Perform(m => m.Compite("Pitagórica", "Eleática"));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Cínica", "Megárica"));
            Perform(m => m.Compite("Pitagórica", "Megárica"));
            Perform(m => m.RegistraEscuela("Aristotélica", new[] {
                new Filosofo("A1", 50)
            }));
            Perform(m => m.Compite("Pitagórica", "Aristotélica"));

            CheckLeaders();
        }
    }

    public class PerteneceAEscuela1Test : TorneoFilosoficoTest
    {
        public void PerteneceAEscuela1()
        {
            Initialize();

            Check(m => m.PerteneceAEscuela(new Filosofo("Romeo")));
        }
    }

    public class PerteneceAEscuela2Test : TorneoFilosoficoTest
    {
        public void PerteneceAEscuela2()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));

            Check(m => m.PerteneceAEscuela(new Filosofo("J2")));
        }
    }

    public class PerteneceAEscuela3Test : TorneoFilosoficoTest
    {
        public void PerteneceAEscuela3()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));

            Check(m => m.PerteneceAEscuela(new Filosofo("E2")));
        }
    }

    public class PerteneceAEscuela4Test : TorneoFilosoficoTest
    {
        public void PerteneceAEscuela4()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));

            Check(m => m.PerteneceAEscuela(new Filosofo("Cuco")));
            Check(m => m.PerteneceAEscuela(new Filosofo("J3")));
        }
    }

    public class PerteneceAEscuela5Test : TorneoFilosoficoTest
    {
        public void PerteneceAEscuela5()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.Compite("Eleática", "Jónica"));

            Check(m => m.PerteneceAEscuela(new Filosofo("E1")));
        }
    }

    public class PerteneceAEscuela6Test : TorneoFilosoficoTest
    {
        public void PerteneceAEscuela6()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.Compite("Eleática", "Jónica"));

            Check(m => m.PerteneceAEscuela(new Filosofo("P1")));
        }
    }

    public class PerteneceAEscuela7Test : TorneoFilosoficoTest
    {
        public void PerteneceAEscuela7()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.Compite("Eleática", "Jónica"));

            Check(m => m.PerteneceAEscuela(new Filosofo("J1")));
        }
    }

    public class PerteneceAEscuela8Test : TorneoFilosoficoTest
    {
        public void PerteneceAEscuela8()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.Compite("Eleática", "Cínica"));

            Check(m => m.PerteneceAEscuela(new Filosofo("C1")));
        }
    }

    public class PerteneceAEscuela9Test : TorneoFilosoficoTest
    {
        public void PerteneceAEscuela9()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Jónica", "Megárica"));

            Check(m => m.PerteneceAEscuela(new Filosofo("C2")));
        }
    }

    public class PerteneceAEscuela10Test : TorneoFilosoficoTest
    {
        public void PerteneceAEscuela10()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));
            Perform(m => m.Compite("Pitagórica", "Eleática"));

            Check(m => m.PerteneceAEscuela(new Filosofo("J2")));
        }
    }

    public class PerteneceAEscuela11Test : TorneoFilosoficoTest
    {
        public void PerteneceAEscuela11()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));
            Perform(m => m.Compite("Pitagórica", "Eleática"));
            Perform(m => m.Compite("Cínica", "Megárica"));
            Perform(m => m.Compite("Pitagórica", "Megárica"));

            Check(m => m.PerteneceAEscuela(new Filosofo("C1")));
        }
    }

    public class PerteneceAEscuela12Test : TorneoFilosoficoTest
    {
        public void PerteneceAEscuela12()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));
            Perform(m => m.Compite("Pitagórica", "Eleática"));
            Perform(m => m.Compite("Cínica", "Megárica"));
            Perform(m => m.Compite("Pitagórica", "Megárica"));
            Perform(m => m.RegistraEscuela("Aristotélica", new[] {
                new Filosofo("A1", 50)
            }));

            Check(m => m.PerteneceAEscuela(new Filosofo("A1")));
        }
    }

    public class PerteneceAEscuela13Test : TorneoFilosoficoTest
    {
        public void PerteneceAEscuela13()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));
            Perform(m => m.Compite("Pitagórica", "Eleática"));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Cínica", "Megárica"));
            Perform(m => m.Compite("Pitagórica", "Megárica"));
            Perform(m => m.RegistraEscuela("Aristotélica", new[] {
                new Filosofo("A1", 50)
            }));
            Perform(m => m.Compite("Pitagórica", "Aristotélica"));

            Check(m => m.PerteneceAEscuela(new Filosofo("E1")));
        }
    }

    public class Compite1Test : TorneoFilosoficoTest
    {
        public void Compite1()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));

            Check(m => m.Compite("Jónica", "Eleática"));
        }
    }

    public class Compite2Test : TorneoFilosoficoTest
    {
        public void Compite2()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));

            Check(m => m.Compite("Jónica", "Eleática"));
        }
    }

    public class Compite3Test : TorneoFilosoficoTest
    {
        public void Compite3()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));

            Check(m => m.Compite("Jónica", "Eleática"));
        }
    }

    public class Compite4Test : TorneoFilosoficoTest
    {
        public void Compite4()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));

            Check(m => m.Compite("Eleática", "Cínica"));
        }
    }

    public class Compite5Test : TorneoFilosoficoTest
    {
        public void Compite5()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));

            Check(m => m.Compite("Jónica", "Megárica"));
        }
    }

    public class Compite6Test : TorneoFilosoficoTest
    {
        public void Compite6()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));

            Check(m => m.Compite("Pitagórica", "Eleática"));
        }
    }

    public class Compite7Test : TorneoFilosoficoTest
    {
        public void Compite7()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));
            Perform(m => m.Compite("Pitagórica", "Eleática"));
            Perform(m => m.Compite("Cínica", "Megárica"));

            Check(m => m.Compite("Pitagórica", "Megárica"));
        }
    }

    public class Compite8Test : TorneoFilosoficoTest
    {
        public void Compite8()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));
            Perform(m => m.Compite("Pitagórica", "Eleática"));
            Perform(m => m.Compite("Cínica", "Megárica"));
            Perform(m => m.RegistraEscuela("Aristotélica", new[] {
                new Filosofo("A1", 50)
            }));

            Check(m => m.Compite("Pitagórica", "Megárica"));
        }
    }

    public class Compite9Test : TorneoFilosoficoTest
    {
        public void Compite9()
        {
            Initialize();

            Perform(m => m.RegistraEscuela("Jónica", new[] {
                new Filosofo("J1", 12),
                new Filosofo("J2", 8),
                new Filosofo("J3", 3)
            }));
            Perform(m => m.RegistraEscuela("Eleática", new[] {
                new Filosofo("E1", 10),
                new Filosofo("E2", 3)
            }));
            Perform(m => m.RegistraEscuela("Pitagórica", new[] {
                new Filosofo("P1", 20),
                new Filosofo("P2", 10)
            }));
            Perform(m => m.RegistraEscuela("Cínica", new[] {
                new Filosofo("C1", 10),
                new Filosofo("C2", 3),
                new Filosofo("C3", 1)
            }));
            Perform(m => m.Compite("Jónica", "Pitagórica"));
            Perform(m => m.Compite("Pitagórica", "Eleática"));
            Perform(m => m.RegistraEscuela("Megárica", new[] {
                new Filosofo("M1", 12),
                new Filosofo("M2", 8),
                new Filosofo("M3", 3)
            }));
            Perform(m => m.Compite("Cínica", "Megárica"));
            Perform(m => m.Compite("Pitagórica", "Megárica"));
            Perform(m => m.RegistraEscuela("Aristotélica", new[] {
                new Filosofo("A1", 50)
            }));

            Check(m => m.Compite("Pitagórica", "Aristotélica"));
        }
    }
}
