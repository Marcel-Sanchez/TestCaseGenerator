﻿using ConceptosSocraticos;
using System.Collections.Generic;

namespace TorneoFilosoficoTester
{
    public class TorneoFilosofico : ITorneoFilosofico
    {
        private LinkedNode<PhylosophicalSchool> _firstSchoolNode;

        public TorneoFilosofico()
        {
            _firstSchoolNode = null;
        }

        public string Compite(string escuela1, string escuela2)
        {
            var school1 = GetSchool(escuela1);
            var school2 = GetSchool(escuela2);

            var phylosopherNode1 = school1.FirstPhiloshopherNode;
            var phylosopherNode2 = school2.FirstPhiloshopherNode;
            string winnerSchool = "EMPATE";
            while (winnerSchool == "EMPATE" && (phylosopherNode1 != null || phylosopherNode2 != null))
            {
                if (phylosopherNode1 == null)
                {
                    winnerSchool = school2.Name;
                }
                else if (phylosopherNode2 == null)
                {
                    winnerSchool = school1.Name;
                }
                else if (phylosopherNode1.Value.Conocimiento > phylosopherNode2.Value.Conocimiento)
                {
                    winnerSchool = school1.Name;
                }
                else if (phylosopherNode1.Value.Conocimiento < phylosopherNode2.Value.Conocimiento)
                {
                    winnerSchool = school2.Name;
                }
                else
                {
                    phylosopherNode1 = phylosopherNode1.Next;
                    phylosopherNode2 = phylosopherNode2.Next;
                }
            }

            if (winnerSchool == school1.Name)
            {
                school1.FirstPhiloshopherNode = Merge(school1.FirstPhiloshopherNode, school2.FirstPhiloshopherNode);
                RemoveSchool(school2.Name);
            }
            if (winnerSchool == school2.Name)
            {
                school2.FirstPhiloshopherNode = Merge(school1.FirstPhiloshopherNode, school2.FirstPhiloshopherNode);
                RemoveSchool(school1.Name);
            }

            return winnerSchool;
        }

        public IEnumerable<string> DameEscuelas()
        {
            for (var schoolNode = _firstSchoolNode; schoolNode != null; schoolNode = schoolNode.Next)
                yield return schoolNode.Value.Name;
        }

        public IEnumerable<Filosofo> FilosofosMasDestacados()
        {
            for (var schoolNode = _firstSchoolNode; schoolNode != null; schoolNode = schoolNode.Next)
                yield return schoolNode.Value.FirstPhiloshopherNode.Value;
        }

        public IEnumerable<Filosofo> Miembros(string escuela)
        {
            var school = GetSchool(escuela);
            if (school == null)
                return null;

            return GetMembers(school);
        }

        public string PerteneceAEscuela(Filosofo filosofo)
        {
            for (var schoolNode = _firstSchoolNode; schoolNode != null; schoolNode = schoolNode.Next)
            {
                for (var phylosopherNode = schoolNode.Value.FirstPhiloshopherNode; phylosopherNode != null; phylosopherNode = phylosopherNode.Next)
                {
                    if (Equals(phylosopherNode.Value, filosofo))
                        return schoolNode.Value.Name;
                }
            }

            return null;
        }

        public void RegistraEscuela(string escuela, IEnumerable<Filosofo> filosofos)
        {
            _firstSchoolNode = new LinkedNode<PhylosophicalSchool>
            {
                Value = new PhylosophicalSchool
                {
                    Name = escuela,
                    FirstPhiloshopherNode = LinkPhylosophers(filosofos)
                },
                Next = _firstSchoolNode
            };
        }

        private LinkedNode<Filosofo> LinkPhylosophers(IEnumerable<Filosofo> phylosophers)
        {
            var previousFirst = new LinkedNode<Filosofo>();
            var current = previousFirst;
            foreach (var phylosopher in phylosophers)
            {
                current.Next = new LinkedNode<Filosofo>
                {
                    Value = phylosopher
                };
                current = current.Next;
            }

            return previousFirst.Next;
        }

        private IEnumerable<Filosofo> GetMembers(PhylosophicalSchool school)
        {
            for (var current = school.FirstPhiloshopherNode; current != null; current = current.Next)
                yield return current.Value;
        }

        private PhylosophicalSchool GetSchool(string name)
        {
            var schoolNode = _firstSchoolNode;
            while (schoolNode != null && schoolNode.Value.Name != name)
                schoolNode = schoolNode.Next;

            if (schoolNode == null)
                return null;

            return schoolNode.Value;
        }

        private LinkedNode<Filosofo> Merge(LinkedNode<Filosofo> phyloshoperNode1, LinkedNode<Filosofo> phyloshoperNode2)
        {
            if (phyloshoperNode1 == null)
            {
                return phyloshoperNode2;
            }
            if (phyloshoperNode2 == null)
            {
                return phyloshoperNode1;
            }

            if (phyloshoperNode1.Value.Conocimiento > phyloshoperNode2.Value.Conocimiento)
            {
                return new LinkedNode<Filosofo>
                {
                    Value = phyloshoperNode1.Value,
                    Next = Merge(phyloshoperNode1.Next, phyloshoperNode2)
                };
            }
            else
            {
                return new LinkedNode<Filosofo>
                {
                    Value = phyloshoperNode2.Value,
                    Next = Merge(phyloshoperNode1, phyloshoperNode2.Next)
                };
            }
        }

        private void RemoveSchool(string name)
        {
            if (_firstSchoolNode.Value.Name == name)
            {
                _firstSchoolNode = _firstSchoolNode.Next;
                return;
            }

            for (var schoolNode = _firstSchoolNode; schoolNode.Next != null; schoolNode = schoolNode.Next)
            {
                if (schoolNode.Next.Value.Name == name)
                {
                    schoolNode.Next = schoolNode.Next.Next;
                    return;
                }
            }
        }

        private class PhylosophicalSchool
        {
            public string Name { get; set; }

            public LinkedNode<Filosofo> FirstPhiloshopherNode { get; set; }
        }

        private class LinkedNode<T>
        {
            public T Value { get; set; }

            public LinkedNode<T> Next { get; set; }
        }
    }
}
