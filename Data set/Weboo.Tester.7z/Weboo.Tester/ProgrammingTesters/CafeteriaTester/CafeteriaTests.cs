﻿using System;
using System.Collections.Generic;
using Weboo.Assess.Tester;
using Weboo.Examen;

namespace CafeteriaTester
{
    public abstract class CafeteriaTest : InterfaceTester<ICafeteria>
    {
        protected override ICafeteria BuildBenchmark(object[] args)
        {
            int[,] demoraEnPlatoPorCocinero = (int[,])args[0];
            return new Cafeteria(demoraEnPlatoPorCocinero);
        }

        protected override ICafeteria BuildTarget(object[] args)
        {
            int[,] demoraEnPlatoPorCocinero = (int[,])args[0];
            return ReflectionHelper.CreateInstance<ICafeteria>(demoraEnPlatoPorCocinero);
        }

        protected void SetupEjemplo()
        {
            int[,] demoraEnPlatoPorCocinero = { { 1, 3, 5 },
                                                { 2, 4, 1 },
                                                { 3, 5, 2 },
                                                { 4, 1, 3 },
                                                { 5, 2, 4 } };

            Initialize(demoraEnPlatoPorCocinero);
        }

        private class PedidoComparer : IEqualityComparer<IPedido>
        {
            public bool Equals(IPedido x, IPedido y)
            {
                if (x == null)
                {
                    return y == null;
                }
                else if (y == null)
                {
                    return false;
                }

                return x.Cliente == y.Cliente && x.Plato == y.Plato && x.TiempoEnEspera == y.TiempoEnEspera;
            }

            public int GetHashCode(IPedido obj)
            {
                return obj.GetHashCode();
            }
        }

        protected void CheckPedidos(Func<ICafeteria, IEnumerable<IPedido>> function)
        {
            base.CheckSequence(function, new PedidoComparer());
        }

        protected void CheckPedido(Func<ICafeteria, IPedido> function)
        {
            base.Check(function, new PedidoComparer());
        }
    }

    public class Test1 : CafeteriaTest
    {
        public void Test1PropiedadesSimples()
        {
            SetupEjemplo();

            Check((m) => m.NumeroDePlatos);
            Check((m) => m.NumeroDeCocineros);
        }
    }

    public class Test2 : CafeteriaTest
    {
        public void Test1PedidosEnEspera()
        {
            SetupEjemplo();

            CheckPedidos(m => m.PedidosEnEspera());
        }
    }

    public class Test3 : CafeteriaTest
    {
        public void Test2PedidosEnEspera()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 1));

            CheckPedidos(m => m.PedidosEnEspera());
        }
    }

    public class Test4 : CafeteriaTest
    {
        public void Test3PedidosEnEspera()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 1));
            Perform(m => m.LlegaCliente("Amalia", 2));

            CheckPedidos(m => m.PedidosEnEspera());
        }
    }

    public class Test5 : CafeteriaTest
    {
        public void Test4PedidosEnEspera()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 1));
            Perform(m => m.LlegaCliente("Amalia", 2));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 3));

            CheckPedidos(m => m.PedidosEnEspera());
        }
    }

    public class Test6 : CafeteriaTest
    {
        public void Test5PedidosEnEspera()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 1));
            Perform(m => m.LlegaCliente("Amalia", 2));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.SalePedido());

            CheckPedidos(m => m.PedidosEnEspera());
        }
    }

    public class Test7 : CafeteriaTest
    {
        public void Test6PedidosEnEspera()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 1));
            Perform(m => m.LlegaCliente("Amalia", 2));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.LlegaCliente("Carmen", 0));
            Perform(m => m.LlegaCliente("Adelaida", 4));
            Perform(m => m.LlegaCliente("Rocio", 4));

            CheckPedidos(m => m.PedidosEnEspera());
        }
    }

    public class Test8 : CafeteriaTest
    {
        public void Test7PedidosEnEspera()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 1));
            Perform(m => m.LlegaCliente("Amalia", 2));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.LlegaCliente("Carmen", 0));
            Perform(m => m.LlegaCliente("Adelaida", 4));
            Perform(m => m.LlegaCliente("Rocio", 4));
            Perform(m => m.SalePedido());

            CheckPedidos(m => m.PedidosEnEspera());
        }
    }

    public class Tes9 : CafeteriaTest
    {
        public void Test8PedidosEnEspera()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 1));
            Perform(m => m.LlegaCliente("Amalia", 2));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.LlegaCliente("Carmen", 0));
            Perform(m => m.LlegaCliente("Adelaida", 4));
            Perform(m => m.LlegaCliente("Rocio", 4));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());

            CheckPedidos(m => m.PedidosEnEspera());
        }
    }

    public class Test10 : CafeteriaTest
    {
        public void Test9PedidosEnEspera()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 1));
            Perform(m => m.LlegaCliente("Amalia", 2));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.LlegaCliente("Carmen", 0));
            Perform(m => m.LlegaCliente("Adelaida", 4));
            Perform(m => m.LlegaCliente("Rocio", 4));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Mariana", 2));

            CheckPedidos(m => m.PedidosEnEspera());
        }
    }

    public class Test11 : CafeteriaTest
    {
        public void Test10PedidosEnEspera()
        {
            SetupEjemplo();

            // Terminan a la vez
            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Amalia", 3));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.LlegaCliente("Adelaida", 4));
            Perform(m => m.SalePedido());

            CheckPedidos(m => m.PedidosEnEspera());
        }
    }

    public class Test12 : CafeteriaTest
    {
        public void Test11PedidosEnEspera()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Amalia", 3));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.LlegaCliente("Carmen", 0));
            Perform(m => m.LlegaCliente("Adelaida", 4));
            Perform(m => m.LlegaCliente("Rocio", 4));
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Mariana", 2));

            CheckPedidos(m => m.PedidosEnEspera());
        }
    }

    public class Test13 : CafeteriaTest
    {
        public void Test12PedidosEnEspera()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Amalia", 3));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.LlegaCliente("Carmen", 0));
            Perform(m => m.LlegaCliente("Adelaida", 4));
            Perform(m => m.LlegaCliente("Rocio", 4));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());

            CheckPedidos(m => m.PedidosEnEspera());
        }
    }

    public class Test14 : CafeteriaTest
    {
        public void Test1PedidosPorCocinero()
        {
            SetupEjemplo();

            CheckPedidos(m => m.PedidosPorCocinero());
        }
    }

    public class Test15 : CafeteriaTest
    {
        public void Test2PedidosPorCocinero()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 3));

            CheckPedidos(m => m.PedidosPorCocinero());
        }
    }

    public class Test16 : CafeteriaTest
    {
        public void Test3PedidosPorCocinero()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 2));
            Perform(m => m.SalePedido());

            CheckPedidos(m => m.PedidosPorCocinero());
        }
    }

    public class Test17 : CafeteriaTest
    {
        public void Test4PedidosPorCocinero()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 2));
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Rocío", 1));

            CheckPedidos(m => m.PedidosPorCocinero());
        }
    }

    public class Test18 : CafeteriaTest
    {
        public void Test5PedidosPorCocinero()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 1));
            Perform(m => m.LlegaCliente("Amalia", 2));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 3));

            CheckPedidos(m => m.PedidosPorCocinero());
        }
    }

    public class Test19 : CafeteriaTest
    {
        public void Test6PedidosPorCocinero()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 1));
            Perform(m => m.LlegaCliente("Amalia", 2));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.LlegaCliente("Carmen", 1));

            CheckPedidos(m => m.PedidosPorCocinero());
        }
    }

    public class Test20 : CafeteriaTest
    {
        public void Test7PedidosPorCocinero()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 3));
            Perform(m => m.LlegaCliente("Amalia", 4));
            Perform(m => m.LlegaCliente("Amanda", 2));
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.LlegaCliente("Carmen", 1));
            Perform(m => m.SalePedido());

            CheckPedidos(m => m.PedidosPorCocinero());
        }
    }

    public class Test21 : CafeteriaTest
    {
        public void Test8PedidosPorCocinero()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 3));
            Perform(m => m.LlegaCliente("Amalia", 4));
            Perform(m => m.LlegaCliente("Amanda", 2));
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.LlegaCliente("Carmen", 1));

            CheckPedidos(m => m.PedidosPorCocinero());
        }
    }

    public class Test22 : CafeteriaTest
    {
        public void Test9PedidosPorCocinero()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 3));
            Perform(m => m.LlegaCliente("Amalia", 4));
            Perform(m => m.LlegaCliente("Amanda", 2));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.LlegaCliente("Carmen", 1));

            CheckPedidos(m => m.PedidosPorCocinero());
        }
    }

    public class Test23 : CafeteriaTest
    {
        public void Test10PedidosPorCocinero()
        {
            SetupEjemplo();

            // Terminan a la vez
            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Amalia", 3));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.SalePedido());

            CheckPedidos(m => m.PedidosPorCocinero());
        }
    }

    public class Test24 : CafeteriaTest
    {
        public void Test11PedidosPorCocinero()
        {
            SetupEjemplo();

            // Terminan a la vez
            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Amalia", 3));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.SalePedido());

            CheckPedidos(m => m.PedidosPorCocinero());
        }
    }

    public class Test25 : CafeteriaTest
    {
        public void Test12PedidosPorCocinero()
        {
            SetupEjemplo();

            // Terminan a la vez
            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Amalia", 3));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.LlegaCliente("Carmen", 0));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Mariana", 2));

            CheckPedidos(m => m.PedidosPorCocinero());
        }
    }

    public class Test26 : CafeteriaTest
    {
        public void Test13PedidosPorCocinero()
        {
            SetupEjemplo();

            // Terminan a la vez
            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Amalia", 3));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 0));
            Perform(m => m.LlegaCliente("Carmen", 3));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Mariana", 2));
            Perform(m => m.SalePedido());

            CheckPedidos(m => m.PedidosPorCocinero());
        }
    }

    public class Test27 : CafeteriaTest
    {
        public void Test14PedidosPorCocinero()
        {
            SetupEjemplo();

            // Terminan a la vez
            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Amalia", 3));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 0));
            Perform(m => m.LlegaCliente("Carmen", 3));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Mariana", 2));
            Perform(m => m.SalePedido());

            CheckPedidos(m => m.PedidosPorCocinero());
        }
    }

    public class Test28 : CafeteriaTest
    {
        public void Test1TiempoRestantePorCocinero()
        {
            SetupEjemplo();

            CheckSequence(m => m.TiempoRestantePorCocinero());
        }
    }

    public class Test29 : CafeteriaTest
    {
        public void Test2TiempoRestantePorCocinero()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 3));

            CheckSequence(m => m.TiempoRestantePorCocinero());
        }
    }

    public class Test30 : CafeteriaTest
    {
        public void Test3TiempoRestantePorCocinero()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 2));
            Perform(m => m.SalePedido());

            CheckSequence(m => m.TiempoRestantePorCocinero());
        }
    }

    public class Test31 : CafeteriaTest
    {
        public void Test4TiempoRestantePorCocinero()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 2));
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Rocío", 1));

            CheckSequence(m => m.TiempoRestantePorCocinero());
        }
    }

    public class Test32 : CafeteriaTest
    {
        public void Test5TiempoRestantePorCocinero()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 1));
            Perform(m => m.LlegaCliente("Amalia", 2));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 3));

            CheckSequence(m => m.TiempoRestantePorCocinero());
        }
    }

    public class Test33 : CafeteriaTest
    {
        public void Test6TiempoRestantePorCocinero()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 1));
            Perform(m => m.LlegaCliente("Amalia", 2));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.LlegaCliente("Carmen", 1));

            CheckSequence(m => m.TiempoRestantePorCocinero());
        }
    }

    public class Test34 : CafeteriaTest
    {
        public void Test7TiempoRestantePorCocinero()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 3));
            Perform(m => m.LlegaCliente("Amalia", 4));
            Perform(m => m.LlegaCliente("Amanda", 2));
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.LlegaCliente("Carmen", 1));
            Perform(m => m.SalePedido());

            CheckSequence(m => m.TiempoRestantePorCocinero());
        }
    }

    public class Test35 : CafeteriaTest
    {
        public void Test8TiempoRestantePorCocinero()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 3));
            Perform(m => m.LlegaCliente("Amalia", 4));
            Perform(m => m.LlegaCliente("Amanda", 2));
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.LlegaCliente("Carmen", 1));

            CheckSequence(m => m.TiempoRestantePorCocinero());
        }
    }

    public class Test36 : CafeteriaTest
    {
        public void Test9TiempoRestantePorCocinero()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 3));
            Perform(m => m.LlegaCliente("Amalia", 4));
            Perform(m => m.LlegaCliente("Amanda", 2));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.LlegaCliente("Carmen", 1));

            CheckSequence(m => m.TiempoRestantePorCocinero());
        }
    }

    public class Test37 : CafeteriaTest
    {
        public void Test10TiempoRestantePorCocinero()
        {
            SetupEjemplo();

            // Terminan a la vez
            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Amalia", 3));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.SalePedido());

            CheckSequence(m => m.TiempoRestantePorCocinero());
        }
    }

    public class Test38 : CafeteriaTest
    {
        public void Test11TiempoRestantePorCocinero()
        {
            SetupEjemplo();

            // Terminan a la vez
            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Amalia", 3));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.SalePedido());

            CheckSequence(m => m.TiempoRestantePorCocinero());
        }
    }

    public class Test39 : CafeteriaTest
    {
        public void Test12TiempoRestantePorCocinero()
        {
            SetupEjemplo();

            // Terminan a la vez
            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Amalia", 3));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.LlegaCliente("Carmen", 0));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Mariana", 2));

            CheckSequence(m => m.TiempoRestantePorCocinero());
        }
    }

    public class Test40 : CafeteriaTest
    {
        public void Test13TiempoRestantePorCocinero()
        {
            SetupEjemplo();

            // Terminan a la vez
            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Amalia", 3));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 0));
            Perform(m => m.LlegaCliente("Carmen", 3));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Mariana", 2));
            Perform(m => m.SalePedido());

            CheckSequence(m => m.TiempoRestantePorCocinero());
        }
    }

    public class Test41 : CafeteriaTest
    {
        public void Test14TiempoRestantePorCocinero()
        {
            SetupEjemplo();

            // Terminan a la vez
            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Amalia", 3));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Grettel", 0));
            Perform(m => m.LlegaCliente("Carmen", 3));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Mariana", 2));
            Perform(m => m.SalePedido());

            CheckSequence(m => m.TiempoRestantePorCocinero());
        }
    }

    public class Test42 : CafeteriaTest
    {
        public void Test1SalePedido()
        {
            SetupEjemplo();

            CheckPedido(m => m.SalePedido());
        }
    }

    public class Test43 : CafeteriaTest
    {
        public void Test2SalePedido()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 3));

            CheckPedido(m => m.SalePedido());
        }
    }

    public class Test44 : CafeteriaTest
    {
        public void Test3SalePedido()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 3));
            Perform(m => m.LlegaCliente("Laura", 0));

            CheckPedido(m => m.SalePedido());
        }
    }

    public class Test45 : CafeteriaTest
    {
        public void Test4SalePedido()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 3));
            Perform(m => m.LlegaCliente("Laura", 0));
            Perform(m => m.LlegaCliente("Amalia", 1));

            CheckPedido(m => m.SalePedido());
        }
    }

    public class Test46 : CafeteriaTest
    {
        public void Test5SalePedido()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 3));
            Perform(m => m.LlegaCliente("Laura", 0));
            Perform(m => m.LlegaCliente("Amalia", 1));
            Perform(m => m.SalePedido());

            CheckPedido(m => m.SalePedido());
        }
    }

    public class Test47 : CafeteriaTest
    {
        public void Test6SalePedido()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 3));
            Perform(m => m.LlegaCliente("Laura", 0));
            Perform(m => m.LlegaCliente("Amalia", 1));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());

            CheckPedido(m => m.SalePedido());
        }
    }

    public class Test48 : CafeteriaTest
    {
        public void Test7SalePedido()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 3));
            Perform(m => m.LlegaCliente("Amalia", 4));
            Perform(m => m.LlegaCliente("Amanda", 2));
            Perform(m => m.LlegaCliente("Grettel", 3));
            Perform(m => m.LlegaCliente("Carmen", 1));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());

            CheckPedido(m => m.SalePedido());
        }
    }

    public class Test49 : CafeteriaTest
    {
        public void Test8SalePedido()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 3));
            Perform(m => m.LlegaCliente("Laura", 0));
            Perform(m => m.LlegaCliente("Amalia", 1));
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Carmen", 1));

            CheckPedido(m => m.SalePedido());
        }
    }

    public class Test50 : CafeteriaTest
    {
        public void Test9SalePedido()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 3));
            Perform(m => m.LlegaCliente("Laura", 0));
            Perform(m => m.LlegaCliente("Amalia", 1));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Carmen", 1));

            CheckPedido(m => m.SalePedido());
        }
    }

    public class Test51 : CafeteriaTest
    {
        public void Test9SalePedido()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Laura", 3));
            Perform(m => m.LlegaCliente("Amalia", 1));

            CheckPedido(m => m.SalePedido());
        }
    }

    public class Test52 : CafeteriaTest
    {
        public void Test10SalePedido()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Laura", 3));
            Perform(m => m.LlegaCliente("Amalia", 1));
            Perform(m => m.SalePedido());

            CheckPedido(m => m.SalePedido());
        }
    }

    public class Test53 : CafeteriaTest
    {
        public void Test11SalePedido()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Laura", 3));
            Perform(m => m.LlegaCliente("Amalia", 1));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());

            CheckPedido(m => m.SalePedido());
        }
    }

    public class Test54 : CafeteriaTest
    {
        public void Test12SalePedido()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Laura", 3));
            Perform(m => m.LlegaCliente("Amalia", 1));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());

            CheckPedido(m => m.SalePedido());
        }
    }

    public class Test55 : CafeteriaTest
    {
        public void Test13SalePedido()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Laura", 3));
            Perform(m => m.LlegaCliente("Amalia", 1));
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Mariana", 2));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());

            CheckPedido(m => m.SalePedido());
        }
    }

    public class Test56 : CafeteriaTest
    {
        public void Test14SalePedido()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Laura", 3));
            Perform(m => m.LlegaCliente("Amalia", 1));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Mariana", 2));
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.LlegaCliente("Rose", 2));

            CheckPedido(m => m.SalePedido());
        }
    }

    public class Test57 : CafeteriaTest
    {
        public void Test15SalePedido()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.LlegaCliente("Laura", 3));
            Perform(m => m.LlegaCliente("Amalia", 1));
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Mariana", 2));
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Amanda", 1));
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("Rose", 2));

            CheckPedido(m => m.SalePedido());
        }
    }

    public class Test58 : CafeteriaTest
    {
        public void Test16SalePedido()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("Gabriela", 0));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());

            CheckPedido(m => m.SalePedido());
        }
    }

    public class Test59 : CafeteriaTest
    {
        public void Test17SalePedido()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("A", 0));
            Perform(m => m.LlegaCliente("B", 0));
            Perform(m => m.LlegaCliente("C", 0));
            Perform(m => m.LlegaCliente("D", 0));
            Perform(m => m.LlegaCliente("E", 0));
            Perform(m => m.LlegaCliente("F", 0));
            Perform(m => m.LlegaCliente("G", 0));
            Perform(m => m.LlegaCliente("H", 0));
            Perform(m => m.LlegaCliente("I", 0));
            Perform(m => m.LlegaCliente("J", 0));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());

            CheckPedido(m => m.SalePedido());
        }
    }

    public class Test60 : CafeteriaTest
    {
        public void Test18SalePedido()
        {
            SetupEjemplo();

            Perform(m => m.LlegaCliente("A", 0));
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("B", 0));
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("C", 0));
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("D", 0));
            Perform(m => m.LlegaCliente("E", 0));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("F", 0));
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("G", 0));
            Perform(m => m.LlegaCliente("H", 0));
            Perform(m => m.LlegaCliente("I", 0));
            Perform(m => m.SalePedido());
            Perform(m => m.SalePedido());
            Perform(m => m.LlegaCliente("J", 0));

            CheckPedido(m => m.SalePedido());
        }
    }
}
