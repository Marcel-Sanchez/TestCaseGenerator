﻿using System.Collections.Generic;
using Weboo.Examen;

namespace CafeteriaTester
{
    public class Cafeteria : ICafeteria
    {
        private readonly int[,] _demoraEnPlatoPorCocinero;
        private int[] _leftOverTime;
        private Pedido[] _orderInPreparation;
        private Queue<Pedido> _queue;

        public Cafeteria(int[,] demoraEnPlatoPorCocinero)
        {
            _demoraEnPlatoPorCocinero = demoraEnPlatoPorCocinero;
            _orderInPreparation = new Pedido[_demoraEnPlatoPorCocinero.GetLength(1)];
            _queue = new Queue<Pedido>();
            _leftOverTime = new int[_demoraEnPlatoPorCocinero.GetLength(1)];

            for (int i = 0; i < _leftOverTime.Length; i++)
                _leftOverTime[i] = -1;
        }

        public int NumeroDePlatos
        {
            get { return _demoraEnPlatoPorCocinero.GetLength(0); }
        }
        public int NumeroDeCocineros
        {
            get { return _demoraEnPlatoPorCocinero.GetLength(1); }
        }

        public void LlegaCliente(string cliente, int plato)
        {
            var order = new Pedido
            {
                Cliente = cliente,
                Plato = plato,
                TiempoEnEspera = 0
            };
            for (int i = 0; i < _leftOverTime.Length; i++)
            {
                if (_leftOverTime[i] == -1)
                {
                    _leftOverTime[i] = _demoraEnPlatoPorCocinero[plato, i];
                    _orderInPreparation[i] = order;
                    return;
                }
            }

            _queue.Enqueue(order);
        }

        public IPedido SalePedido()
        {
            int timeToFinishNextOrder = int.MaxValue;
            for (int i = 0; i < _leftOverTime.Length; i++)
            {
                if (_leftOverTime[i] > -1 && timeToFinishNextOrder > _leftOverTime[i])
                {
                    timeToFinishNextOrder = _leftOverTime[i];
                }
            }

            if (timeToFinishNextOrder != int.MaxValue)
            {
                for (int i = 0; i < _leftOverTime.Length; i++)
                {
                    if (_leftOverTime[i] > -1)
                    {
                        _leftOverTime[i] -= timeToFinishNextOrder;
                        _orderInPreparation[i].TiempoEnEspera += timeToFinishNextOrder;
                    }
                }

                foreach (var item in _queue)
                {
                    item.TiempoEnEspera += timeToFinishNextOrder;
                }

                for (int i = 0; i < _leftOverTime.Length; i++)
                {
                    if (_leftOverTime[i] == 0)
                    {
                        var order = _orderInPreparation[i];
                        if (_queue.Count > 0)
                        {
                            var nextOrder = _queue.Dequeue();
                            _orderInPreparation[i] = nextOrder;
                            _leftOverTime[i] = _demoraEnPlatoPorCocinero[nextOrder.Plato, i];
                        }
                        else
                        {
                            _orderInPreparation[i] = null;
                            _leftOverTime[i] = -1;
                        }

                        return order;
                    }
                }
            }

            return null;
        }

        public IEnumerable<IPedido> PedidosEnEspera()
        {
            return _queue;
        }

        public IEnumerable<IPedido> PedidosPorCocinero()
        {
            return _orderInPreparation;
        }

        public IEnumerable<int> TiempoRestantePorCocinero()
        {
            return _leftOverTime;
        }

        private class Pedido : IPedido
        {
            public string Cliente { get; set; }

            public int Plato { get; set; }

            public int TiempoEnEspera { get; set; }

            public override string ToString()
            {
                return $"<Cliente: {Cliente}, Plato: {Plato}, EnEspera: {TiempoEnEspera}>";
            }
        }
    }
}
