﻿using System.Linq;
using Weboo.Assess.Tester;

namespace CriptoAritmeticaTester
{
    public abstract class CriptoAritmeticaTest : TestCase
    {
        public int[] Student(string alfabeto, string sumando1, string sumando2, string suma)
        {
            return ReflectionHelper.InvokeStatic<int[]>("Weboo.Examen.CriptoAritmetica", "CriptoSolucion", alfabeto, sumando1, sumando2, suma);
        }

        protected string GetAlphabet(string sumando1, string sumando2, string suma)
        {
            return new string(string.Concat(sumando1, sumando2, suma).Distinct().ToArray());
        }

        static bool IsInvalidNumber(string s, string alfabeto, int[] assignment)
        {
            return s.Length > 1 && assignment[alfabeto.IndexOf(s[0])] == 0;
        }

        protected bool IsValidAssignment(int[] assignment, string alfabeto, string sumando1, string sumando2, string suma)
        {
            if (assignment == null || assignment.Length != alfabeto.Length || assignment.Any(m => m < 0 || m > 9))
            {
                return false;
            }

            if (IsInvalidNumber(sumando1, alfabeto, assignment) || IsInvalidNumber(sumando2, alfabeto, assignment) || IsInvalidNumber(suma, alfabeto, assignment))
            {
                return false;
            }

            sumando1 = new string(sumando1.Reverse().ToArray());
            sumando2 = new string(sumando2.Reverse().ToArray());
            suma = new string(suma.Reverse().ToArray());
            int s = 0;
            for (int i = 0; i < suma.Length; i++)
            {
                if (i < sumando1.Length)
                {
                    s += assignment[alfabeto.IndexOf(sumando1[i])];
                }
                if (i < sumando2.Length)
                {
                    s += assignment[alfabeto.IndexOf(sumando2[i])];
                }

                if (s % 10 != assignment[alfabeto.IndexOf(suma[i])])
                {
                    return false;
                }

                s /= 10;
            }

            return true;
        }
    }

    public class Ejemplo1Test : CriptoAritmeticaTest
    {
        public void Ejemplo1()
        {
            string sumando1 = "SEND";
            string sumando2 = "MORE";
            string suma = "MONEY";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
        }
    }

    public class Ejemplo2Test : CriptoAritmeticaTest
    {
        public void Ejemplo2()
        {
            string sumando1 = "ABC";
            string sumando2 = "ABC";
            string suma = "ABC";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(assignment, Is.Null);
        }
    }

    public class Ejemplo3Test : CriptoAritmeticaTest
    {
        public void Ejemplo3()
        {
            string sumando1 = "FOUR";
            string sumando2 = "FOUR";
            string suma = "EIGHT";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
        }
    }

    public class Ejemplo4Test : CriptoAritmeticaTest
    {
        public void Ejemplo4()
        {
            string sumando1 = "FRANK";
            string sumando2 = "SINATRA";
            string suma = "LAVOZ";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(assignment, Is.Null);
        }
    }

    //public class Ejemplo5Test : CriptoAritmeticaTest
    //{
    //    public void Ejemplo5()
    //    {
    //        string sumando1 = "MADRID";
    //        string sumando2 = "BARCA";
    //        string suma = "CLASICO";
    //        string alfabeto = GetAlphabet(sumando1, sumando2, suma);

    //        int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
    //        Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
    //    }
    //}

    public class NoSolucion1Test : CriptoAritmeticaTest
    {
        public void NoSolucion1()
        {
            string sumando1 = "A";
            string sumando2 = "A";
            string suma = "AB";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(assignment, Is.Null);
        }
    }

    public class NoSolucion2Test : CriptoAritmeticaTest
    {
        public void NoSolucion2()
        {
            string sumando1 = "A";
            string sumando2 = "A";
            string suma = "BA";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(assignment, Is.Null);
        }
    }

    public class NoSolucion3Test : CriptoAritmeticaTest
    {
        public void NoSolucion3()
        {
            string sumando1 = "A";
            string sumando2 = "B";
            string suma = "AB";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(assignment, Is.Null);
        }
    }

    public class NoSolucion4Test : CriptoAritmeticaTest
    {
        public void NoSolucion4()
        {
            string sumando1 = "AA";
            string sumando2 = "AA";
            string suma = "AA";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(assignment, Is.Null);
        }
    }

    public class NoSolucion5Test : CriptoAritmeticaTest
    {
        public void NoSolucion5()
        {
            string sumando1 = "AB";
            string sumando2 = "CD";
            string suma = "E";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(assignment, Is.Null);
        }
    }

    public class NoSolucion6Test : CriptoAritmeticaTest
    {
        public void NoSolucion6()
        {
            string sumando1 = "AB";
            string sumando2 = "AC";
            string suma = "AE";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(assignment, Is.Null);
        }
    }

    public class NoSolucion7Test : CriptoAritmeticaTest
    {
        public void NoSolucion7()
        {
            string sumando1 = "AB";
            string sumando2 = "APLL";
            string suma = "AE";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(assignment, Is.Null);
        }
    }

    public class NoSolucion8Test : CriptoAritmeticaTest
    {
        public void NoSolucion8()
        {
            string sumando1 = "ABC";
            string sumando2 = "CBA";
            string suma = "BCA";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(assignment, Is.Null);
        }
    }

    public class NoSolucion9Test : CriptoAritmeticaTest
    {
        public void NoSolucion9()
        {
            string sumando1 = "ABCDEFGHIJKLMNOPQRSTUV";
            string sumando2 = "CBA";
            string suma = "BCA";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(assignment, Is.Null);
        }
    }

    public class SolucionSimple1Test : CriptoAritmeticaTest
    {
        public void SolucionSimple1()
        {
            string sumando1 = "A";
            string sumando2 = "B";
            string suma = "C";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
        }
    }

    public class SolucionSimple2Test : CriptoAritmeticaTest
    {
        public void SolucionSimple2()
        {
            string sumando1 = "G";
            string sumando2 = "G";
            string suma = "G";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
        }
    }

    public class SolucionSimple3Test : CriptoAritmeticaTest
    {
        public void SolucionSimple3()
        {
            string sumando1 = "AB";
            string sumando2 = "CD";
            string suma = "EF";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
        }
    }

    public class SolucionSimple4Test : CriptoAritmeticaTest
    {
        public void SolucionSimple4()
        {
            string sumando1 = "ABC";
            string sumando2 = "D";
            string suma = "ABD";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
        }
    }

    public class SolucionSimple5Test : CriptoAritmeticaTest
    {
        public void SolucionSimple5()
        {
            string sumando1 = "ACC";
            string sumando2 = "BC";
            string suma = "ABC";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
        }
    }

    public class SolucionSimple6Test : CriptoAritmeticaTest
    {
        public void SolucionSimple6()
        {
            string sumando1 = "FRA";
            string sumando2 = "X";
            string suma = "FRA";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
        }
    }

    public class SolucionSimple7Test : CriptoAritmeticaTest
    {
        public void SolucionSimple7()
        {
            string sumando1 = "AAAA";
            string sumando2 = "B";
            string suma = "BCCCC";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
        }
    }

    public class SolucionSimple8Test : CriptoAritmeticaTest
    {
        public void SolucionSimple8()
        {
            string sumando1 = "B";
            string sumando2 = "AAAA";
            string suma = "BCCCC";
            string alfabeto = GetAlphabet(sumando1, sumando2, suma);

            int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
            Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
        }
    }

    //public class Grande1Test : CriptoAritmeticaTest
    //{
    //    public void Grande1()
    //    {
    //        string sumando1 = "BEER";
    //        string sumando2 = "MUSIC";
    //        string suma = "PARTY";
    //        string alfabeto = GetAlphabet(sumando1, sumando2, suma);

    //        int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
    //        Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
    //    }
    //}

    //public class Grande2Test : CriptoAritmeticaTest
    //{
    //    public void Grande2()
    //    {
    //        string sumando1 = "BONNIE";
    //        string sumando2 = "CLYDE";
    //        string suma = "CRIMES";
    //        string alfabeto = GetAlphabet(sumando1, sumando2, suma);

    //        int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
    //        Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
    //    }
    //}

    //public class Grande3Test : CriptoAritmeticaTest
    //{
    //    public void Grande3()
    //    {
    //        string sumando1 = "CAVALIERS";
    //        string sumando2 = "WARRIORS";
    //        string suma = "NBAFINALS";
    //        string alfabeto = GetAlphabet(sumando1, sumando2, suma);

    //        int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
    //        Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
    //    }
    //}

    //public class Grande4Test : CriptoAritmeticaTest
    //{
    //    public void Grande4()
    //    {
    //        string sumando1 = "JOBS";
    //        string sumando2 = "WOZ";
    //        string suma = "APPLE";
    //        string alfabeto = GetAlphabet(sumando1, sumando2, suma);

    //        int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
    //        Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
    //    }
    //}

    //public class Grande5Test : CriptoAritmeticaTest
    //{
    //    public void Grande5()
    //    {
    //        string sumando1 = "SBRIN";
    //        string sumando2 = "LPAGE";
    //        string suma = "GOOGLE";
    //        string alfabeto = GetAlphabet(sumando1, sumando2, suma);

    //        int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
    //        Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
    //    }
    //}

    //public class Grande6Test : CriptoAritmeticaTest
    //{
    //    public void Grande6()
    //    {
    //        string sumando1 = "PAULALLEN";
    //        string sumando2 = "BILLGATES";
    //        string suma = "MICROSOFT";
    //        string alfabeto = GetAlphabet(sumando1, sumando2, suma);

    //        int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
    //        Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
    //    }
    //}

    //public class Grande7Test : CriptoAritmeticaTest
    //{
    //    public void Grande7()
    //    {
    //        string sumando1 = "STRING";
    //        string sumando2 = "BOARD";
    //        string suma = "GUITAR";
    //        string alfabeto = GetAlphabet(sumando1, sumando2, suma);

    //        int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
    //        Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
    //    }
    //}

    //public class Grande8Test : CriptoAritmeticaTest
    //{
    //    public void Grande8()
    //    {
    //        string sumando1 = "CERF";
    //        string sumando2 = "KAHN";
    //        string suma = "TCPIP";
    //        string alfabeto = GetAlphabet(sumando1, sumando2, suma);

    //        int[] assignment = Student(alfabeto, sumando1, sumando2, suma);
    //        Assert.That(IsValidAssignment(assignment, alfabeto, sumando1, sumando2, suma), Is.EqualTo(true));
    //    }
    //}
}
