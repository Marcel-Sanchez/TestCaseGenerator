﻿using System.Collections.Generic;
using Weboo.Assess.Tester;

namespace ParentesisTester
{
    public class ParentesisTest
    {
        public static IEnumerable<string> Solution(int n, int d)
        {
            return Solution(n, n, d, d == 0, "");
        }

        private static IEnumerable<string> Solution(int opened, int closed, int depth, bool matched, string str)
        {
            if (opened < 0 || closed < 0 || closed < opened)
                yield break;

            if (depth < 0)
                yield break;

            if (opened < depth && !matched)
                yield break;

            if (closed == 0)
            {
                yield return str;
                yield break;
            }

            foreach (var item in Solution(opened - 1, closed, depth - 1, matched || depth == 1, str + "("))
                yield return item;
            foreach (var item in Solution(opened, closed - 1, depth + 1, matched, str + ")"))
                yield return item;
        }

        public static IEnumerable<string> Student(int n, int d)
        {
            return ReflectionHelper.InvokeStatic<IEnumerable<string>>("Weboo.Examen.Parentesis", "ParentesisBalanceadosConProfundidad", n, d);
        }
    }

    public class Test1 : TestCase
    {
        public void OnlyEmptyString()
        {
            const int n = 0, d = 0;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test2 : TestCase
    {
        public void MaxDepthPossible1()
        {
            const int n = 10, d = 10;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test3 : TestCase
    {
        public void MaxDepthPossible2()
        {
            const int n = 1, d = 1;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test4 : TestCase
    {
        public void MaxDepthPossible3()
        {
            const int n = 5, d = 5;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test5 : TestCase
    {
        public void MaxDepthPossible4()
        {
            const int n = 20, d = 20;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test6 : TestCase
    {
        public void MaxDepthPossible5()
        {
            const int n = 7, d = 7;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test7 : TestCase
    {
        public void MaxDepthPossible6()
        {
            const int n = 100, d = 100;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test8 : TestCase
    {
        public void MaxDepthPossible7()
        {
            const int n = 50, d = 50;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test9 : TestCase
    {
        public void MaxDepthPossible8()
        {
            const int n = 300, d = 300;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test10 : TestCase
    {
        public void MaxDepthPossible9()
        {
            const int n = 1000, d = 1000;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test11 : TestCase
    {
        public void InvalidDepth1()
        {
            const int n = 0, d = 1;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test12 : TestCase
    {
        public void InvalidDepth2()
        {
            const int n = 5, d = 10;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test13 : TestCase
    {
        public void InvalidDepth3()
        {
            const int n = 10, d = 11;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test14 : TestCase
    {
        public void InvalidDepth4()
        {
            const int n = 1, d = 1000;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test15 : TestCase
    {
        public void InvalidDepth5()
        {
            const int n = 1000, d = 1001;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }

    }

    public class Test16 : TestCase
    {
        public void InvalidDepth6()
        {
            const int n = 1000, d = 2000;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test17 : TestCase
    {
        public void InvalidDepth7()
        {
            const int n = 15, d = 0;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test18 : TestCase
    {
        public void InvalidDepth8()
        {
            const int n = 1, d = 0;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test19 : TestCase
    {
        public void InvalidDepth9()
        {
            const int n = 10, d = 0;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test20 : TestCase
    {
        public void InvalidDepth10()
        {
            const int n = 100, d = 0;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test21 : TestCase
    {
        public void InvalidDepth11()
        {
            const int n = 1000, d = 0;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test22 : TestCase
    {
        public void MinDepthPossible1()
        {
            const int n = 2, d = 1;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test23 : TestCase
    {
        public void MinDepthPossible2()
        {
            const int n = 12, d = 1;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test24 : TestCase
    {
        public void MinDepthPossible3()
        {
            const int n = 50, d = 1;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test25 : TestCase
    {
        public void MinDepthPossible4()
        {
            const int n = 1000, d = 1;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test26 : TestCase
    {
        public void MinDepthPossible5()
        {
            const int n = 1200, d = 1;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test27 : TestCase
    {
        public void NormalCase1()
        {
            const int n = 8, d = 2;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test28 : TestCase
    {
        public void NormalCase2()
        {
            const int n = 8, d = 4;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test29 : TestCase
    {
        public void NormalCase3()
        {
            const int n = 9, d = 5;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test30 : TestCase
    {
        public void NormalCase4()
        {
            const int n = 11, d = 8;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test31 : TestCase
    {
        public void NormalCase5()
        {
            const int n = 10, d = 7;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test32 : TestCase
    {
        public void NormalCase6()
        {
            const int n = 15, d = 14;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test33 : TestCase
    {
        public void NormalCase7()
        {
            const int n = 13, d = 6;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test34 : TestCase
    {
        public void NormalCase8()
        {
            const int n = 18, d = 2;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test35 : TestCase
    {
        public void NormalCase9()
        {
            const int n = 30, d = 28;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test36 : TestCase
    {
        public void NormalCase10()
        {
            const int n = 100, d = 98;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test37 : TestCase
    {
        public void NormalCase11()
        {
            const int n = 120, d = 118;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }

    public class Test38 : TestCase
    {
        public void NormalCase12()
        {
            const int n = 400, d = 399;
            Assert.That(ParentesisTest.Student(n, d), Is.SequenceEqualTo(ParentesisTest.Solution(n, d)));
        }
    }
}
