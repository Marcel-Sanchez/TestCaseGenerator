﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Weboo.Examen.Interfaces;

namespace ConcursoACMTester
{
    public class Concurso : IConcurso
    {
        private readonly int teams;
        private readonly int problems;

        private readonly int[,] acc;
        private readonly int[,] wa;
        private readonly int[] disqualified;

        private readonly int[] teamIds;
        private readonly int[] problemIds;

        public Concurso(int equipos, int problemas, int penalizacion)
        {
            teams = equipos;
            problems = problemas;
            Penalizacion = penalizacion;

            acc = new int[equipos + 1, problemas + 1];
            wa = new int[equipos + 1, problemas + 1];
            disqualified = new int[equipos + 1];

            for (int i = 0; i < disqualified.Length; i++)
                disqualified[i] = -1;

            for (int i = 1; i <= equipos; i++)
                for (int j = 1; j <= problemas; j++)
                    acc[i, j] = -1;

            teamIds = new int[teams];
            problemIds = new int[problems];

            for (int i = 1; i <= teams; i++)
                teamIds[i - 1] = i;

            for (int i = 1; i <= problems; i++)
                problemIds[i - 1] = i;
        }
        public int Penalizacion { get; private set; }

        public void RegistrarEnvio(int tiempo, int equipo, int problema, bool correcto)
        {
            if (disqualified[equipo] != -1) return;

            if (correcto)
            {
                if (acc[equipo, problema] == -1)
                    acc[equipo, problema] = tiempo;
            }
            else if (acc[equipo, problema] == -1)
            {
                wa[equipo, problema]++;
            }
        }

        public void RegistrarDescalificacion(int tiempo, int equipo)
        {
            if (disqualified[equipo] != -1) return;
            disqualified[equipo] = tiempo;
        }

        public IEnumerable<int> TablaDePosiciones(int tiempo)
        {
            int[] accepted = new int[teams];
            int[] penalty = new int[teams];

            for (int i = 1; i <= teams; i++)
                for (int j = 1; j <= problems; j++)
                    if (acc[i, j] != -1 && acc[i, j] <= tiempo)
                    {
                        accepted[i - 1]++;
                        penalty[i - 1] += acc[i, j] + Penalizacion * wa[i, j];
                    }

            int[] result = new int[teams];
            teamIds.CopyTo(result, 0);
            Array.Sort(result, new AcmComparer(accepted, penalty));

            return result.Where(x => disqualified[x] == -1 || disqualified[x] > tiempo);
        }

        public IEnumerable<int> EquiposDescalificados(int tiempo)
        {
            return teamIds.Where(x => disqualified[x] != -1 && disqualified[x] <= tiempo);
        }

        public IEnumerable<int> ProblemasResueltos(int tiempo, int equipo)
        {
            if (disqualified[equipo] != -1 && disqualified[equipo] <= tiempo)
                return Enumerable.Empty<int>();

            return problemIds.Where(p => acc[equipo, p] != -1 && acc[equipo, p] <= tiempo);
        }

        public IEnumerable<int> ProblemasConMasSoluciones(int tiempo)
        {
            int[] keys = new int[problems];

            for (int i = 1; i <= teams; i++)
                if (disqualified[i] == -1 || disqualified[i] > tiempo)
                    for (int j = 1; j <= problems; j++)
                        if (acc[i, j] != -1 && acc[i, j] <= tiempo)
                            keys[j - 1]--;

            int[] items = new int[problemIds.Length];
            problemIds.CopyTo(items, 0);

            Array.Sort(keys, items);

            return items;
        }

        public IComparer<int> GetRankingComparer(int time)
        {
            int[] accepted = new int[teams];
            int[] penalty = new int[teams];

            for (int i = 1; i <= teams; i++)
                for (int j = 1; j <= problems; j++)
                    if (acc[i, j] != -1 && acc[i, j] <= time)
                    {
                        accepted[i - 1]++;
                        penalty[i - 1] += acc[i, j] + Penalizacion * wa[i, j];
                    }

            return new AcmComparer(accepted, penalty);
        }

        public Dictionary<int, int> GetProblemsSolved(int time)
        {
            int[] keys = new int[problems];

            for (int i = 1; i <= teams; i++)
                if (disqualified[i] == -1 || disqualified[i] > time)
                    for (int j = 1; j <= problems; j++)
                        if (acc[i, j] != -1 && acc[i, j] <= time)
                            keys[j - 1]--;

            return Enumerable.Range(0, problems)
                .ToDictionary(m => m + 1, m => keys[m]);
        }
    }

    public class AcmComparer : IComparer<int>
    {
        private readonly int[] accepted;
        private readonly int[] penalty;

        public AcmComparer(int[] accepted, int[] penalty)
        {
            this.accepted = accepted;
            this.penalty = penalty;
        }

        public int Compare(int team1, int team2)
        {
            if (accepted[team1 - 1] == accepted[team2 - 1])
                return penalty[team1 - 1].CompareTo(penalty[team2 - 1]);
            return accepted[team2 - 1].CompareTo(accepted[team1 - 1]);
        }
    }

}