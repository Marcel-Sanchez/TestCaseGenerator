﻿using Weboo.Assess.Tester;
using Weboo.Examen.Interfaces;

namespace ConcursoACMTester
{
    public class ConcursoACMTester : InterfaceTester<IConcurso>
    {
        protected override IConcurso BuildTarget(object[] args)
        {
            int teams = (int) args[0];
            int problems = (int) args[1];
            int penalization = (int) args[2];
            return ReflectionHelper.CreateInstance<IConcurso>(teams, problems, penalization);
        }

        protected override IConcurso BuildBenchmark(object[] args)
        {
            int teams = (int)args[0];
            int problems = (int)args[1];
            int penalization = (int)args[2];
            return new Concurso(teams, problems, penalization);
        }


        private void CheckRanking(int time)
        {
            var acmComparer = (Benchmark as Concurso).GetRankingComparer(time);
            CheckOrdering(contest => contest.TablaDePosiciones(time), (a, b) => acmComparer.Compare(a, b));
        }

        private void CheckMoreSolved(int time)
        {
            var problemsSolved = (Benchmark as Concurso).GetProblemsSolved(time);
            CheckOrdering(contest => contest.ProblemasConMasSoluciones(time), (a, b) => problemsSolved[a] - problemsSolved[b]);
        }


        #region Ejemplos del Examen

        private void SetupEjemplo1()
        {
            Initialize(8, 5, 20);

            Perform(contest => contest.RegistrarEnvio(3, 1, 5, false));

            //El equipo 2 hace un envío correcto al problema 5 en el minuto 4
            Perform(contest => contest.RegistrarEnvio(4, 2, 5, true));

            //El equipo 1 hace un envío correcto al problema 5 en el minuto 5
            Perform(contest => contest.RegistrarEnvio(5, 1, 5, true));

            //El equipo 3 hace un envío correcto al problema 5 en el minuto 6
            Perform(contest => contest.RegistrarEnvio(6, 3, 5, true));

            //El equipo 4 hace un envío correcto al problema 5 en el minuto 6
            Perform(contest => contest.RegistrarEnvio(6, 4, 5, true));

            //El equipo 5 hace un envío correcto al problema 5 en el minuto 10
            Perform(contest => contest.RegistrarEnvio(10, 5, 5, true));

            //El equipo 2 hace un envío incorrecto al problema 3 en el minuto 15
            Perform(contest => contest.RegistrarEnvio(15, 2, 3, false));

            //El equipo 2 hace un envío correcto al problema 3 en el minuto 17
            Perform(contest => contest.RegistrarEnvio(17, 2, 3, true));

            //El equipo 5 hace un envío correcto al problema 3 en el minuto 20
            Perform(contest => contest.RegistrarEnvio(20, 5, 3, true));
        }

        private void SetupEjemplo2()
        {
            //Son descalificados los equipos 4 y 7 en los minutos 33 y 40 respectivamente
            Perform(contest => contest.RegistrarDescalificacion(33, 4));
            Perform(contest => contest.RegistrarDescalificacion(40, 7));
        }

        public void Ejemplo1()
        {
            SetupEjemplo1();

            CheckRanking(2);
        }

        public void Ejemplo2()
        {
            SetupEjemplo1();
            CheckRanking(7);
        }

        public void Ejemplo3()
        {
            SetupEjemplo1();

            CheckRanking(30);
        }

        public void Ejemplo4()
        {
            SetupEjemplo1();
            SetupEjemplo2();

            CheckRanking(32);
        }

        public void Ejemplo5()
        {
            SetupEjemplo1();
            SetupEjemplo2();

            CheckRanking(34);
        }

        public void Ejemplo6()
        {
            SetupEjemplo1();
            SetupEjemplo2();

            CheckRanking(41);
        }

        public void Ejemplo7()
        {
            SetupEjemplo1();
            SetupEjemplo2();

            CheckRanking(41);
        }

        public void Ejemplo8()
        {
            SetupEjemplo1();
            SetupEjemplo2();

            CheckMultiSet(contest => contest.EquiposDescalificados(34));
        }

        public void Ejemplo9()
        {
            SetupEjemplo1();
            SetupEjemplo2();

            CheckMultiSet(contest => contest.EquiposDescalificados(41));
        }

        public void Ejemplo10()
        {
            SetupEjemplo1();
            SetupEjemplo2();

            CheckMultiSet(contest => contest.ProblemasResueltos(16, 1));
        }

        public void Ejemplo11()
        {
            SetupEjemplo1();
            SetupEjemplo2();

            CheckMultiSet(contest => contest.ProblemasResueltos(16, 5));
        }

        public void Ejemplo12()
        {
            SetupEjemplo1();
            SetupEjemplo2();

            CheckMultiSet(contest => contest.ProblemasResueltos(16, 8));
        }

        public void Ejemplo13()
        {
            SetupEjemplo1();
            SetupEjemplo2();

            CheckMultiSet(contest => contest.ProblemasResueltos(45, 1));
        }

        public void Ejemplo14()
        {
            SetupEjemplo1();
            SetupEjemplo2();

            CheckMultiSet(contest => contest.ProblemasResueltos(45, 5));
        }

        public void Ejemplo15()
        {
            SetupEjemplo1();
            SetupEjemplo2();

            CheckMultiSet(contest => contest.ProblemasResueltos(45, 8));
        }

        public void Ejemplo16()
        {
            SetupEjemplo1();
            SetupEjemplo2();

            CheckMoreSolved(0);
        }

        public void Ejemplo17()
        {
            SetupEjemplo1();
            SetupEjemplo2();

            CheckMoreSolved(7);
        }

        public void Ejemplo18()
        {
            SetupEjemplo1();
            SetupEjemplo2();

            CheckMoreSolved(18);
        }

        #endregion


        public void TablaDePosiciones1()
        {
            Initialize(4, 10, 40);

            Perform(contest => contest.RegistrarEnvio(20, 1, 3, true));
            Perform(contest => contest.RegistrarEnvio(21, 2, 1, true));
            Perform(contest => contest.RegistrarEnvio(22, 2, 2, true));
            Perform(contest => contest.RegistrarEnvio(30, 1, 4, true));

            CheckRanking(32);
        }

        public void TablaDePosiciones2()
        {
            Initialize(4, 10, 40);

            Perform(contest => contest.RegistrarEnvio(2, 2, 1, true));
            Perform(contest => contest.RegistrarEnvio(4, 1, 3, true));
            Perform(contest => contest.RegistrarEnvio(6, 1, 1, false));
            Perform(contest => contest.RegistrarEnvio(7, 1, 5, true));
            Perform(contest => contest.RegistrarEnvio(10, 2, 3, true));

            CheckRanking(12);
        }

        public void TablaDePosiciones3()
        {
            Initialize(4, 10, 40);

            Perform(contest => contest.RegistrarEnvio(2, 2, 1, true));
            Perform(contest => contest.RegistrarEnvio(4, 1, 3, true));
            Perform(contest => contest.RegistrarEnvio(6, 1, 5, false));
            Perform(contest => contest.RegistrarEnvio(7, 1, 5, true));
            Perform(contest => contest.RegistrarEnvio(10, 2, 3, true));

            CheckRanking(12);
        }

        public void TablaDePosiciones4()
        {
            Initialize(4, 10, 40);

            Perform(contest => contest.RegistrarEnvio(2, 2, 1, true));
            Perform(contest => contest.RegistrarEnvio(4, 1, 3, true));
            Perform(contest => contest.RegistrarEnvio(6, 1, 5, false));
            Perform(contest => contest.RegistrarEnvio(7, 1, 5, true));
            Perform(contest => contest.RegistrarEnvio(60, 2, 3, true));

            CheckRanking(61);
        }

        public void TablaDePosiciones5()
        {
            Initialize(4, 10, 40);

            Perform(contest => contest.RegistrarEnvio(2, 2, 1, true));
            Perform(contest => contest.RegistrarEnvio(4, 1, 3, true));
            Perform(contest => contest.RegistrarEnvio(6, 1, 5, false));
            Perform(contest => contest.RegistrarEnvio(7, 1, 5, true));
            Perform(contest => contest.RegistrarEnvio(8, 1, 1, true));
            Perform(contest => contest.RegistrarDescalificacion(10, 1));
            Perform(contest => contest.RegistrarEnvio(10, 2, 3, true));

            CheckRanking(11);
        }

        public void TablaDePosiciones6()
        {
            Initialize(4, 10, 40);

            Perform(contest => contest.RegistrarEnvio(2, 2, 1, true));
            Perform(contest => contest.RegistrarEnvio(4, 1, 3, true));
            Perform(contest => contest.RegistrarEnvio(6, 1, 5, false));
            Perform(contest => contest.RegistrarEnvio(7, 1, 5, true));
            Perform(contest => contest.RegistrarEnvio(8, 1, 1, true));
            Perform(contest => contest.RegistrarDescalificacion(10, 1));
            Perform(contest => contest.RegistrarEnvio(10, 2, 3, true));

            CheckRanking(9);
        }

        public void TablaDePosiciones7()
        {
            Initialize(4, 10, 40);

            Perform(contest => contest.RegistrarEnvio(2, 2, 1, true));
            Perform(contest => contest.RegistrarEnvio(4, 1, 3, true));
            Perform(contest => contest.RegistrarEnvio(6, 1, 5, false));
            Perform(contest => contest.RegistrarEnvio(7, 1, 5, true));
            Perform(contest => contest.RegistrarEnvio(8, 1, 1, true));
            Perform(contest => contest.RegistrarDescalificacion(10, 1));
            Perform(contest => contest.RegistrarEnvio(10, 2, 3, true));
            Perform(contest => contest.RegistrarDescalificacion(15, 4));
            Perform(contest => contest.RegistrarDescalificacion(20, 2));

            CheckRanking(40);
        }

        public void EquiposDescalificados1()
        {
            Initialize(8, 10, 40);

            Perform(contest => contest.RegistrarEnvio(2, 2, 1, true));
            Perform(contest => contest.RegistrarEnvio(4, 1, 3, true));
            Perform(contest => contest.RegistrarDescalificacion(4, 1));
            Perform(contest => contest.RegistrarEnvio(5, 2, 3, true));
            Perform(contest => contest.RegistrarDescalificacion(8, 6));
            Perform(contest => contest.RegistrarEnvio(9, 3, 5, false));
            Perform(contest => contest.RegistrarEnvio(12, 3, 5, true));
            Perform(contest => contest.RegistrarEnvio(15, 3, 1, true));
            Perform(contest => contest.RegistrarDescalificacion(20, 3));

            CheckMultiSet(contest => contest.EquiposDescalificados(2));
        }

        public void EquiposDescalificados2()
        {
            Initialize(8, 10, 40);

            Perform(contest => contest.RegistrarEnvio(2, 2, 1, true));
            Perform(contest => contest.RegistrarEnvio(4, 1, 3, true));
            Perform(contest => contest.RegistrarDescalificacion(4, 1));
            Perform(contest => contest.RegistrarEnvio(5, 2, 3, true));
            Perform(contest => contest.RegistrarDescalificacion(8, 6));
            Perform(contest => contest.RegistrarEnvio(9, 3, 5, false));
            Perform(contest => contest.RegistrarEnvio(12, 7, 5, true));
            Perform(contest => contest.RegistrarEnvio(15, 3, 1, true));
            Perform(contest => contest.RegistrarDescalificacion(20, 3));

            CheckMultiSet(contest => contest.EquiposDescalificados(10));
        }

        public void EquiposDescalificados3()
        {
            Initialize(4, 10, 40);

            Perform(contest => contest.RegistrarEnvio(2, 2, 1, true));
            Perform(contest => contest.RegistrarEnvio(4, 1, 3, true));
            Perform(contest => contest.RegistrarDescalificacion(4, 1));
            Perform(contest => contest.RegistrarEnvio(5, 2, 3, true));
            Perform(contest => contest.RegistrarDescalificacion(8, 4));
            Perform(contest => contest.RegistrarDescalificacion(10, 3));
            Perform(contest => contest.RegistrarDescalificacion(20, 2));

            CheckMultiSet(contest => contest.EquiposDescalificados(25));
        }

        public void ProblemasResueltos1()
        {
            Initialize(4, 10, 40);

            Perform(contest => contest.RegistrarEnvio(2, 1, 5, true));
            Perform(contest => contest.RegistrarEnvio(4, 1, 3, true));

            CheckMultiSet(contest => contest.ProblemasResueltos(5, 1));
        }

        public void ProblemasResueltos2()
        {
            Initialize(4, 10, 40);

            Perform(contest => contest.RegistrarEnvio(2, 1, 5, true));
            Perform(contest => contest.RegistrarEnvio(4, 1, 3, false));
            Perform(contest => contest.RegistrarEnvio(6, 1, 4, false));
            Perform(contest => contest.RegistrarEnvio(8, 1, 3, false));
            Perform(contest => contest.RegistrarEnvio(27, 1, 3, true));

            CheckMultiSet(contest => contest.ProblemasResueltos(28, 1));
        }

        public void ProblemasResueltos3()
        {
            Initialize(4, 10, 40);

            Perform(contest => contest.RegistrarEnvio(2, 1, 5, true));
            Perform(contest => contest.RegistrarEnvio(5, 1, 3, false));
            Perform(contest => contest.RegistrarEnvio(7, 1, 4, false));
            Perform(contest => contest.RegistrarEnvio(11, 1, 3, false));
            Perform(contest => contest.RegistrarEnvio(13, 1, 3, true));
            Perform(contest => contest.RegistrarDescalificacion(20, 1));

            CheckMultiSet(contest => contest.ProblemasResueltos(19, 1));
        }

        public void ProblemasResueltos4()
        {
            Initialize(4, 10, 40);

            Perform(contest => contest.RegistrarEnvio(2, 1, 5, true));
            Perform(contest => contest.RegistrarEnvio(5, 1, 3, false));
            Perform(contest => contest.RegistrarEnvio(7, 1, 4, false));
            Perform(contest => contest.RegistrarEnvio(11, 1, 3, false));
            Perform(contest => contest.RegistrarEnvio(13, 2, 3, true));

            CheckMultiSet(contest => contest.ProblemasResueltos(15, 1));
        }

        public void ProblemasResueltos5()
        {
            Initialize(4, 10, 40);

            Perform(contest => contest.RegistrarEnvio(2, 1, 5, false));
            Perform(contest => contest.RegistrarEnvio(5, 1, 3, false));
            Perform(contest => contest.RegistrarEnvio(7, 1, 4, false));
            Perform(contest => contest.RegistrarEnvio(11, 1, 2, false));
            Perform(contest => contest.RegistrarEnvio(13, 2, 3, true));
            Perform(contest => contest.RegistrarEnvio(14, 4, 1, true));
            Perform(contest => contest.RegistrarEnvio(15, 3, 8, true));

            CheckMultiSet(contest => contest.ProblemasResueltos(15, 1));
        }

        public void ProblemasConMasSoluciones1()
        {
            Initialize(6, 10, 25);

            Perform(contest => contest.RegistrarEnvio(5, 1, 4, true));

            CheckMoreSolved(10);
        }

        public void ProblemasConMasSoluciones2()
        {
            Initialize(6, 10, 25);

            Perform(contest => contest.RegistrarEnvio(5, 1, 4, true));
            Perform(contest => contest.RegistrarEnvio(6, 2, 1, false));
            Perform(contest => contest.RegistrarEnvio(7, 2, 1, false));
            Perform(contest => contest.RegistrarEnvio(9, 6, 1, false));
            Perform(contest => contest.RegistrarEnvio(10, 3, 1, true));
            Perform(contest => contest.RegistrarEnvio(15, 4, 3, true));
            Perform(contest => contest.RegistrarEnvio(18, 1, 1, false));
            Perform(contest => contest.RegistrarEnvio(20, 1, 3, true));
            Perform(contest => contest.RegistrarEnvio(22, 2, 4, true));

            CheckMoreSolved(25);
        }

        public void ProblemasConMasSoluciones3()
        {
            Initialize(6, 10, 25);

            Perform(contest => contest.RegistrarEnvio(5, 1, 4, true));
            Perform(contest => contest.RegistrarEnvio(6, 2, 1, false));
            Perform(contest => contest.RegistrarEnvio(7, 2, 1, false));
            Perform(contest => contest.RegistrarEnvio(9, 6, 1, false));
            Perform(contest => contest.RegistrarEnvio(10, 3, 1, true));
            Perform(contest => contest.RegistrarEnvio(15, 4, 3, true));
            Perform(contest => contest.RegistrarEnvio(18, 1, 1, false));

            CheckMoreSolved(40);
        }

        public void ProblemasConMasSoluciones4()
        {
            Initialize(6, 10, 25);

            Perform(contest => contest.RegistrarEnvio(5, 1, 4, true));
            Perform(contest => contest.RegistrarEnvio(6, 1, 6, true));
            Perform(contest => contest.RegistrarEnvio(7, 2, 4, true));
            Perform(contest => contest.RegistrarEnvio(9, 3, 4, true));
            Perform(contest => contest.RegistrarEnvio(11, 6, 6, true));
            Perform(contest => contest.RegistrarEnvio(12, 5, 4, true));
            Perform(contest => contest.RegistrarEnvio(13, 5, 6, true));
            Perform(contest => contest.RegistrarDescalificacion(14, 2));
            Perform(contest => contest.RegistrarDescalificacion(15, 1));
            Perform(contest => contest.RegistrarDescalificacion(20, 3));

            CheckMoreSolved(13);
        }

        public void ProblemasConMasSoluciones5()
        {
            Initialize(6, 10, 25);

            Perform(contest => contest.RegistrarEnvio(5, 1, 4, true));
            Perform(contest => contest.RegistrarEnvio(6, 1, 6, true));
            Perform(contest => contest.RegistrarEnvio(7, 2, 4, true));
            Perform(contest => contest.RegistrarEnvio(9, 3, 4, true));
            Perform(contest => contest.RegistrarEnvio(11, 6, 6, true));
            Perform(contest => contest.RegistrarEnvio(12, 5, 4, true));
            Perform(contest => contest.RegistrarEnvio(13, 5, 6, true));
            Perform(contest => contest.RegistrarDescalificacion(14, 2));
            Perform(contest => contest.RegistrarDescalificacion(15, 1));
            Perform(contest => contest.RegistrarDescalificacion(20, 3));

            CheckMoreSolved(25);
        }
    }
}
