﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Assess.Tester;

namespace InviertebotTester
{
    public abstract class InviertebotTests : TestCase
    {
        public int[] Student(int n, int[] i, int[] d)
        {
            return ReflectionHelper.InvokeStatic<int[]>("Weboo.Examen.Inviertebot", "EjecutaInstrucciones", n, i, d);
        }

        public int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            int[] gifts = new int[n];
            for(int p = 0; p < n; p++)
            {
                gifts[p] = p + 1;
            }

            for (int p = 0; p < i.Length; p++)
            {
                int len = ((d[p] - i[p] + n) % n) / 2;
                for (int l = i[p], r = d[p]; len >= 0; len--)
                {
                    int tmp = gifts[l];
                    gifts[l] = gifts[r];
                    gifts[r] = tmp;

                    l = (l + 1) % n;
                    r = (r - 1 + n) % n;
                }
            }

            return gifts;
        }
    }

    public class Ejemplo1Test : InviertebotTests
    {
        public void Ejemplo1()
        {
            int n = 6;
            int[] iStudent = { 0, 5, 4, 3, 3 };
            int[] dStudent = { 2, 1, 4, 1, 0 };

            int[] iBenchmark = { 0, 5, 4, 3, 3 };
            int[] dBenchmark = { 2, 1, 4, 1, 0 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class Ejemplo2Test : InviertebotTests
    {
        public void Ejemplo2()
        {
            int n = 10;
            int[] iStudent = { 0, 0, 3 };
            int[] dStudent = { 5, 5, 3 };

            int[] iBenchmark = { 0, 0, 3 };
            int[] dBenchmark = { 5, 5, 3 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class Ejemplo3Test : InviertebotTests
    {
        public void Ejemplo3()
        {
            int n = 8;
            int[] iStudent = { 4, 1, 6, 3, 7 };
            int[] dStudent = { 5, 7, 1, 2, 1 };

            int[] iBenchmark = { 4, 1, 6, 3, 7 };
            int[] dBenchmark = { 5, 7, 1, 2, 1 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class Ejemplo4Test : InviertebotTests
    {
        public void Ejemplo4()
        {
            int n = 2;
            int[] iStudent = { 1, 0, 0, 1, 1 };
            int[] dStudent = { 0, 1, 1, 0, 0 };

            int[] iBenchmark = { 1, 0, 0, 1, 1 };
            int[] dBenchmark = { 0, 1, 1, 0, 0 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class Ejemplo5Test : InviertebotTests
    {
        public void Ejemplo5()
        {
            int n = 6;
            int[] iStudent = { 2, 3, 3, 4, 5 };
            int[] dStudent = { 3, 5, 4, 5, 1 };

            int[] iBenchmark = { 2, 3, 3, 4, 5 };
            int[] dBenchmark = { 3, 5, 4, 5, 1 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples1Test : InviertebotTests
    {
        public void IntervalosSimples1()
        {
            int n = 10;
            int[] iStudent = { 2, 8, 3, 8, 5 };
            int[] dStudent = { 2, 9, 9, 8, 9 };

            int[] iBenchmark = { 2, 8, 3, 8, 5 };
            int[] dBenchmark = { 2, 9, 9, 8, 9 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples2Test : InviertebotTests
    {
        public void IntervalosSimples2()
        {
            int n = 1;
            int[] iStudent = { 0 };
            int[] dStudent = { 0 };

            int[] iBenchmark = { 0 };
            int[] dBenchmark = { 0 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples3Test : InviertebotTests
    {
        public void IntervalosSimples3()
        {
            int n = 1;
            int[] iStudent = { 0, 0, 0, 0 };
            int[] dStudent = { 0, 0, 0, 0 };

            int[] iBenchmark = { 0, 0, 0, 0 };
            int[] dBenchmark = { 0, 0, 0, 0 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples4Test : InviertebotTests
    {
        public void IntervalosSimples4()
        {
            int n = 3;
            int[] iStudent = { 0 };
            int[] dStudent = { 2 };

            int[] iBenchmark = { 0 };
            int[] dBenchmark = { 2 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples5Test : InviertebotTests
    {
        public void IntervalosSimples5()
        {
            int n = 3;
            int[] iStudent = { 0, 0 };
            int[] dStudent = { 2, 2 };

            int[] iBenchmark = { 0, 0 };
            int[] dBenchmark = { 2, 2 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples6Test : InviertebotTests
    {
        public void IntervalosSimples6()
        {
            int n = 8;
            int[] iStudent = { 0, 1, 2, 3 };
            int[] dStudent = { 7, 6, 5, 4 };

            int[] iBenchmark = { 0, 1, 2, 3 };
            int[] dBenchmark = { 7, 6, 5, 4 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples7Test : InviertebotTests
    {
        public void IntervalosSimples7()
        {
            int n = 8;
            int[] iStudent = { 3, 2, 1, 0 };
            int[] dStudent = { 4, 5, 6, 7 };

            int[] iBenchmark = { 3, 2, 1, 0 };
            int[] dBenchmark = { 4, 5, 6, 7 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples8Test : InviertebotTests
    {
        public void IntervalosSimples8()
        {
            int n = 8;
            int[] iStudent = { 0, 1, 4, 0 };
            int[] dStudent = { 0, 1, 4, 0 };

            int[] iBenchmark = { 0, 1, 4, 0 };
            int[] dBenchmark = { 0, 1, 4, 0 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples9Test : InviertebotTests
    {
        public void IntervalosSimples9()
        {
            int n = 20;
            int[] iStudent = { 0, 4, 6, 15 };
            int[] dStudent = { 6, 8, 8, 16 };

            int[] iBenchmark = { 0, 4, 6, 15 };
            int[] dBenchmark = { 6, 8, 8, 16 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples10Test : InviertebotTests
    {
        public void IntervalosSimples10()
        {
            int n = 6;
            int[] iStudent = { 0, 4, 2, 1 };
            int[] dStudent = { 5, 5, 5, 5 };

            int[] iBenchmark = { 0, 4, 2, 1 };
            int[] dBenchmark = { 5, 5, 5, 5 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples11Test : InviertebotTests
    {
        public void IntervalosSimples11()
        {
            int n = 20;
            int[] iStudent = { 1, 6, 5, 11, 17, 2, 7, 8, 5, 14 };
            int[] dStudent = { 14, 18, 10, 19, 17, 18, 14, 11, 14, 15 };

            int[] iBenchmark = { 1, 6, 5, 11, 17, 2, 7, 8, 5, 14 };
            int[] dBenchmark = { 14, 18, 10, 19, 17, 18, 14, 11, 14, 15 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples12Test : InviertebotTests
    {
        public void IntervalosSimples12()
        {
            int n = 30;
            int[] iStudent = { 13, 27, 8, 7, 12, 20, 15, 17 };
            int[] dStudent = { 24, 27, 10, 15, 15, 28, 20, 27 };

            int[] iBenchmark = { 13, 27, 8, 7, 12, 20, 15, 17 };
            int[] dBenchmark = { 24, 27, 10, 15, 15, 28, 20, 27 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples13Test : InviertebotTests
    {
        public void IntervalosSimples13()
        {
            int n = 35;
            int[] iStudent = { 26, 26, 29, 33, 4, 16, 7, 15, 0 };
            int[] dStudent = { 33, 28, 30, 34, 23, 24, 16, 15, 11 };

            int[] iBenchmark = { 26, 26, 29, 33, 4, 16, 7, 15, 0 };
            int[] dBenchmark = { 33, 28, 30, 34, 23, 24, 16, 15, 11 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples14Test : InviertebotTests
    {
        public void IntervalosSimples14()
        {
            int n = 50;
            int[] iStudent = { 0, 33, 23, 21, 44, 46, 32, 44, 3, 1, 7, 9, 48, 41, 17, 9, 45, 5, 14, 32, 25, 26, 34, 10, 5 };
            int[] dStudent = { 39, 44, 49, 24, 49, 47, 32, 45, 32, 39, 12, 37, 49, 48, 40, 48, 48, 15, 26, 49, 38, 35, 45, 14, 19 };

            int[] iBenchmark = { 0, 33, 23, 21, 44, 46, 32, 44, 3, 1, 7, 9, 48, 41, 17, 9, 45, 5, 14, 32, 25, 26, 34, 10, 5 };
            int[] dBenchmark = { 39, 44, 49, 24, 49, 47, 32, 45, 32, 39, 12, 37, 49, 48, 40, 48, 48, 15, 26, 49, 38, 35, 45, 14, 19 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples15Test : InviertebotTests
    {
        public void IntervalosSimples15()
        {
            int n = 10;
            int[] iStudent = { 6, 6, 8, 6, 6, 1, 3, 4, 3, 4, 8, 1, 3, 7, 4, 0, 6, 4, 9, 4 };
            int[] dStudent = { 8, 9, 9, 8, 9, 5, 9, 4, 6, 4, 8, 4, 3, 8, 6, 2, 6, 4, 9, 8 };

            int[] iBenchmark = { 6, 6, 8, 6, 6, 1, 3, 4, 3, 4, 8, 1, 3, 7, 4, 0, 6, 4, 9, 4 };
            int[] dBenchmark = { 8, 9, 9, 8, 9, 5, 9, 4, 6, 4, 8, 4, 3, 8, 6, 2, 6, 4, 9, 8 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples16Test : InviertebotTests
    {
        public void IntervalosSimples16()
        {
            int n = 10;
            int[] iStudent = { 2, 5, 1, 1, 1, 3, 7, 0, 3, 4, 6, 2, 3, 4, 3, 9, 8, 8, 6, 3, 4, 5, 5, 4, 6, 3, 1, 6, 0, 3 };
            int[] dStudent = { 4, 5, 9, 3, 2, 3, 9, 9, 8, 7, 8, 5, 9, 9, 8, 9, 9, 8, 9, 3, 9, 5, 9, 5, 9, 3, 5, 6, 8, 8 };

            int[] iBenchmark = { 2, 5, 1, 1, 1, 3, 7, 0, 3, 4, 6, 2, 3, 4, 3, 9, 8, 8, 6, 3, 4, 5, 5, 4, 6, 3, 1, 6, 0, 3 };
            int[] dBenchmark = { 4, 5, 9, 3, 2, 3, 9, 9, 8, 7, 8, 5, 9, 9, 8, 9, 9, 8, 9, 3, 9, 5, 9, 5, 9, 3, 5, 6, 8, 8 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples17Test : InviertebotTests
    {
        public void IntervalosSimples17()
        {
            int n = 20;
            int[] iStudent = { 0, 2, 4, 13, 19 };
            int[] dStudent = { 16, 3, 6, 13, 19 };

            int[] iBenchmark = { 0, 2, 4, 13, 19 };
            int[] dBenchmark = { 16, 3, 6, 13, 19 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples18Test : InviertebotTests
    {
        public void IntervalosSimples18()
        {
            int n = 17;
            int[] iStudent = { 10, 10, 11, 7, 1, 1, 2, 8, 6, 11, 3, 9, 15, 11, 3, 1, 10 };
            int[] dStudent = { 10, 16, 12, 10, 9, 2, 11, 15, 14, 15, 11, 16, 15, 12, 16, 5, 12 };

            int[] iBenchmark = { 10, 10, 11, 7, 1, 1, 2, 8, 6, 11, 3, 9, 15, 11, 3, 1, 10 };
            int[] dBenchmark = { 10, 16, 12, 10, 9, 2, 11, 15, 14, 15, 11, 16, 15, 12, 16, 5, 12 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples19Test : InviertebotTests
    {
        public void IntervalosSimples19()
        {
            int n = 15;
            int[] iStudent = { 1, 8, 10, 0, 1, 4, 5, 9, 2, 2 };
            int[] dStudent = { 2, 8, 11, 13, 9, 9, 10, 11, 11, 9 };

            int[] iBenchmark = { 1, 8, 10, 0, 1, 4, 5, 9, 2, 2 };
            int[] dBenchmark = { 2, 8, 11, 13, 9, 9, 10, 11, 11, 9 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosSimples20Test : InviertebotTests
    {
        public void IntervalosSimples20()
        {
            int n = 30;
            int[] iStudent = { 28, 3, 5, 8, 3 };
            int[] dStudent = { 28, 11, 6, 24, 28 };

            int[] iBenchmark = { 28, 3, 5, 8, 3 };
            int[] dBenchmark = { 28, 11, 6, 24, 28 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosCirculares1Test : InviertebotTests
    {
        public void IntervalosCirculares1()
        {
            int n = 50;
            int[] iStudent = { 1 };
            int[] dStudent = { 0 };

            int[] iBenchmark = { 1 };
            int[] dBenchmark = { 0 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosCirculares2Test : InviertebotTests
    {
        public void IntervalosCirculares2()
        {
            int n = 10;
            int[] iStudent = { 1, 0 };
            int[] dStudent = { 0, 1 };

            int[] iBenchmark = { 1, 0 };
            int[] dBenchmark = { 0, 1 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosCirculares3Test : InviertebotTests
    {
        public void IntervalosCirculares3()
        {
            int n = 10;
            int[] iStudent = { 9, 9 };
            int[] dStudent = { 0, 0 };

            int[] iBenchmark = { 9, 9 };
            int[] dBenchmark = { 0, 0 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosCirculares4Test : InviertebotTests
    {
        public void IntervalosCirculares4()
        {
            int n = 10;
            int[] iStudent = { 0, 3 };
            int[] dStudent = { 4, 2 };

            int[] iBenchmark = { 0, 3 };
            int[] dBenchmark = { 4, 2 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }

    public class IntervalosCirculares5Test : InviertebotTests
    {
        public void IntervalosCirculares5()
        {
            int n = 100;
            int[] iStudent = { 1, 51, 0 };
            int[] dStudent = { 50, 0, 99 };

            int[] iBenchmark = { 1, 51, 00 };
            int[] dBenchmark = { 50, 0, 99 };

            Assert.That(Student(n, iStudent, dStudent),
                Is.SequenceEqualTo(EjecutaInstrucciones(n, iBenchmark, dBenchmark)));
        }
    }
}
