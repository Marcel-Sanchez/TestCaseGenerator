﻿using Weboo.Assess.Tester;

namespace CadenasBalanceadasTester
{
    public abstract class CadenasBalanceadasTest : TestCase
    {
        public int Student(string s)
        {
            return ReflectionHelper.InvokeStatic<int>("Weboo.Examen.CadenasBalanceadas", "MinOperacionesParaBalancear", s);
        }
    }

    public class Ejemplo1Test : CadenasBalanceadasTest
    {
        public void Ejemplo1()
        {
            string s = "{{)";
            int sol = -1;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Ejemplo2Test : CadenasBalanceadasTest
    {
        public void Ejemplo2()
        {
            string s = "}}[)";
            int sol = 2;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Ejemplo3Test : CadenasBalanceadasTest
    {
        public void Ejemplo3()
        {
            string s = "(()[]){{}}";
            int sol = 0;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Ejemplo4Test : CadenasBalanceadasTest
    {
        public void Ejemplo4()
        {
            string s = "]{(]{{{[";
            int sol = 4;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Ejemplo5Test : CadenasBalanceadasTest
    {
        public void Ejemplo5()
        {
            string s = "{[]}}[}({]])";
            int sol = 3;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Ejemplo6Test : CadenasBalanceadasTest
    {
        public void Ejemplo6()
        {
            string s = "])[]{(()(]{}[[{]}][)";
            int sol = 6;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Ejemplo7Test : CadenasBalanceadasTest
    {
        public void Ejemplo7()
        {
            string s = ")](}[])}}(){({({}[(({][}";
            int sol = 9;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class NoSolucion1Test : CadenasBalanceadasTest
    {
        public void NoSolucion1()
        {
            string s = "(";
            int sol = -1;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class NoSolucion2Test : CadenasBalanceadasTest
    {
        public void NoSolucion2()
        {
            string s = "]";
            int sol = -1;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class NoSolucion3Test : CadenasBalanceadasTest
    {
        public void NoSolucion3()
        {
            string s = "(()";
            int sol = -1;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }
    public class NoSolucion4Test : CadenasBalanceadasTest
    {
        public void NoSolucion4()
        {
            string s = "())";
            int sol = -1;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class NoSolucion5Test : CadenasBalanceadasTest
    {
        public void NoSolucion5()
        {
            string s = "[({}{}[])]{)(()}[))][[}}[[(}([()](]{{{(](}{[]{}[)[(]})[(}][[})[}[){((]){))]()[}{){){[)}})]]{}{{][]]";
            int sol = -1;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Balanceadas1Test : CadenasBalanceadasTest
    {
        public void Balanceadas1()
        {
            string s = "()";
            int sol = 0;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Balanceadas2Test : CadenasBalanceadasTest
    {
        public void Balanceadas2()
        {
            string s = "[()]";
            int sol = 0;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Balanceadas3Test : CadenasBalanceadasTest
    {
        public void Balanceadas3()
        {
            string s = "{}[]";
            int sol = 0;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Balanceadas4Test : CadenasBalanceadasTest
    {
        public void Balanceadas4()
        {
            string s = "[{[]}]";
            int sol = 0;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Balanceadas5Test : CadenasBalanceadasTest
    {
        public void Balanceadas5()
        {
            string s = "()(({}(()))[]{[]})";
            int sol = 0;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class SemiBalanceadas1Test : CadenasBalanceadasTest
    {
        public void SemiBalanceadas1()
        {
            string s = "{)";
            int sol = 1;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Semibalanceadas2Test : CadenasBalanceadasTest
    {
        public void Semibalanceadas2()
        {
            string s = "[}";
            int sol = 1;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Semibalanceadas3Test : CadenasBalanceadasTest
    {
        public void Semibalanceadas3()
        {
            string s = "[{]}";
            int sol = 2;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Semibalanceadas4Test : CadenasBalanceadasTest
    {
        public void Semibalanceadas4()
        {
            string s = "{[}{]}";
            int sol = 2;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Semibalanceadas5Test : CadenasBalanceadasTest
    {
        public void Semibalanceadas5()
        {
            string s = "([{)]}";
            int sol = 2;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Semibalanceadas6Test : CadenasBalanceadasTest
    {
        public void Semibalanceadas6()
        {
            string s = "([[()])]";
            int sol = 2;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Semibalanceadas7Test : CadenasBalanceadasTest
    {
        public void Semibalanceadas7()
        {
            string s = "{([](){}{)}}[]";
            int sol = 2;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Semibalanceadas8Test : CadenasBalanceadasTest
    {
        public void Semibalanceadas8()
        {
            string s = "{[[{}{]{}]}}";
            int sol = 2;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Length16Caso1Test : CadenasBalanceadasTest
    {
        public void Length16Caso1()
        {
            string s = "][(}({){[()}}{{{";
            int sol = 6;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Length16Caso2Test : CadenasBalanceadasTest
    {
        public void Length16Caso2()
        {
            string s = "[]}()}(]}){){)])";
            int sol = 5;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Length16Caso3Test : CadenasBalanceadasTest
    {
        public void Length16Caso3()
        {
            string s = "[)}){][]])}])({[";
            int sol = 7;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Length18Caso1Test : CadenasBalanceadasTest
    {
        public void Length18Caso1()
        {
            string s = "{][[{(]){[)[(]}{)}";
            int sol = 6;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Length18Caso2Test : CadenasBalanceadasTest
    {
        public void Length18Caso2()
        {
            string s = ")}]]}{])]](}(]({()";
            int sol = 8;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Length18Caso3Test : CadenasBalanceadasTest
    {
        public void Length18Caso3()
        {
            string s = "}}){({[})[(]{({{[(";
            int sol = 9;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Length20Caso1Test : CadenasBalanceadasTest
    {
        public void Length20Caso1()
        {
            string s = "())][{])[)])[{({{}{{";
            int sol = 8;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Length20Caso2Test : CadenasBalanceadasTest
    {
        public void Length20Caso2()
        {
            string s = "]}[]]{[]({]{[]{}[]})";
            int sol = 4;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Length20Caso3Test : CadenasBalanceadasTest
    {
        public void Length20Caso3()
        {
            string s = "[}[{}[}[}])(]][][}{(";
            int sol = 6;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Length22Caso1Test : CadenasBalanceadasTest
    {
        public void Length22Caso1()
        {
            string s = "([}({){)((]{][[{)((]){";
            int sol = 9;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Length22Caso2Test : CadenasBalanceadasTest
    {
        public void Length22Caso2()
        {
            string s = "})}((([}[)]]({}{{{}]))";
            int sol = 7;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Length22Caso3Test : CadenasBalanceadasTest
    {
        public void Length22Caso3()
        {
            string s = ")]][[]}[([{(){]{})({[{";
            int sol = 7;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Length24Caso1Test : CadenasBalanceadasTest
    {
        public void Length24Caso1()
        {
            string s = "(({(}]][{)(()[{]][{})}}(";
            int sol = 7;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Length24Caso2Test : CadenasBalanceadasTest
    {
        public void Length24Caso2()
        {
            string s = "}){[[[[)((](]}))}[{])([(";
            int sol = 9;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }

    public class Length24Caso3Test : CadenasBalanceadasTest
    {
        public void Length24Caso3()
        {
            string s = "(){(])[[}{({[[{}{{)([]][";
            int sol = 8;

            Assert.That(Student(s), Is.EqualTo(sol));
        }
    }
}
