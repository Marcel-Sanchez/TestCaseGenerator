﻿using Weboo.Assess.Tester;
using Weboo.Examen.Interfaces;

namespace TiendaAmazonTester
{
    public class TiendaAmazonTester : InterfaceTester<ITienda>
    {
        protected override ITienda BuildTarget(object[] args)
        {
            int discount = (int)args[0];
            return ReflectionHelper.CreateInstance<ITienda>(discount);
        }

        protected override ITienda BuildBenchmark(object[] args)
        {
            int discount = (int) args[0];
            return new Tienda(discount);
        }


        private void CheckMoreDemand()
        {
            var orderedProducts = (Benchmark as Tienda).OrderedProducts;
            CheckOrdering(shop => shop.ProductosMasSolicitados(), (a, b) => orderedProducts[b] - orderedProducts[a]);
        }

        private void CheckProductsByPrice(int moment)
        {
            var priceProducts = (Benchmark as Tienda).PriceProducts(moment);
            //using (var stream = new StreamWriter("product prices.txt", true))
            //{
            //    stream.WriteLine();
            //    foreach (var kvp in priceProducts)
            //    {
            //        stream.WriteLine("{0}: {1}", kvp.Key, kvp.Value);
            //    }
            //}
            CheckOrdering(shop => shop.ProductosPorPrecio(moment), (a, b) => (int)(priceProducts[a] - priceProducts[b]));
        }


        #region Ejemplos del Examen

        private void SetupEjemplos1()
        {
            //Los clientes añaden productos a sus carritos
            Perform(shop => shop.PonEnCarrito(4, "TV", 200, 1, 50));
            Perform(shop => shop.PonEnCarrito(6, "Phone", 100, 2, 100));
            Perform(shop => shop.PonEnCarrito(4, "TV", 200, 2, 200));
            Perform(shop => shop.PonEnCarrito(2, "Perfume", 10, 20, 220));

            //Se aplica descuento al los TV hasta el instante 300
            Perform(shop => shop.DescuentoAProducto("TV", 300));

            Perform(shop => shop.PonEnCarrito(6, "Phone", 100, 3, 350));
            Perform(shop => shop.RetiraDeCarrito(2, "Perfume", 5));

            //Se cierran las compras para los clientes 4 y 6 con lo que llevan en el carrito
            Perform(shop => shop.CierraCompra(4)); //Paga 3*(200-20% de 200) = $480 por los TV con descuento
            Perform(shop => shop.CierraCompra(6)); //Paga 5*(100) = $500 por los teléfonos

            Perform(shop => shop.PonEnCarrito(7, "Juguete", 20, 10, 500));
            Perform(shop => shop.PonEnCarrito(4, "Phone", 100, 3, 510));

            Perform(shop => shop.CierraCompra(2)); //Paga 15*(20)= $300 por los perfumes

            //Se aplica descuento a los teléfonos reservados antes del instante 550. El cliente 6 no se //benefició pues ya cerró su compra.
            Perform(shop => shop.DescuentoAProducto("Phone", 550));
        }

        private void SetupEjemplos2()
        {
            Perform(shop => shop.PonEnCarrito(6, "Juguete", 20, 4, 600));
            Perform(shop => shop.RetiraDeCarrito(7, "Juguete", 2));
            Perform(shop => shop.PonEnCarrito(7, "TV", 200, 1, 650));
            Perform(shop => shop.PonEnCarrito(7, "Anillo", 85, 1, 700));
            Perform(shop => shop.RetiraDeCarrito(4, "Phone", 100));
        }

        public void Ejemplo1()
        {
            Initialize(20);

            SetupEjemplos1();
            CheckMultiSet<int>(shop => shop.MejoresClientes(500));
        }

        public void Ejemplo2()
        {
            Initialize(20);

            SetupEjemplos1();
            CheckMultiSet<int>(shop => shop.MejoresClientes(400));
        }

        public void Ejemplo3()
        {
            Initialize(20);

            SetupEjemplos1();
            SetupEjemplos2();

            CheckMoreDemand();
        }

        public void Ejemplo4()
        {
            Initialize(20);

            SetupEjemplos1();
            SetupEjemplos2();

            CheckMultiSet(shop => shop.ContenidoDelCarrito(7));
        }

        public void Ejemplo5()
        {
            Initialize(20);

            SetupEjemplos1();
            SetupEjemplos2();

            CheckMultiSet(shop => shop.ContenidoDelCarrito(6));
        }

        public void Ejemplo6()
        {
            Initialize(20);

            SetupEjemplos1();
            SetupEjemplos2();

            CheckMultiSet(shop => shop.ContenidoDelCarrito(4));
        }

        public void Ejemplo7()
        {
            Initialize(20);

            SetupEjemplos1();
            SetupEjemplos2();

            CheckProductsByPrice(301);
        }

        public void Ejemplo8()
        {
            Initialize(20);

            SetupEjemplos1();
            SetupEjemplos2();

            CheckProductsByPrice(500);
        }

        public void Ejemplo9()
        {
            Initialize(20);

            SetupEjemplos1();
            SetupEjemplos2();

            CheckProductsByPrice(600);
        }

        #endregion

        public void MejoresClientes1()
        {
            Initialize(10);
            Perform(shop => shop.PonEnCarrito(1, "a", 10, 5, 10));
            Perform(shop => shop.PonEnCarrito(2, "a", 10, 20, 80));
            Perform(shop => shop.CierraCompra(1));
            Perform(shop => shop.CierraCompra(2));

            CheckMultiSet(shop => shop.MejoresClientes(50));
        }

        public void MejoresClientes2()
        {
            Initialize(10);
            Perform(shop => shop.PonEnCarrito(1, "a", 10, 5, 10));
            Perform(shop => shop.PonEnCarrito(2, "a", 10, 20, 80));
            Perform(shop => shop.CierraCompra(1));

            CheckMultiSet(shop => shop.MejoresClientes(50));
        }

        public void MejoresClientes3()
        {
            Initialize(10);
            Perform(shop => shop.PonEnCarrito(1, "a", 10, 5, 1));
            Perform(shop => shop.CierraCompra(1));
            Perform(shop => shop.PonEnCarrito(1, "b", 20, 2, 2));
            Perform(shop => shop.CierraCompra(1));
            Perform(shop => shop.PonEnCarrito(2, "a", 10, 20, 80));
            Perform(shop => shop.CierraCompra(2));

            CheckMultiSet(shop => shop.MejoresClientes(60));
        }

        public void MejoresClientes4()
        {
            Initialize(10);
            Perform(shop => shop.PonEnCarrito(1, "a", 10, 5, 3));
            Perform(shop => shop.CierraCompra(1));
            Perform(shop => shop.PonEnCarrito(1, "b", 40, 2, 5));
            Perform(shop => shop.CierraCompra(1));
            Perform(shop => shop.PonEnCarrito(1, "c", 25, 2, 7));
            Perform(shop => shop.CierraCompra(1));
            Perform(shop => shop.PonEnCarrito(2, "a", 10, 20, 80));
            Perform(shop => shop.CierraCompra(2));

            CheckMultiSet(shop => shop.MejoresClientes(60));
        }

        public void MejoresClientes5()
        {
            Initialize(50);
            Perform(shop => shop.PonEnCarrito(1, "a", 300, 7, 10));
            Perform(shop => shop.DescuentoAProducto("a", 10));
            Perform(shop => shop.RetiraDeCarrito(1, "a", 2));
            Perform(shop => shop.PonEnCarrito(2, "a", 300, 6, 10));
            Perform(shop => shop.CierraCompra(1));
            Perform(shop => shop.CierraCompra(2));

            CheckMultiSet(shop => shop.MejoresClientes(751));
        }

        public void MejoresClientes6()
        {
            Initialize(50);
            Perform(shop => shop.PonEnCarrito(1, "a", 300, 9, 10));
            Perform(shop => shop.DescuentoAProducto("a", 10));
            Perform(shop => shop.RetiraDeCarrito(1, "a", 2));
            Perform(shop => shop.PonEnCarrito(2, "a", 300, 6, 10));
            Perform(shop => shop.CierraCompra(1));
            Perform(shop => shop.CierraCompra(2));

            CheckMultiSet(shop => shop.MejoresClientes(751));
        }

        public void MejoresClientes7()
        {
            Initialize(50);
            Perform(shop => shop.PonEnCarrito(1, "a", 300, 5, 6));
            Perform(shop => shop.PonEnCarrito(2, "a", 300, 8, 10));
            Perform(shop => shop.CierraCompra(1));
            Perform(shop => shop.DescuentoAProducto("a", 10));
            Perform(shop => shop.CierraCompra(2));

            CheckMultiSet(shop => shop.MejoresClientes(751));
        }

        public void MejoresClientes8()
        {
            Initialize(50);
            Perform(shop => shop.PonEnCarrito(1, "a", 300, 5, 12));
            Perform(shop => shop.DescuentoAProducto("a", 10));
            Perform(shop => shop.PonEnCarrito(2, "b", 400, 5, 15));
            Perform(shop => shop.CierraCompra(1));
            Perform(shop => shop.CierraCompra(2));

            CheckMultiSet(shop => shop.MejoresClientes(751));
        }

        public void MejoresClientes9()
        {
            Initialize(50);

            Perform(shop => shop.PonEnCarrito(1, "a", 300, 2, 5));
            Perform(shop => shop.DescuentoAProducto("a", 10));
            Perform(shop => shop.PonEnCarrito(1, "a", 300, 2, 50));
            Perform(shop => shop.CierraCompra(1));
            Perform(shop => shop.PonEnCarrito(2, "b", 400, 5, 52));
            Perform(shop => shop.CierraCompra(2));

            CheckMultiSet(shop => shop.MejoresClientes(751));
        }

        public void MejoresClientes10()
        {
            Initialize(13);

            Perform(shop => shop.PonEnCarrito(1, "a", 140, 2, 5));
            Perform(shop => shop.PonEnCarrito(2, "b", 100, 1, 20));
            Perform(shop => shop.PonEnCarrito(3, "c", 500, 2, 20));
            Perform(shop => shop.DescuentoAProducto("a", 10));
            Perform(shop => shop.DescuentoAProducto("b", 200));

            Perform(shop => shop.PonEnCarrito(1, "b", 100, 2, 80));
            Perform(shop => shop.CierraCompra(3));
            Perform(shop => shop.CierraCompra(1));
            Perform(shop => shop.CierraCompra(2));

            CheckMultiSet(shop => shop.MejoresClientes(418));
        }

        public void MejoresClientes11()
        {
            Initialize(0);
            Perform(shop => shop.PonEnCarrito(1, "a", 1, 200, 5));
            Perform(shop => shop.DescuentoAProducto("a", 10));
            Perform(shop => shop.PonEnCarrito(2, "b", 100, 2, 80));
            Perform(shop => shop.CierraCompra(2));
            Perform(shop => shop.CierraCompra(1));

            CheckMultiSet(shop => shop.MejoresClientes(200));
        }

        public void MejoresClientes12()
        {
            Initialize(10);
            Perform(shop => shop.PonEnCarrito(1, "a", 200, 2, 5));
            Perform(shop => shop.RetiraDeCarrito(1, "a", 4));
            Perform(shop => shop.PonEnCarrito(1, "a", 200, 2, 6));
            Perform(shop => shop.PonEnCarrito(7, "b", 100, 10, 80));
            Perform(shop => shop.CierraCompra(7));
            Perform(shop => shop.CierraCompra(1));

            CheckMultiSet(shop => shop.MejoresClientes(200));
        }

        public void ContenidoDelCarrito1()
        {
            Initialize(10);
            Perform(shop => shop.PonEnCarrito(1, "a", 10, 1, 10));
            Perform(shop => shop.PonEnCarrito(2, "c", 25, 1, 10));
            Perform(shop => shop.PonEnCarrito(1, "b", 20, 5, 12));

            CheckMultiSet(shop => shop.ContenidoDelCarrito(1));
        }

        public void ContenidoDelCarrito2()
        {
            Initialize(10);
            Perform(shop => shop.PonEnCarrito(1, "a", 10, 15, 10));
            Perform(shop => shop.PonEnCarrito(2, "b", 25, 8, 10));
            Perform(shop => shop.PonEnCarrito(1, "a", 10, 2, 11));
            Perform(shop => shop.CierraCompra(1));

            CheckMultiSet(shop => shop.ContenidoDelCarrito(1));
        }

        public void ContenidoDelCarrito3()
        {
            Initialize(10);
            Perform(shop => shop.PonEnCarrito(1, "a", 10, 15, 10));
            Perform(shop => shop.PonEnCarrito(2, "b", 25, 8, 10));
            Perform(shop => shop.RetiraDeCarrito(1, "a", 20));
            Perform(shop => shop.PonEnCarrito(1, "a", 10, 2, 21));

            CheckMultiSet(shop => shop.ContenidoDelCarrito(1));
        }

        public void ContenidoDelCarrito4()
        {
            Initialize(10);
            Perform(shop => shop.PonEnCarrito(1, "a", 10, 15, 10));
            Perform(shop => shop.PonEnCarrito(2, "b", 25, 8, 10));
            Perform(shop => shop.RetiraDeCarrito(1, "a", 20));
            Perform(shop => shop.PonEnCarrito(1, "a", 10, 2, 21));

            CheckMultiSet(shop => shop.ContenidoDelCarrito(1));
        }

        public void ContenidoDelCarrito5()
        {
            Initialize(10);
            Perform(shop => shop.PonEnCarrito(1, "a", 10, 15, 10));
            Perform(shop => shop.PonEnCarrito(2, "c", 5, 8, 10));
            Perform(shop => shop.PonEnCarrito(1, "b", 25, 1, 11));
            Perform(shop => shop.RetiraDeCarrito(1, "a", 20));
            Perform(shop => shop.RetiraDeCarrito(1, "b", 20));
            Perform(shop => shop.RetiraDeCarrito(1, "c", 20));

            CheckMultiSet(shop => shop.ContenidoDelCarrito(1));
        }

        public void ProductosMasSolicitados1()
        {
            Initialize(10);
            Perform(shop => shop.PonEnCarrito(1, "a", 10, 20, 20));
            Perform(shop => shop.PonEnCarrito(1, "b", 33, 80, 21));
            Perform(shop => shop.PonEnCarrito(1, "c", 22, 7, 22));
            Perform(shop => shop.CierraCompra(1));
            Perform(shop => shop.PonEnCarrito(1, "a", 10, 61, 23));
            CheckMoreDemand();
        }

        public void ProductosMasSolicitados2()
        {
            Initialize(10);
            Perform(shop => shop.PonEnCarrito(1, "a", 10, 20, 20));
            Perform(shop => shop.PonEnCarrito(1, "b", 33, 80, 21));
            Perform(shop => shop.PonEnCarrito(1, "c", 22, 7, 22));
            Perform(shop => shop.CierraCompra(1));
            Perform(shop => shop.PonEnCarrito(1, "a", 10, 61, 23));
            CheckMoreDemand();
        }

        public void ProductosMasSolicitados3()
        {
            Initialize(10);
            Perform(shop => shop.PonEnCarrito(1, "a", 10, 20, 20));
            Perform(shop => shop.PonEnCarrito(1, "b", 33, 80, 21));
            Perform(shop => shop.PonEnCarrito(1, "c", 22, 7, 22));
            Perform(shop => shop.CierraCompra(1));
            Perform(shop => shop.PonEnCarrito(1, "a", 10, 61, 23));
            Perform(shop => shop.RetiraDeCarrito(1, "a", 2));
            CheckMoreDemand();
        }

        public void ProductosMasSolicitados4()
        {
            Initialize(10);

            Perform(shop => shop.PonEnCarrito(1, "a", 10, 20, 20));
            Perform(shop => shop.PonEnCarrito(1, "b", 33, 80, 21));
            Perform(shop => shop.PonEnCarrito(1, "c", 22, 7, 22));
            Perform(shop => shop.CierraCompra(1));
            Perform(shop => shop.PonEnCarrito(1, "d", 55, 81, 23));

            CheckMoreDemand();
        }

        public void ProductosMasSolicitados5()
        {
            Initialize(10);

            Perform(shop => shop.PonEnCarrito(1, "a", 10, 60, 20));
            Perform(shop => shop.PonEnCarrito(1, "b", 33, 40, 21));
            Perform(shop => shop.PonEnCarrito(1, "c", 22, 7, 22));
            Perform(shop => shop.PonEnCarrito(2, "b", 33, 40, 23));
            Perform(shop => shop.CierraCompra(1));

            CheckMoreDemand();
        }

        public void ProductosPorPrecio1()
        {
            Initialize(30);

            Perform(shop => shop.PonEnCarrito(1, "a", 100, 60, 10));
            Perform(shop => shop.PonEnCarrito(2, "b", 500, 60, 10));
            Perform(shop => shop.PonEnCarrito(8, "d", 250, 1, 20));
            Perform(shop => shop.PonEnCarrito(5, "c", 300, 1, 20));

            CheckProductsByPrice(40);
        }

        public void ProductosPorPrecio2()
        {
            Initialize(30);
            Perform(shop => shop.PonEnCarrito(1, "a", 100, 60, 10));
            Perform(shop => shop.PonEnCarrito(2, "b", 500, 60, 10));
            Perform(shop => shop.PonEnCarrito(8, "d", 250, 1, 20));
            Perform(shop => shop.PonEnCarrito(5, "c", 300, 1, 20));
            Perform(shop => shop.DescuentoAProducto("b", 20));

            CheckProductsByPrice(20);
        }

        public void ProductosPorPrecio3()
        {
            Initialize(30);

            Perform(shop => shop.PonEnCarrito(1, "a", 100, 60, 10));
            Perform(shop => shop.PonEnCarrito(2, "b", 500, 60, 10));
            Perform(shop => shop.PonEnCarrito(8, "d", 250, 1, 20));
            Perform(shop => shop.PonEnCarrito(5, "c", 300, 1, 20));
            Perform(shop => shop.DescuentoAProducto("a", 20));
            Perform(shop => shop.DescuentoAProducto("a", 50));

            CheckProductsByPrice(25);
        }

        public void ProductosPorPrecio4()
        {
            Initialize(30);

            Perform(shop => shop.PonEnCarrito(1, "a", 100, 60, 10));
            Perform(shop => shop.PonEnCarrito(2, "b", 500, 60, 10));
            Perform(shop => shop.PonEnCarrito(8, "d", 250, 1, 20));
            Perform(shop => shop.PonEnCarrito(5, "c", 300, 1, 20));
            Perform(shop => shop.DescuentoAProducto("b", 60));
            Perform(shop => shop.DescuentoAProducto("c", 150));

            CheckProductsByPrice(50);
        }

        public void ProductosPorPrecio5()
        {
            Initialize(30);

            Perform(shop => shop.PonEnCarrito(1, "a", 100, 60, 10));
            Perform(shop => shop.PonEnCarrito(2, "b", 500, 60, 10));
            Perform(shop => shop.PonEnCarrito(8, "d", 250, 1, 20));
            Perform(shop => shop.PonEnCarrito(5, "c", 300, 1, 20));
            Perform(shop => shop.DescuentoAProducto("b", 20));
            Perform(shop => shop.DescuentoAProducto("b", 50));

            CheckProductsByPrice(50);
        }

        public void ProductosPorPrecio6()
        {
            Initialize(30);

            Perform(shop => shop.PonEnCarrito(1, "a", 100, 60, 10));
            Perform(shop => shop.PonEnCarrito(2, "b", 500, 60, 10));
            Perform(shop => shop.PonEnCarrito(8, "d", 250, 1, 20));
            Perform(shop => shop.PonEnCarrito(5, "c", 300, 1, 20));
            Perform(shop => shop.DescuentoAProducto("b", 50));
            Perform(shop => shop.DescuentoAProducto("c", 50));
            Perform(shop => shop.DescuentoAProducto("a", 25));
            Perform(shop => shop.DescuentoAProducto("d", 80));

            CheckProductsByPrice(100);
        }

        public void ProductosPorPrecio7()
        {
            Initialize(30);

            Perform(shop => shop.PonEnCarrito(1, "a", 100, 60, 10));
            Perform(shop => shop.PonEnCarrito(2, "b", 500, 60, 10));
            Perform(shop => shop.PonEnCarrito(8, "d", 250, 1, 20));
            Perform(shop => shop.PonEnCarrito(5, "c", 300, 1, 20));
            Perform(shop => shop.DescuentoAProducto("b", 50));
            Perform(shop => shop.DescuentoAProducto("c", 40));
            Perform(shop => shop.DescuentoAProducto("a", 25));
            Perform(shop => shop.DescuentoAProducto("d", 80));

            CheckProductsByPrice(20);
        }

        public void ProductosPorPrecio8()
        {
            Initialize(30);

            Perform(shop => shop.PonEnCarrito(1, "a", 100, 60, 10));
            Perform(shop => shop.PonEnCarrito(2, "b", 500, 60, 10));
            Perform(shop => shop.PonEnCarrito(8, "d", 250, 1, 20));
            Perform(shop => shop.PonEnCarrito(5, "c", 300, 1, 20));
            Perform(shop => shop.DescuentoAProducto("a", 1));
            Perform(shop => shop.DescuentoAProducto("a", 100));
            Perform(shop => shop.DescuentoAProducto("a", 120));
            Perform(shop => shop.DescuentoAProducto("a", 200));

            CheckProductsByPrice(2);
        }
    }
}
