﻿using System;
using System.Collections.Generic;
using System.Linq;
using Weboo.Examen.Interfaces;

namespace TiendaAmazonTester
{
    public class CartItem
    {
        public CartItem(string product, int amount, int time, double price)
        {
            Product = product;
            Amount = amount;
            Time = time;
            Price = price;
        }

        public string Product { get; set; }
        public double Price { get; set; }
        public int Amount { get; set; }
        public int Time { get; set; }
    }

    public class Tienda : ITienda
    {
        private readonly Dictionary<int, Dictionary<string, CartItem>> carts =
            new Dictionary<int, Dictionary<string, CartItem>>();

        private readonly Dictionary<string, int> discounts = new Dictionary<string, int>();
        private readonly Dictionary<string, int> productOrders = new Dictionary<string, int>();
        private readonly Dictionary<string, double> productPrices = new Dictionary<string, double>();
        private readonly Dictionary<int, List<double>> purchases = new Dictionary<int, List<double>>();

        public Tienda(int descuento)
        {
            Descuento = descuento;
        }

        public int Descuento { get; }

        public void PonEnCarrito(int cliente, string producto, double precio, int unidades, int instantePuestaEnCarrito)
        {
            if (!carts.ContainsKey(cliente))
            {
                carts.Add(cliente, new Dictionary<string, CartItem>());
                purchases.Add(cliente, new List<double>());
            }

            if (!productOrders.ContainsKey(producto))
            {
                productOrders.Add(producto, 0);
                discounts.Add(producto, 0);
                productPrices.Add(producto, precio);
            }

            productOrders[producto] += unidades;

            var cart = carts[cliente];

            if (!cart.ContainsKey(producto))
            {
                cart.Add(producto, new CartItem(producto, unidades, instantePuestaEnCarrito, precio));
            }
            else
            {
                var item = cart[producto];
                item.Amount += unidades;
                item.Time = instantePuestaEnCarrito;
            }
        }

        public void RetiraDeCarrito(int cliente, string producto, int unidades)
        {
            var cart = carts[cliente];

            if (cart.ContainsKey(producto))
            {
                var item = cart[producto];

                if (unidades >= item.Amount)
                {
                    productOrders[producto] -= item.Amount;
                    cart.Remove(producto);
                }
                else
                {
                    item.Amount -= unidades;
                    productOrders[producto] -= unidades;
                }
            }
        }

        public void CierraCompra(int cliente)
        {
            var cart = carts[cliente];
            double amount = 0;

            foreach (var kvp in cart)
            {
                double value = kvp.Value.Price;

                if (kvp.Value.Time <= discounts[kvp.Value.Product])
                    value -= value * (Descuento / 100d);

                amount += value * kvp.Value.Amount;
            }

            purchases[cliente].Add(amount);
            carts[cliente] = new Dictionary<string, CartItem>();
        }

        public void DescuentoAProducto(string producto, int vencimientoDelDescuento)
        {
            discounts[producto] = vencimientoDelDescuento;
        }

        public IEnumerable<int> MejoresClientes(double monto)
        {
            foreach (var kvp in purchases)
            {
                double amount = kvp.Value.Sum();

                if (amount >= monto)
                    yield return kvp.Key;
            }
        }

        public IEnumerable<string> ProductosMasSolicitados()
        {
            var items = productOrders.Keys.ToArray();
            var keys = productOrders.Values.ToArray();
            Array.Sort(keys, items);

            return items.Reverse();
        }

        public IEnumerable<string> ContenidoDelCarrito(int cliente)
        {
            return carts[cliente].Keys;
        }

        public IEnumerable<string> ProductosPorPrecio(int instante)
        {
            var items = productPrices.Keys.ToArray();
            var keys = productPrices.Values.ToArray();

            for (int i = 0; i < items.Length; i++)
                if (instante <= discounts[items[i]])
                    keys[i] -= keys[i] * (Descuento / 100d);

            Array.Sort(keys, items);

            return items;
        }

        public Dictionary<string, int> OrderedProducts => productOrders;

        public Dictionary<string, double> PriceProducts(int moment)
        {
            return productPrices
                .ToDictionary(
                    m => m.Key,
                    m => moment <= discounts[m.Key] ? m.Value - m.Value * (Descuento / 100d) : m.Value);
        }
    }
}