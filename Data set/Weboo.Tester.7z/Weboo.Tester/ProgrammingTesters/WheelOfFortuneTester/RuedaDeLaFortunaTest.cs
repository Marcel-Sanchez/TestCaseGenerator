﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Assess.Tester;

namespace WheelOfFortuneTester
{
    public class RuedaDeLaFortunaTest : TestCase
    {
        private static int EncontrarGanador(int[] rueda, int jugadores, int[] pasos)
        {
            int p = 0;
            int[] score = new int[jugadores];
            for (int i = 0; i < pasos.Length; i++)
            {
                p = (p + pasos[i]) % rueda.Length;
                score[i % jugadores] += rueda[p];
            }

            int maxIndex = 0;
            for (int i = 1; i < score.Length; i++)
            {
                if (score[maxIndex] < score[i])
                {
                    maxIndex = i;
                }
            }

            int[] rotation = new int[rueda.Length];
            for (int i = 0; i < rueda.Length; i++)
            {
                rotation[(i - p + rotation.Length) % rotation.Length] = rueda[i];
            }

            for (int i = 0; i < rotation.Length; i++)
            {
                rueda[i] = rotation[i];
            }

            return maxIndex;
        }

        private int Student(int[] rueda, int jugadores, int[] pasos)
        {
            return ReflectionHelper.InvokeStatic<int>("Weboo.Examen.RuedaDeLaFortuna", "EncontrarGanador", rueda,
                jugadores, pasos);
        }

        public void Case1()
        {
            int jugadores = 2;
            int[] ruedaStudent = { 5, 10, 15, 20, 30 };
            int[] pasosStudent = { 1, 3, 4, 3 };

            int[] ruedaSolution = { 5, 10, 15, 20, 30 };
            int[] pasosSolution = { 1, 3, 4, 3 };

            Assert.That(Student(ruedaStudent, jugadores, pasosStudent),
                Is.EqualTo(EncontrarGanador(ruedaSolution, jugadores, pasosSolution)));
            Assert.That(ruedaStudent, Is.SequenceEqualTo(ruedaSolution));
        }

        public void Case2()
        {
            int jugadores = 2;
            int[] ruedaStudent = { 5, 10, 15, 20, 0 };
            int[] pasosStudent = { 1, 3, 4, 3 };

            int[] ruedaSolution = { 5, 10, 15, 20, 0 };
            int[] pasosSolution = { 1, 3, 4, 3 };

            Assert.That(Student(ruedaStudent, jugadores, pasosStudent),
                Is.EqualTo(EncontrarGanador(ruedaSolution, jugadores, pasosSolution)));
            Assert.That(ruedaStudent, Is.SequenceEqualTo(ruedaSolution));
        }

        public void Case3()
        {
            int jugadores = 8;
            int[] ruedaStudent = { 5, 10, 15, 20, 30 };
            int[] pasosStudent = { 1, 3, 4, 3, 1, 4, 2, 20 };

            int[] ruedaSolution = { 5, 10, 15, 20, 30 };
            int[] pasosSolution = { 1, 3, 4, 3, 1, 4, 2, 20 };

            Assert.That(Student(ruedaStudent, jugadores, pasosStudent),
                Is.EqualTo(EncontrarGanador(ruedaSolution, jugadores, pasosSolution)));
            Assert.That(ruedaStudent, Is.SequenceEqualTo(ruedaSolution));
        }

        public void Case4()
        {
            int jugadores = 8;
            int[] ruedaStudent = { 5, 10, 20, 30 };
            int[] pasosStudent =
            {
                1, 3, 4, 3, 1, 4, 2, 20,
                3, 4, 10, 6, 9, 3, 2, 3,
                2, 3, 1, 336, 3, 1, 8, 5
            };

            int[] ruedaSolution = { 5, 10, 20, 30 };
            int[] pasosSolution =
            {
                1, 3, 4, 3, 1, 4, 2, 20,
                3, 4, 10, 6, 9, 3, 2, 3,
                2, 3, 1, 336, 3, 1, 8, 5
            };

            Assert.That(Student(ruedaStudent, jugadores, pasosStudent),
                Is.EqualTo(EncontrarGanador(ruedaSolution, jugadores, pasosSolution)));
            Assert.That(ruedaStudent, Is.SequenceEqualTo(ruedaSolution));
        }

        public void Case5()
        {
            int jugadores = 3;
            int[] ruedaStudent = { 5, 10, 0, -20, 30 };
            int[] pasosStudent =
            {
                5, 3, 2,
                3, 4, 10,
                2, 3, 1
            };

            int[] ruedaSolution = { 5, 10, 0, -20, 30 };
            int[] pasosSolution =
            {
                5, 3, 2,
                3, 4, 10,
                2, 3, 1
            };

            Assert.That(Student(ruedaStudent, jugadores, pasosStudent),
                Is.EqualTo(EncontrarGanador(ruedaSolution, jugadores, pasosSolution)));
            Assert.That(ruedaStudent, Is.SequenceEqualTo(ruedaSolution));
        }

        public void Case6()
        {
            int jugadores = 3;
            int[] ruedaStudent = { 5, 10, 0, -20, 30 };
            int[] pasosStudent =
            {
                5, 5, 5,
                5, 3, 2,
                5, 5, 5,
                3, 4, 10,
                5, 5, 5,
                2, 3, 1,
                5, 5, 5
            };

            int[] ruedaSolution = { 5, 10, 0, -20, 30 };
            int[] pasosSolution =
            {
                5, 5, 5,
                5, 3, 2,
                5, 5, 5,
                3, 4, 10,
                5, 5, 5,
                2, 3, 1,
                5, 5, 5
            };

            Assert.That(Student(ruedaStudent, jugadores, pasosStudent),
                Is.EqualTo(EncontrarGanador(ruedaSolution, jugadores, pasosSolution)));
            Assert.That(ruedaStudent, Is.SequenceEqualTo(ruedaSolution));
        }

        public void Case7()
        {
            int jugadores = 4;
            int[] ruedaStudent = { -3, -29, -17 };
            int[] pasosStudent = { 2, 3, 4, 1 };

            int[] ruedaSolution = { -3, -29, -17 };
            int[] pasosSolution = { 2, 3, 4, 1 };

            Assert.That(Student(ruedaStudent, jugadores, pasosStudent),
                Is.EqualTo(EncontrarGanador(ruedaSolution, jugadores, pasosSolution)));
            Assert.That(ruedaStudent, Is.SequenceEqualTo(ruedaSolution));
        }

        public void Case8()
        {
            int jugadores = 3;
            int[] ruedaStudent = { 1, -29, 29, -17, 0 };
            int[] pasosStudent =
            {
                1, 2, 4,
                5, 3, 4,
                3, 3, 4
            };

            int[] ruedaSolution = { 1, -29, 29, -17, 0 };
            int[] pasosSolution =
            {
                1, 2, 4,
                5, 3, 4,
                3, 3, 4
            };

            Assert.That(Student(ruedaStudent, jugadores, pasosStudent),
                Is.EqualTo(EncontrarGanador(ruedaSolution, jugadores, pasosSolution)));
            Assert.That(ruedaStudent, Is.SequenceEqualTo(ruedaSolution));
        }

        public void Case9()
        {
            int jugadores = 3;
            int[] ruedaStudent = { 0, 2, 0 };
            int[] pasosStudent =
            {
                1, 1, 1
            };

            int[] ruedaSolution = { 0, 2, 0 };
            int[] pasosSolution =
            {
                1, 1, 1
            };

            Assert.That(Student(ruedaStudent, jugadores, pasosStudent),
                Is.EqualTo(EncontrarGanador(ruedaSolution, jugadores, pasosSolution)));
            Assert.That(ruedaStudent, Is.SequenceEqualTo(ruedaSolution));
        }

        public void Case10()
        {
            int jugadores = 3;
            int[] ruedaStudent = { -1, -10, -5 };
            int[] pasosStudent =
            {
                20, 30, 11,
                13, 23, 19,
                1, 1, 1
            };

            int[] ruedaSolution = { -1, -10, -5 };
            int[] pasosSolution =
            {
                20, 30, 11,
                13, 23, 19,
                1, 1, 1
            };

            Assert.That(Student(ruedaStudent, jugadores, pasosStudent),
                Is.EqualTo(EncontrarGanador(ruedaSolution, jugadores, pasosSolution)));
            Assert.That(ruedaStudent, Is.SequenceEqualTo(ruedaSolution));
        }
    }
}
