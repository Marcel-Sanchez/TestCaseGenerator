﻿using Weboo.Assess.Tester;
using Weboo.Domino;

namespace DominoTester
{
    public abstract class DominoTester : InterfaceTester<IJuegoDeDomino>
    {
        protected override IJuegoDeDomino BuildTarget(object[] args)
        {
            return ReflectionHelper.CreateInstance<IJuegoDeDomino>();
        }

        protected override IJuegoDeDomino BuildBenchmark(object[] args)
        {
            return new JuegoDeDomino();
        }
    }

    public class Test1 : DominoTester
    {
        public void CantidadDeJugadores1()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 4), new Ficha(1, 2), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 3), new Ficha(2, 2), new Ficha(0, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 3), new Ficha(1, 1), new Ficha(0, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(0, 2), new Ficha(4, 4), new Ficha(3, 3) }));

            Check(d => d.CantidadDeJugadores);
        }
    }

    public class Test2 : DominoTester
    {
        public void CantidadDeJugadores2()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 4), new Ficha(1, 2), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 3), new Ficha(2, 2), new Ficha(0, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 3), new Ficha(1, 1), new Ficha(0, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(0, 2), new Ficha(4, 4), new Ficha(3, 3) }));
            Perform(d => d.Juega());

            Check(d => d.CantidadDeJugadores);
        }
    }

    public class Test3 : DominoTester
    {
        public void CantidadDeJugadores3()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(5, 5), new Ficha(1, 2), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(0, 3) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(0, 2), new Ficha(1, 0) }));
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());

            Check(d => d.CantidadDeJugadores);
        }
    }

    public class Test4 : DominoTester
    {
        public void JuegoTerminado1()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 4), new Ficha(1, 2), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 3), new Ficha(2, 2), new Ficha(0, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 3), new Ficha(1, 1), new Ficha(0, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(0, 2), new Ficha(4, 4), new Ficha(3, 3) }));

            Check(d => d.JuegoTerminado);
        }
    }

    public class Test5 : DominoTester
    {
        public void JuegoTerminado2()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 4), new Ficha(1, 2), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 3), new Ficha(2, 2), new Ficha(0, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 3), new Ficha(1, 1), new Ficha(0, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(0, 2), new Ficha(4, 4), new Ficha(3, 3) }));
            Perform(d => d.Juega());

            Check(d => d.JuegoTerminado);
        }
    }

    public class Test6 : DominoTester
    {
        public void JuegoTerminado3()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(5, 5), new Ficha(1, 2), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(0, 3) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(0, 2), new Ficha(1, 0) }));
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());

            Check(d => d.JuegoTerminado);
        }
    }

    public class Test7 : DominoTester
    {
        public void JuegoTerminado4()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(0, 0) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(0, 3) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(0, 2), new Ficha(1, 0) }));

            Check(d => d.JuegoTerminado);
        }
    }

    public class Test8 : DominoTester
    {
        public void JuegoTerminado5()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(0, 0) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(0, 3) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(0, 2), new Ficha(1, 0) }));
            Perform(d => d.Juega());

            Check(d => d.JuegoTerminado);
        }
    }

    public class Test9 : DominoTester
    {
        public void JugadorActual1()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(9, 1), new Ficha(8, 2), new Ficha(7, 3) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 2), new Ficha(3, 3), new Ficha(5, 5), new Ficha(7, 7) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 1), new Ficha(3, 5), new Ficha(8, 11) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 2), new Ficha(2, 3), new Ficha(3, 4), new Ficha(4, 5), new Ficha(5, 6), new Ficha(6, 7), new Ficha(7, 8) }));

            Check(d => d.JugadorActual);
        }
    }

    public class Test10 : DominoTester
    {
        public void JugadorActual2()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(9, 1), new Ficha(8, 2), new Ficha(7, 3) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 2), new Ficha(3, 3), new Ficha(5, 5), new Ficha(7, 7) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 1), new Ficha(3, 5), new Ficha(8, 11) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 2), new Ficha(2, 3), new Ficha(3, 4), new Ficha(4, 5), new Ficha(5, 6), new Ficha(6, 7), new Ficha(7, 8) }));
            Perform(d => d.Juega());

            Check(d => d.JugadorActual);
        }
    }

    public class Test11 : DominoTester
    {
        public void JugadorActual3()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(9, 1), new Ficha(8, 2), new Ficha(7, 3) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 2), new Ficha(3, 3), new Ficha(5, 5), new Ficha(7, 7) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 1), new Ficha(3, 5), new Ficha(8, 11) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 2), new Ficha(2, 3), new Ficha(3, 4), new Ficha(4, 5), new Ficha(5, 6), new Ficha(6, 7), new Ficha(7, 8) }));
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());

            Check(d => d.JugadorActual);
        }
    }

    public class Test12 : DominoTester
    {
        public void FichasDe1()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(9, 1), new Ficha(8, 2), new Ficha(7, 3) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 2), new Ficha(3, 3), new Ficha(5, 5), new Ficha(7, 7) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 1), new Ficha(3, 5), new Ficha(8, 11) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 2), new Ficha(2, 3), new Ficha(3, 4), new Ficha(4, 5), new Ficha(5, 6), new Ficha(6, 7), new Ficha(7, 8) }));

            CheckMultiSet(d => d.FichasDe(0));
        }
    }

    public class Test13 : DominoTester
    {
        public void FichasDe2()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(9, 1), new Ficha(8, 2), new Ficha(7, 3) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 2), new Ficha(3, 3), new Ficha(5, 5), new Ficha(7, 7) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 1), new Ficha(3, 5), new Ficha(8, 11) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 2), new Ficha(2, 3), new Ficha(3, 4), new Ficha(4, 5), new Ficha(5, 6), new Ficha(6, 7), new Ficha(7, 8) }));

            CheckMultiSet(d => d.FichasDe(3));
        }
    }

    public class Test14 : DominoTester
    {
        public void FichasDe3()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(9, 1), new Ficha(8, 2), new Ficha(7, 3) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 2), new Ficha(3, 3), new Ficha(5, 5), new Ficha(7, 7) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 1), new Ficha(3, 5), new Ficha(8, 11) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 2), new Ficha(2, 3), new Ficha(3, 4), new Ficha(4, 5), new Ficha(5, 6), new Ficha(6, 7), new Ficha(7, 8) }));
            Perform(d => d.Juega());

            CheckMultiSet(d => d.FichasDe(0));
        }
    }

    public class Test15 : DominoTester
    {
        public void FichasDe4()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(9, 1), new Ficha(8, 2), new Ficha(7, 3) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 2), new Ficha(3, 3), new Ficha(5, 5), new Ficha(7, 7) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 1), new Ficha(3, 5), new Ficha(8, 11) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 2), new Ficha(2, 3), new Ficha(3, 4), new Ficha(4, 5), new Ficha(5, 6), new Ficha(6, 7), new Ficha(7, 8) }));
            Perform(d => d.Juega());
            Perform(d => d.Juega());

            CheckMultiSet(d => d.FichasDe(1));
        }
    }

    public class Test16 : DominoTester
    {
        public void FichasDe5()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(9, 1), new Ficha(8, 2), new Ficha(7, 3) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 2), new Ficha(3, 3), new Ficha(5, 5), new Ficha(7, 7) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 1), new Ficha(3, 5), new Ficha(8, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 2), new Ficha(2, 3), new Ficha(3, 4), new Ficha(4, 5), new Ficha(5, 6), new Ficha(6, 7), new Ficha(7, 8) }));
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());

            CheckMultiSet(d => d.FichasDe(3));
        }
    }

    public class Test17 : DominoTester
    {
        public void FichasDe6()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(9, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 2), new Ficha(3, 3), new Ficha(5, 5), new Ficha(7, 7) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 1), new Ficha(3, 5), new Ficha(8, 11) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 2), new Ficha(2, 3), new Ficha(3, 4), new Ficha(4, 5), new Ficha(5, 6), new Ficha(6, 7), new Ficha(7, 8) }));
            Perform(d => d.Juega());

            CheckMultiSet(d => d.FichasDe(0));
        }
    }

    public class Test18 : DominoTester
    {
        public void FichasDe6()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(9, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 2), new Ficha(3, 3), new Ficha(5, 5), new Ficha(7, 7) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 1), new Ficha(3, 5), new Ficha(8, 11) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 2), new Ficha(2, 3), new Ficha(3, 4), new Ficha(4, 5), new Ficha(5, 6), new Ficha(6, 7), new Ficha(7, 8) }));
            Perform(d => d.Juega());

            CheckMultiSet(d => d.FichasDe(1));
        }
    }

    public class Tester19 : DominoTester
    {
        public void Tablero1()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 1), new Ficha(1, 3), new Ficha(9, 2), new Ficha(7, 5) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 4), new Ficha(5, 0), new Ficha(7, 9) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(5, 0), new Ficha(7, 6), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(3, 1), new Ficha(4, 3), new Ficha(3, 7), new Ficha(3, 2) }));

            CheckSequence(d => d.Tablero);
        }
    }

    public class Tester20 : DominoTester
    {
        public void Tablero2()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 1), new Ficha(1, 3), new Ficha(9, 2), new Ficha(7, 5) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 4), new Ficha(5, 0), new Ficha(7, 9) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(5, 0), new Ficha(7, 6), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(3, 1), new Ficha(4, 3), new Ficha(3, 7), new Ficha(3, 2) }));
            Perform(d => d.Juega());

            CheckSequence(d => d.Tablero);
        }
    }

    public class Tester21 : DominoTester
    {
        public void Tablero3()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 1), new Ficha(1, 3), new Ficha(9, 2), new Ficha(7, 5) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 4), new Ficha(5, 0), new Ficha(7, 9) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(5, 0), new Ficha(7, 6), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(3, 1), new Ficha(4, 3), new Ficha(3, 7), new Ficha(3, 2) }));
            Perform(d => d.Juega());
            Perform(d => d.Juega());

            CheckSequence(d => d.Tablero);
        }
    }

    public class Tester22 : DominoTester
    {
        public void Tablero4()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 1), new Ficha(1, 3), new Ficha(9, 2), new Ficha(7, 5) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 4), new Ficha(5, 0), new Ficha(7, 9), new Ficha(1, 5) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(5, 0), new Ficha(7, 6), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(3, 1), new Ficha(4, 3), new Ficha(3, 7), new Ficha(3, 2) }));
            Perform(d => d.Juega());
            Perform(d => d.Juega());

            CheckSequence(d => d.Tablero);
        }
    }

    public class Tester23 : DominoTester
    {
        public void Tablero5()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(7, 1), new Ficha(1, 3), new Ficha(9, 2), new Ficha(7, 5) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 4), new Ficha(5, 0), new Ficha(7, 9), new Ficha(5, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(5, 0), new Ficha(7, 6), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(3, 1), new Ficha(4, 3), new Ficha(3, 7), new Ficha(3, 2) }));
            Perform(d => d.Juega());
            Perform(d => d.Juega());

            CheckSequence(d => d.Tablero);
        }
    }

    public class Tester24 : DominoTester
    {
        public void Tablero6()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(7, 1), new Ficha(1, 3), new Ficha(9, 2), new Ficha(7, 5) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 4), new Ficha(5, 0), new Ficha(7, 9), new Ficha(5, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(5, 0), new Ficha(7, 6), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(3, 1), new Ficha(4, 3), new Ficha(3, 7), new Ficha(3, 2) }));
            Perform(d => d.Juega());
            Perform(d => d.Juega());

            CheckSequence(d => d.Tablero);
        }
    }

    public class Tester25 : DominoTester
    {
        public void Tablero7()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(7, 1), new Ficha(1, 3), new Ficha(9, 2), new Ficha(7, 5) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 4), new Ficha(5, 0), new Ficha(7, 9), new Ficha(5, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(5, 0), new Ficha(7, 6), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(3, 1), new Ficha(4, 3), new Ficha(3, 7), new Ficha(3, 2) }));
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());

            CheckSequence(d => d.Tablero);
        }
    }

    public class Tester26 : DominoTester
    {
        public void Ganadores1()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(7, 1), new Ficha(1, 3), new Ficha(9, 2), new Ficha(7, 5) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 4), new Ficha(5, 0), new Ficha(7, 9), new Ficha(5, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(5, 0), new Ficha(7, 6), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(3, 1), new Ficha(4, 3), new Ficha(3, 7), new Ficha(3, 2) }));

            CheckMultiSet(d => d.Ganadores);
        }
    }

    public class Tester27 : DominoTester
    {
        public void Ganadores2()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(7, 1), new Ficha(0, 0) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 4), new Ficha(5, 0), new Ficha(7, 9), new Ficha(5, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(5, 0), new Ficha(7, 6), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(3, 1), new Ficha(4, 3), new Ficha(3, 7), new Ficha(3, 2) }));
            Perform(d => d.Juega());

            CheckMultiSet(d => d.Ganadores);
        }
    }

    public class Tester28 : DominoTester
    {
        public void Ganadores3()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(8, 8), new Ficha(1, 3), new Ficha(9, 2), new Ficha(7, 5) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 4), new Ficha(5, 0), new Ficha(7, 9), new Ficha(5, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(5, 0), new Ficha(7, 6), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(3, 1), new Ficha(4, 3), new Ficha(3, 7), new Ficha(3, 2) }));
            Perform(d => d.Juega());

            CheckMultiSet(d => d.Ganadores);
        }
    }

    public class Tester29 : DominoTester
    {
        public void Ganadores4()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(8, 8), new Ficha(1, 3), new Ficha(9, 2), new Ficha(7, 5) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 4), new Ficha(5, 0), new Ficha(7, 9), new Ficha(5, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(5, 0), new Ficha(7, 6), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(3, 1), new Ficha(4, 3), new Ficha(3, 7), new Ficha(3, 2) }));
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());

            CheckMultiSet(d => d.Ganadores);
        }
    }

    public class Tester30 : DominoTester
    {
        public void Ganadores5()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(7, 1), new Ficha(1, 3), new Ficha(9, 2), new Ficha(7, 5) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(7, 9), new Ficha(1, 2) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(5, 0), new Ficha(7, 6), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(3, 1), new Ficha(4, 3), new Ficha(3, 7), new Ficha(3, 2) }));
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());

            CheckMultiSet(d => d.Ganadores);
        }
    }

    public class Tester31 : DominoTester
    {
        public void Ganadores6()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(7, 1), new Ficha(1, 3), new Ficha(0, 0) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(7, 9), new Ficha(1, 2) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(5, 0), new Ficha(7, 6), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(3, 1), new Ficha(4, 3), new Ficha(3, 7), new Ficha(3, 2) }));
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());

            CheckMultiSet(d => d.Ganadores);
        }
    }

    public class Tester32 : DominoTester
    {
        public void Ganadores7()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(7, 1), new Ficha(8, 3), new Ficha(1, 5) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(7, 9), new Ficha(2, 3) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 4), new Ficha(1, 1), new Ficha(1, 0) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(3, 1), new Ficha(4, 3), new Ficha(3, 7) }));
            for (int i = 0; i < 9; i++)
                Perform(d => d.Juega());

            CheckMultiSet(d => d.Ganadores);
        }
    }

    public class Tester33 : DominoTester
    {
        public void Ganadores8()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(7, 1), new Ficha(8, 3), new Ficha(1, 2) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(7, 9), new Ficha(4, 5) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(5, 0), new Ficha(7, 6), new Ficha(1, 4) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(4, 3), new Ficha(1, 0), new Ficha(0, 2) }));
            for (int i = 0; i < 9; i++)
                Perform(d => d.Juega());

            CheckMultiSet(d => d.Ganadores);
        }
    }

    public class Tester34 : DominoTester
    {
        public void Ganadores9()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(7, 1), new Ficha(8, 3), new Ficha(0, 5) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(7, 9), new Ficha(1, 1), new Ficha(2, 0), new Ficha(0, 1) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 4), new Ficha(2, 3) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(4, 3), new Ficha(5, 0) }));
            for (int i = 0; i < 9; i++)
                Perform(d => d.Juega());

            CheckMultiSet(d => d.Ganadores);
        }
    }

    public class Tester35 : DominoTester
    {
        public void Ganadores10()
        {
            Initialize();

            Perform(d => d.IniciaJuego(4));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(7, 1), new Ficha(0, 3), new Ficha(1, 5) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(7, 9), new Ficha(0, 0) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 4), new Ficha(1, 1), new Ficha(1, 0) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(3, 1), new Ficha(4, 3), new Ficha(3, 7) }));
            for (int i = 0; i < 6; i++)
                Perform(d => d.Juega());

            CheckMultiSet(d => d.Ganadores);
        }
    }

    public class Tester36 : DominoTester
    {
        public void DiferentesEstrategias1()
        {
            Initialize();

            Perform(d => d.IniciaJuego(3));
            Perform(d => d.CreaJugador(new BotaGorda(), new[] { new Ficha(1, 1), new Ficha(1, 3), new Ficha(9, 2), new Ficha(7, 5) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 4), new Ficha(5, 0), new Ficha(7, 9) }));
            Perform(d => d.CreaJugador(new LaUltimaQueMeEncuentre(), new[] { new Ficha(5, 0), new Ficha(7, 6), new Ficha(1, 4) }));
            Perform(d => d.Juega());
            Perform(d => d.Juega());
            Perform(d => d.Juega());

            CheckMultiSet(d => d.FichasDe(0));
            CheckMultiSet(d => d.FichasDe(1));
            CheckMultiSet(d => d.FichasDe(2));
            CheckSequence(d => d.Tablero);
            CheckMultiSet(d => d.Ganadores);
        }
    }

    public class Tester37 : DominoTester
    {
        public void DiferentesEstrategias2()
        {
            Initialize();

            Perform(d => d.IniciaJuego(3));
            Perform(d => d.CreaJugador(new BotaGorda(), new[] { new Ficha(1, 1), new Ficha(1, 3), new Ficha(9, 2), new Ficha(7, 5) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(2, 4), new Ficha(5, 0), new Ficha(7, 9) }));
            Perform(d => d.CreaJugador(new LaUltimaQueMeEncuentre(), new[] { new Ficha(5, 0), new Ficha(7, 6), new Ficha(1, 4) }));
            for (int i = 0; i < 12; i++)
                Perform(d => d.Juega());

            CheckMultiSet(d => d.FichasDe(0));
            CheckMultiSet(d => d.FichasDe(1));
            CheckMultiSet(d => d.FichasDe(2));
            CheckSequence(d => d.Tablero);
            CheckMultiSet(d => d.Ganadores);
        }
    }

    public class Tester38 : DominoTester
    {
        public void DiferentesEstrategias3()
        {
            Initialize();

            Perform(d => d.IniciaJuego(3));
            Perform(d => d.CreaJugador(new BotaGorda(), new[] { new Ficha(1, 8), new Ficha(2, 6), new Ficha(9, 2) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(6, 0), new Ficha(0, 8), new Ficha(3, 7), new Ficha(1, 1) }));
            Perform(d => d.CreaJugador(new LaUltimaQueMeEncuentre(), new[] { new Ficha(2, 0), new Ficha(5, 8), new Ficha(6, 6) }));
            for (int i = 0; i < 4; i++)
                Perform(d => d.Juega());

            CheckMultiSet(d => d.FichasDe(0));
            CheckMultiSet(d => d.FichasDe(1));
            CheckMultiSet(d => d.FichasDe(2));
            CheckSequence(d => d.Tablero);
            CheckMultiSet(d => d.Ganadores);
        }
    }

    public class Tester39 : DominoTester
    {
        public void DiferentesEstrategias4()
        {
            Initialize();

            Perform(d => d.IniciaJuego(3));
            Perform(d => d.CreaJugador(new BotaGorda(), new[] { new Ficha(1, 8), new Ficha(2, 6), new Ficha(9, 2) }));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(6, 0), new Ficha(0, 8), new Ficha(3, 7), new Ficha(1, 1) }));
            Perform(d => d.CreaJugador(new LaUltimaQueMeEncuentre(), new[] { new Ficha(2, 0), new Ficha(5, 8), new Ficha(6, 6) }));
            for (int i = 0; i < 8; i++)
                Perform(d => d.Juega());

            CheckMultiSet(d => d.FichasDe(0));
            CheckMultiSet(d => d.FichasDe(1));
            CheckMultiSet(d => d.FichasDe(2));
            CheckSequence(d => d.Tablero);
            CheckMultiSet(d => d.Ganadores);
        }
    }

    public class Tester40 : DominoTester
    {
        public void DiferentesEstrategias5()
        {
            Initialize();

            Perform(d => d.IniciaJuego(3));
            Perform(d => d.CreaJugador(new LaPrimeraQueMeEncuentre(), new[] { new Ficha(1, 8), new Ficha(2, 6), new Ficha(9, 2) }));
            Perform(d => d.CreaJugador(new BotaGorda(), new[] { new Ficha(6, 0), new Ficha(0, 8), new Ficha(3, 7), new Ficha(1, 1) }));
            Perform(d => d.CreaJugador(new LaUltimaQueMeEncuentre(), new[] { new Ficha(2, 0), new Ficha(5, 8), new Ficha(6, 6) }));
            for (int i = 0; i < 10; i++)
                Perform(d => d.Juega());

            CheckMultiSet(d => d.FichasDe(0));
            CheckMultiSet(d => d.FichasDe(1));
            CheckMultiSet(d => d.FichasDe(2));
            CheckSequence(d => d.Tablero);
            CheckMultiSet(d => d.Ganadores);
        }
    }
}
