﻿using System;
using System.Collections.Generic;
using System.Linq;
using Weboo.Domino;

namespace DominoTester
{
    public class JuegoDeDomino : IJuegoDeDomino
    {
        private LinkedList<Ficha> _Board;
        private Tuple<IEstrategia, List<Ficha>>[] _Players;
        private List<int> _Winners;
        private int _InTurn;
        private int _ConsecutivePassedTurns;

        public JuegoDeDomino() // Su tipo no puede tener otros constructores especializados
        {
            // Implemente aquí cualquier inicialización de su tipo.
        }

        /// <summary>
        /// Debe iniciar un nuevo juego con una determinada cantidad de jugadores.
        /// </summary>
        public void IniciaJuego(int cantidadDeJugadores)
        {
            _Board = new LinkedList<Ficha>();
            _Players = new Tuple<IEstrategia, List<Ficha>>[cantidadDeJugadores];
            _Winners = new List<int>();
            _InTurn = 0;
            _ConsecutivePassedTurns = 0;
        }

        /// <summary>
        /// Debe devolver la cantidad de jugadores con que se inició el juego.
        /// </summary>
        public int CantidadDeJugadores
        {
            get { return _Players.Length; }
        }

        /// <summary>
        /// Luego de iniciado un juego se reparte a cada jugado sus fichas y se determina qué estrategia utilizará.
        /// El primer llamado configura el jugador 0, el segundo llamado el jugador 1, etc.
        /// </summary>
        public void CreaJugador(IEstrategia estrategia, IEnumerable<Ficha> fichasIniciales)
        {
            _Players[_InTurn] = new Tuple<IEstrategia, List<Ficha>>(estrategia, new List<Ficha>(fichasIniciales));
            _InTurn = (_InTurn + 1) % CantidadDeJugadores;
        }

        /// <summary>
        /// En cualquier momento del juego se puede consultar las fichas de algun jugador a través de este método.
        /// </summary>
        public IEnumerable<Ficha> FichasDe(int jugador)
        {
            return _Players[jugador].Item2;
        }

        /// <summary>
        /// Ejecuta un turno consistente en:
        /// si el jugador actual tiene una ficha posible para jugar se consulta su estrategia y se realizan los cambios pertinentes (se realiza la jugada).
        /// Se pasa el turno al próximo jugador
        /// </summary>
        public void Juega()
        {
            if (JuegoTerminado)
                return;

            var currentPlayer = _Players[_InTurn];
            if (_Board.Count == 0 ||
                currentPlayer.Item2.Any(m => m.TieneUn(_Board.First.Value.NumeroIzquierdo) ||
                                             m.TieneUn(_Board.Last.Value.NumeroDerecho)))
            {
                var nextChip = currentPlayer.Item1.DimeJugada(currentPlayer.Item2, _Board);
                currentPlayer.Item2.Remove(nextChip.Ficha);
                if (nextChip.Extremo == Extremo.Izquierdo)
                {
                    _Board.AddFirst(nextChip.Ficha);
                }
                else
                {
                    _Board.AddLast(nextChip.Ficha);
                }

                _ConsecutivePassedTurns = 0;
                if (currentPlayer.Item2.Count == 0)
                {
                    _Winners.Add(_InTurn);
                    return;
                }
            }
            else
            {
                _ConsecutivePassedTurns++;
                if (_ConsecutivePassedTurns == CantidadDeJugadores)
                {
                    int min = int.MaxValue;
                    for (int i = 0; i < _Players.Length; i++)
                    {
                        int sum = _Players[i].Item2.Sum(m => m.Total);
                        if (sum < min)
                        {
                            min = sum;
                            _Winners = new List<int>(new[] { i });
                        }
                        else if (sum == min)
                        {
                            _Winners.Add(i);
                        }
                    }
                }
            }

            _InTurn = (_InTurn + 1) % CantidadDeJugadores;
        }

        /// <summary>
        /// Devuelve un enumerable con los indices de los jugadores ganadores.
        /// Si el juego no ha terminado debe devolver un enumerable vacío.
        /// Si algún jugador se pegó se debe devolver un enumerable con un único elemento igual al índice del jugador pegao'
        /// Si se trancó, todos aquellos jugadores que hayan alcanzado la mínima puntuación.
        /// </summary>
        public IEnumerable<int> Ganadores
        {
            get { return _Winners; }
        }

        /// <summary>
        /// Devuelve true si el juego se terminó, ya sea porque se pegó un jugador o porque se pasaron N jugadores consecutivamente.
        /// </summary>
        public bool JuegoTerminado
        {
            get { return _Winners.Count > 0; }
        }

        /// <summary>
        /// Devuelve el índice del jugador actual al que le toca jugar
        /// </summary>
        public int JugadorActual
        {
            get { return _InTurn; }
        }

        /// <summary>
        /// Devuelve un enumerable con el estado del tablero
        /// </summary>
        public IEnumerable<Ficha> Tablero
        {
            get { return _Board; }
        }
    }
}
