﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Domino;

namespace DominoTester
{
    public class LaPrimeraQueMeEncuentre : IEstrategia
    {
        public Jugada DimeJugada(IEnumerable<Ficha> fichasDelJugador, IEnumerable<Ficha> tableroActual)
        {
            if (!tableroActual.Any())
                return new Jugada(fichasDelJugador.First(), Extremo.Izquierdo);

            int extremoIzquierdo = tableroActual.First().NumeroIzquierdo;
            int extremoDerecho = tableroActual.Last().NumeroDerecho;

            foreach (var f in fichasDelJugador)
            {
                if (f.NumeroDerecho == extremoIzquierdo)
                    return new Jugada(f, Extremo.Izquierdo);
                if (f.NumeroIzquierdo == extremoIzquierdo)
                    return new Jugada(f.Girada, Extremo.Izquierdo);
                if (f.NumeroIzquierdo == extremoDerecho)
                    return new Jugada(f, Extremo.Derecho);
                if (f.NumeroDerecho == extremoDerecho)
                    return new Jugada(f.Girada, Extremo.Derecho);
            }
            throw new InvalidOperationException("No existen fichas que se puedan jugar");
        }
    }

    public class LaUltimaQueMeEncuentre : IEstrategia
    {
        public Jugada DimeJugada(IEnumerable<Ficha> fichasDelJugador, IEnumerable<Ficha> tableroActual)
        {
            if (!tableroActual.Any())
                return new Jugada(fichasDelJugador.First(), Extremo.Izquierdo);

            int extremoIzquierdo = tableroActual.First().NumeroIzquierdo;
            int extremoDerecho = tableroActual.Last().NumeroDerecho;

            foreach (var f in fichasDelJugador.Reverse())
            {
                if (f.NumeroDerecho == extremoIzquierdo)
                    return new Jugada(f, Extremo.Izquierdo);
                if (f.NumeroIzquierdo == extremoIzquierdo)
                    return new Jugada(f.Girada, Extremo.Izquierdo);
                if (f.NumeroIzquierdo == extremoDerecho)
                    return new Jugada(f, Extremo.Derecho);
                if (f.NumeroDerecho == extremoDerecho)
                    return new Jugada(f.Girada, Extremo.Derecho);
            }
            throw new InvalidOperationException("No existen fichas que se puedan jugar");
        }
    }

    public class BotaGorda : IEstrategia
    {
        public Jugada DimeJugada(IEnumerable<Ficha> fichasDelJugador, IEnumerable<Ficha> tableroActual)
        {
            if (!tableroActual.Any())
                return new Jugada(fichasDelJugador.First(), Extremo.Izquierdo);

            int extremoIzquierdo = tableroActual.First().NumeroIzquierdo;
            int extremoDerecho = tableroActual.Last().NumeroDerecho;

            foreach (var f in fichasDelJugador.OrderByDescending(m => m.Total))
            {
                if (f.NumeroDerecho == extremoIzquierdo)
                    return new Jugada(f, Extremo.Izquierdo);
                if (f.NumeroIzquierdo == extremoIzquierdo)
                    return new Jugada(f.Girada, Extremo.Izquierdo);
                if (f.NumeroIzquierdo == extremoDerecho)
                    return new Jugada(f, Extremo.Derecho);
                if (f.NumeroDerecho == extremoDerecho)
                    return new Jugada(f.Girada, Extremo.Derecho);
            }
            throw new InvalidOperationException("No existen fichas que se puedan jugar");
        }
    }
}
