﻿using Weboo.Assess.Tester;

namespace ParchisRaroTester
{
    public abstract class ParchisRaroTests : TestCase
    {
        public int[] Student(int[] tablero, int cantidadDeJugadores, int[] lanzamientos)
        {
            return ReflectionHelper.InvokeStatic<int[]>("Weboo.Examen.ParchisRaro", "Simula", tablero, cantidadDeJugadores, lanzamientos);
        }

        public int[] Simula(int[] tablero, int cantidadDeJugadores, int[] lanzamientos)
        {
            int[] position = new int[cantidadDeJugadores];
            for(int i = 0; i < lanzamientos.Length; i++)
            {
                int current = i % cantidadDeJugadores;
                while (position[current] < tablero.Length && tablero[position[current]] != lanzamientos[i])
                    position[current]++;

                if (position[current] == tablero.Length)
                {
                    break;
                }
            }

            return position;
        }
    }

    public class Ejemplo1Test : ParchisRaroTests
    {
        public void Ejemplo1()
        {
            int cantidadDeJugadores = 3;
            int[] tableroStudent = { 3, 1, 5, 2, 3, 4, 1, 1, 1, 2, 5, 2, 7, 8, 2, 7, 2, 3, 1, 6 };
            int[] lanzamientosStudent = { 5, 3, 7, 1, 2, 2 };

            int[] tableroBenchmark = { 3, 1, 5, 2, 3, 4, 1, 1, 1, 2, 5, 2, 7, 8, 2, 7, 2, 3, 1, 6 };
            int[] lanzamientosBenchmark = { 5, 3, 7, 1, 2, 2 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class Ejemplo2Test : ParchisRaroTests
    {
        public void Ejemplo2()
        {
            int cantidadDeJugadores = 3;
            int[] tableroStudent = { 3, 1, 5, 2, 3, 4, 1, 1, 1, 2, 5, 2, 7, 8, 2, 7, 2, 3, 1, 6 };
            int[] lanzamientosStudent = { 5, 3, 7, 1, 2, 2, 4, 5, 6, 23 };

            int[] tableroBenchmark = { 3, 1, 5, 2, 3, 4, 1, 1, 1, 2, 5, 2, 7, 8, 2, 7, 2, 3, 1, 6 };
            int[] lanzamientosBenchmark = { 5, 3, 7, 1, 2, 2, 4, 5, 6, 23 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class Ejemplo3Test : ParchisRaroTests
    {
        public void Ejemplo3()
        {
            int cantidadDeJugadores = 3;
            int[] tableroStudent = { 3, 1, 5, 2, 3, 4, 1, 1, 1, 2, 5, 2, 7, 8, 2, 7, 2, 3, 1, 6 };
            int[] lanzamientosStudent = { 5, 3, 7, 1, 2, 2, 2, 5, 6, 23 };

            int[] tableroBenchmark = { 3, 1, 5, 2, 3, 4, 1, 1, 1, 2, 5, 2, 7, 8, 2, 7, 2, 3, 1, 6 };
            int[] lanzamientosBenchmark = { 5, 3, 7, 1, 2, 2, 2, 5, 6, 23 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class Ejemplo4Test : ParchisRaroTests
    {
        public void Ejemplo4()
        {
            int cantidadDeJugadores = 100;
            int[] tableroStudent = { 150, -5, 23, 0 };
            int[] lanzamientosStudent = { -5, 1 };

            int[] tableroBenchmark = { 150, -5, 23, 0 };
            int[] lanzamientosBenchmark = { -5, 1 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class UnJugador1Test : ParchisRaroTests
    {
        public void UnJugador1()
        {
            int cantidadDeJugadores = 1;
            int[] tableroStudent = { 4, 1, 3, 2 };
            int[] lanzamientosStudent = { 4, 1, 3, 2 };

            int[] tableroBenchmark = { 4, 1, 3, 2 };
            int[] lanzamientosBenchmark = { 4, 1, 3, 2 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class UnJugador2Test : ParchisRaroTests
    {
        public void UnJugador2()
        {
            int cantidadDeJugadores = 1;
            int[] tableroStudent = { 8 };
            int[] lanzamientosStudent = { 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8 };

            int[] tableroBenchmark = { 8 };
            int[] lanzamientosBenchmark = { 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class UnJugador3Test : ParchisRaroTests
    {
        public void UnJugador3()
        {
            int cantidadDeJugadores = 1;
            int[] tableroStudent = { 4, 1, 4, 4 };
            int[] lanzamientosStudent = { 1, 4 };

            int[] tableroBenchmark = { 4, 1, 4, 4 };
            int[] lanzamientosBenchmark = { 1, 4 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class UnJugador4Test : ParchisRaroTests
    {
        public void UnJugador4()
        {
            int cantidadDeJugadores = 1;
            int[] tableroStudent = { 4, 1, 4, 1, 3 };
            int[] lanzamientosStudent = { 1, 4 };

            int[] tableroBenchmark = { 4, 1, 4, 1, 3 };
            int[] lanzamientosBenchmark = { 1, 4 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class UnJugador5Test : ParchisRaroTests
    {
        public void TesUnJugador5()
        {
            int cantidadDeJugadores = 1;
            int[] tableroStudent = { 4, 1, 2, 1, 3 };
            int[] lanzamientosStudent = { 3, 4 };

            int[] tableroBenchmark = { 4, 1, 2, 1, 3 };
            int[] lanzamientosBenchmark = { 3, 4 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class UnJugador6Test : ParchisRaroTests
    {
        public void UnJugador6()
        {
            int cantidadDeJugadores = 1;
            int[] tableroStudent = { -4, -1, -2, -1, -3 };
            int[] lanzamientosStudent = { -3, -4 };

            int[] tableroBenchmark = { -4, -1, -2, -1, -3 };
            int[] lanzamientosBenchmark = { -3, -4 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class UnJugador7Test : ParchisRaroTests
    {
        public void UnJugador7()
        {
            int cantidadDeJugadores = 1;
            int[] tableroStudent = { 1000 };
            int[] lanzamientosStudent = { 1000 };

            int[] tableroBenchmark = { 1000 };
            int[] lanzamientosBenchmark = { 1000 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class UnJugador8Test : ParchisRaroTests
    {
        public void UnJugador8()
        {
            int cantidadDeJugadores = 1;
            int[] tableroStudent = { -1000 };
            int[] lanzamientosStudent = { 1000 };

            int[] tableroBenchmark = { -1000 };
            int[] lanzamientosBenchmark = { 1000 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class UnJugador9Test : ParchisRaroTests
    {
        public void UnJugador9()
        {
            int cantidadDeJugadores = 1;
            int[] tableroStudent = { 1, 2, 1, 2, 1, 2 };
            int[] lanzamientosStudent = { 2, 1, 2, 1 };

            int[] tableroBenchmark = { 1, 2, 1, 2, 1, 2 };
            int[] lanzamientosBenchmark = { 2, 1, 2, 1 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class UnJugador10Test : ParchisRaroTests
    {
        public void UnJugador10()
        {
            int cantidadDeJugadores = 1;
            int[] tableroStudent = { -1, -2, -3, int.MinValue + 1 };
            int[] lanzamientosStudent = { 8 };

            int[] tableroBenchmark = { -1, -2, -3, int.MinValue + 1 };
            int[] lanzamientosBenchmark = { 8 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class MultiplesJugadores1Test : ParchisRaroTests
    {
        public void MultiplesJugadores1()
        {
            int cantidadDeJugadores = 2;
            int[] tableroStudent = { 1, 8, 20, 4, 5 };
            int[] lanzamientosStudent = { 8, 1, 8, 4 };

            int[] tableroBenchmark = { 1, 8, 20, 4, 5 };
            int[] lanzamientosBenchmark = { 8, 1, 8, 4 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class MultiplesJugadores2Test : ParchisRaroTests
    {
        public void MultiplesJugadores2()
        {
            int cantidadDeJugadores = 4;
            int[] tableroStudent = { 1, 8, 20, 4, 5, 100, 30, -10 };
            int[] lanzamientosStudent = { 8, 1, 0, 4 };

            int[] tableroBenchmark = { 1, 8, 20, 4, 5, 100, 30, -10 };
            int[] lanzamientosBenchmark = { 8, 1, 0, 4 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class MultiplesJugadores3Test : ParchisRaroTests
    {
        public void MultiplesJugadores3()
        {
            int cantidadDeJugadores = 1000;
            int[] tableroStudent = { 1, 8, 20, 4, 5, 100, 30, -10 };
            int[] lanzamientosStudent = { -11, 1, 0, 4 };

            int[] tableroBenchmark = { 1, 8, 20, 4, 5, 100, 30, -10 };
            int[] lanzamientosBenchmark = { -11, 1, 0, 4 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class MultiplesJugadores4Test : ParchisRaroTests
    {
        public void MultiplesJugadores4()
        {
            int cantidadDeJugadores = 4;
            int[] tableroStudent = { 1, 8, 20, 4, 5, 100, 30, -10 };
            int[] lanzamientosStudent = { 20, 8, -10, 1, 4, 8, -10, 100, 4, 8, -10, 100, 4, 8, -10, 100, 4, 8, -10, 100 };

            int[] tableroBenchmark = { 1, 8, 20, 4, 5, 100, 30, -10 };
            int[] lanzamientosBenchmark = { 20, 8, -10, 1, 4, 8, -10, 100, 4, 8, -10, 100, 4, 8, -10, 100, 4, 8, -10, 100 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class MultiplesJugadores5Test : ParchisRaroTests
    {
        public void MultiplesJugadores5()
        {
            int cantidadDeJugadores = 5;
            int[] tableroStudent = { 1, 8, 20, 4, 5, 100, 30, -10 };
            int[] lanzamientosStudent = { 20, 8, -10, 1, 4, 8, -10, 100, 4, 8, -10, 100, 4, 8, -10, 100, 4, 8, -10, 100 };

            int[] tableroBenchmark = { 1, 8, 20, 4, 5, 100, 30, -10 };
            int[] lanzamientosBenchmark = { 20, 8, -10, 1, 4, 8, -10, 100, 4, 8, -10, 100, 4, 8, -10, 100, 4, 8, -10, 100 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class MultiplesJugadores6Test : ParchisRaroTests
    {
        public void MultiplesJugadores6()
        {
            int cantidadDeJugadores = 9;
            int[] tableroStudent = { 1, 8, 20, 4, 5, 100, 30, -10 };
            int[] lanzamientosStudent = { 20, 8, -10, 10, 4, 8, -10, 100, 4, 8, -10, 100, 4, 8, -10, 100, 4, 8, -10, 100 };

            int[] tableroBenchmark = { 1, 8, 20, 4, 5, 100, 30, -10 };
            int[] lanzamientosBenchmark = { 20, 8, -10, 10, 4, 8, -10, 100, 4, 8, -10, 100, 4, 8, -10, 100, 4, 8, -10, 100 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class MultiplesJugadores7Test : ParchisRaroTests
    {
        public void MultiplesJugadores7()
        {
            int cantidadDeJugadores = 3;
            int[] tableroStudent = { 1, 20, 5, 1, 1, 2, 3, 1, 9, 0, -8, 8 };
            int[] lanzamientosStudent = { 8 };

            int[] tableroBenchmark = { 1, 20, 5, 1, 1, 2, 3, 1, 9, 0, -8, 8 };
            int[] lanzamientosBenchmark = { 8 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class MultiplesJugadores8Test : ParchisRaroTests
    {
        public void MultiplesJugadores8()
        {
            int cantidadDeJugadores = 3;
            int[] tableroStudent = { 8 };
            int[] lanzamientosStudent = { 1, 20, 5, 1, 1, 2, 3, 1, 9, 0, -8, 8 };

            int[] tableroBenchmark = { 8 };
            int[] lanzamientosBenchmark = { 1, 20, 5, 1, 1, 2, 3, 1, 9, 0, -8, 8 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class MultiplesJugadores9Test : ParchisRaroTests
    {
        public void MultiplesJugadores9()
        {
            int cantidadDeJugadores = 3;
            int[] tableroStudent = { 5 };
            int[] lanzamientosStudent = { 5, 5, 5, 5, 5, 5, 5 };

            int[] tableroBenchmark = { 5 };
            int[] lanzamientosBenchmark = { 5, 5, 5, 5, 5, 5, 5 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class MultiplesJugadores10Test : ParchisRaroTests
    {
        public void MultiplesJugadores10()
        {
            int cantidadDeJugadores = 3;
            int[] tableroStudent = { 1, 5 };
            int[] lanzamientosStudent = { 5, 5, 5, 5, 5, 5, 5, 1, 5, 5, 5, 5, 5, 5 };

            int[] tableroBenchmark = { 1, 5 };
            int[] lanzamientosBenchmark = { 5, 5, 5, 5, 5, 5, 5, 1, 5, 5, 5, 5, 5, 5 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class MultiplesJugadores11Test : ParchisRaroTests
    {
        public void MultiplesJugadores11()
        {
            int cantidadDeJugadores = 9;
            int[] tableroStudent = { 10, 10, 10 };
            int[] lanzamientosStudent = { 5 };

            int[] tableroBenchmark = { 10, 10, 10 };
            int[] lanzamientosBenchmark = { 5 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class MultiplesJugadores12Test : ParchisRaroTests
    {
        public void MultiplesJugadores12()
        {
            int cantidadDeJugadores = 2;
            int[] tableroStudent = { 8, 8, 8 };
            int[] lanzamientosStudent = { 8, 8, 8, 8, 8, 8, 8, 8, 8, 1 };

            int[] tableroBenchmark = { 8, 8, 8 };
            int[] lanzamientosBenchmark = { 8, 8, 8, 8, 8, 8, 8, 8, 8, 1 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class MultiplesJugadores13Test : ParchisRaroTests
    {
        public void MultiplesJugadores13()
        {
            int cantidadDeJugadores = 2;
            int[] tableroStudent = { 4, 9 };
            int[] lanzamientosStudent = { 9, 8 };

            int[] tableroBenchmark = { 4, 9 };
            int[] lanzamientosBenchmark = { 9, 8 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class MultiplesJugadores14Test : ParchisRaroTests
    {
        public void MultiplesJugadores14()
        {
            int cantidadDeJugadores = 2;
            int[] tableroStudent = { 0 };
            int[] lanzamientosStudent = { 3, 1 };

            int[] tableroBenchmark = { 0 };
            int[] lanzamientosBenchmark = { 3, 1 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }

    public class MultiplesJugadores15Test : ParchisRaroTests
    {
        public void MultiplesJugadores15()
        {
            int cantidadDeJugadores = 3;
            int[] tableroStudent = { -1, 0, -1, 0, -1 };
            int[] lanzamientosStudent = { -1, 0, -1, 0, -1 };

            int[] tableroBenchmark = { -1, 0, -1, 0, -1 };
            int[] lanzamientosBenchmark = { -1, 0, -1, 0, -1 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }
    public class MultiplesJugadores16Test : ParchisRaroTests
    {
        public void MultiplesJugadores16()
        {
            int cantidadDeJugadores = 4;
            int[] tableroStudent = { -1, 0, -1, 0, -1 };
            int[] lanzamientosStudent = { -1, 0, -1, 0, -1 };

            int[] tableroBenchmark = { -1, 0, -1, 0, -1 };
            int[] lanzamientosBenchmark = { -1, 0, -1, 0, -1 };

            Assert.That(Student(tableroStudent, cantidadDeJugadores, lanzamientosStudent),
                Is.SequenceEqualTo(Simula(tableroBenchmark, cantidadDeJugadores, lanzamientosBenchmark)));
        }
    }
}
