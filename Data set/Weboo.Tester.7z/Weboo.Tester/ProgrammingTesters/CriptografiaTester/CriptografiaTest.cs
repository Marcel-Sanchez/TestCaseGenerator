﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Assess.Tester;

namespace CriptografiaTester
{
    public class CriptografiaTest : TestCase
    {
        private string Desencriptar(char[] alfabeto, char caracter, string mensaje)
        {
            char modeEncrypted = mensaje[0];
            int count = 0;
            for (int i = 0; i < mensaje.Length; i++)
            {
                int c = 1;
                for (int j = i + 1; j < mensaje.Length; j++)
                {
                    if (mensaje[i] == mensaje[j])
                    {
                        c++;
                    }
                }

                if (c > count)
                {
                    modeEncrypted = mensaje[i];
                    count = c;
                }
            }

            int modeIndex = GetIndexOf(alfabeto, caracter);
            int modeEncryptedIndex = GetIndexOf(alfabeto, modeEncrypted);

            int shift = (modeEncryptedIndex - modeIndex + alfabeto.Length) % alfabeto.Length;
            string deciphered = string.Empty;
            for (int i = 0; i < mensaje.Length; i++)
            {
                int p = GetIndexOf(alfabeto, mensaje[i]);
                deciphered += alfabeto[(p - shift + alfabeto.Length) % alfabeto.Length];
            }

            return deciphered;
        }
        private static int GetIndexOf(char[] alf, char c)
        {
            for (int i = 0; i < alf.Length; i++)
            {
                if (alf[i] == c)
                    return i;
            }

            return -1;
        }

        private string Student(char[] alfabeto, char caracter, string mensaje)
        {
            return ReflectionHelper.InvokeStatic<string>("Weboo.Examen.Criptografía", "Desencriptar", alfabeto, caracter,
                mensaje);
        }

        public void Case1()
        {
            char[] alfabetoStudent = { 'A', 'B', 'T', 'E' };
            char[] alfabetoSolution = { 'A', 'B', 'T', 'E' };
            char caracter = 'B';
            string mensaje = "ATAE";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case2()
        {
            char[] alfabetoStudent = { 'A', 'E', 'T', 'B' };
            char[] alfabetoSolution = { 'A', 'E', 'T', 'B' };
            char caracter = 'T';
            string mensaje = "ABEABA";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case3()
        {
            char[] alfabetoStudent = { 'A', 'B', 'T', 'E' };
            char[] alfabetoSolution = { 'A', 'B', 'T', 'E' };
            char caracter = 'A';
            string mensaje = "EAEBT";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case4()
        {
            char[] alfabetoStudent = { 'A', 'B', 'T', 'E' };
            char[] alfabetoSolution = { 'A', 'B', 'T', 'E' };
            char caracter = 'A';
            string mensaje = "EBBTBTTET";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case5()
        {
            char[] alfabetoStudent = { 'S', ' ', 'T', 'E', 'H', 'U', 'R', 'Y', 'O' };
            char[] alfabetoSolution = { 'S', ' ', 'T', 'E', 'H', 'U', 'R', 'Y', 'O' };
            char caracter = 'E';
            string mensaje = "EORSURHYT ";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case6()
        {
            char[] alfabetoStudent = { 'S', 'T', 'E', 'H', 'U', ' ', 'R', 'Y', 'O' };
            char[] alfabetoSolution = { 'S', 'T', 'E', 'H', 'U', ' ', 'R', 'Y', 'O' };
            char caracter = 'E';
            string mensaje = "  SERO  ";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case7()
        {
            char[] alfabetoStudent = { 'x', '-', 'Q', '1', '*', '0', 'c', 'L', '[' };
            char[] alfabetoSolution = { 'x', '-', 'Q', '1', '*', '0', 'c', 'L', '[' };
            char caracter = '1';
            string mensaje = "*[*[xx1-*cL";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case8()
        {
            char[] alfabetoStudent = { 'x', '-', 'Q', '1', '*', '0', 'c', 'L', '[' };
            char[] alfabetoSolution = { 'x', '-', 'Q', '1', '*', '0', 'c', 'L', '[' };
            char caracter = '[';
            string mensaje = "*[*1-*[cL";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case9()
        {
            char[] alfabetoStudent = { '1', '2', '3', '4', '5', '0' };
            char[] alfabetoSolution = { '1', '2', '3', '4', '5', '0' };
            char caracter = '1';
            string mensaje = "21121212113";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case10()
        {
            char[] alfabetoStudent = { '1', '2', '3', '4', '5', '0' };
            char[] alfabetoSolution = { '1', '2', '3', '4', '5', '0' };
            char caracter = '1';
            string mensaje = "050";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case11()
        {
            char[] alfabetoStudent = { 'a', 'b' };
            char[] alfabetoSolution = { 'a', 'b' };
            char caracter = 'b';
            string mensaje = "aaaaaaaa";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case12()
        {
            char[] alfabetoStudent = { 'b' };
            char[] alfabetoSolution = { 'b' };
            char caracter = 'b';
            string mensaje = "b";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case13()
        {
            char[] alfabetoStudent = { 'a', 'b', 'c', 'd', 'e' };
            char[] alfabetoSolution = { 'a', 'b', 'c', 'd', 'e' };
            char caracter = 'e';
            string mensaje = "bbbccccceaa";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case14()
        {
            char[] alfabetoStudent = { 'a', 'b', 'c', 'd', 'e' };
            char[] alfabetoSolution = { 'a', 'b', 'c', 'd', 'e' };
            char caracter = 'e';
            string mensaje = "eaeacdca";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case15()
        {
            char[] alfabetoStudent = { '*', 'a', '+', '-', '_', '.' };
            char[] alfabetoSolution = { '*', 'a', '+', '-', '_', '.' };
            char caracter = 'a';
            string mensaje = "*a*+-a++-_-.-";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case16()
        {
            char[] alfabetoStudent = { '*', 'a', '+', '-', '_', '.' };
            char[] alfabetoSolution = { '*', 'a', '+', '-', '_', '.' };
            char caracter = '.';
            string mensaje = "_+_";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case17()
        {
            char[] alfabetoStudent = { '*', '-', '+', '/' };
            char[] alfabetoSolution = { '*', '-', '+', '/' };
            char caracter = '+';
            string mensaje = "+-/*-*/+**";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case18()
        {
            char[] alfabetoStudent = { '*', '-', '+', '/' };
            char[] alfabetoSolution = { '*', '-', '+', '/' };
            char caracter = '+';
            string mensaje = "-/+//+-++-+-++/-+";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case19()
        {
            char[] alfabetoStudent = { '*', '-', '+', '/' };
            char[] alfabetoSolution = { '*', '-', '+', '/' };
            char caracter = '+';
            string mensaje = "/";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }

        public void Case20()
        {
            char[] alfabetoStudent = { '*', '-', '+', '/' };
            char[] alfabetoSolution = { '*', '-', '+', '/' };
            char caracter = '-';
            string mensaje = "-";

            Assert.That(Student(alfabetoStudent, caracter, mensaje),
                Is.EqualTo(Desencriptar(alfabetoSolution, caracter, mensaje)));
        }
    }
}
