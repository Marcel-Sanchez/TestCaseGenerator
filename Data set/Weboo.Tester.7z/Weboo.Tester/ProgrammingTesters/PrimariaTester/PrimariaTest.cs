﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Assess.Tester;

namespace PrimariaTester
{
    public class PrimariaTest : TestCase
    {
        private static int Student(bool[,] preferencia)
        {
            return ReflectionHelper.InvokeStatic<int>("Weboo.Examen.Primaria", "CantidadMinimaDeZonas", preferencia);
        }

        public void Basic0()
        {
            bool[,] input = {
                { true,     false,  false,  false },
                { true,     true,   false,  false },
                { true,     false,  true,   false },
                { false,    true,   true,   true },
                { false,    false,  false,  true }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));

        }

        public void Basic1()
        {
            bool[,] input = {
                {true, false, false, false},
                {true, false, false, false},
                {true, false, false, false},
                {true, false, false, false},
                {true, false, false, false}
            };
            int expectedOutput = 1;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }

        public void Basic2()
        {
            bool[,] input = {
                {true, false, false, false},
                {false, true, false, false},
                {false, false, true, false},
                {false, false, false, true}
            };
            int expectedOutput = 4;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }

        public void Basic3()
        {
            bool[,] input = {
                {true, false, false, false, false, false, false, false},
                {false, false, false, false, false, false, false, true},
                {false, true, false, false, false, true, false, false},
                {false, false, false, true, false, false, false, false},
                {false, true, false, false, false, false, true, false},
                {true, false, false, false, true, false, false, false},
                {false, true, false, false, false, false, false, false},
                {true, false, false, true, true, true, true, true},
                {true, true, true, true, true, true, true, false}
            };
            int expectedOutput = 4;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case0()
        {
            bool[,] input = {
                { true, false },
                { true, false },
                { false, true },
                { true, false },
                { false, true },
                { false, true },
                { true, false },
                { true, false },
                { true, false },
                { true, false },
                { true, false },
                { true, false }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case1()
        {
            bool[,] input = {
                { false, false, true, false, false, false, false },
                { false, true, false, false, false, false, false },
                { false, false, false, true, false, false, false },
                { true, false, false, false, false, false, false },
                { true, false, false, false, false, false, false },
                { false, false, true, false, false, false, false },
                { false, false, true, false, false, false, false },
                { false, false, false, true, false, false, false },
                { false, false, false, true, false, false, false },
                { false, false, true, true, false, false, false },
                { true, false, false, false, true, false, false },
                { true, false, false, true, false, true, false }
            };
            int expectedOutput = 4;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case2()
        {
            bool[,] input = {
                { false, false, false, true },
                { true, false, false, false },
                { true, false, false, true },
                { true, false, false, false },
                { false, false, true, true },
                { false, false, false, true },
                { true, false, true, false }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case3()
        {
            bool[,] input = {
                { false, false, false, false, false, false, true, true, false },
                { false, false, false, true, false, false, false, false, false },
                { true, false, false, false, false, false, false, true, false },
                { false, false, false, false, false, false, true, false, false },
                { false, false, false, false, true, false, false, false, false },
                { false, false, false, false, false, false, true, false, true },
                { false, false, false, false, false, false, false, false, true },
                { true, false, false, false, true, false, false, true, false },
                { false, false, true, false, false, false, false, true, false }
            };
            int expectedOutput = 5;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case4()
        {
            bool[,] input = {
                { true, true },
                { false, true },
                { true, true },
                { true, false }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case5()
        {
            bool[,] input = {
                { false, false, true, false },
                { true, false, false, false },
                { false, false, true, false },
                { false, false, true, false },
                { false, false, true, false },
                { true, true, false, true },
                { false, false, false, true },
                { false, false, false, true }
            };
            int expectedOutput = 3;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case6()
        {
            bool[,] input = {
                { false, true, false, false, false, false, false, false, false, false, false },
                { false, false, false, false, false, false, true, true, false, false, true },
                { false, true, false, false, false, false, false, false, true, false, false },
                { false, true, false, false, true, false, false, false, false, false, true },
                { false, false, false, false, false, false, true, false, false, false, false },
                { false, false, false, false, false, false, false, false, false, false, true },
                { false, false, false, false, false, false, false, true, false, false, true }
            };
            int expectedOutput = 3;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case7()
        {
            bool[,] input = {
                { true, false, false, false, false, false, false },
                { false, false, true, true, false, false, true }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case8()
        {
            bool[,] input = {
                { false, false, true, false, false, true, false, false, false, true },
                { false, true, false, false, false, false, false, false, true, false }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case9()
        {
            bool[,] input = {
                { false, false, false, false, false, true, false, false, false, false, false }
            };
            int expectedOutput = 1;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case10()
        {
            bool[,] input = {
                { true, true, false, false, false, false, false, true },
                { false, false, false, false, true, false, false, false },
                { false, false, false, false, false, false, false, true },
                { false, false, true, false, false, false, false, false },
                { true, false, false, false, false, false, false, false },
                { true, false, false, false, false, false, false, false },
                { false, false, false, false, true, false, false, false }
            };
            int expectedOutput = 4;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case11()
        {
            bool[,] input = {
                { false, false, false, false, false, false, false, true },
                { false, false, true, false, false, false, false, false },
                { false, false, true, false, false, false, false, false },
                { false, false, true, false, false, false, false, true },
                { false, false, false, false, false, true, false, false },
                { false, false, false, false, false, false, false, true },
                { false, false, false, false, false, false, true, false },
                { false, false, false, false, false, true, false, false },
                { false, false, true, false, false, false, false, false }
            };
            int expectedOutput = 4;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case12()
        {
            bool[,] input = {
                { false, true, false, false, false, true },
                { false, false, true, false, false, true }
            };
            int expectedOutput = 1;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case13()
        {
            bool[,] input = {
                { true, false },
                { true, false },
                { true, false },
                { false, true },
                { true, false },
                { false, true },
                { true, false },
                { true, false },
                { false, true },
                { true, false },
                { false, true },
                { true, false }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case14()
        {
            bool[,] input = {
                { false, true, false, false, true },
                { true, false, false, false, false },
                { true, false, false, false, false },
                { true, false, false, false, false },
                { true, false, false, true, true },
                { false, true, false, false, false },
                { false, false, false, false, true },
                { false, true, false, false, true },
                { true, false, false, false, false }
            };
            int expectedOutput = 3;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case15()
        {
            bool[,] input = {
                { true, false },
                { false, true }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case16()
        {
            bool[,] input = {
                { true },
                { true },
                { true },
                { true }
            };
            int expectedOutput = 1;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case17()
        {
            bool[,] input = {
                { true, false, false, false, false, false, false }
            };
            int expectedOutput = 1;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case18()
        {
            bool[,] input = {
                { false, false, true, false, false, false, false },
                { false, false, true, false, false, false, false },
                { false, false, true, false, false, false, false },
                { false, false, false, false, false, true, false },
                { false, false, false, false, true, false, false },
                { true, true, false, false, false, false, false },
                { false, false, false, true, false, false, false }
            };
            int expectedOutput = 5;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case19()
        {
            bool[,] input = {
                { false, false, false, true, false, false, false },
                { false, true, false, false, false, false, false },
                { false, true, false, false, false, false, false },
                { false, true, false, false, false, true, false },
                { false, true, false, false, false, false, false },
                { false, false, true, false, false, false, false },
                { false, false, false, false, false, true, false },
                { false, false, true, false, false, false, false },
                { false, true, true, false, false, false, false },
                { false, false, false, true, false, true, false },
                { false, false, false, false, false, true, false },
                { false, false, false, false, true, false, false }
            };
            int expectedOutput = 5;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case20()
        {
            bool[,] input = {
                { false, false, true, false },
                { false, false, false, true },
                { false, false, false, true },
                { false, false, true, false },
                { false, false, true, false }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case21()
        {
            bool[,] input = {
                { false, true },
                { false, true },
                { true, false },
                { true, false },
                { false, true },
                { true, false },
                { false, true },
                { true, false },
                { false, true },
                { false, true },
                { true, false }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case22()
        {
            bool[,] input = {
                { false, false, false, false, false, true, false, false, true, false },
                { false, false, false, false, false, false, false, true, false, false }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case23()
        {
            bool[,] input = {
                { true },
                { true },
                { true },
                { true },
                { true },
                { true }
            };
            int expectedOutput = 1;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case24()
        {
            bool[,] input = {
                { false, false, false, true, false, false, false, false, false, false },
                { false, false, true, false, false, false, false, false, false, false },
                { true, false, true, false, false, false, false, false, false, false },
                { false, false, true, false, false, false, false, true, false, false },
                { false, false, false, false, false, false, false, false, true, false },
                { true, false, false, false, false, false, false, false, false, false },
                { false, false, false, false, false, false, false, false, true, false },
                { false, false, true, false, false, true, true, false, false, false },
                { false, false, false, false, false, true, false, true, false, false },
                { false, false, true, false, false, false, false, false, false, false },
                { false, false, false, false, false, false, true, false, false, true }
            };
            int expectedOutput = 6;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case25()
        {
            bool[,] input = {
                { false, false, false, false, false, false, true, false },
                { false, true, false, false, false, true, false, false },
                { false, false, true, true, false, false, false, true },
                { false, false, false, false, true, false, false, false }
            };
            int expectedOutput = 4;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case26()
        {
            bool[,] input = {
                { false, false, true, false, false, true, false },
                { true, false, false, false, false, false, false },
                { false, false, false, false, false, true, true },
                { false, true, false, false, false, false, true },
                { false, false, false, false, true, true, false },
                { false, false, false, false, true, true, false },
                { false, false, false, false, true, false, false },
                { false, false, false, true, false, false, false },
                { false, false, true, false, false, true, false },
                { false, true, false, false, false, false, false },
                { false, false, false, false, false, true, false }
            };
            int expectedOutput = 5;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case27()
        {
            bool[,] input = {
                { false, false, false, false, true, false },
                { true, false, false, false, false, false }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case28()
        {
            bool[,] input = {
                { false, false, false, false, false, false, false, false, false, false, true, true },
                { false, false, false, false, false, true, false, false, false, false, false, false },
                { false, false, false, false, false, false, false, true, false, false, false, false },
                { false, false, false, true, false, false, false, false, false, false, false, false },
                { false, false, false, false, false, false, true, false, false, false, false, false }
            };
            int expectedOutput = 5;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case29()
        {
            bool[,] input = {
                { false, true, false, false, false, false, false, false, false },
                { false, false, false, true, false, false, false, false, false },
                { false, false, true, true, false, false, false, false, false },
                { false, false, false, false, false, false, false, false, true },
                { false, true, false, false, false, false, false, false, false },
                { false, false, false, false, false, false, false, true, false },
                { false, false, true, false, false, false, false, false, true },
                { false, false, true, false, false, false, false, false, false },
                { false, true, false, true, true, false, false, false, false },
                { false, false, true, false, false, false, false, false, false },
                { false, false, false, false, false, true, false, false, false }
            };
            int expectedOutput = 6;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case30()
        {
            bool[,] input = {
                { false, false, false, false, false, false, false, true, false, false }
            };
            int expectedOutput = 1;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case31()
        {
            bool[,] input = {
                { false, false, false, false, false, false, false, false, true, false, false },
                { false, false, false, false, false, false, false, false, false, false, true },
                { false, false, true, true, false, false, false, false, false, false, false },
                { false, false, false, false, false, false, true, false, false, false, false },
                { false, false, true, false, false, false, false, false, false, false, false },
                { false, true, false, false, false, false, false, false, false, false, false }
            };
            int expectedOutput = 5;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case32()
        {
            bool[,] input = {
                { true },
                { true },
                { true }
            };
            int expectedOutput = 1;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case33()
        {
            bool[,] input = {
                { false, false, true, true, false, false, false, true, false },
                { false, false, false, true, true, false, false, false, false },
                { false, false, false, false, false, false, true, false, false },
                { true, false, false, false, false, false, false, false, false },
                { false, false, false, false, true, false, false, false, true },
                { false, true, false, false, false, true, false, false, false },
                { false, true, false, false, false, true, false, true, false },
                { true, false, false, false, false, false, false, false, false },
                { false, true, false, false, true, false, false, false, false }
            };
            int expectedOutput = 5;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case34()
        {
            bool[,] input = {
                { false, false, false, false, true },
                { false, false, false, true, false },
                { true, false, false, false, false },
                { false, false, false, true, false },
                { false, false, true, false, false },
                { false, true, false, false, false },
                { true, false, true, false, false },
                { false, false, false, true, false },
                { false, false, true, true, false },
                { false, false, false, false, true }
            };
            int expectedOutput = 5;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case35()
        {
            bool[,] input = {
                { false, true, false, false, false },
                { true, false, false, false, false },
                { true, false, false, false, false },
                { false, false, false, false, true },
                { false, false, true, false, false },
                { false, true, false, false, true },
                { false, false, false, true, false },
                { true, false, false, true, false },
                { false, false, true, false, false },
                { false, false, false, true, false },
                { false, false, false, true, false }
            };
            int expectedOutput = 5;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case36()
        {
            bool[,] input = {
                { false, true, false },
                { false, true, false },
                { false, false, true },
                { false, false, true },
                { false, true, false },
                { false, true, false },
                { true, false, false },
                { true, false, false },
                { true, false, false },
                { true, true, false },
                { false, true, false },
                { false, false, true }
            };
            int expectedOutput = 3;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case37()
        {
            bool[,] input = {
                { false, true },
                { false, true },
                { false, true },
                { true, false },
                { true, false },
                { true, false }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case38()
        {
            bool[,] input = {
                { false, false, false, false, false, false, false, true },
                { false, false, false, false, true, true, false, false },
                { false, false, false, false, true, false, false, false },
                { false, true, false, false, false, true, false, true },
                { true, false, false, false, false, false, false, true },
                { false, false, true, true, false, false, false, false },
                { false, false, false, false, false, true, false, false },
                { false, false, false, false, false, false, true, false },
                { false, false, false, true, false, false, false, false },
                { false, false, false, true, false, false, false, true }
            };
            int expectedOutput = 5;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case39()
        {
            bool[,] input = {
                { true, false }
            };
            int expectedOutput = 1;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case40()
        {
            bool[,] input = {
                { false, false, true, false, false },
                { true, false, false, false, false },
                { false, true, false, false, false }
            };
            int expectedOutput = 3;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case41()
        {
            bool[,] input = {
                { false, false, false, true, false, true, false, false, false, false, false },
                { false, false, false, false, true, false, false, false, false, false, false },
                { false, false, true, false, false, false, false, false, false, false, false },
                { false, false, false, false, false, true, false, false, true, false, false },
                { false, false, false, false, false, false, false, true, false, false, false }
            };
            int expectedOutput = 4;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case42()
        {
            bool[,] input = {
                { false, false, false, false, false, false, false, false, false, false, true, false },
                { false, true, true, false, false, true, false, false, false, false, false, false },
                { false, true, false, false, false, false, false, false, false, false, false, false },
                { false, false, false, false, false, true, false, false, false, false, false, true },
                { false, false, false, false, false, false, false, false, false, false, false, true },
                { true, false, false, true, false, false, false, false, false, false, false, false },
                { false, false, false, true, false, false, false, false, false, false, false, false },
                { false, false, false, true, false, false, false, false, false, false, false, false },
                { false, false, false, false, true, false, false, false, false, false, false, false }
            };
            int expectedOutput = 5;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case43()
        {
            bool[,] input = {
                { false, false, false, false, false, false, true, false, false },
                { true, false, true, false, false, false, false, false, false },
                { false, false, false, true, false, false, false, false, false },
                { false, true, false, false, false, false, false, false, false },
                { false, false, false, false, true, false, false, false, false },
                { true, false, false, true, false, true, false, false, false },
                { false, false, false, false, false, true, false, true, false },
                { false, false, false, false, false, false, false, false, true },
                { false, true, false, false, false, false, true, false, false },
                { false, true, false, false, false, false, false, false, false },
                { false, false, false, true, false, false, false, false, false }
            };
            int expectedOutput = 7;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case44()
        {
            bool[,] input = {
                { true, false, false, false, false, true, false, false, false, false, true },
                { false, false, false, true, false, false, true, false, false, false, false },
                { false, false, false, false, false, false, true, false, false, false, false },
                { true, false, false, false, false, false, false, false, false, false, false },
                { false, true, false, false, false, false, false, false, false, false, false },
                { false, true, false, false, false, true, false, false, false, false, true },
                { false, false, false, true, true, false, false, false, false, false, false }
            };
            int expectedOutput = 4;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case45()
        {
            bool[,] input = {
                { true, false, false, false },
                { false, false, false, true },
                { false, true, false, false },
                { false, false, false, true },
                { false, false, true, false },
                { false, false, true, true },
                { false, false, true, false },
                { false, false, false, true },
                { false, false, false, true },
                { false, false, true, false }
            };
            int expectedOutput = 4;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case46()
        {
            bool[,] input = {
                { false, false, false, true, false, false },
                { false, false, true, false, false, false },
                { false, false, false, false, true, true },
                { true, false, false, false, false, false },
                { false, false, true, true, false, true },
                { false, false, false, true, false, false },
                { true, false, false, false, false, true },
                { false, false, false, false, true, false }
            };
            int expectedOutput = 4;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case47()
        {
            bool[,] input = {
                { false, false, false, false, false, true, false, false, false, false, false, false },
                { true, false, true, true, false, false, false, false, false, false, true, false }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case48()
        {
            bool[,] input = {
                { false, true },
                { false, true },
                { false, true },
                { true, false },
                { false, true },
                { true, false },
                { false, true },
                { true, false },
                { true, false },
                { true, false },
                { true, false },
                { true, false }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }



        public void Terror0()
        {
            bool[,] input = {
                { true, false, false, false, false, false, false, false, false, false, false, false },
                { false, true, false, false, false, false, false, false, false, false, false, false },
                { false, false, true, false, false, false, false, false, false, false, false, false },
                { false, false, false, true, false, false, false, false, false, false, false, false },
                { false, false, false, false, true, false, false, false, false, false, false, false },
                { false, false, false, false, false, true, false, false, false, false, false, false },
                { false, false, false, false, false, false, true, false, false, false, false, false },
                { false, false, false, false, false, false, false, true, false, false, false, false },
                { false, false, false, false, false, false, false, false, true, false, false, false },
                { false, false, false, false, false, false, false, false, false, true, false, false },
                { false, false, false, false, false, false, false, false, false, false, true, false },
                { false, false, false, false, false, false, false, false, false, false, false, true }
            };
            int expectedOutput = input.GetLength(0);

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }

        public void Terror1()
        {
            bool[,] input = {
                { true,     false,  false,  false },
                { true,     true,   false,  false },
                { true,     false,  true,   false },
                { false,    true,   true,   true },
                { false,    false,  false,  true }
            };
            int expectedOutput = 2;

            bool[,] input1 = {
                {true, false, false, false},
                {false, true, false, false},
                {false, false, true, false},
                {false, false, false, true}
            };
            int expectedOutput1 = 4;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
            Assert.That(Student(input1), Is.EqualTo(expectedOutput1));

        }
    }
}
