﻿using System.Collections.Generic;
using System.Linq;
using Weboo.Examen.Interfaces.Trie;

namespace TrieTester
{
    public class Trie : ITrie
    {
        public Trie()
        {
            Raiz = new NodoTrie('\0');
        }

        public void AgregarPalabra(string palabra)
        {
            var currentNode = Raiz;
            foreach (char c in palabra)
            {
                var nextNode = currentNode[c];
                if (nextNode == null)
                {
                    nextNode = new NodoTrie(c);
                    currentNode.Hijos.Add(nextNode);
                }

                currentNode = nextNode;
            }

            if (!currentNode.FinDePalabra)
                CantidadDePalabras++;
            currentNode.FinDePalabra = true;
        }

        public string MayorPrefijoComun()
        {
            string greatestPrefix = string.Empty;
            var currentNode = Raiz;
            while (currentNode.Hijos?.Count == 1 && !currentNode.FinDePalabra)
            {
                currentNode = currentNode.Hijos[0];
                greatestPrefix += currentNode.Valor;
            }

            return greatestPrefix;
        }

        public IEnumerable<string> PalabrasConPrefijo(string prefijo)
        {
            var node = GetNodePrefix(prefijo);
            if (node == null)
                return Enumerable.Empty<string>();

            return PreOrder(node, prefijo);
        }

        public bool Contiene(string palabra)
        {
            return GetNodePrefix(palabra)?.FinDePalabra ?? false;
        }

        public void Vaciar()
        {
            Raiz.Hijos.Clear();
            CantidadDePalabras = 0;
        }

        public NodoTrie Raiz { get; }

        public int CantidadDePalabras { get; private set; }

        public NodoTrie this[char valor]
        {
            get { return Raiz[valor]; }
        }


        private NodoTrie GetNodePrefix(string prefix)
        {
            var currentNode = Raiz;
            foreach (char c in prefix)
            {
                currentNode = currentNode[c];
                if (currentNode == null)
                    return null;
            }

            return currentNode;
        }

        private static IEnumerable<string> PreOrder(NodoTrie currentNode, string prefix)
        {
            if (currentNode.FinDePalabra)
                yield return prefix;

            foreach (var nextNode in currentNode.Hijos)
            {
                foreach (var word in PreOrder(nextNode, prefix + nextNode.Valor))
                {
                    yield return word;
                }
            }
        }
    }
}
