﻿using Weboo.Assess.Tester;
using Weboo.Examen.Interfaces.Trie;

namespace TrieTester
{
    public abstract class TrieTest : InterfaceTester<ITrie>
    {
        protected override ITrie BuildTarget(object[] args)
        {
            return ReflectionHelper.CreateInstance<ITrie>();
        }

        protected override ITrie BuildBenchmark(object[] args)
        {
            return new Trie();
        }
    }

    public class TrieTest1 : TrieTest
    {
        public void MayorPrefijoComun1()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABC"));
            Perform(t => t.AgregarPalabra("ABD"));

            Check(t => t.MayorPrefijoComun());
        }
    }

    public class TrieTest2 : TrieTest
    {
        public void MayorPrefijoComun2()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABC"));
            Perform(t => t.AgregarPalabra("ABCD"));

            Check(t => t.MayorPrefijoComun());
        }
    }

    public class TrieTest3 : TrieTest
    {
        public void MayorPrefijoComun3()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABG"));
            Perform(t => t.AgregarPalabra("ABCE"));
            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.AgregarPalabra("ABCF"));
            Perform(t => t.AgregarPalabra("ABGE"));

            Check(t => t.MayorPrefijoComun());
        }
    }

    public class TrieTest4 : TrieTest
    {
        public void MayorPrefijoComun4()
        {
            Initialize();

            Check(t => t.MayorPrefijoComun());
        }
    }

    public class TrieTest5 : TrieTest
    {
        public void MayorPrefijoComun5()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("A"));

            Check(t => t.MayorPrefijoComun());
        }
    }

    public class TrieTest6 : TrieTest
    {
        public void MayorPrefijoComun6()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("A"));
            Perform(t => t.AgregarPalabra("B"));

            Check(t => t.MayorPrefijoComun());
        }

    }

    public class TrieTest7 : TrieTest
    {
        public void MayorPrefijoComun7()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("Z"));
            Perform(t => t.AgregarPalabra("ZZZZZZZZZZ"));
            Perform(t => t.AgregarPalabra("ZZZZZ"));

            Check(t => t.MayorPrefijoComun());
        }

    }
    public class TrieTest8 : TrieTest
    {
        public void MayorPrefijoComun8()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABABABABABABA"));
            Perform(t => t.AgregarPalabra("ABABABABABAB"));
            Perform(t => t.AgregarPalabra("ABABABABABA"));
            Perform(t => t.AgregarPalabra("ABABABABAB"));
            Perform(t => t.AgregarPalabra("ABABABABA"));
            Perform(t => t.AgregarPalabra("ABABABAB"));
            Perform(t => t.AgregarPalabra("ABABABA"));
            Perform(t => t.AgregarPalabra("ABABAB"));
            Perform(t => t.AgregarPalabra("ABABA"));
            Perform(t => t.AgregarPalabra("ABAB"));
            Perform(t => t.AgregarPalabra("ABA"));

            Check(t => t.MayorPrefijoComun());
        }

    }
    public class TrieTest9 : TrieTest
    {
        public void MayorPrefijoComun9()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("QWE"));
            Perform(t => t.AgregarPalabra("RTY"));
            Perform(t => t.AgregarPalabra("QWERTY"));

            Check(t => t.MayorPrefijoComun());
        }

    }
    public class TrieTest10 : TrieTest
    {
        public void MayorPrefijoComun10()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("QWE"));
            Perform(t => t.AgregarPalabra("RTY"));
            Perform(t => t.AgregarPalabra("QWERTY"));
            Perform(t => t.AgregarPalabra("R"));
            Perform(t => t.AgregarPalabra("Q"));

            Check(t => t.MayorPrefijoComun());
        }


    }
    public class TrieTest11 : TrieTest
    {
        public void PalabrasConPrefijo1()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABC"));
            Perform(t => t.AgregarPalabra("ABD"));
            Perform(t => t.AgregarPalabra("ABE"));
            Perform(t => t.AgregarPalabra("ABF"));
            Perform(t => t.AgregarPalabra("ABG"));

            CheckSequence(t => t.PalabrasConPrefijo("AB"));
        }

    }
    public class TrieTest12 : TrieTest
    {
        public void PalabrasConPrefijo2()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABC"));
            Perform(t => t.AgregarPalabra("ABD"));
            Perform(t => t.AgregarPalabra("ABE"));
            Perform(t => t.AgregarPalabra("ABF"));
            Perform(t => t.AgregarPalabra("ABG"));

            CheckSequence(t => t.PalabrasConPrefijo("ABF"));
        }

    }
    public class TrieTest13 : TrieTest
    {
        public void PalabrasConPrefijo3()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.AgregarPalabra("ABBG"));
            Perform(t => t.AgregarPalabra("ABDH"));
            Perform(t => t.AgregarPalabra("ABBA"));
            Perform(t => t.AgregarPalabra("ABCE"));
            Perform(t => t.AgregarPalabra("ABCF"));

            CheckSequence(t => t.PalabrasConPrefijo("A"));
        }

    }
    public class TrieTest14 : TrieTest
    {
        public void PalabrasConPrefijo4()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("JKLO"));
            Perform(t => t.AgregarPalabra("ABBG"));
            Perform(t => t.AgregarPalabra("PQOT"));
            Perform(t => t.AgregarPalabra("ABBA"));
            Perform(t => t.AgregarPalabra("ABCE"));
            Perform(t => t.AgregarPalabra("ABCF"));

            CheckSequence(t => t.PalabrasConPrefijo(""));
        }

    }
    public class TrieTest15 : TrieTest
    {
        public void PalabrasConPrefijo5()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.AgregarPalabra("ABBG"));
            Perform(t => t.AgregarPalabra("ABDH"));
            Perform(t => t.AgregarPalabra("ABBA"));
            Perform(t => t.AgregarPalabra("ABCE"));
            Perform(t => t.AgregarPalabra("ABCF"));

            CheckSequence(t => t.PalabrasConPrefijo("FCBA"));
        }

    }
    public class TrieTest16 : TrieTest
    {
        public void PalabrasConPrefijo6()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("AB"));
            Perform(t => t.AgregarPalabra("ABCDEF"));
            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.AgregarPalabra("ABCDE"));
            Perform(t => t.AgregarPalabra("ABC"));
            Perform(t => t.AgregarPalabra("A"));

            CheckSequence(t => t.PalabrasConPrefijo("AB"));
        }

    }
    public class TrieTest17 : TrieTest
    {
        public void PalabrasConPrefijo7()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("AB"));
            Perform(t => t.AgregarPalabra("ABCDEF"));
            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.AgregarPalabra("ABCDE"));
            Perform(t => t.AgregarPalabra("ABC"));
            Perform(t => t.AgregarPalabra("A"));

            CheckSequence(t => t.PalabrasConPrefijo("ABCD"));
        }

    }
    public class TrieTest18 : TrieTest
    {
        public void PalabrasConPrefijo8()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("B"));
            Perform(t => t.AgregarPalabra("AA"));
            Perform(t => t.AgregarPalabra("AAA"));
            Perform(t => t.AgregarPalabra("AAAA"));
            Perform(t => t.AgregarPalabra("AAAAA"));
            Perform(t => t.AgregarPalabra("A"));

            CheckSequence(t => t.PalabrasConPrefijo("BA"));
        }

    }
    public class TrieTest19 : TrieTest
    {
        public void PalabrasConPrefijo9()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("RMA"));
            Perform(t => t.AgregarPalabra("JUV"));
            Perform(t => t.AgregarPalabra("ATM"));
            Perform(t => t.AgregarPalabra("MON"));
            Perform(t => t.AgregarPalabra("BAR"));
            Perform(t => t.AgregarPalabra("BAY"));
            Perform(t => t.AgregarPalabra("LEI"));
            Perform(t => t.AgregarPalabra("DOR"));

            CheckSequence(t => t.PalabrasConPrefijo("BAYERN"));
        }

    }
    public class TrieTest20 : TrieTest
    {
        public void PalabrasConPrefijo10()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("RMA"));
            Perform(t => t.AgregarPalabra("JUV"));
            Perform(t => t.AgregarPalabra("ATM"));
            Perform(t => t.AgregarPalabra("MON"));
            Perform(t => t.AgregarPalabra("BAR"));
            Perform(t => t.AgregarPalabra("BAY"));
            Perform(t => t.AgregarPalabra("LEI"));
            Perform(t => t.AgregarPalabra("DOR"));

            CheckSequence(t => t.PalabrasConPrefijo("CHAMPIONS"));
        }

    }
    public class TrieTest21 : TrieTest
    {
        public void PalabrasConPrefijo11()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("RMA"));
            Perform(t => t.AgregarPalabra("RMADRID"));

            CheckSequence(t => t.PalabrasConPrefijo("RMADRIDFC"));
        }

    }
    public class TrieTest22 : TrieTest
    {
        public void PalabrasConPrefijo12()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("AAAAAA"));

            CheckSequence(t => t.PalabrasConPrefijo("AAA"));
        }


    }
    public class TrieTest23 : TrieTest
    {
        public void Contiene1()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABC"));

            Check(t => t.Contiene("ABC"));
        }

    }
    public class TrieTest24 : TrieTest
    {
        public void Contiene2()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("QWERTY"));
            Perform(t => t.AgregarPalabra("ABC"));
            Perform(t => t.AgregarPalabra("ASDFGH"));
            Perform(t => t.AgregarPalabra("ZXCVBNM"));
            Perform(t => t.AgregarPalabra("POIUY"));

            Check(t => t.Contiene("ABC"));
        }

    }
    public class TrieTest25 : TrieTest
    {
        public void Contiene3()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("AFJ"));
            Perform(t => t.AgregarPalabra("AWDRGYJIL"));
            Perform(t => t.AgregarPalabra("ASDFGH"));
            Perform(t => t.AgregarPalabra("AZSXDCFVGBHNJMK"));
            Perform(t => t.AgregarPalabra("IJKL"));

            Check(t => t.Contiene("ABC"));
        }

    }
    public class TrieTest26 : TrieTest
    {
        public void Contiene4()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("QWERTY"));
            Perform(t => t.AgregarPalabra("ABC"));
            Perform(t => t.AgregarPalabra("ASDFGH"));
            Perform(t => t.AgregarPalabra("ZXCVBNM"));
            Perform(t => t.AgregarPalabra("POIUY"));

            Check(t => t.Contiene("QAAZP"));
        }

    }
    public class TrieTest27 : TrieTest
    {
        public void Contiene5()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("QWERTY"));
            Perform(t => t.AgregarPalabra("ABC"));
            Perform(t => t.AgregarPalabra("ASDFGH"));
            Perform(t => t.AgregarPalabra("ZXCVBNM"));
            Perform(t => t.AgregarPalabra("POIUY"));

            Check(t => t.Contiene("QW"));
        }

    }
    public class TrieTest28 : TrieTest
    {
        public void Contiene6()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("AAAAAA"));
            Perform(t => t.AgregarPalabra("AAA"));
            Perform(t => t.AgregarPalabra("AAAAAAA"));

            Check(t => t.Contiene("AAA"));
        }

    }
    public class TrieTest29 : TrieTest
    {
        public void Contiene7()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("AAAAAA"));
            Perform(t => t.AgregarPalabra("AAA"));
            Perform(t => t.AgregarPalabra("AAAAAAA"));

            Check(t => t.Contiene("AAAA"));
        }

    }
    public class TrieTest30 : TrieTest
    {
        public void Contiene8()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("AAAAAA"));
            Perform(t => t.AgregarPalabra("AAA"));
            Perform(t => t.AgregarPalabra("AAAAAAA"));

            Check(t => t.Contiene("AAAAAAAA"));
        }

    }
    public class TrieTest31 : TrieTest
    {
        public void Contiene9()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.AgregarPalabra("ABC"));
            Perform(t => t.AgregarPalabra("ABCE"));

            Check(t => t.Contiene("ABCT"));
        }

    }
    public class TrieTest32 : TrieTest
    {
        public void Contiene10()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.AgregarPalabra("BLOCK"));
            Perform(t => t.AgregarPalabra("WAR"));
            Perform(t => t.AgregarPalabra("KICK"));

            Check(t => t.Contiene("RAW"));
        }


    }
    public class TrieTest33 : TrieTest
    {
        public void Vaciar1()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.Vaciar());

            Check(t => t.Raiz.Hijos.Count);
        }

    }
    public class TrieTest34 : TrieTest
    {
        public void Vaciar2()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.Vaciar());

            Check(t => t.CantidadDePalabras);
        }

    }
    public class TrieTest35 : TrieTest
    {
        public void Vaciar3()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.Vaciar());

            Check(t => t.Contiene("ABCD"));
        }

    }
    public class TrieTest36 : TrieTest
    {
        public void Vaciar4()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.AgregarPalabra("BJK"));
            Perform(t => t.AgregarPalabra("POP"));
            Perform(t => t.Vaciar());
            Perform(t => t.AgregarPalabra("BJK"));

            Check(t => t.Contiene("BJK"));
        }

    }
    public class TrieTest37 : TrieTest
    {
        public void Vaciar5()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.AgregarPalabra("BJK"));
            Perform(t => t.AgregarPalabra("POP"));
            Perform(t => t.Vaciar());
            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.AgregarPalabra("ABC"));
            Perform(t => t.AgregarPalabra("ABCDE"));

            Check(t => t.MayorPrefijoComun());
        }

    }
    public class TrieTest38 : TrieTest
    {
        public void Vaciar6()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.AgregarPalabra("BJK"));
            Perform(t => t.AgregarPalabra("POP"));
            Perform(t => t.Vaciar());
            Perform(t => t.AgregarPalabra("LOCO"));

            CheckSequence(t => t.PalabrasConPrefijo(""));
        }

    }
    public class TrieTest39 : TrieTest
    {
        public void Vaciar7()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.AgregarPalabra("BJK"));
            Perform(t => t.AgregarPalabra("POP"));
            Perform(t => t.Vaciar());

            Check(t => t['P']);
        }

    }
    public class TrieTest40 : TrieTest
    {
        public void Vaciar8()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.AgregarPalabra("BJK"));
            Perform(t => t.AgregarPalabra("POP"));
            Perform(t => t.Vaciar());
            Perform(t => t.AgregarPalabra("P"));

            Check(t => t['P'].Hijos.Count);
        }

    }
    public class TrieTest41 : TrieTest
    {
        public void Vaciar9()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.AgregarPalabra("BJK"));
            Perform(t => t.AgregarPalabra("POP"));
            Perform(t => t.AgregarPalabra("POLITE"));
            Perform(t => t.AgregarPalabra("POOR"));
            Perform(t => t.Vaciar());
            Perform(t => t.AgregarPalabra("POP"));
            Perform(t => t.AgregarPalabra("P"));

            Check(t => t['P']['O'].Hijos.Count);
        }

    }
    public class TrieTest42 : TrieTest
    {
        public void Vaciar10()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.AgregarPalabra("BJK"));
            Perform(t => t.AgregarPalabra("POP"));
            Perform(t => t.AgregarPalabra("POLITE"));
            Perform(t => t.AgregarPalabra("POOR"));
            Perform(t => t.Vaciar());
            Perform(t => t.AgregarPalabra("POLITENESS"));

            Check(t => t.CantidadDePalabras);
        }

    }
    public class TrieTest43 : TrieTest
    {
        public void Vaciar11()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.AgregarPalabra("BJK"));
            Perform(t => t.AgregarPalabra("POP"));
            Perform(t => t.AgregarPalabra("POLITE"));
            Perform(t => t.AgregarPalabra("POOR"));
            Perform(t => t.Vaciar());

            Check(t => t.Raiz.Hijos.Count);
        }

    }
    public class TrieTest44 : TrieTest
    {
        public void Vaciar12()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.AgregarPalabra("BJK"));
            Perform(t => t.AgregarPalabra("POP"));
            Perform(t => t.AgregarPalabra("POLITE"));
            Perform(t => t.AgregarPalabra("POOR"));
            Perform(t => t.Vaciar());
            Perform(t => t.AgregarPalabra("POP"));
            Perform(t => t.AgregarPalabra("BJK"));

            Check(t => t.Raiz.Hijos[0].Valor);
        }


    }
    public class TrieTest45 : TrieTest
    {
        public void CantidadDePalabras1()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABC"));

            Check(t => t.CantidadDePalabras);
        }

    }
    public class TrieTest46 : TrieTest
    {
        public void CantidadDePalabras2()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABC"));
            Perform(t => t.AgregarPalabra("ABCD"));
            Perform(t => t.AgregarPalabra("ABCDE"));

            Check(t => t.CantidadDePalabras);
        }

    }
    public class TrieTest47 : TrieTest
    {
        public void CantidadDePalabras3()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABC"));
            Perform(t => t.AgregarPalabra("AB"));
            Perform(t => t.AgregarPalabra("A"));

            Check(t => t.CantidadDePalabras);
        }

    }
    public class TrieTest48 : TrieTest
    {
        public void CantidadDePalabras4()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("HOLA"));
            Perform(t => t.AgregarPalabra("HELLO"));
            Perform(t => t.AgregarPalabra("ALOHA"));
            Perform(t => t.AgregarPalabra("HALLO"));

            Check(t => t.CantidadDePalabras);
        }

    }
    public class TrieTest49 : TrieTest
    {
        public void CantidadDePalabras5()
        {
            Initialize();

            Check(t => t.CantidadDePalabras);
        }


    }
    public class TrieTest50 : TrieTest
    {
        public void Indexer1()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABC"));

            Check(t => t['A'].Hijos.Count);
        }

    }
    public class TrieTest51 : TrieTest
    {
        public void Indexer2()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABC"));

            Check(t => t['A']['B'].Hijos.Count);
        }

    }
    public class TrieTest52 : TrieTest
    {
        public void Indexer3()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABC"));

            Check(t => t['A']['B']['C'].Hijos.Count);
        }

    }
    public class TrieTest53 : TrieTest
    {
        public void Indexer4()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABC"));

            Check(t => t['A']['B']['C'].FinDePalabra);
        }

    }
    public class TrieTest54 : TrieTest
    {
        public void Indexer5()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABC"));

            Check(t => t['A'].FinDePalabra);
        }

    }
    public class TrieTest55 : TrieTest
    {
        public void Indexer6()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABC"));

            Check(t => t['A']['B'].Valor);
        }

    }
    public class TrieTest56 : TrieTest
    {
        public void Indexer7()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABC"));
            Perform(t => t.AgregarPalabra("ZYX"));

            Check(t => t['X']);
        }

    }
    public class TrieTest57 : TrieTest
    {
        public void Indexer8()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABC"));
            Perform(t => t.AgregarPalabra("ZYX"));

            Check(t => t['Z'].Valor);
        }

    }
    public class TrieTest58 : TrieTest
    {
        public void Indexer9()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABC"));
            Perform(t => t.AgregarPalabra("ZYX"));
            Perform(t => t.AgregarPalabra("ABCDE"));

            Check(t => t['A'].Hijos.Count);
        }

    }
    public class TrieTest59 : TrieTest
    {
        public void Indexer10()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("ABC"));
            Perform(t => t.AgregarPalabra("ABCDE"));
            Perform(t => t.AgregarPalabra("ZYX"));
            Perform(t => t.AgregarPalabra("ABCRT"));

            Check(t => t['A']['B']['C'].Hijos.Count);
        }

    }
    public class TrieTest60 : TrieTest
    {
        public void Indexer11()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("PRO"));
            Perform(t => t.AgregarPalabra("ABCDE"));
            Perform(t => t.AgregarPalabra("WRONG"));
            Perform(t => t.AgregarPalabra("BALD"));
            Perform(t => t.AgregarPalabra("ABCRT"));

            Check(t => t.Raiz.Hijos.Count);
        }

    }
    public class TrieTest61 : TrieTest
    {
        public void Indexer12()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("PRO"));
            Perform(t => t.AgregarPalabra("ABCDE"));
            Perform(t => t.AgregarPalabra("WRONG"));
            Perform(t => t.AgregarPalabra("BLIND"));
            Perform(t => t.AgregarPalabra("ABCRT"));
            Perform(t => t.AgregarPalabra("BALD"));

            Check(t => t.Raiz.Hijos[2].Hijos.Count);
        }

    }
    public class TrieTest62 : TrieTest
    {
        public void Indexer13()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("PRO"));
            Perform(t => t.AgregarPalabra("ABCDE"));
            Perform(t => t.AgregarPalabra("WRONG"));
            Perform(t => t.AgregarPalabra("BLIND"));
            Perform(t => t.AgregarPalabra("ABCRT"));
            Perform(t => t.AgregarPalabra("BALD"));

            Check(t => t.Raiz.Hijos[3].Hijos[0].Valor);
        }

    }
    public class TrieTest63 : TrieTest
    {
        public void Indexer14()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("AAAAAA"));
            Perform(t => t.AgregarPalabra("AAAA"));
            Perform(t => t.AgregarPalabra("AA"));

            Check(t => t.Raiz.Hijos.Count);
        }

    }
    public class TrieTest64 : TrieTest
    {
        public void Indexer15()
        {
            Initialize();

            Perform(t => t.AgregarPalabra("PARK"));
            Perform(t => t.AgregarPalabra("PARKING"));

            Check(t => t.Raiz['P']['A']['R']['K']['Y']);
        }
    }
}
