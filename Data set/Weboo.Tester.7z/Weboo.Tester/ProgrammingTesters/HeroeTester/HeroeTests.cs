﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Assess.Tester;

namespace HeroeTester
{
    internal abstract class HeroeTest
    {
        public static IEnumerable<Tuple<int, int>> Student(int[,] bonificaciones)
        {
            return ReflectionHelper.InvokeStatic<IEnumerable<Tuple<int, int>>>("Weboo.Examen.Heroe", "Resuelve", bonificaciones);
        }

        public static int? Check(int[,] bonificaciones, IEnumerable<Tuple<int, int>> solution)
        {
            var acc = new int[3];
            int i = 0;
            foreach (var v in solution)
            {
                acc[v.Item1] += bonificaciones[i, v.Item1];
                acc[v.Item2] += bonificaciones[i, v.Item2];
                i++;
            }
            if (acc[0] == acc[1] && acc[1] == acc[2])
                return acc[0];
            return null;
        }
    }

    #region A fews optimizations (Easy) - Max Size 10

    //public class Test1 : TestCase
    //{
    //    public void Case1()
    //    {
    //        int[,] input = {
    //            { 34, 85, 1 },
    //            { 93, 14, 39 },
    //            { 33, 33, 75 },
    //            { 77, 33, 25 },
    //            { 52, 40, 69 },
    //            { 78, 86, 76 },
    //            { 42, 37, 8 },
    //            { 47, 4, 30 }
    //        };

    //        Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
    //    }
    //}


    //public class Test2 : TestCase
    //{
    //    public void Case2()
    //    {
    //        int[,] input = {
    //            { 28, 90, 64 },
    //            { 62, 37, 42 },
    //            { 23, 23, 3 },
    //            { 0, 47, 100 },
    //            { 58, 75, 63 },
    //            { 65, 24, 57 }
    //        };

    //        Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
    //    }
    //}


    //public class Test3 : TestCase
    //{
    //    public void Case3()
    //    {
    //        int[,] input = {
    //            { 6, 42, 44 },
    //            { 5, 30, 94 },
    //            { 79, 20, 10 },
    //            { 17, 47, 51 },
    //            { 4, 89, 46 },
    //            { 71, 37, 55 },
    //            { 20, 42, 60 }
    //        };

    //        Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
    //    }
    //}


    //public class Test4 : TestCase
    //{
    //    public void Case4()
    //    {
    //        int[,] input = {
    //            { 63, 69, 83 },
    //            { 28, 27, 71 },
    //            { 56, 99, 43 },
    //            { 34, 63, 26 },
    //            { 40, 53, 35 },
    //            { 45, 87, 94 },
    //            { 66, 26, 35 },
    //            { 84, 33, 75 }
    //        };

    //        int? expectedOutput = 310;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test5 : TestCase
    //{
    //    public void Case5()
    //    {
    //        int[,] input = {
    //            { 18, 77, 15 },
    //            { 0, 2, 27 },
    //            { 0, 45, 25 },
    //            { 49, 42, 99 },
    //            { 41, 87, 5 },
    //            { 29, 59, 15 },
    //            { 91, 34, 48 },
    //            { 90, 64, 84 },
    //            { 71, 6, 89 },
    //            { 98, 85, 56 }
    //        };

    //        int? expectedOutput = 368;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test6 : TestCase
    //{
    //    public void Case6()
    //    {
    //        int[,] input = {
    //            { 43, 90, 43 },
    //            { 100, 78, 46 },
    //            { 29, 85, 90 },
    //            { 17, 85, 12 }
    //        };

    //        Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
    //    }
    //}


    //public class Test7 : TestCase
    //{
    //    public void Case7()
    //    {
    //        int[,] input = {
    //            { 68, 50, 65 },
    //            { 92, 81, 86 },
    //            { 67, 86, 73 },
    //            { 95, 31, 32 },
    //            { 70, 19, 100 },
    //            { 60, 55, 100 },
    //            { 98, 93, 83 },
    //            { 99, 33, 83 },
    //            { 68, 70, 49 },
    //            { 31, 12, 50 }
    //        };

    //        Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
    //    }
    //}


    //public class Test8 : TestCase
    //{
    //    public void Case8()
    //    {
    //        int[,] input = {
    //            { 35, 5, 69 },
    //            { 70, 14, 61 },
    //            { 67, 27, 26 }
    //        };

    //        Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
    //    }
    //}


    //public class Test9 : TestCase
    //{
    //    public void Case9()
    //    {
    //        int[,] input = {
    //            { 61, 48, 21 },
    //            { 91, 85, 99 },
    //            { 92, 0, 46 },
    //            { 87, 17, 88 }
    //        };

    //        Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
    //    }
    //}


    //public class Test10 : TestCase
    //{
    //    public void Case10()
    //    {
    //        int[,] input = {
    //            { 45, 31, 2 },
    //            { 12, 60, 38 },
    //            { 79, 37, 64 },
    //            { 35, 57, 75 },
    //            { 62, 66, 3 },
    //            { 34, 4, 10 },
    //            { 93, 63, 80 },
    //            { 97, 87, 3 }
    //        };

    //        Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
    //    }
    //}


    //public class Test11 : TestCase
    //{
    //    public void Case11()
    //    {
    //        int[,] input = {
    //            { 71, 63, 40 },
    //            { 6, 34, 49 },
    //            { 10, 33, 46 },
    //            { 58, 58, 54 },
    //            { 15, 72, 42 },
    //            { 52, 3, 0 }
    //        };

    //        Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
    //    }
    //}


    //public class Test12 : TestCase
    //{
    //    public void Case12()
    //    {
    //        int[,] input = {
    //            { 21, 72, 100 },
    //            { 13, 83, 100 }
    //        };

    //        Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
    //    }
    //}


    //public class Test13 : TestCase
    //{
    //    public void Case13()
    //    {
    //        int[,] input = {
    //            { 12, 100, 37 },
    //            { 2, 51, 33 },
    //            { 98, 20, 86 },
    //            { 59, 37, 31 },
    //            { 31, 89, 20 },
    //            { 95, 30, 19 }
    //        };

    //        Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
    //    }
    //}


    //public class Test14 : TestCase
    //{
    //    public void Case14()
    //    {
    //        int[,] input = {
    //            { 73, 52, 48 },
    //            { 0, 39, 21 },
    //            { 21, 98, 94 },
    //            { 14, 87, 82 },
    //            { 70, 100, 25 },
    //            { 6, 99, 53 },
    //            { 59, 8, 60 },
    //            { 55, 29, 56 },
    //            { 31, 75, 23 },
    //            { 67, 94, 65 }
    //        };

    //        Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
    //    }
    //}


    //public class Test15 : TestCase
    //{
    //    public void Case15()
    //    {
    //        int[,] input = {
    //            { 59, 64, 20 },
    //            { 98, 87, 45 },
    //            { 85, 24, 65 }
    //        };

    //        Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
    //    }
    //}


    //public class Test16 : TestCase
    //{
    //    public void Case16()
    //    {
    //        int[,] input = {
    //            { 5, 55, 37 },
    //            { 64, 33, 55 },
    //            { 93, 19, 92 },
    //            { 77, 22, 17 },
    //            { 43, 11, 9 },
    //            { 5, 88, 74 },
    //            { 68, 54, 5 },
    //            { 83, 50, 40 }
    //        };

    //        Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
    //    }
    //}


    //public class Test17 : TestCase
    //{
    //    public void Case17()
    //    {
    //        int[,] input = {
    //            { 43, 18, 75 },
    //            { 10, 2, 57 },
    //            { 92, 54, 13 },
    //            { 88, 13, 82 },
    //            { 76, 24, 90 }
    //        };

    //        Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
    //    }
    //}


    //public class Test18 : TestCase
    //{
    //    public void Case18()
    //    {
    //        int[,] input = {
    //            { 77, 89, 23 },
    //            { 51, 18, 7 },
    //            { 19, 39, 90 },
    //            { 26, 0, 80 },
    //            { 11, 6, 0 }
    //        };

    //        Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
    //    }
    //}


    //public class Test19 : TestCase
    //{
    //    public void Case19()
    //    {
    //        int[,] input = {
    //            { 44, 77, 67 },
    //            { 49, 17, 38 },
    //            { 31, 46, 78 },
    //            { 42, 93, 48 },
    //            { 59, 6, 33 },
    //            { 11, 43, 31 },
    //            { 30, 13, 77 },
    //            { 31, 83, 100 },
    //            { 71, 8, 100 },
    //            { 32, 20, 86 }
    //        };

    //        int? expectedOutput = 327;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test20 : TestCase
    //{
    //    public void Case20()
    //    {
    //        int[,] input = {
    //            { 6, 1, 94 },
    //            { 15, 60, 58 },
    //            { 65, 6, 34 },
    //            { 89, 15, 6 },
    //            { 73, 29, 27 },
    //            { 91, 29, 70 },
    //            { 91, 94, 79 },
    //            { 74, 18, 56 },
    //            { 83, 43, 48 }
    //        };

    //        int? expectedOutput = 266;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test21 : TestCase
    //{
    //    public void Case21()
    //    {
    //        int[,] input = {
    //            { 34, 68, 7 },
    //            { 37, 83, 50 },
    //            { 51, 24, 28 },
    //            { 22, 1, 77 },
    //            { 43, 65, 87 },
    //            { 31, 19, 14 },
    //            { 19, 20, 41 },
    //            { 45, 34, 27 },
    //            { 78, 72, 60 }
    //        };

    //        int? expectedOutput = 270;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test22 : TestCase
    //{
    //    public void Case22()
    //    {
    //        int[,] input = {
    //            { 32, 9, 92 },
    //            { 38, 22, 16 },
    //            { 94, 72, 28 },
    //            { 33, 55, 87 },
    //            { 75, 49, 24 },
    //            { 19, 34, 68 },
    //            { 18, 32, 47 },
    //            { 38, 34, 48 },
    //            { 1, 23, 66 },
    //            { 75, 20, 97 }
    //        };

    //        int? expectedOutput = 278;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test23 : TestCase
    //{
    //    public void Case23()
    //    {
    //        int[,] input = {
    //            { 3, 34, 5 },
    //            { 17, 1, 74 },
    //            { 74, 88, 40 },
    //            { 7, 91, 78 },
    //            { 64, 54, 25 },
    //            { 86, 54, 50 },
    //            { 37, 78, 0 }
    //        };

    //        int? expectedOutput = 197;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test24 : TestCase
    //{
    //    public void Case24()
    //    {
    //        int[,] input = {
    //            { 71, 81, 8 },
    //            { 10, 78, 86 },
    //            { 18, 87, 85 },
    //            { 57, 85, 3 },
    //            { 11, 79, 26 },
    //            { 39, 73, 36 },
    //            { 48, 97, 30 },
    //            { 38, 30, 89 },
    //            { 47, 81, 75 },
    //            { 38, 76, 42 }
    //        };

    //        int? expectedOutput = 339;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test25 : TestCase
    //{
    //    public void Case25()
    //    {
    //        int[,] input = {
    //            { 66, 47, 12 },
    //            { 59, 11, 22 },
    //            { 0, 52, 46 },
    //            { 3, 59, 51 },
    //            { 12, 74, 18 },
    //            { 21, 56, 13 },
    //            { 10, 59, 82 },
    //            { 82, 3, 81 },
    //            { 81, 65, 50 },
    //            { 23, 39, 42 }
    //        };

    //        int? expectedOutput = 295;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test26 : TestCase
    //{
    //    public void Case26()
    //    {
    //        int[,] input = {
    //            { 73, 43, 30 },
    //            { 32, 9, 15 },
    //            { 28, 28, 53 },
    //            { 67, 94, 84 },
    //            { 68, 28, 9 },
    //            { 66, 89, 27 },
    //            { 88, 73, 71 },
    //            { 15, 51, 57 },
    //            { 40, 54, 12 },
    //            { 34, 49, 13 }
    //        };

    //        int? expectedOutput = 305;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test27 : TestCase
    //{
    //    public void Case27()
    //    {
    //        int[,] input = {
    //            { 66, 18, 38 },
    //            { 87, 47, 60 },
    //            { 48, 89, 11 },
    //            { 90, 43, 6 },
    //            { 35, 82, 84 },
    //            { 11, 80, 19 },
    //            { 37, 56, 50 },
    //            { 36, 10, 27 }
    //        };

    //        int? expectedOutput = 235;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test28 : TestCase
    //{
    //    public void Case28()
    //    {
    //        int[,] input = {
    //            { 62, 92, 74 },
    //            { 15, 28, 4 },
    //            { 53, 64, 11 },
    //            { 59, 75, 49 },
    //            { 70, 62, 43 },
    //            { 8, 83, 27 },
    //            { 77, 96, 43 },
    //            { 50, 71, 26 },
    //            { 27, 1, 68 },
    //            { 23, 48, 60 }
    //        };

    //        int? expectedOutput = 327;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test29 : TestCase
    //{
    //    public void Case29()
    //    {
    //        int[,] input = {
    //            { 96, 4, 10 },
    //            { 52, 96, 48 },
    //            { 89, 15, 100 },
    //            { 7, 51, 22 },
    //            { 65, 79, 22 },
    //            { 38, 2, 60 },
    //            { 72, 22, 59 },
    //            { 90, 65, 99 },
    //            { 11, 26, 41 }
    //        };

    //        int? expectedOutput = 303;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test30 : TestCase
    //{
    //    public void Case30()
    //    {
    //        int[,] input = {
    //            { 18, 65, 99 },
    //            { 56, 54, 0 },
    //            { 39, 22, 45 },
    //            { 31, 9, 85 },
    //            { 74, 7, 88 },
    //            { 16, 65, 77 },
    //            { 58, 85, 31 },
    //            { 99, 14, 48 },
    //            { 41, 93, 6 },
    //            { 39, 0, 80 }
    //        };

    //        int? expectedOutput = 338;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test31 : TestCase
    //{
    //    public void Case31()
    //    {
    //        int[,] input = {
    //            { 90, 3, 35 },
    //            { 49, 10, 4 },
    //            { 63, 59, 49 },
    //            { 16, 55, 51 },
    //            { 28, 35, 27 },
    //            { 67, 76, 94 },
    //            { 40, 19, 46 },
    //            { 88, 67, 34 },
    //            { 14, 32, 56 },
    //            { 30, 84, 43 }
    //        };

    //        int? expectedOutput = 299;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test32 : TestCase
    //{
    //    public void Case32()
    //    {
    //        int[,] input = {
    //            { 95, 59, 89 },
    //            { 36, 48, 24 },
    //            { 19, 4, 57 },
    //            { 56, 77, 46 },
    //            { 13, 80, 16 },
    //            { 20, 88, 69 },
    //            { 62, 44, 14 },
    //            { 34, 68, 6 },
    //            { 18, 20, 2 },
    //            { 12, 37, 46 }
    //        };

    //        int? expectedOutput = 256;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test33 : TestCase
    //{
    //    public void Case33()
    //    {
    //        int[,] input = {
    //            { 65, 51, 49 },
    //            { 43, 24, 62 },
    //            { 43, 73, 18 },
    //            { 95, 44, 19 },
    //            { 40, 0, 7 },
    //            { 22, 14, 88 },
    //            { 61, 18, 68 },
    //            { 88, 27, 75 },
    //            { 9, 12, 55 }
    //        };

    //        int? expectedOutput = 236;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test34 : TestCase
    //{
    //    public void Case34()
    //    {
    //        int[,] input = {
    //            { 52, 26, 61 },
    //            { 30, 87, 1 },
    //            { 6, 65, 11 },
    //            { 72, 30, 47 },
    //            { 59, 100, 7 },
    //            { 16, 35, 0 },
    //            { 7, 20, 93 },
    //            { 10, 75, 94 },
    //            { 89, 14, 87 }
    //        };

    //        int? expectedOutput = 266;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test35 : TestCase
    //{
    //    public void Case35()
    //    {
    //        int[,] input = {
    //            { 46, 19, 61 },
    //            { 81, 19, 75 },
    //            { 19, 97, 3 },
    //            { 47, 75, 47 },
    //            { 13, 65, 77 },
    //            { 10, 1, 5 },
    //            { 0, 35, 46 },
    //            { 81, 59, 94 }
    //        };

    //        int? expectedOutput = 250;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test36 : TestCase
    //{
    //    public void Case36()
    //    {
    //        int[,] input = {
    //            { 56, 2, 81 },
    //            { 18, 85, 10 },
    //            { 74, 34, 73 },
    //            { 23, 84, 21 },
    //            { 32, 58, 70 },
    //            { 58, 95, 57 },
    //            { 14, 26, 75 },
    //            { 99, 11, 68 },
    //            { 31, 50, 84 },
    //            { 95, 72, 15 }
    //        };

    //        int? expectedOutput = 325;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test37 : TestCase
    //{
    //    public void Case37()
    //    {
    //        int[,] input = {
    //            { 84, 28, 32 },
    //            { 8, 25, 26 },
    //            { 46, 74, 95 },
    //            { 80, 26, 37 },
    //            { 56, 54, 2 },
    //            { 71, 39, 41 },
    //            { 36, 54, 94 },
    //            { 26, 58, 57 },
    //            { 3, 55, 73 },
    //            { 43, 58, 72 }
    //        };

    //        int? expectedOutput = 371;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test38 : TestCase
    //{
    //    public void Case38()
    //    {
    //        int[,] input = {
    //            { 60, 9, 21 },
    //            { 27, 23, 30 },
    //            { 55, 67, 74 },
    //            { 23, 50, 21 },
    //            { 74, 89, 76 },
    //            { 37, 61, 47 },
    //            { 31, 35, 13 },
    //            { 88, 37, 11 }
    //        };

    //        int? expectedOutput = 221;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test39 : TestCase
    //{
    //    public void Case39()
    //    {
    //        int[,] input = {
    //            { 99, 4, 86 },
    //            { 5, 62, 19 },
    //            { 32, 80, 86 },
    //            { 49, 32, 52 },
    //            { 20, 98, 12 },
    //            { 60, 57, 28 },
    //            { 36, 45, 57 },
    //            { 32, 65, 46 },
    //            { 49, 63, 99 },
    //            { 1, 24, 24 }
    //        };

    //        int? expectedOutput = 248;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test40 : TestCase
    //{
    //    public void Case40()
    //    {
    //        int[,] input = {
    //            { 22, 81, 87 },
    //            { 30, 6, 60 },
    //            { 72, 20, 37 },
    //            { 1, 14, 7 },
    //            { 67, 87, 22 },
    //            { 69, 35, 47 },
    //            { 5, 51, 93 },
    //            { 47, 8, 20 },
    //            { 50, 94, 99 }
    //        };

    //        int? expectedOutput = 289;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test41 : TestCase
    //{
    //    public void Case41()
    //    {
    //        int[,] input = {
    //            { 47, 18, 100 },
    //            { 72, 49, 86 },
    //            { 92, 46, 48 },
    //            { 90, 15, 60 },
    //            { 89, 98, 34 },
    //            { 3, 13, 99 },
    //            { 89, 75, 55 },
    //            { 52, 7, 24 },
    //            { 77, 63, 1 },
    //            { 34, 50, 69 }
    //        };

    //        int? expectedOutput = 358;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test42 : TestCase
    //{
    //    public void Case42()
    //    {
    //        int[,] input = {
    //            { 50, 19, 56 },
    //            { 79, 12, 36 },
    //            { 27, 77, 91 },
    //            { 93, 76, 43 },
    //            { 14, 61, 4 },
    //            { 2, 4, 88 },
    //            { 7, 83, 66 },
    //            { 100, 80, 49 },
    //            { 42, 18, 81 }
    //        };

    //        int? expectedOutput = 341;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test43 : TestCase
    //{
    //    public void Case43()
    //    {
    //        int[,] input = {
    //            { 27, 83, 49 },
    //            { 10, 43, 66 },
    //            { 59, 25, 72 },
    //            { 47, 16, 57 },
    //            { 0, 61, 35 },
    //            { 100, 99, 46 },
    //            { 30, 98, 2 },
    //            { 30, 97, 23 },
    //            { 21, 62, 65 },
    //            { 54, 44, 80 }
    //        };

    //        int? expectedOutput = 304;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test44 : TestCase
    //{
    //    public void Case44()
    //    {
    //        int[,] input = {
    //            { 61, 86, 25 },
    //            { 54, 78, 59 },
    //            { 21, 35, 90 },
    //            { 83, 0, 72 },
    //            { 71, 98, 92 },
    //            { 12, 40, 33 },
    //            { 81, 29, 24 },
    //            { 81, 36, 66 },
    //            { 1, 31, 95 }
    //        };

    //        int? expectedOutput = 373;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test45 : TestCase
    //{
    //    public void Case45()
    //    {
    //        int[,] input = {
    //            { 13, 52, 75 },
    //            { 51, 89, 37 },
    //            { 78, 98, 48 },
    //            { 23, 32, 13 },
    //            { 100, 29, 38 },
    //            { 58, 69, 26 },
    //            { 45, 6, 55 },
    //            { 53, 10, 32 },
    //            { 66, 20, 74 },
    //            { 29, 58, 70 }
    //        };

    //        int? expectedOutput = 335;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test46 : TestCase
    //{
    //    public void Case46()
    //    {
    //        int[,] input = {
    //            { 77, 42, 42 },
    //            { 56, 85, 61 },
    //            { 98, 17, 59 },
    //            { 14, 55, 88 },
    //            { 45, 54, 79 },
    //            { 47, 77, 32 },
    //            { 100, 65, 94 },
    //            { 46, 100, 26 },
    //            { 19, 69, 8 },
    //            { 27, 71, 3 }
    //        };

    //        int? expectedOutput = 337;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test47 : TestCase
    //{
    //    public void Case47()
    //    {
    //        int[,] input = {
    //            { 80, 54, 84 },
    //            { 99, 8, 34 },
    //            { 0, 20, 35 },
    //            { 6, 7, 36 },
    //            { 43, 11, 85 },
    //            { 13, 67, 13 },
    //            { 28, 63, 36 },
    //            { 83, 34, 93 }
    //        };

    //        int? expectedOutput = 253;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test48 : TestCase
    //{
    //    public void Case48()
    //    {
    //        int[,] input = {
    //            { 97, 95, 9 },
    //            { 95, 84, 71 },
    //            { 54, 100, 22 },
    //            { 29, 100, 93 },
    //            { 77, 28, 68 },
    //            { 83, 22, 10 },
    //            { 3, 99, 72 },
    //            { 33, 9, 21 },
    //            { 33, 13, 28 },
    //            { 51, 11, 41 }
    //        };

    //        int? expectedOutput = 334;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test49 : TestCase
    //{
    //    public void Case49()
    //    {
    //        int[,] input = {
    //            { 48, 76, 68 },
    //            { 31, 20, 52 },
    //            { 51, 52, 65 },
    //            { 50, 8, 7 },
    //            { 51, 33, 74 },
    //            { 3, 54, 70 },
    //            { 40, 43, 33 }
    //        };

    //        int? expectedOutput = 223;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test50 : TestCase
    //{
    //    public void Case50()
    //    {
    //        int[,] input = {
    //            { 16, 92, 18 },
    //            { 58, 73, 2 },
    //            { 67, 34, 25 },
    //            { 56, 49, 76 },
    //            { 18, 80, 97 },
    //            { 37, 87, 24 },
    //            { 54, 64, 59 },
    //            { 37, 15, 47 },
    //            { 48, 97, 42 },
    //            { 96, 50, 2 }
    //        };

    //        int? expectedOutput = 348;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test51 : TestCase
    //{
    //    public void Case51()
    //    {
    //        int[,] input = {
    //            { 3, 94, 64 },
    //            { 3, 53, 90 },
    //            { 4, 37, 38 },
    //            { 63, 9, 61 },
    //            { 57, 52, 23 },
    //            { 54, 31, 96 },
    //            { 18, 61, 17 },
    //            { 13, 64, 57 },
    //            { 0, 70, 69 },
    //            { 51, 28, 1 }
    //        };

    //        int? expectedOutput = 263;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test52 : TestCase
    //{
    //    public void Case52()
    //    {
    //        int[,] input = {
    //            { 40, 12, 7 },
    //            { 76, 57, 54 },
    //            { 40, 99, 57 },
    //            { 64, 67, 48 },
    //            { 61, 83, 63 },
    //            { 25, 18, 79 },
    //            { 92, 62, 22 },
    //            { 19, 76, 15 },
    //            { 94, 64, 69 }
    //        };

    //        int? expectedOutput = 345;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test53 : TestCase
    //{
    //    public void Case53()
    //    {
    //        int[,] input = {
    //            { 41, 42, 45 },
    //            { 66, 58, 36 },
    //            { 51, 86, 0 },
    //            { 65, 17, 34 },
    //            { 89, 74, 11 },
    //            { 14, 84, 70 },
    //            { 90, 81, 81 },
    //            { 9, 5, 31 },
    //            { 70, 5, 38 },
    //            { 75, 43, 3 }
    //        };

    //        int? expectedOutput = 346;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test54 : TestCase
    //{
    //    public void Case54()
    //    {
    //        int[,] input = {
    //            { 89, 69, 22 },
    //            { 79, 71, 76 },
    //            { 86, 98, 39 },
    //            { 1, 19, 67 },
    //            { 53, 3, 49 },
    //            { 16, 60, 89 },
    //            { 6, 14, 20 },
    //            { 91, 26, 79 },
    //            { 32, 93, 23 },
    //            { 74, 85, 10 }
    //        };

    //        int? expectedOutput = 419;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test55 : TestCase
    //{
    //    public void Case55()
    //    {
    //        int[,] input = {
    //            { 26, 71, 73 },
    //            { 59, 56, 84 },
    //            { 22, 3, 25 },
    //            { 90, 14, 74 },
    //            { 50, 25, 23 },
    //            { 70, 91, 70 },
    //            { 92, 58, 69 },
    //            { 21, 88, 48 }
    //        };

    //        int? expectedOutput = 301;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test56 : TestCase
    //{
    //    public void Case56()
    //    {
    //        int[,] input = {
    //            { 93, 36, 33 },
    //            { 48, 94, 88 },
    //            { 82, 43, 74 },
    //            { 73, 18, 40 },
    //            { 57, 92, 46 },
    //            { 67, 68, 89 },
    //            { 4, 17, 13 },
    //            { 51, 36, 18 },
    //            { 6, 62, 91 }
    //        };

    //        int? expectedOutput = 351;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test57 : TestCase
    //{
    //    public void Case57()
    //    {
    //        int[,] input = {
    //            { 27, 48, 98 },
    //            { 98, 76, 1 },
    //            { 99, 19, 76 },
    //            { 75, 28, 98 },
    //            { 79, 19, 57 },
    //            { 16, 71, 4 },
    //            { 27, 28, 46 },
    //            { 47, 70, 80 },
    //            { 99, 41, 66 },
    //            { 53, 80, 15 }
    //        };

    //        int? expectedOutput = 362;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test58 : TestCase
    //{
    //    public void Case58()
    //    {
    //        int[,] input = {
    //            { 82, 98, 57 },
    //            { 89, 2, 82 },
    //            { 11, 9, 57 },
    //            { 36, 6, 46 },
    //            { 40, 44, 32 },
    //            { 71, 4, 16 },
    //            { 6, 46, 42 },
    //            { 45, 3, 64 },
    //            { 23, 91, 23 }
    //        };

    //        int? expectedOutput = 210;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test59 : TestCase
    //{
    //    public void Case59()
    //    {
    //        int[,] input = {
    //            { 85, 40, 27 },
    //            { 16, 98, 29 },
    //            { 14, 57, 3 },
    //            { 20, 50, 54 },
    //            { 64, 44, 27 },
    //            { 18, 100, 25 },
    //            { 29, 67, 95 },
    //            { 70, 27, 27 },
    //            { 7, 96, 35 },
    //            { 50, 6, 53 }
    //        };

    //        int? expectedOutput = 291;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test60 : TestCase
    //{
    //    public void Case60()
    //    {
    //        int[,] input = {
    //            { 74, 29, 6 },
    //            { 46, 2, 99 },
    //            { 37, 76, 10 },
    //            { 13, 55, 71 },
    //            { 44, 83, 27 },
    //            { 32, 0, 19 },
    //            { 28, 3, 84 },
    //            { 52, 33, 3 },
    //            { 59, 55, 19 },
    //            { 38, 12, 58 }
    //        };

    //        int? expectedOutput = 269;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test61 : TestCase
    //{
    //    public void Case61()
    //    {
    //        int[,] input = {
    //            { 3, 94, 32 },
    //            { 86, 10, 27 },
    //            { 82, 16, 52 },
    //            { 68, 2, 68 },
    //            { 86, 16, 1 },
    //            { 10, 16, 50 },
    //            { 83, 63, 23 },
    //            { 74, 34, 62 },
    //            { 72, 34, 11 }
    //        };

    //        int? expectedOutput = 235;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test62 : TestCase
    //{
    //    public void Case62()
    //    {
    //        int[,] input = {
    //            { 62, 28, 69 },
    //            { 11, 12, 80 },
    //            { 98, 61, 44 },
    //            { 60, 55, 17 },
    //            { 97, 95, 63 },
    //            { 31, 95, 38 },
    //            { 48, 2, 3 },
    //            { 46, 28, 29 },
    //            { 33, 15, 34 },
    //            { 25, 99, 51 }
    //        };

    //        int? expectedOutput = 322;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test63 : TestCase
    //{
    //    public void Case63()
    //    {
    //        int[,] input = {
    //            { 75, 75, 22 },
    //            { 12, 33, 13 },
    //            { 8, 18, 40 },
    //            { 49, 95, 35 },
    //            { 59, 90, 7 },
    //            { 73, 30, 82 },
    //            { 66, 1, 14 },
    //            { 91, 30, 58 },
    //            { 15, 50, 76 },
    //            { 16, 87, 75 }
    //        };

    //        int? expectedOutput = 276;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test64 : TestCase
    //{
    //    public void Case64()
    //    {
    //        int[,] input = {
    //            { 62, 70, 49 },
    //            { 47, 64, 74 },
    //            { 47, 55, 50 },
    //            { 65, 20, 1 },
    //            { 98, 36, 38 },
    //            { 61, 40, 23 },
    //            { 63, 1, 13 },
    //            { 61, 62, 84 }
    //        };

    //        int? expectedOutput = 257;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test65 : TestCase
    //{
    //    public void Case65()
    //    {
    //        int[,] input = {
    //            { 63, 10, 16 },
    //            { 100, 99, 78 },
    //            { 49, 39, 49 },
    //            { 48, 74, 35 },
    //            { 94, 59, 27 },
    //            { 20, 12, 7 },
    //            { 20, 25, 93 },
    //            { 98, 37, 75 },
    //            { 1, 17, 35 }
    //        };

    //        int? expectedOutput = 298;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test66 : TestCase
    //{
    //    public void Case66()
    //    {
    //        int[,] input = {
    //            { 36, 74, 30 },
    //            { 60, 28, 83 },
    //            { 48, 19, 69 },
    //            { 6, 75, 87 },
    //            { 90, 9, 28 },
    //            { 66, 70, 81 },
    //            { 81, 48, 6 },
    //            { 66, 63, 81 },
    //            { 27, 69, 84 },
    //            { 99, 95, 63 }
    //        };

    //        int? expectedOutput = 363;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test67 : TestCase
    //{
    //    public void Case67()
    //    {
    //        int[,] input = {
    //            { 24, 31, 65 },
    //            { 28, 11, 27 },
    //            { 3, 36, 88 },
    //            { 33, 30, 93 },
    //            { 49, 1, 44 },
    //            { 10, 38, 5 },
    //            { 80, 32, 74 },
    //            { 92, 28, 99 },
    //            { 42, 46, 37 },
    //            { 7, 64, 38 }
    //        };

    //        int? expectedOutput = 278;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test68 : TestCase
    //{
    //    public void Case68()
    //    {
    //        int[,] input = {
    //            { 47, 20, 10 },
    //            { 58, 17, 74 },
    //            { 100, 72, 59 },
    //            { 82, 6, 56 },
    //            { 76, 45, 13 },
    //            { 21, 46, 49 },
    //            { 57, 10, 80 },
    //            { 19, 8, 91 },
    //            { 1, 79, 64 },
    //            { 34, 66, 78 }
    //        };

    //        int? expectedOutput = 344;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test69 : TestCase
    //{
    //    public void Case69()
    //    {
    //        int[,] input = {
    //            { 27, 1, 74 },
    //            { 17, 100, 22 },
    //            { 34, 36, 60 },
    //            { 30, 78, 87 },
    //            { 90, 73, 16 },
    //            { 92, 44, 51 },
    //            { 86, 38, 60 },
    //            { 7, 58, 82 },
    //            { 43, 56, 86 }
    //        };

    //        int? expectedOutput = 389;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test70 : TestCase
    //{
    //    public void Case70()
    //    {
    //        int[,] input = {
    //            { 9, 33, 7 },
    //            { 55, 38, 57 },
    //            { 51, 71, 21 },
    //            { 62, 34, 76 },
    //            { 92, 43, 32 },
    //            { 71, 1, 71 }
    //        };

    //        int? expectedOutput = 186;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test71 : TestCase
    //{
    //    public void Case71()
    //    {
    //        int[,] input = {
    //            { 14, 90, 57 },
    //            { 41, 5, 53 },
    //            { 81, 82, 9 },
    //            { 53, 26, 97 },
    //            { 25, 62, 92 },
    //            { 21, 56, 98 },
    //            { 63, 37, 18 },
    //            { 81, 12, 14 },
    //            { 75, 36, 10 },
    //            { 81, 2, 28 }
    //        };

    //        int? expectedOutput = 313;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test72 : TestCase
    //{
    //    public void Case72()
    //    {
    //        int[,] input = {
    //            { 30, 41, 10 },
    //            { 58, 93, 69 },
    //            { 64, 100, 79 },
    //            { 54, 93, 22 },
    //            { 19, 24, 41 },
    //            { 68, 38, 20 },
    //            { 41, 62, 4 },
    //            { 91, 16, 11 },
    //            { 76, 52, 50 }
    //        };

    //        int? expectedOutput = 296;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test73 : TestCase
    //{
    //    public void Case73()
    //    {
    //        int[,] input = {
    //            { 45, 17, 26 },
    //            { 62, 59, 90 },
    //            { 81, 17, 72 },
    //            { 37, 85, 98 },
    //            { 51, 71, 12 },
    //            { 79, 20, 78 },
    //            { 14, 88, 91 },
    //            { 68, 39, 51 },
    //            { 61, 65, 34 },
    //            { 58, 37, 15 }
    //        };

    //        int? expectedOutput = 363;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test74 : TestCase
    //{
    //    public void Case74()
    //    {
    //        int[,] input = {
    //            { 43, 41, 91 },
    //            { 38, 59, 4 },
    //            { 7, 87, 16 },
    //            { 23, 96, 43 },
    //            { 86, 21, 21 },
    //            { 19, 55, 81 },
    //            { 72, 54, 85 },
    //            { 20, 39, 98 },
    //            { 72, 19, 38 }
    //        };

    //        int? expectedOutput = 251;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test75 : TestCase
    //{
    //    public void Case75()
    //    {
    //        int[,] input = {
    //            { 96, 94, 80 },
    //            { 50, 91, 56 },
    //            { 89, 65, 80 },
    //            { 93, 78, 48 },
    //            { 72, 74, 42 },
    //            { 18, 13, 93 },
    //            { 47, 11, 40 },
    //            { 62, 84, 49 },
    //            { 69, 54, 60 },
    //            { 35, 43, 42 }
    //        };

    //        int? expectedOutput = 437;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test76 : TestCase
    //{
    //    public void Case76()
    //    {
    //        int[,] input = {
    //            { 15, 96, 99 },
    //            { 79, 17, 75 },
    //            { 10, 44, 47 },
    //            { 5, 22, 1 },
    //            { 48, 82, 24 },
    //            { 76, 21, 68 },
    //            { 30, 93, 99 },
    //            { 72, 34, 26 },
    //            { 14, 86, 0 },
    //            { 54, 78, 24 }
    //        };

    //        int? expectedOutput = 345;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test77 : TestCase
    //{
    //    public void Case77()
    //    {
    //        int[,] input = {
    //            { 34, 81, 5 },
    //            { 56, 23, 58 },
    //            { 63, 78, 9 },
    //            { 92, 97, 50 },
    //            { 55, 10, 78 },
    //            { 0, 16, 52 },
    //            { 6, 50, 33 },
    //            { 84, 84, 52 },
    //            { 7, 45, 29 },
    //            { 94, 31, 93 }
    //        };

    //        int? expectedOutput = 334;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test78 : TestCase
    //{
    //    public void Case78()
    //    {
    //        int[,] input = {
    //            { 26, 94, 84 },
    //            { 76, 47, 0 },
    //            { 18, 62, 61 },
    //            { 17, 89, 24 },
    //            { 100, 97, 1 },
    //            { 39, 44, 21 },
    //            { 26, 86, 63 },
    //            { 61, 59, 61 },
    //            { 3, 97, 73 }
    //        };

    //        int? expectedOutput = 324;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test79 : TestCase
    //{
    //    public void Case79()
    //    {
    //        int[,] input = {
    //            { 8, 4, 49 },
    //            { 23, 36, 84 },
    //            { 32, 96, 0 },
    //            { 80, 98, 82 },
    //            { 61, 67, 72 },
    //            { 60, 74, 17 },
    //            { 12, 37, 31 },
    //            { 4, 25, 95 },
    //            { 63, 55, 19 },
    //            { 95, 34, 69 }
    //        };

    //        int? expectedOutput = 292;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}


    //public class Test80 : TestCase
    //{
    //    public void Case80()
    //    {
    //        int[,] input = {
    //            { 100, 10, 45 },
    //            { 6, 89, 47 },
    //            { 1, 33, 26 },
    //            { 91, 94, 46 },
    //            { 57, 34, 51 },
    //            { 74, 21, 71 },
    //            { 85, 85, 75 },
    //            { 63, 28, 79 },
    //            { 14, 90, 21 },
    //            { 11, 21, 90 }
    //        };

    //        int? expectedOutput = 310;
    //        int? result = HeroeTest.Check(input, HeroeTest.Student(input));
    //        Assert.That(result, Is.EqualTo(expectedOutput));
    //    }
    //}

    #endregion

    #region Better Max Size - 8

    public class Test1 : TestCase
    {
        public void Case1()
        {
            int[,] input = {
                { 21, 70, 22 },
                { 31, 10, 81 },
                { 47, 25, 21 },
                { 100, 94, 31 },
                { 32, 54, 72 },
                { 39, 100, 66 },
                { 10, 79, 76 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test2 : TestCase
    {
        public void Case2()
        {
            int[,] input = {
                { 66, 30, 97 },
                { 64, 10, 81 },
                { 21, 79, 41 },
                { 11, 98, 2 },
                { 42, 2, 80 },
                { 42, 99, 88 },
                { 58, 1, 72 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test3 : TestCase
    {
        public void Case3()
        {
            int[,] input = {
                { 89, 29, 16 },
                { 29, 0, 52 },
                { 64, 71, 87 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test4 : TestCase
    {
        public void Case4()
        {
            int[,] input = {
                { 35, 40, 64 },
                { 75, 4, 100 },
                { 7, 45, 81 },
                { 25, 99, 20 },
                { 90, 74, 19 },
                { 28, 2, 48 },
                { 38, 96, 75 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test5 : TestCase
    {
        public void Case5()
        {
            int[,] input = {
                { 64, 71, 100 },
                { 73, 59, 22 },
                { 19, 1, 90 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test6 : TestCase
    {
        public void Case6()
        {
            int[,] input = {
                { 15, 31, 53 },
                { 17, 24, 31 },
                { 92, 75, 0 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test7 : TestCase
    {
        public void Case7()
        {
            int[,] input = {
                { 51, 66, 54 },
                { 4, 19, 69 },
                { 22, 92, 68 },
                { 41, 26, 52 },
                { 76, 12, 83 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test8 : TestCase
    {
        public void Case8()
        {
            int[,] input = {
                { 17, 5, 49 },
                { 77, 50, 82 },
                { 66, 93, 42 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test9 : TestCase
    {
        public void Case9()
        {
            int[,] input = {
                { 95, 41, 72 },
                { 50, 39, 33 },
                { 0, 22, 8 },
                { 89, 24, 100 },
                { 75, 22, 68 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test10 : TestCase
    {
        public void Case10()
        {
            int[,] input = {
                { 59, 89, 35 },
                { 84, 98, 83 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test11 : TestCase
    {
        public void Case11()
        {
            int[,] input = {
                { 66, 21, 65 },
                { 50, 83, 37 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test12 : TestCase
    {
        public void Case12()
        {
            int[,] input = {
                { 49, 41, 10 },
                { 28, 60, 45 },
                { 87, 76, 49 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test13 : TestCase
    {
        public void Case13()
        {
            int[,] input = {
                { 31, 45, 45 },
                { 59, 89, 20 },
                { 68, 67, 49 },
                { 90, 30, 42 },
                { 98, 18, 82 },
                { 4, 20, 5 },
                { 15, 76, 12 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test14 : TestCase
    {
        public void Case14()
        {
            int[,] input = {
                { 41, 56, 54 },
                { 14, 90, 91 },
                { 9, 21, 3 },
                { 35, 44, 68 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test15 : TestCase
    {
        public void Case15()
        {
            int[,] input = {
                { 46, 42, 100 },
                { 46, 37, 17 },
                { 38, 93, 67 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test16 : TestCase
    {
        public void Case16()
        {
            int[,] input = {
                { 33, 33, 42 },
                { 13, 81, 56 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test17 : TestCase
    {
        public void Case17()
        {
            int[,] input = {
                { 77, 86, 80 },
                { 71, 69, 42 },
                { 69, 47, 52 },
                { 22, 86, 25 },
                { 17, 29, 32 },
                { 0, 86, 44 },
                { 72, 81, 17 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test18 : TestCase
    {
        public void Case18()
        {
            int[,] input = {
                { 31, 79, 9 },
                { 9, 9, 25 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test19 : TestCase
    {
        public void Case19()
        {
            int[,] input = {
                { 31, 65, 24 },
                { 44, 93, 41 },
                { 34, 47, 11 },
                { 54, 75, 73 },
                { 76, 97, 41 },
                { 16, 66, 99 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }


    public class Test20 : TestCase
    {
        public void Case20()
        {
            int[,] input = {
                { 91, 43, 60 },
                { 65, 97, 57 }
            };

            Assert.That(HeroeTest.Student(input), Is.SequenceEqualTo(new Tuple<int, int>[] { }));
        }
    }

    //2

    public class Test21 : TestCase
    {
        public void Case21()
        {
            int[,] input = {
                { 21, 0, 58 },
                { 10, 138, 15 },
                { 152, 40, 15 },
                { 0, 0, 22 },
                { 0, 88, 172 },
                { 7, 13, 20 },
                { 42, 7, 7 },
                { 54, 0, 34 }
            };

            int? expectedOutput = 286;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //3

    public class Test22 : TestCase
    {
        public void Case22()
        {
            int[,] input = {
                { 4, 2, 3 },
                { 17, 6, 0 },
                { 14, 0, 0 },
                { 1, 30, 31 },
                { 6, 0, 11 },
                { 9, 2, 4 },
                { 0, 7, 2 },
                { 1, 8, 0 }
            };

            int? expectedOutput = 51;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //4

    public class Test23 : TestCase
    {
        public void Case23()
        {
            int[,] input = {
                { 2, 5, 0 },
                { 1, 2, 0 },
                { 1, 0, 1 },
                { 2, 9, 0 },
                { 3, 2, 27 },
                { 1, 10, 0 },
                { 7, 4, 2 },
                { 14, 6, 0 }
            };

            int? expectedOutput = 30;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test24 : TestCase
    {
        public void Case24()
        {
            int[,] input = {
                { 1, 21, 1 },
                { 3, 0, 1 },
                { 0, 0, 3 },
                { 8, 10, 2 },
                { 6, 0, 5 },
                { 0, 2, 2 },
                { 2, 0, 7 },
                { 13, 0, 16 }
            };

            int? expectedOutput = 33;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //3

    public class Test25 : TestCase
    {
        public void Case25()
        {
            int[,] input = {
                { 6, 2, 0 },
                { 1, 3, 0 },
                { 16, 7, 0 },
                { 0, 8, 11 },
                { 1, 2, 5 },
                { 31, 0, 4 },
                { 0, 5, 38 },
                { 4, 33, 0 }
            };

            int? expectedOutput = 58;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test26 : TestCase
    {
        public void Case26()
        {
            int[,] input = {
                { 2, 0, 2 },
                { 3, 1, 1 },
                { 35, 1, 1 },
                { 12, 2, 1 },
                { 0, 0, 5 },
                { 0, 0, 39 },
                { 0, 13, 5 },
                { 0, 35, 1 }
            };

            int? expectedOutput = 52;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test27 : TestCase
    {
        public void Case27()
        {
            int[,] input = {
                { 1, 17, 0 },
                { 4, 1, 0 },
                { 7, 7, 0 },
                { 7, 5, 0 },
                { 1, 4, 1 },
                { 8, 0, 1 },
                { 20, 4, 14 },
                { 1, 19, 32 }
            };

            int? expectedOutput = 48;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test28 : TestCase
    {
        public void Case28()
        {
            int[,] input = {
                { 1, 7, 0 },
                { 10, 0, 0 },
                { 19, 4, 0 },
                { 7, 0, 0 },
                { 6, 30, 0 },
                { 0, 12, 1 },
                { 1, 0, 40 },
                { 10, 0, 12 }
            };

            int? expectedOutput = 53;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //4

    public class Test29 : TestCase
    {
        public void Case29()
        {
            int[,] input = {
                { 1, 0, 19 },
                { 9, 0, 3 },
                { 0, 0, 3 },
                { 1, 25, 7 },
                { 1, 7, 0 },
                { 19, 9, 0 },
                { 12, 0, 9 }
            };

            int? expectedOutput = 41;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //3

    public class Test30 : TestCase
    {
        public void Case30()
        {
            int[,] input = {
                { 3, 3, 0 },
                { 13, 1, 0 },
                { 4, 20, 0 },
                { 11, 0, 0 },
                { 2, 0, 7 },
                { 1, 2, 13 },
                { 1, 10, 4 },
                { 5, 0, 12 }
            };

            int? expectedOutput = 36;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test31 : TestCase
    {
        public void Case31()
        {
            int[,] input = {
                { 16, 6, 15 },
                { 9, 8, 0 },
                { 27, 7, 1 },
                { 1, 7, 22 },
                { 1, 36, 6 },
                { 1, 7, 5 },
                { 1, 3, 9 },
                { 4, 7, 1 }
            };

            int? expectedOutput = 58;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test32 : TestCase
    {
        public void Case32()
        {
            int[,] input = {
                { 0, 38, 1 },
                { 2, 0, 6 },
                { 50, 1, 7 },
                { 2, 33, 5 },
                { 11, 0, 7 },
                { 0, 22, 76 },
                { 0, 2, 4 },
                { 31, 1, 2 }
            };

            int? expectedOutput = 96;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //3

    public class Test33 : TestCase
    {
        public void Case33()
        {
            int[,] input = {
                { 66, 2, 2 },
                { 64, 1, 61 },
                { 96, 18, 2 },
                { 1, 38, 4 },
                { 4, 21, 144 },
                { 3, 44, 8 },
                { 5, 1, 11 },
                { 4, 108, 3 }
            };

            int? expectedOutput = 231;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test34 : TestCase
    {
        public void Case34()
        {
            int[,] input = {
                { 8, 2, 0 },
                { 2, 2, 22 },
                { 18, 4, 0 },
                { 0, 14, 0 },
                { 2, 1, 0 },
                { 3, 0, 6 },
                { 0, 8, 3 }
            };

            int? expectedOutput = 31;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test35 : TestCase
    {
        public void Case35()
        {
            int[,] input = {
                { 15, 5, 1 },
                { 2, 12, 1 },
                { 13, 21, 1 },
                { 1, 6, 8 },
                { 48, 2, 20 },
                { 4, 46, 1 },
                { 28, 4, 59 },
                { 1, 25, 22 }
            };

            int? expectedOutput = 110;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test36 : TestCase
    {
        public void Case36()
        {
            int[,] input = {
                { 0, 0, 81 },
                { 0, 1, 0 },
                { 2, 1, 17 },
                { 1, 8, 0 },
                { 5, 3, 0 },
                { 0, 1, 3 },
                { 20, 1, 0 },
                { 73, 88, 0 }
            };

            int? expectedOutput = 101;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test37 : TestCase
    {
        public void Case37()
        {
            int[,] input = {
                { 0, 0, 15 },
                { 15, 2, 0 },
                { 5, 0, 8 },
                { 27, 1, 2 },
                { 0, 2, 14 },
                { 2, 4, 0 },
                { 12, 45, 2 },
                { 0, 10, 22 }
            };

            int? expectedOutput = 61;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test38 : TestCase
    {
        public void Case38()
        {
            int[,] input = {
                { 27, 2, 0 },
                { 1, 4, 2 },
                { 0, 5, 1 },
                { 3, 0, 0 },
                { 0, 4, 13 },
                { 0, 0, 4 },
                { 4, 0, 15 },
                { 1, 20, 0 }
            };

            int? expectedOutput = 35;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test39 : TestCase
    {
        public void Case39()
        {
            int[,] input = {
                { 33, 12, 2 },
                { 23, 12, 25 },
                { 6, 10, 9 },
                { 4, 28, 25 },
                { 18, 12, 0 },
                { 22, 4, 2 },
                { 2, 25, 2 },
                { 1, 25, 39 }
            };

            int? expectedOutput = 102;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //8

    public class Test40 : TestCase
    {
        public void Case40()
        {
            int[,] input = {
                { 0, 2, 0 },
                { 0, 18, 0 },
                { 1, 11, 0 },
                { 2, 1, 0 },
                { 0, 4, 1 },
                { 36, 2, 0 },
                { 1, 0, 29 },
                { 1, 1, 9 }
            };

            int? expectedOutput = 39;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test41 : TestCase
    {
        public void Case41()
        {
            int[,] input = {
                { 38, 1, 34 },
                { 0, 12, 11 },
                { 25, 1, 22 },
                { 1, 1, 1 },
                { 0, 45, 0 },
                { 1, 1, 0 },
                { 1, 11, 0 },
                { 3, 0, 1 }
            };

            int? expectedOutput = 69;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test42 : TestCase
    {
        public void Case42()
        {
            int[,] input = {
                { 13, 12, 0 },
                { 14, 1, 0 },
                { 4, 41, 3 },
                { 1, 97, 11 },
                { 7, 4, 45 },
                { 39, 3, 0 },
                { 12, 8, 0 },
                { 87, 1, 106 }
            };

            int? expectedOutput = 165;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //3

    public class Test43 : TestCase
    {
        public void Case43()
        {
            int[,] input = {
                { 3, 9, 1 },
                { 2, 10, 0 },
                { 0, 7, 2 },
                { 0, 1, 17 },
                { 0, 3, 7 },
                { 14, 4, 1 },
                { 5, 0, 8 },
                { 10, 1, 2 }
            };

            int? expectedOutput = 34;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test44 : TestCase
    {
        public void Case44()
        {
            int[,] input = {
                { 2, 0, 0 },
                { 1, 0, 0 },
                { 11, 17, 0 },
                { 1, 0, 7 },
                { 5, 0, 13 },
                { 1, 15, 10 },
                { 13, 0, 2 }
            };

            int? expectedOutput = 32;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //4

    public class Test45 : TestCase
    {
        public void Case45()
        {
            int[,] input = {
                { 11, 4, 2 },
                { 7, 0, 28 },
                { 24, 1, 8 },
                { 0, 2, 3 },
                { 1, 6, 9 },
                { 1, 1, 0 },
                { 4, 2, 1 },
                { 1, 33, 0 }
            };

            int? expectedOutput = 48;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //3

    public class Test46 : TestCase
    {
        public void Case46()
        {
            int[,] input = {
                { 1, 1, 1 },
                { 8, 4, 0 },
                { 1, 0, 1 },
                { 19, 0, 5 },
                { 1, 4, 21 },
                { 4, 10, 1 },
                { 3, 13, 1 },
                { 1, 3, 7 }
            };

            int? expectedOutput = 35;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test47 : TestCase
    {
        public void Case47()
        {
            int[,] input = {
                { 2, 1, 20 },
                { 8, 1, 1 },
                { 0, 7, 9 },
                { 0, 10, 89 },
                { 1, 56, 2 },
                { 2, 55, 0 },
                { 8, 1, 7 },
                { 109, 1, 2 }
            };

            int? expectedOutput = 129;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test48 : TestCase
    {
        public void Case48()
        {
            int[,] input = {
                { 0, 2, 24 },
                { 1, 2, 38 },
                { 0, 44, 21 },
                { 29, 4, 0 },
                { 8, 6, 0 },
                { 0, 38, 0 },
                { 59, 1, 1 },
                { 0, 5, 13 }
            };

            int? expectedOutput = 97;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test49 : TestCase
    {
        public void Case49()
        {
            int[,] input = {
                { 3, 0, 15 },
                { 4, 9, 0 },
                { 3, 0, 3 },
                { 0, 20, 9 },
                { 9, 0, 2 },
                { 14, 0, 0 },
                { 3, 1, 1 }
            };

            int? expectedOutput = 30;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test50 : TestCase
    {
        public void Case50()
        {
            int[,] input = {
                { 0, 0, 21 },
                { 0, 10, 12 },
                { 0, 0, 7 },
                { 3, 15, 1 },
                { 3, 31, 12 },
                { 6, 0, 22 },
                { 66, 19, 1 },
                { 0, 3, 23 }
            };

            int? expectedOutput = 78;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test51 : TestCase
    {
        public void Case51()
        {
            int[,] input = {
                { 1, 12, 1 },
                { 0, 20, 1 },
                { 11, 3, 19 },
                { 22, 5, 12 },
                { 16, 7, 1 },
                { 1, 11, 18 }
            };

            int? expectedOutput = 50;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test52 : TestCase
    {
        public void Case52()
        {
            int[,] input = {
                { 10, 20, 27 },
                { 7, 45, 0 },
                { 1, 13, 14 },
                { 13, 22, 3 },
                { 22, 34, 18 },
                { 0, 15, 8 },
                { 14, 36, 0 },
                { 14, 34, 11 }
            };

            int? expectedOutput = 81;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test53 : TestCase
    {
        public void Case53()
        {
            int[,] input = {
                { 2, 0, 3 },
                { 3, 0, 2 },
                { 6, 0, 16 },
                { 1, 1, 11 },
                { 1, 20, 3 },
                { 23, 11, 1 },
                { 0, 2, 4 }
            };

            int? expectedOutput = 34;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test54 : TestCase
    {
        public void Case54()
        {
            int[,] input = {
                { 3, 13, 49 },
                { 4, 0, 15 },
                { 14, 1, 9 },
                { 2, 9, 5 },
                { 1, 50, 2 },
                { 70, 1, 0 },
                { 2, 8, 0 },
                { 2, 7, 8 }
            };

            int? expectedOutput = 88;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //4

    public class Test55 : TestCase
    {
        public void Case55()
        {
            int[,] input = {
                { 0, 36, 0 },
                { 0, 1, 0 },
                { 2, 1, 7 },
                { 5, 10, 0 },
                { 1, 1, 30 },
                { 7, 1, 5 },
                { 2, 4, 0 },
                { 34, 0, 9 }
            };

            int? expectedOutput = 51;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test56 : TestCase
    {
        public void Case56()
        {
            int[,] input = {
                { 0, 0, 33 },
                { 3, 0, 5 },
                { 8, 33, 2 },
                { 4, 8, 3 },
                { 0, 17, 22 },
                { 0, 7, 12 },
                { 0, 0, 10 },
                { 67, 17, 2 }
            };

            int? expectedOutput = 82;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test57 : TestCase
    {
        public void Case57()
        {
            int[,] input = {
                { 4, 15, 2 },
                { 13, 10, 4 },
                { 16, 7, 0 },
                { 15, 2, 15 },
                { 0, 3, 21 },
                { 0, 23, 9 },
                { 8, 4, 14 },
                { 3, 4, 7 }
            };

            int? expectedOutput = 59;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test58 : TestCase
    {
        public void Case58()
        {
            int[,] input = {
                { 0, 16, 0 },
                { 1, 5, 0 },
                { 0, 1, 3 },
                { 2, 1, 0 },
                { 12, 2, 0 },
                { 0, 0, 5 },
                { 17, 1, 0 },
                { 0, 6, 24 }
            };

            int? expectedOutput = 32;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test59 : TestCase
    {
        public void Case59()
        {
            int[,] input = {
                { 4, 25, 1 },
                { 10, 6, 23 },
                { 4, 8, 1 },
                { 0, 8, 15 },
                { 9, 8, 1 },
                { 2, 8, 0 },
                { 0, 3, 3 },
                { 20, 5, 7 }
            };

            int? expectedOutput = 49;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test60 : TestCase
    {
        public void Case60()
        {
            int[,] input = {
                { 10, 1, 0 },
                { 0, 0, 14 },
                { 23, 0, 19 },
                { 1, 1, 0 },
                { 0, 0, 2 },
                { 0, 15, 0 },
                { 0, 19, 1 },
                { 2, 1, 0 }
            };

            int? expectedOutput = 36;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test61 : TestCase
    {
        public void Case61()
        {
            int[,] input = {
                { 31, 20, 0 },
                { 1, 31, 8 },
                { 15, 5, 1 },
                { 2, 6, 5 },
                { 2, 1, 17 },
                { 1, 0, 20 },
                { 2, 0, 18 },
                { 10, 1, 2 }
            };

            int? expectedOutput = 63;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test62 : TestCase
    {
        public void Case62()
        {
            int[,] input = {
                { 7, 0, 0 },
                { 2, 0, 273 },
                { 206, 0, 22 },
                { 2, 14, 0 },
                { 14, 0, 0 },
                { 24, 190, 0 },
                { 0, 105, 0 },
                { 56, 0, 14 }
            };

            int? expectedOutput = 309;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //4

    public class Test63 : TestCase
    {
        public void Case63()
        {
            int[,] input = {
                { 2, 0, 0 },
                { 29, 9, 0 },
                { 2, 0, 9 },
                { 1, 3, 0 },
                { 10, 11, 0 },
                { 1, 30, 0 },
                { 6, 0, 41 },
                { 3, 0, 3 }
            };

            int? expectedOutput = 53;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test64 : TestCase
    {
        public void Case64()
        {
            int[,] input = {
                { 2, 6, 2 },
                { 2, 0, 12 },
                { 2, 4, 1 },
                { 2, 27, 1 },
                { 10, 4, 4 },
                { 6, 4, 1 },
                { 0, 10, 24 },
                { 27, 2, 3 }
            };

            int? expectedOutput = 47;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test65 : TestCase
    {
        public void Case65()
        {
            int[,] input = {
                { 9, 0, 0 },
                { 11, 2, 0 },
                { 12, 1, 0 },
                { 0, 13, 0 },
                { 0, 8, 14 },
                { 6, 1, 2 },
                { 0, 18, 26 },
                { 4, 1, 0 }
            };

            int? expectedOutput = 42;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test66 : TestCase
    {
        public void Case66()
        {
            int[,] input = {
                { 1, 37, 0 },
                { 3, 0, 3 },
                { 17, 2, 2 },
                { 1, 0, 27 },
                { 9, 0, 6 },
                { 8, 0, 2 },
                { 1, 0, 3 }
            };

            int? expectedOutput = 39;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test67 : TestCase
    {
        public void Case67()
        {
            int[,] input = {
                { 9, 5, 0 },
                { 12, 36, 0 },
                { 4, 15, 80 },
                { 31, 9, 0 },
                { 29, 0, 0 },
                { 15, 0, 7 },
                { 6, 3, 9 },
                { 9, 28, 0 }
            };

            int? expectedOutput = 96;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test68 : TestCase
    {
        public void Case68()
        {
            int[,] input = {
                { 25, 8, 0 },
                { 0, 0, 19 },
                { 1, 30, 0 },
                { 10, 4, 0 },
                { 1, 39, 3 },
                { 48, 0, 27 },
                { 0, 34, 29 },
                { 31, 0, 37 }
            };

            int? expectedOutput = 115;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test69 : TestCase
    {
        public void Case69()
        {
            int[,] input = {
                { 33, 15, 0 },
                { 8, 2, 0 },
                { 4, 25, 0 },
                { 20, 0, 1 },
                { 25, 0, 5 },
                { 2, 0, 11 },
                { 7, 1, 52 },
                { 2, 43, 17 }
            };

            int? expectedOutput = 86;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test70 : TestCase
    {
        public void Case70()
        {
            int[,] input = {
                { 22, 10, 0 },
                { 0, 20, 2 },
                { 0, 3, 1 },
                { 1, 3, 12 },
                { 0, 4, 1 },
                { 0, 3, 12 },
                { 7, 0, 9 },
                { 7, 3, 1 }
            };

            int? expectedOutput = 37;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test71 : TestCase
    {
        public void Case71()
        {
            int[,] input = {
                { 0, 4, 1 },
                { 46, 0, 13 },
                { 61, 11, 0 },
                { 0, 1, 73 },
                { 12, 0, 11 },
                { 0, 6, 2 },
                { 0, 97, 12 },
                { 0, 1, 8 }
            };

            int? expectedOutput = 119;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //7

    public class Test72 : TestCase
    {
        public void Case72()
        {
            int[,] input = {
                { 0, 0, 3 },
                { 1, 0, 20 },
                { 1, 2, 3 },
                { 14, 1, 2 },
                { 5, 17, 2 },
                { 16, 0, 3 },
                { 0, 6, 3 },
                { 0, 11, 11 }
            };

            int? expectedOutput = 37;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test73 : TestCase
    {
        public void Case73()
        {
            int[,] input = {
                { 2, 0, 29 },
                { 1, 1, 3 },
                { 0, 1, 9 },
                { 0, 1, 4 },
                { 43, 0, 18 },
                { 1, 52, 0 },
                { 3, 1, 3 },
                { 13, 8, 3 }
            };

            int? expectedOutput = 63;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test74 : TestCase
    {
        public void Case74()
        {
            int[,] input = {
                { 2, 4, 1 },
                { 3, 2, 21 },
                { 11, 0, 20 },
                { 3, 15, 0 },
                { 1, 2, 1 },
                { 2, 23, 1 },
                { 23, 0, 2 }
            };

            int? expectedOutput = 44;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test75 : TestCase
    {
        public void Case75()
        {
            int[,] input = {
                { 1, 2, 2 },
                { 18, 1, 0 },
                { 0, 7, 8 },
                { 26, 0, 3 },
                { 1, 1, 39 },
                { 10, 4, 0 },
                { 0, 42, 6 }
            };

            int? expectedOutput = 56;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test76 : TestCase
    {
        public void Case76()
        {
            int[,] input = {
                { 0, 1, 1 },
                { 2, 2, 0 },
                { 30, 0, 1 },
                { 5, 1, 29 },
                { 0, 6, 0 },
                { 0, 26, 6 },
                { 0, 2, 0 },
                { 0, 0, 0 }
            };

            int? expectedOutput = 37;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test77 : TestCase
    {
        public void Case77()
        {
            int[,] input = {
                { 0, 13, 2 },
                { 4, 4, 0 },
                { 0, 10, 5 },
                { 3, 15, 4 },
                { 10, 0, 26 },
                { 9, 3, 6 },
                { 8, 2, 14 },
                { 12, 4, 6 }
            };

            int? expectedOutput = 46;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test78 : TestCase
    {
        public void Case78()
        {
            int[,] input = {
                { 8, 6, 0 },
                { 3, 1, 6 },
                { 3, 6, 1 },
                { 1, 7, 17 },
                { 20, 0, 0 },
                { 0, 2, 1 },
                { 3, 9, 7 }
            };

            int? expectedOutput = 31;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //4

    public class Test79 : TestCase
    {
        public void Case79()
        {
            int[,] input = {
                { 8, 0, 0 },
                { 5, 0, 0 },
                { 2, 0, 13 },
                { 36, 2, 0 },
                { 0, 39, 2 },
                { 19, 0, 0 },
                { 1, 17, 45 },
                { 2, 12, 10 }
            };

            int? expectedOutput = 70;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    //2

    public class Test80 : TestCase
    {
        public void Case80()
        {
            int[,] input = {
                { 6, 10, 0 },
                { 1, 3, 0 },
                { 17, 1, 6 },
                { 2, 16, 9 },
                { 3, 1, 20 },
                { 2, 15, 3 },
                { 6, 1, 0 },
                { 13, 0, 7 }
            };

            int? expectedOutput = 45;
            int? result = HeroeTest.Check(input, HeroeTest.Student(input));
            Assert.That(result, Is.EqualTo(expectedOutput));
        }
    }

    #endregion
}
