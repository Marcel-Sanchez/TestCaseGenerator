﻿using Balanzas;
using Weboo.Assess.Tester;

namespace EquilibrandoBalanzasTester
{
    internal abstract class EquilibrandoBalanzasTest : TestCase
    {
        private static bool Student(IBalanza balanza, int bolas, int pesoBola)
        {
            return ReflectionHelper.InvokeStatic<bool>("Weboo.Examen.ExamenMundial", "Equilibrar", balanza, bolas, pesoBola);
        }

        private static bool Benchmark(IBalanza balanza, int bolas, int pesoBolas)
        {
            if (Equilibrate(balanza, bolas))
            {
                SetWeights(balanza, bolas, pesoBolas);
                return true;
            }

            return false;
        }

        private static bool Equilibrate(IPesable pesable, int ballsCount)
        {
            if (pesable is IPlatillo)
                return true;

            var scales = pesable as IBalanza;
            int sides = scales.LargoIzquierdo + scales.LargoDerecho;

            return (ballsCount * scales.LargoDerecho) % sides == 0 &&
                   Equilibrate(scales.PesoIzquierdo, (ballsCount * scales.LargoDerecho) / sides) &&
                   Equilibrate(scales.PesoDerecho, (ballsCount * scales.LargoIzquierdo) / sides);
        }

        private static void SetWeights(IPesable pesable, int ballsCount, int ballWeight)
        {
            pesable.Peso = ballsCount * ballWeight;

            if (pesable is IBalanza)
            {
                var scales = (IBalanza)pesable;
                int sides = scales.LargoIzquierdo + scales.LargoDerecho;
                SetWeights(scales.PesoIzquierdo, (ballsCount * scales.LargoDerecho) / sides, ballWeight);
                SetWeights(scales.PesoDerecho, (ballsCount * scales.LargoIzquierdo) / sides, ballWeight);
            }
        }

        private void CheckBallstDistribution(IPesable target, IPesable benchmark, string path = "[.]")
        {
            if (target.Peso != benchmark.Peso)
                Assert.Fail($"Wrong weight {target.Peso} in path {path}. (Expected {benchmark.Peso})");

            if (target is IBalanza)
            {
                if (!(benchmark is IBalanza))
                {
                    Assert.Fail($"Structure modified in {path}");
                    return;
                }

                CheckBallstDistribution((target as IBalanza).PesoIzquierdo, (benchmark as IBalanza).PesoIzquierdo, path + "[L]");
                CheckBallstDistribution((target as IBalanza).PesoDerecho, (benchmark as IBalanza).PesoDerecho, path + "[R]");
            }
            else if (benchmark is IBalanza)
            {
                Assert.Fail($"Structure modified in {path}");
            }
        }

        protected void Check(Balanza balanza, int bolas, int pesoBola)
        {
            var studentBalanza = balanza.DeepClone();
            var benchmarkBalanza = balanza.DeepClone();

            bool studentResult = Student(studentBalanza, bolas, pesoBola);
            bool benchamerResult = Benchmark(benchmarkBalanza, bolas, pesoBola);

            Assert.That(studentResult, Is.EqualTo(benchamerResult));
            if (studentResult == benchamerResult)
            {
                CheckBallstDistribution(studentBalanza, benchmarkBalanza);
            }
        }
    }

    class Test1 : EquilibrandoBalanzasTest
    {
        public void Case1()
        {
            var balanza = new Balanza(
                2, new Platillo(),
                4, new Platillo()
            );
            Check(balanza, 9, 1);
        }
    }

    class Test2 : EquilibrandoBalanzasTest
    {
        public void Case2()
        {
            var balanza = new Balanza(
                2, new Platillo(),
                4, new Platillo()
            );
            Check(balanza, 10, 1);
        }
    }

    class Test3 : EquilibrandoBalanzasTest
    {
        public void Case3()
        {
            var balanza = new Balanza(
                2, new Balanza(
                    2, new Platillo(),
                    2, new Balanza(
                        2, new Platillo(),
                        2, new Platillo()
                    )
                ), 4, new Platillo()
            );
            Check(balanza, 6, 3);
        }
    }

    class Test4 : EquilibrandoBalanzasTest
    {
        public void Case4()
        {
            var balanza = new Balanza(
                5, new Balanza(
                    2, new Balanza(
                        1, new Balanza(
                            1, new Balanza(
                                3, new Platillo(),
                                1, new Platillo()
                            ),
                            1, new Platillo()
                        ),
                        2, new Platillo()
                    ),
                    1, new Balanza(
                        1, new Platillo(),
                        2, new Platillo()
                    )
                ),
                5, new Balanza(
                    4, new Platillo(),
                    3, new Platillo()
                )
            );
            Check(balanza, 504, 1);
        }
    }

    class Test5 : EquilibrandoBalanzasTest
    {
        public void Case5()
        {
            var balanza = new Balanza(
                5, new Balanza(
                    2, new Balanza(
                        1, new Balanza(
                            1, new Balanza(
                                3, new Platillo(),
                                1, new Platillo()
                            ),
                            1, new Platillo()
                        ),
                        2, new Platillo()
                    ),
                    1, new Balanza(
                        1, new Platillo(),
                        2, new Platillo()
                    )
                ),
                5, new Balanza(
                    4, new Platillo(),
                    3, new Platillo()
                )
            );
            Check(balanza, 210, 8);
        }
    }

    class Test6 : EquilibrandoBalanzasTest
    {
        public void Case6()
        {
            var balanza = new Balanza(
                5, new Balanza(
                    2, new Balanza(
                        1, new Balanza(
                            1, new Balanza(
                                3, new Platillo(),
                                1, new Platillo()
                            ),
                            1, new Platillo()
                        ),
                        2, new Platillo()
                    ),
                    1, new Balanza(
                        1, new Platillo(),
                        2, new Platillo()
                    )
                ),
                5, new Balanza(
                    4, new Platillo(),
                    3, new Platillo()
                )
            );
            Check(balanza, 20, 11);
        }
    }

    class Test7 : EquilibrandoBalanzasTest
    {
        public void Case7()
        {
            var balanza = new Balanza(
                2, new Balanza(
                    2, new Platillo(),
                    7, new Balanza(
                        1, new Platillo(),
                        1, new Platillo()
                    )
                ),
                5, new Balanza(
                    3, new Balanza(
                        2, new Platillo(),
                        1, new Platillo()
                       ),
                    4, new Platillo()
                )
            );
            Check(balanza, 441, 1);
        }
    }

    class Test8 : EquilibrandoBalanzasTest
    {
        public void Case8()
        {
            var balanza = new Balanza(
                2, new Balanza(
                    2, new Platillo(),
                    7, new Balanza(
                        1, new Platillo(),
                        1, new Platillo()
                    )
                ),
                5, new Balanza(
                    3, new Balanza(
                        2, new Platillo(),
                        1, new Platillo()
                    ),
                    4, new Platillo()
                )
            );
            Check(balanza, 112, 2);
        }
    }

    class Test9 : EquilibrandoBalanzasTest
    {
        public void Case9()
        {
            var balanza = new Balanza(
                2, new Balanza(
                    2, new Platillo(),
                    7, new Balanza(
                        1, new Platillo(),
                        1, new Platillo()
                    )
                ),
                5, new Balanza(
                    3, new Balanza(
                        2, new Platillo(),
                        1, new Platillo()
                    ),
                    4, new Platillo()
                )
            );
            Check(balanza, 23, 3);
        }
    }

    class Test10 : EquilibrandoBalanzasTest
    {
        public void Case10()
        {
            var balanza = new Balanza(
                2, new Balanza(
                    1, new Platillo(),
                    4, new Balanza(
                        2, new Platillo(),
                        3, new Platillo()
                    )
                ),
                5, new Balanza(
                    1, new Platillo(),
                    2, new Balanza(
                        4, new Balanza(
                            1, new Platillo(),
                            4, new Platillo()
                        ),
                        4, new Balanza(
                            1, new Platillo(),
                            4, new Platillo()
                        )
                    )
                )
            );
            Check(balanza, 105, 10);
        }
    }

    class Test11 : EquilibrandoBalanzasTest
    {
        public void Case11()
        {
            var balanza = new Balanza(
                2, new Balanza(
                    1, new Platillo(),
                    4, new Balanza(
                        2, new Platillo(),
                        3, new Platillo()
                    )
                ),
                5, new Balanza(
                    1, new Platillo(),
                    2, new Balanza(
                        4, new Balanza(
                            1, new Platillo(),
                            4, new Platillo()
                        ),
                        4, new Balanza(
                            1, new Platillo(),
                            4, new Platillo()
                        )
                    )
                )
            );
            Check(balanza, 80, 7);
        }
    }

    class Test12 : EquilibrandoBalanzasTest
    {
        public void Case12()
        {
            var balanza = new Balanza(
                2, new Balanza(
                    1, new Platillo(),
                    4, new Balanza(
                        2, new Platillo(),
                        3, new Platillo()
                    )
                ),
                5, new Balanza(
                    1, new Platillo(),
                    2, new Balanza(
                        4, new Balanza(
                            1, new Platillo(),
                            4, new Platillo()
                        ),
                        4, new Balanza(
                            1, new Platillo(),
                            4, new Platillo()
                        )
                    )
                )
            );
            Check(balanza, 2017, 5);
        }
    }

    class Test13 : EquilibrandoBalanzasTest
    {
        public void Case13()
        {
            var balanza = new Balanza(
                5, new Platillo(),
                5, new Balanza(
                    4, new Platillo(),
                    3, new Platillo()
                )
            );
            Check(balanza, 10, 5);
        }
    }

    class Test14 : EquilibrandoBalanzasTest
    {
        public void Case14()
        {
            var balanza = new Balanza(
                8, new Platillo(),
                10, new Platillo()
            );
            Check(balanza, 1, 1);
        }
    }

    class Test15 : EquilibrandoBalanzasTest
    {
        public void Case15()
        {
            var balanza = new Balanza(
                1, new Balanza(
                    1, new Balanza(
                        1, new Balanza(
                            1, new Balanza(
                                1, new Balanza(
                                    1, new Balanza(
                                        1, new Balanza(
                                            1, new Balanza(
                                                1, new Balanza(
                                                    1, new Platillo(),
                                                    1, new Platillo()
                                                ),
                                                1, new Platillo()
                                            ),
                                            1, new Platillo()
                                        ),
                                        1, new Platillo()
                                    ),
                                    1, new Platillo()
                                ),
                                1, new Platillo()
                            ),
                            1, new Platillo()
                        ),
                        1, new Platillo()
                    ),
                    1, new Platillo()
                ),
                1, new Platillo()
            );
            Check(balanza, 200, 7);
        }
    }

    class Test16 : EquilibrandoBalanzasTest
    {
        public void Case16()
        {
            var balanza = new Balanza(
                1, new Balanza(
                    1, new Balanza(
                        1, new Balanza(
                            1, new Balanza(
                                1, new Balanza(
                                    1, new Balanza(
                                        1, new Balanza(
                                            1, new Balanza(
                                                1, new Balanza(
                                                    1, new Platillo(),
                                                    1, new Platillo()
                                                ),
                                                2, new Platillo()
                                            ),
                                            3, new Platillo()
                                        ),
                                        4, new Platillo()
                                    ),
                                    5, new Platillo()
                                ),
                                6, new Platillo()
                            ),
                            7, new Platillo()
                        ),
                        8, new Platillo()
                    ),
                    9, new Platillo()
                ),
                10, new Platillo()
            );
            Check(balanza, 20, 7);
        }
    }

    class Test17 : EquilibrandoBalanzasTest
    {
        public void Case17()
        {
            var balanza = new Balanza(
                1, new Balanza(
                    1, new Platillo(),
                    5, new Platillo()
                ),
                1, new Platillo()
            );
            Check(balanza, 7, 1);
        }
    }

    class Test18 : EquilibrandoBalanzasTest
    {
        public void Case18()
        {
            var balanza = new Balanza(
                10, new Balanza(
                    1, new Platillo(),
                    1, new Platillo()
                ),
                7, new Platillo()
            );
            Check(balanza, 170, 3);
        }
    }

    class Test19 : EquilibrandoBalanzasTest
    {
        public void Case19()
        {
            var balanza = new Balanza(
                10, new Balanza(
                    1, new Platillo(),
                    1, new Platillo()
                ),
                7, new Platillo()
            );
            Check(balanza, 17, 2);
        }
    }

    class Test20 : EquilibrandoBalanzasTest
    {
        public void Case20()
        {
            var balanza = new Balanza(
                3, new Balanza(
                    3, new Platillo(),
                    3, new Platillo()
                ),
                3, new Balanza(
                    3, new Platillo(),
                    3, new Platillo()
                )
            );
            Check(balanza, 6000000, 3);
        }
    }
}
