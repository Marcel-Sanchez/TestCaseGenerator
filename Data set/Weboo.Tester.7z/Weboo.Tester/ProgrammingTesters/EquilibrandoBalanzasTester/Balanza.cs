﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Balanzas;

namespace EquilibrandoBalanzasTester
{
    public class Balanza : IBalanza
    {
        public Balanza(int largoIzquierdo, IPesable pesoIzquierdo, int largoDerecho, IPesable pesoDerecho)
        {
            this.LargoIzquierdo = largoIzquierdo;
            this.LargoDerecho = largoDerecho;
            this.PesoIzquierdo = pesoIzquierdo;
            this.PesoDerecho = pesoDerecho;
        }
        public int Peso { get; set; }

        public int LargoIzquierdo { get; set; }

        public int LargoDerecho { get; set; }

        public IPesable PesoIzquierdo { get; set; }

        public IPesable PesoDerecho { get; set; }

        public Balanza DeepClone()
        {
            var left = PesoIzquierdo is IPlatillo ? (IPesable) new Platillo() : (PesoIzquierdo as Balanza).DeepClone();
            var right = PesoDerecho is IPlatillo ? (IPesable)new Platillo() : (PesoDerecho as Balanza).DeepClone();
            return new Balanza(LargoIzquierdo, left, LargoDerecho, right);
        }
    }

    public class Platillo : IPlatillo
    {
        public int Peso { get; set; }
    }
}
