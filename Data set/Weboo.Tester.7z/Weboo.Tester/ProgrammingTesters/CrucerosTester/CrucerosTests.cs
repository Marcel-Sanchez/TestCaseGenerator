﻿using System;
using System.Collections.Generic;
using System.Linq;
using Interfaces;
using Weboo.Assess.Tester;

namespace CrucerosTester
{
    public abstract class CrucerosTest : InterfaceTester<IAduana>
    {
        protected override IAduana BuildTarget(object[] args)
        {
            return ReflectionHelper.CreateInstance<IAduana>(args);
        }

        protected override IAduana BuildBenchmark(object[] args)
        {
            int libreDeImpuestos = (int)args[0];
            var tablaImpuestos = (int[,]) args[1];
            int colasSinImpuesto = (int) args[2];
            int colasConImpuesto = (int)args[3];
            return new Aduana(libreDeImpuestos, tablaImpuestos, colasSinImpuesto, colasConImpuesto);
        }

        protected void Ignore<T>(IEnumerable<T> enumerable)
        {
            var list = enumerable.ToList();
            Console.WriteLine(list);
        }
    }

    public class SDV1 : CrucerosTest
    {
        public void SalidaDeVisitantes1()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    public class SDV2 : CrucerosTest
    {
        public void SalidaDeVisitantes2()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("M1", 10))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("M1", 10))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    public class SDV3 : CrucerosTest
    {
        public void SalidaDeVisitantes3()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("M1", 10))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("M1", 10))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    public class SDV4 : CrucerosTest
    {
        public void SalidaDeVisitantes4()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("M1", 50))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("M1", 50))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    public class SDV5 : CrucerosTest
    {
        public void SalidaDeVisitantes5()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("M1", 50)),
                new Visitante("B", new Maleta("M2", 10)),
                new Visitante("C", new Maleta("M3", 40)),
                new Visitante("D", new Maleta("M4", 15))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("M1", 50)),
                new Visitante("B", new Maleta("M2", 10)),
                new Visitante("C", new Maleta("M3", 40)),
                new Visitante("D", new Maleta("M4", 15))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    public class SDV6 : CrucerosTest
    {
        public void SalidaDeVisitantes6()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("M1", 50)),
                new Visitante("B", new Maleta("M2", 10)),
                new Visitante("C", new Maleta("M3", 40)),
                new Visitante("D", new Maleta("M4", 15))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("M1", 50)),
                new Visitante("B", new Maleta("M2", 10)),
                new Visitante("C", new Maleta("M3", 40)),
                new Visitante("D", new Maleta("M4", 15))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    public class SDV7 : CrucerosTest
    {
        public void SalidaDeVisitantes7()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("M1", 50)),
                new Visitante("B", new Maleta("M2", 10)),
                new Visitante("C", new Maleta("M3", 40)),
                new Visitante("D", new Maleta("M4", 15)),
                new Visitante("E", new Maleta("M5", 30))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("M1", 50)),
                new Visitante("B", new Maleta("M2", 10)),
                new Visitante("C", new Maleta("M3", 40)),
                new Visitante("D", new Maleta("M4", 15)),
                new Visitante("E", new Maleta("M5", 30))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    public class SDV8 : CrucerosTest
    {
        public void SalidaDeVisitantes8()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 2), new Maleta("A2", 3), new Maleta("A3", 7), new Maleta("A4", 11), new Maleta("A5", 13)),
                new Visitante("B", new Maleta("B1", 10), new Maleta("B2", 20)),
                new Visitante("C", new Maleta("C1", 40)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 10)),
                new Visitante("E", new Maleta("E1", 30), new Maleta("E2", 1))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 2), new Maleta("A2", 3), new Maleta("A3", 7), new Maleta("A4", 11), new Maleta("A5", 13)),
                new Visitante("B", new Maleta("B1", 10), new Maleta("B2", 20)),
                new Visitante("C", new Maleta("C1", 40)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 10)),
                new Visitante("E", new Maleta("E1", 30), new Maleta("E2", 1))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    public class SDV9 : CrucerosTest
    {
        public void SalidaDeVisitantes9()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 2), new Maleta("A2", 3), new Maleta("A3", 7), new Maleta("A4", 11), new Maleta("A5", 13)),
                new Visitante("B", new Maleta("B1", 10), new Maleta("B2", 20)),
                new Visitante("C", new Maleta("C1", 40)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 10)),
                new Visitante("E", new Maleta("E1", 30), new Maleta("E2", 1))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 2), new Maleta("A2", 3), new Maleta("A3", 7), new Maleta("A4", 11), new Maleta("A5", 13)),
                new Visitante("B", new Maleta("B1", 10), new Maleta("B2", 20)),
                new Visitante("C", new Maleta("C1", 40)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 10)),
                new Visitante("E", new Maleta("E1", 30), new Maleta("E2", 1))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    public class SDV10 : CrucerosTest
    {
        public void SalidaDeVisitantes10()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 2), new Maleta("A2", 3), new Maleta("A3", 7), new Maleta("A4", 11), new Maleta("A5", 13)),
                new Visitante("B", new Maleta("B1", 10), new Maleta("B2", 20)),
                new Visitante("C", new Maleta("C1", 40)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 10)),
                new Visitante("E", new Maleta("E1", 1), new Maleta("E2", 1), new Maleta("E3", 1), new Maleta("E4", 1), new Maleta("E5", 1), new Maleta("E6", 1))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 2), new Maleta("A2", 3), new Maleta("A3", 7), new Maleta("A4", 11), new Maleta("A5", 13)),
                new Visitante("B", new Maleta("B1", 10), new Maleta("B2", 20)),
                new Visitante("C", new Maleta("C1", 40)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 10)),
                new Visitante("E", new Maleta("E1", 1), new Maleta("E2", 1), new Maleta("E3", 1), new Maleta("E4", 1), new Maleta("E5", 1), new Maleta("E6", 1))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    public class SDV11 : CrucerosTest
    {
        public void SalidaDeVisitantes11()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 25)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 90)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 80))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 25)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 90)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 80))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    public class SDV12 : CrucerosTest
    {
        public void SalidaDeVisitantes9()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 25)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C"),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 80))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 25)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C"),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 80))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    public class SDV13 : CrucerosTest
    {
        public void SalidaDeVisitantes13()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 25)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 80)),
                new Visitante("F", new Maleta("F1", 354)),
                new Visitante("G", new Maleta("G1", 12), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 22)),
                new Visitante("I", new Maleta("I1", 48)),
                new Visitante("J", new Maleta("J1", 65), new Maleta("J2", 20)),
                new Visitante("K", new Maleta("K1", 80))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 25)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 80)),
                new Visitante("F", new Maleta("F1", 354)),
                new Visitante("G", new Maleta("G1", 12), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 22)),
                new Visitante("I", new Maleta("I1", 48)),
                new Visitante("J", new Maleta("J1", 65), new Maleta("J2", 20)),
                new Visitante("K", new Maleta("K1", 80))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    //public class SDV14 : CrucerosTest
    //{
    //    public void SalidaDeVisitantes14()
    //    {
    //        int libreImpuesto = 25;
    //        int[,] tablaImpuestos =
    //        {
    //            {26, 50, 5},
    //            {51, 75, 10},
    //            {76, int.MaxValue, 15}
    //        };
    //        int colasSinImpuesto = 2;
    //        int colasConImpuesto = 3;
    //        Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

    //        var visitantesTarget = new[]
    //        {
    //            new Visitante("A", new Maleta("A1", 25)),
    //            new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
    //            new Visitante("C", new Maleta("C1", 1)),
    //            new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
    //            new Visitante("E", new Maleta("E1", 80)),
    //            new Visitante("F", new Maleta("F1", 354)),
    //            new Visitante("G", new Maleta("G1", 12), new Maleta("G2", 10)),
    //            new Visitante("H", new Maleta("H1", 22)),
    //            new Visitante("I", new Maleta("I1", 48)),
    //            new Visitante("J", new Maleta("J1", 65), new Maleta("J2", 20)),
    //            new Visitante("K", new Maleta("K1", 80))
    //        };
    //        var visitantesBenchmark = new[]
    //        {
    //            new Visitante("A", new Maleta("A1", 25)),
    //            new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
    //            new Visitante("C", new Maleta("C1", 1)),
    //            new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
    //            new Visitante("E", new Maleta("E1", 80)),
    //            new Visitante("F", new Maleta("F1", 354)),
    //            new Visitante("G", new Maleta("G1", 12), new Maleta("G2", 10)),
    //            new Visitante("H", new Maleta("H1", 22)),
    //            new Visitante("I", new Maleta("I1", 48)),
    //            new Visitante("J", new Maleta("J1", 65), new Maleta("J2", 20)),
    //            new Visitante("K", new Maleta("K1", 80))
    //        };

    //        PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
    //        PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

    //        Assert.That(visitantesTarget, Is.SequenceEqualTo(visitantesBenchmark));
    //    }
    //}

    //public class SDV15 : CrucerosTest
    //{
    //    public void SalidaDeVisitantes15()
    //    {
    //        int libreImpuesto = 25;
    //        int[,] tablaImpuestos =
    //        {
    //            {26, 50, 5},
    //            {51, 75, 10},
    //            {76, int.MaxValue, 15}
    //        };
    //        int colasSinImpuesto = 2;
    //        int colasConImpuesto = 3;
    //        Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

    //        var visitantesTarget = new[]
    //        {
    //            new Visitante("A", new Maleta("A1", 25)),
    //            new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
    //            new Visitante("C", new Maleta("C1", 1)),
    //            new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
    //            new Visitante("E", new Maleta("E1", 80)),
    //            new Visitante("F", new Maleta("F1", 354)),
    //            new Visitante("G", new Maleta("G1", 12), new Maleta("G2", 10)),
    //            new Visitante("H", new Maleta("H1", 22)),
    //            new Visitante("I", new Maleta("I1", 48)),
    //            new Visitante("J", new Maleta("J1", 65), new Maleta("J2", 20)),
    //            new Visitante("K", new Maleta("K1", 80))
    //        };
    //        var visitantesBenchmark = new[]
    //        {
    //            new Visitante("A", new Maleta("A1", 25)),
    //            new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
    //            new Visitante("C", new Maleta("C1", 1)),
    //            new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
    //            new Visitante("E", new Maleta("E1", 80)),
    //            new Visitante("F", new Maleta("F1", 354)),
    //            new Visitante("G", new Maleta("G1", 12), new Maleta("G2", 10)),
    //            new Visitante("H", new Maleta("H1", 22)),
    //            new Visitante("I", new Maleta("I1", 48)),
    //            new Visitante("J", new Maleta("J1", 65), new Maleta("J2", 20)),
    //            new Visitante("K", new Maleta("K1", 80))
    //        };

    //        PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
    //        PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

    //        Check(aduana => aduana.SalidaDeVisitantes());
    //        Assert.That(visitantesTarget, Is.SequenceEqualTo(visitantesBenchmark));
    //    }
    //}

    //public class SDV16 : CrucerosTest
    //{
    //    public void SalidaDeVisitantes16()
    //    {
    //        int libreImpuesto = 25;
    //        int[,] tablaImpuestos =
    //        {
    //            {26, 50, 5},
    //            {51, 75, 10},
    //            {76, int.MaxValue, 15}
    //        };
    //        int colasSinImpuesto = 2;
    //        int colasConImpuesto = 3;
    //        Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

    //        var visitantesTarget = new[]
    //        {
    //            new Visitante("A", new Maleta("A1", 25)),
    //            new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
    //            new Visitante("C", new Maleta("C1", 1)),
    //            new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
    //            new Visitante("E", new Maleta("E1", 80)),
    //            new Visitante("F", new Maleta("F1", 354)),
    //            new Visitante("G", new Maleta("G1", 12), new Maleta("G2", 10)),
    //            new Visitante("H", new Maleta("H1", 22)),
    //            new Visitante("I", new Maleta("I1", 48)),
    //            new Visitante("J", new Maleta("J1", 65), new Maleta("J2", 20)),
    //            new Visitante("K", new Maleta("K1", 80))
    //        };
    //        var visitantesBenchmark = new[]
    //        {
    //            new Visitante("A", new Maleta("A1", 25)),
    //            new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
    //            new Visitante("C", new Maleta("C1", 1)),
    //            new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
    //            new Visitante("E", new Maleta("E1", 80)),
    //            new Visitante("F", new Maleta("F1", 354)),
    //            new Visitante("G", new Maleta("G1", 12), new Maleta("G2", 10)),
    //            new Visitante("H", new Maleta("H1", 22)),
    //            new Visitante("I", new Maleta("I1", 48)),
    //            new Visitante("J", new Maleta("J1", 65), new Maleta("J2", 20)),
    //            new Visitante("K", new Maleta("K1", 80))
    //        };

    //        PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
    //        PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

    //        Check(aduana => aduana.SalidaDeVisitantes());
    //        Assert.That(visitantesTarget, Is.SequenceEqualTo(visitantesBenchmark));
    //    }
    //}

    public class SDV17 : CrucerosTest
    {
        public void SalidaDeVisitantes17()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 1;
            int colasConImpuesto = 7;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 25)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 80)),
                new Visitante("F", new Maleta("F1", 354)),
                new Visitante("G", new Maleta("G1", 12), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 22), new Maleta("H2", 5), new Maleta("H3", 10), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 48)),
                new Visitante("J", new Maleta("J1", 65), new Maleta("J2", 20)),
                new Visitante("K", new Maleta("K1", 80))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 25)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 80)),
                new Visitante("F", new Maleta("F1", 354)),
                new Visitante("G", new Maleta("G1", 12), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 22), new Maleta("H2", 5), new Maleta("H3", 10), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 48)),
                new Visitante("J", new Maleta("J1", 65), new Maleta("J2", 20)),
                new Visitante("K", new Maleta("K1", 80))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    public class SDV18 : CrucerosTest
    {
        public void SalidaDeVisitantes18()
        {
            int libreImpuesto = 10;
            int[,] tablaImpuestos =
            {
                {11, 26, 40},
                {27, 28, 10},
                {29, 75, 20},
                {76, 100, 2},
                {101, int.MaxValue, 15}
            };
            int colasSinImpuesto = 1;
            int colasConImpuesto = 7;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 25)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 80)),
                new Visitante("F", new Maleta("F1", 354)),
                new Visitante("G", new Maleta("G1", 12), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 22), new Maleta("H2", 5), new Maleta("H3", 10), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 48)),
                new Visitante("J", new Maleta("J1", 65), new Maleta("J2", 20)),
                new Visitante("K", new Maleta("K1", 80))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 25)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 80)),
                new Visitante("F", new Maleta("F1", 354)),
                new Visitante("G", new Maleta("G1", 12), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 22), new Maleta("H2", 5), new Maleta("H3", 10), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 48)),
                new Visitante("J", new Maleta("J1", 65), new Maleta("J2", 20)),
                new Visitante("K", new Maleta("K1", 80))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    public class SDV19 : CrucerosTest
    {
        public void SalidaDeVisitantes19()
        {
            int libreImpuesto = 10;
            int[,] tablaImpuestos =
            {
                {11, 26, 40},
                {27, 28, 10},
                {29, 75, 20},
                {76, 100, 2},
                {101, int.MaxValue, 15}
            };
            int colasSinImpuesto = 1;
            int colasConImpuesto = 7;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 2), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 2), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    public class SDV20 : CrucerosTest
    {
        public void SalidaDeVisitantes20()
        {
            int libreImpuesto = 10;
            int[,] tablaImpuestos =
            {
                {11, 26, 40},
                {27, 28, 10},
                {29, 75, 20},
                {76, 100, 2},
                {101, int.MaxValue, 15}
            };
            int colasSinImpuesto = 1;
            int colasConImpuesto = 7;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    public class SDV21 : CrucerosTest
    {
        public void SalidaDeVisitantes21()
        {
            int libreImpuesto = 10;
            int[,] tablaImpuestos =
            {
                {11, 26, 40},
                {27, 28, 10},
                {29, 75, 20},
                {76, 100, 2},
                {101, int.MaxValue, 15}
            };
            int colasSinImpuesto = 1;
            int colasConImpuesto = 7;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4))
            };
            var visitantesTarget2 = new[]
            {
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4))
            };
            var visitantesBenchmark2 = new[]
            {
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget2));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark2));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    public class SDV22 : CrucerosTest
    {
        public void SalidaDeVisitantes22()
        {
            int libreImpuesto = 10;
            int[,] tablaImpuestos =
            {
                {11, 26, 40},
                {27, 28, 10},
                {29, 75, 20},
                {76, 100, 2},
                {101, int.MaxValue, 15}
            };
            int colasSinImpuesto = 1;
            int colasConImpuesto = 7;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5))
            };
            var visitantesTarget2 = new[]
            {
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2))
            };
            var visitantesTarget3 = new[]
            {
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5))
            };
            var visitantesBenchmark2 = new[]
            {
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2))
            };
            var visitantesBenchmark3 = new[]
            {
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget2));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark2));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget3));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark3));

            CheckSequence(aduana => aduana.SalidaDeVisitantes());
            CheckSequence(aduana => aduana.SalidaDeVisitantes());
        }
    }

    public class TMDE1 : CrucerosTest
    {
        public void TiempoMaximoDeEspera1()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            Check(aduana => aduana.TiempoMaximoDeEspera);
        }
    }

    public class TMDE2 : CrucerosTest
    {
        public void TiempoMaximoDeEspera2()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("M1", 10))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("M1", 10))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            Check(aduana => aduana.TiempoMaximoDeEspera);
        }
    }

    public class TMDE3 : CrucerosTest
    {
        public void TiempoMaximoDeEspera3()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("M1", 10))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("M1", 10))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            Check(aduana => aduana.TiempoMaximoDeEspera);
        }
    }

    public class TMDE4 : CrucerosTest
    {
        public void TiempoMaximoDeEspera4()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 2;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 2), new Maleta("A2", 3), new Maleta("A3", 7), new Maleta("A4", 11), new Maleta("A5", 13)),
                new Visitante("B", new Maleta("B1", 10), new Maleta("B2", 20)),
                new Visitante("C", new Maleta("C1", 40)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 10)),
                new Visitante("E", new Maleta("E1", 30), new Maleta("E2", 1))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 2), new Maleta("A2", 3), new Maleta("A3", 7), new Maleta("A4", 11), new Maleta("A5", 13)),
                new Visitante("B", new Maleta("B1", 10), new Maleta("B2", 20)),
                new Visitante("C", new Maleta("C1", 40)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 10)),
                new Visitante("E", new Maleta("E1", 30), new Maleta("E2", 1))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            Check(aduana => aduana.TiempoMaximoDeEspera);
        }
    }

    public class TMDE5 : CrucerosTest
    {
        public void TiempoMaximoDeEspera5()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 2;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 2), new Maleta("A2", 3), new Maleta("A3", 7), new Maleta("A4", 11), new Maleta("A5", 13)),
                new Visitante("B", new Maleta("B1", 10), new Maleta("B2", 20)),
                new Visitante("C", new Maleta("C1", 40)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 10)),
                new Visitante("E", new Maleta("E1", 30), new Maleta("E2", 1))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 2), new Maleta("A2", 3), new Maleta("A3", 7), new Maleta("A4", 11), new Maleta("A5", 13)),
                new Visitante("B", new Maleta("B1", 10), new Maleta("B2", 20)),
                new Visitante("C", new Maleta("C1", 40)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 10)),
                new Visitante("E", new Maleta("E1", 30), new Maleta("E2", 1))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            Check(aduana => aduana.TiempoMaximoDeEspera);
        }
    }

    public class TMDE6 : CrucerosTest
    {
        public void TiempoMaximoDeEspera6()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 1;
            int colasConImpuesto = 7;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 25)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 80)),
                new Visitante("F", new Maleta("F1", 354)),
                new Visitante("G", new Maleta("G1", 12), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 22), new Maleta("H2", 5), new Maleta("H3", 10), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 48)),
                new Visitante("J", new Maleta("J1", 65), new Maleta("J2", 20)),
                new Visitante("K", new Maleta("K1", 80))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 25)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 80)),
                new Visitante("F", new Maleta("F1", 354)),
                new Visitante("G", new Maleta("G1", 12), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 22), new Maleta("H2", 5), new Maleta("H3", 10), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 48)),
                new Visitante("J", new Maleta("J1", 65), new Maleta("J2", 20)),
                new Visitante("K", new Maleta("K1", 80))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            Check(aduana => aduana.TiempoMaximoDeEspera);
        }
    }

    public class TMDE7 : CrucerosTest
    {
        public void TiempoMaximoDeEspera7()
        {
            int libreImpuesto = 10;
            int[,] tablaImpuestos =
            {
                {11, 26, 40},
                {27, 28, 10},
                {29, 75, 20},
                {76, 100, 2},
                {101, int.MaxValue, 15}
            };
            int colasSinImpuesto = 1;
            int colasConImpuesto = 7;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            Check(aduana => aduana.TiempoMaximoDeEspera);
        }
    }

    public class TMDE8 : CrucerosTest
    {
        public void TiempoMaximaDeEspera8()
        {
            int libreImpuesto = 10;
            int[,] tablaImpuestos =
            {
                {11, 26, 40},
                {27, 28, 10},
                {29, 75, 20},
                {76, 100, 2},
                {101, int.MaxValue, 15}
            };
            int colasSinImpuesto = 1;
            int colasConImpuesto = 7;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5))
            };
            var visitantesTarget2 = new[]
            {
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2))
            };
            var visitantesTarget3 = new[]
            {
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5))
            };
            var visitantesBenchmark2 = new[]
            {
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2))
            };
            var visitantesBenchmark3 = new[]
            {
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            Check(aduana => aduana.TiempoMaximoDeEspera);

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget2));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark2));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            Check(aduana => aduana.TiempoMaximoDeEspera);

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget3));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark3));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            Check(aduana => aduana.TiempoMaximoDeEspera);
        }
    }

    public class ITP1 : CrucerosTest
    {
        public void ImpuestoTotalPagado1()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            Check(aduana => aduana.ImpuestoTotalPagado);
        }
    }

    public class ITP2 : CrucerosTest
    {
        public void ImpuestoTotalPagado2()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("M1", 10))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("M1", 10))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            Check(aduana => aduana.ImpuestoTotalPagado);
        }
    }

    public class ITP3 : CrucerosTest
    {
        public void ImpuestoTotalPagado3()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("M1", 10))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("M1", 10))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            Check(aduana => aduana.ImpuestoTotalPagado);
        }
    }

    public class ITP4 : CrucerosTest
    {
        public void ImpuestoTotalPagado4()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 2;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 2), new Maleta("A2", 3), new Maleta("A3", 7), new Maleta("A4", 11), new Maleta("A5", 13)),
                new Visitante("B", new Maleta("B1", 10), new Maleta("B2", 20)),
                new Visitante("C", new Maleta("C1", 40)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 10)),
                new Visitante("E", new Maleta("E1", 30), new Maleta("E2", 1))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 2), new Maleta("A2", 3), new Maleta("A3", 7), new Maleta("A4", 11), new Maleta("A5", 13)),
                new Visitante("B", new Maleta("B1", 10), new Maleta("B2", 20)),
                new Visitante("C", new Maleta("C1", 40)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 10)),
                new Visitante("E", new Maleta("E1", 30), new Maleta("E2", 1))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            Check(aduana => aduana.ImpuestoTotalPagado);
        }
    }

    public class ITP5 : CrucerosTest
    {
        public void ImpuestoTotalPagado5()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 2;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 2), new Maleta("A2", 3), new Maleta("A3", 7), new Maleta("A4", 11), new Maleta("A5", 13)),
                new Visitante("B", new Maleta("B1", 10), new Maleta("B2", 20)),
                new Visitante("C", new Maleta("C1", 40)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 10)),
                new Visitante("E", new Maleta("E1", 30), new Maleta("E2", 1))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 2), new Maleta("A2", 3), new Maleta("A3", 7), new Maleta("A4", 11), new Maleta("A5", 13)),
                new Visitante("B", new Maleta("B1", 10), new Maleta("B2", 20)),
                new Visitante("C", new Maleta("C1", 40)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 10)),
                new Visitante("E", new Maleta("E1", 30), new Maleta("E2", 1))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            Check(aduana => aduana.ImpuestoTotalPagado);
        }
    }

    public class ITP6 : CrucerosTest
    {
        public void ImpuestoTotalPagado6()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 1;
            int colasConImpuesto = 7;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 25)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 80)),
                new Visitante("F", new Maleta("F1", 354)),
                new Visitante("G", new Maleta("G1", 12), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 22), new Maleta("H2", 5), new Maleta("H3", 10), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 48)),
                new Visitante("J", new Maleta("J1", 65), new Maleta("J2", 20)),
                new Visitante("K", new Maleta("K1", 80))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 25)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 20), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 80)),
                new Visitante("F", new Maleta("F1", 354)),
                new Visitante("G", new Maleta("G1", 12), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 22), new Maleta("H2", 5), new Maleta("H3", 10), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 48)),
                new Visitante("J", new Maleta("J1", 65), new Maleta("J2", 20)),
                new Visitante("K", new Maleta("K1", 80))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            Check(aduana => aduana.ImpuestoTotalPagado);
        }
    }

    public class ITP7 : CrucerosTest
    {
        public void ImpuestoTotalPagado7()
        {
            int libreImpuesto = 10;
            int[,] tablaImpuestos =
            {
                {11, 26, 40},
                {27, 28, 10},
                {29, 75, 20},
                {76, 100, 2},
                {101, int.MaxValue, 15}
            };
            int colasSinImpuesto = 1;
            int colasConImpuesto = 7;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            Check(aduana => aduana.ImpuestoTotalPagado);
        }
    }

    public class ITP8 : CrucerosTest
    {
        public void ImpuestoTotalPagado8()
        {
            int libreImpuesto = 10;
            int[,] tablaImpuestos =
            {
                {11, 26, 40},
                {27, 28, 10},
                {29, 75, 20},
                {76, 100, 2},
                {101, int.MaxValue, 15}
            };
            int colasSinImpuesto = 1;
            int colasConImpuesto = 7;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5))
            };
            var visitantesTarget2 = new[]
            {
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2))
            };
            var visitantesTarget3 = new[]
            {
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5))
            };
            var visitantesBenchmark2 = new[]
            {
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2))
            };
            var visitantesBenchmark3 = new[]
            {
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            Check(aduana => aduana.ImpuestoTotalPagado);

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget2));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark2));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            Check(aduana => aduana.ImpuestoTotalPagado);

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget3));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark3));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            Check(aduana => aduana.ImpuestoTotalPagado);
        }
    }

    public class ECCI1 : CrucerosTest
    {
        public void EnColaConImpuesto1()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            CheckSequence(aduana => aduana.EnColaConImpuesto(1));
        }
    }

    //public class ECCI2 : CrucerosTest
    //{
    //    public void EnColaConImpuesto2()
    //    {
    //        int libreImpuesto = 25;
    //        int[,] tablaImpuestos =
    //        {
    //            {26, 50, 5},
    //            {51, 75, 10},
    //            {76, int.MaxValue, 15}
    //        };
    //        int colasSinImpuesto = 2;
    //        int colasConImpuesto = 3;
    //        Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

    //        var visitantesTarget = new[]
    //        {
    //            new Visitante("A", new Maleta("M1", 50)),
    //            new Visitante("B", new Maleta("M2", 10)),
    //            new Visitante("C", new Maleta("M3", 40)),
    //            new Visitante("D", new Maleta("M4", 15))
    //        };
    //        var visitantesBenchmark = new[]
    //        {
    //            new Visitante("A", new Maleta("M1", 50)),
    //            new Visitante("B", new Maleta("M2", 10)),
    //            new Visitante("C", new Maleta("M3", 40)),
    //            new Visitante("D", new Maleta("M4", 15))
    //        };

    //        PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
    //        PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));
            
    //        Check(aduana => aduana.EnColaConImpuesto(0));
    //    }
    //}

    public class ECCI3 : CrucerosTest
    {
        public void EnColaConImpuesto3()
        {
            int libreImpuesto = 25;
            int[,] tablaImpuestos =
            {
                {26, 50, 5},
                {51, 75, 10},
                {76, int.MaxValue, 15}
            };
            int colasSinImpuesto = 2;
            int colasConImpuesto = 3;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("M1", 50)),
                new Visitante("B", new Maleta("M2", 10)),
                new Visitante("C", new Maleta("M3", 40)),
                new Visitante("D", new Maleta("M4", 15))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("M1", 50)),
                new Visitante("B", new Maleta("M2", 10)),
                new Visitante("C", new Maleta("M3", 40)),
                new Visitante("D", new Maleta("M4", 15))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            CheckSequence(aduana => aduana.EnColaConImpuesto(0));
        }
    }

    public class ECCI4 : CrucerosTest
    {
        public void EnColaConImpuesto4()
        {
            int libreImpuesto = 10;
            int[,] tablaImpuestos =
            {
                {11, 26, 40},
                {27, 28, 10},
                {29, 75, 20},
                {76, 100, 2},
                {101, int.MaxValue, 15}
            };
            int colasSinImpuesto = 1;
            int colasConImpuesto = 7;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));

            CheckSequence(aduana => aduana.EnColaConImpuesto(3));
        }
    }

    public class ECCI5 : CrucerosTest
    {
        public void EnColaConImpuesto5()
        {
            int libreImpuesto = 10;
            int[,] tablaImpuestos =
            {
                {11, 26, 40},
                {27, 28, 10},
                {29, 75, 20},
                {76, 100, 2},
                {101, int.MaxValue, 15}
            };
            int colasSinImpuesto = 1;
            int colasConImpuesto = 7;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5)),
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2)),
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            CheckSequence(aduana => aduana.EnColaConImpuesto(3));
        }
    }

    public class ECSI1 : CrucerosTest
    {
        public void EnColaSinImpuesto1()
        {
            int libreImpuesto = 10;
            int[,] tablaImpuestos =
            {
                {11, 26, 40},
                {27, 28, 10},
                {29, 75, 20},
                {76, 100, 2},
                {101, int.MaxValue, 15}
            };
            int colasSinImpuesto = 3;
            int colasConImpuesto = 7;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5))
            };
            var visitantesTarget2 = new[]
            {
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5))
            };
            var visitantesBenchmark2 = new[]
            {
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            CheckSequence(aduana => aduana.EnColaSinImpuesto(2));

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget2));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark2));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            CheckSequence(aduana => aduana.EnColaSinImpuesto(0));
            CheckSequence(aduana => aduana.EnColaSinImpuesto(1));
            CheckSequence(aduana => aduana.EnColaSinImpuesto(2));
        }
    }

    public class ECSI2 : CrucerosTest
    {
        public void EnColaSinImpuesto2()
        {
            int libreImpuesto = 10;
            int[,] tablaImpuestos =
            {
                {11, 26, 40},
                {27, 28, 10},
                {29, 75, 20},
                {76, 100, 2},
                {101, int.MaxValue, 15}
            };
            int colasSinImpuesto = 3;
            int colasConImpuesto = 7;
            Initialize(libreImpuesto, tablaImpuestos, colasSinImpuesto, colasConImpuesto);

            var visitantesTarget = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5))
            };
            var visitantesTarget2 = new[]
            {
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2))
            };
            var visitantesTarget3 = new[]
            {
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };
            var visitantesBenchmark = new[]
            {
                new Visitante("A", new Maleta("A1", 11)),
                new Visitante("B", new Maleta("B1", 20), new Maleta("B2", 6)),
                new Visitante("C", new Maleta("C1", 1)),
                new Visitante("D", new Maleta("D1", 2), new Maleta("D2", 5))
            };
            var visitantesBenchmark2 = new[]
            {
                new Visitante("E", new Maleta("E1", 8)),
                new Visitante("F", new Maleta("F1", 4)),
                new Visitante("G", new Maleta("G1", 1), new Maleta("G2", 10)),
                new Visitante("H", new Maleta("H1", 2), new Maleta("H2", 5), new Maleta("H3", 1), new Maleta("H4", 2))
            };
            var visitantesBenchmark3 = new[]
            {
                new Visitante("I", new Maleta("I1", 8)),
                new Visitante("J", new Maleta("J1", 6), new Maleta("J2", 2)),
                new Visitante("K", new Maleta("K1", 10))
            };

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            CheckSequence(aduana => aduana.EnColaSinImpuesto(2));

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget2));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark2));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            CheckSequence(aduana => aduana.EnColaSinImpuesto(1));

            PerformTarget(aduana => aduana.LlegadaDeCrucero(visitantesTarget3));
            PerformBenchmark(aduana => aduana.LlegadaDeCrucero(visitantesBenchmark3));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));
            Perform(aduana => Ignore(aduana.SalidaDeVisitantes()));

            CheckSequence(aduana => aduana.EnColaSinImpuesto(2));
        }
    }
}
