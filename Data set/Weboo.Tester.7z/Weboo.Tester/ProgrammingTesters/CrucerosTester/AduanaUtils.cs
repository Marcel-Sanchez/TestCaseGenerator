﻿using System;
using System.Collections.Generic;
using System.Linq;
using Interfaces;

namespace CrucerosTester
{
    public class Aduana : IAduana
    {
        public Aduana(int libreDeImpuestos, int[,] tablaImpuestos, int colasSinImpuesto, int colasConImpuesto)
        {
            _withTaxes = new Queue<VisitorWrapper>[colasConImpuesto];
            _withoutTaxes = new Queue<VisitorWrapper>[colasSinImpuesto];
            _taxesTable = tablaImpuestos;

            _currentTurn = 0;
            for (int i = 0; i < colasConImpuesto; i++)
                _withTaxes[i] = new Queue<VisitorWrapper>();
            for (int i = 0; i < colasSinImpuesto; i++)
                _withoutTaxes[i] = new Queue<VisitorWrapper>();
        }

        private class VisitorWrapper
        {
            public VisitorWrapper(int arrivedOn, IVisitante visitor)
            {
                ArrivedOnTurn = arrivedOn;
                SuitcasesToProcess = visitor.Equipaje.Count();
                Visitor = visitor;
                TotalWeight = visitor.Equipaje.Sum(m => m.Peso);
            }

            public int ArrivedOnTurn { get; }

            public int SuitcasesToProcess { get; set; }

            public IVisitante Visitor { get; }

            public int TotalWeight { get; }
        }

        private Queue<VisitorWrapper>[] _withTaxes;
        private Queue<VisitorWrapper>[] _withoutTaxes;
        private int[,] _taxesTable;

        private int _currentTurn;

        private int MinIndex<T>(Queue<T>[] collection)
        {
            int minIndex = 0;
            for (int i = 1; i < collection.Length; i++)
            {
                if (collection[i].Count < collection[minIndex].Count)
                {
                    minIndex = i;
                }
            }

            return minIndex;
        }
        private void UpdateProperties(VisitorWrapper wrapper)
        {
            if (TiempoMaximoDeEspera < _currentTurn - wrapper.ArrivedOnTurn)
                TiempoMaximoDeEspera = _currentTurn - wrapper.ArrivedOnTurn;

            int totalAmount = 0;
            for (int i = 0; i < _taxesTable.GetLength(0); i++)
            {
                int k = Math.Min(wrapper.TotalWeight, _taxesTable[i, 1]);
                totalAmount += Math.Max(0, k - _taxesTable[i, 0] + 1) * _taxesTable[i, 2];
            }

            if (totalAmount > 0)
            {
                wrapper.Visitor.CantidadAPagar = totalAmount;
                ImpuestoTotalPagado += totalAmount;
            }
        }

        public void LlegadaDeCrucero(IEnumerable<IVisitante> visitantes)
        {
            foreach (var visitor in visitantes)
            {
                var wrapper = new VisitorWrapper(_currentTurn, visitor);
                if (wrapper.TotalWeight < _taxesTable[0, 0])
                {
                    int index = MinIndex(_withoutTaxes);
                    _withoutTaxes[index].Enqueue(wrapper);
                }
                else
                {
                    int index = MinIndex(_withTaxes);
                    _withTaxes[index].Enqueue(wrapper);
                }
            }
        }

        public IEnumerable<IVisitante> SalidaDeVisitantes()
        {
            _currentTurn++;
            foreach (var queue in _withoutTaxes)
            {
                if (queue.Count > 0)
                {
                    var wrapper = queue.Dequeue();
                    UpdateProperties(wrapper);

                    yield return wrapper.Visitor;
                }
            }

            foreach (var queue in _withTaxes)
            {
                if (queue.Count > 0)
                {
                    var wrapper = queue.Peek();
                    wrapper.SuitcasesToProcess--;
                    if (wrapper.SuitcasesToProcess < 1)
                    {
                        queue.Dequeue();
                        UpdateProperties(wrapper);

                        yield return wrapper.Visitor;
                    }
                }
            }
        }

        public IEnumerable<IVisitante> EnColaSinImpuesto(int colaNumero)
        {
            return _withoutTaxes[colaNumero].Select(m => m.Visitor);
        }

        public IEnumerable<IVisitante> EnColaConImpuesto(int colaNumero)
        {
            return _withTaxes[colaNumero].Select(m => m.Visitor);
        }

        public int TiempoMaximoDeEspera { get; set; }
        public int ImpuestoTotalPagado { get; set; }
    }

    public class Maleta : IMaleta
    {
        public Maleta(string descripcion, int peso)
        {
            Descripcion = descripcion;
            Peso = peso;
        }

        public string Descripcion { get; }
        public int Peso { get; }

        public override bool Equals(object obj)
        {
            var other = obj as IMaleta;
            if (other == null)
                return false;

            return other.Descripcion == Descripcion && other.Peso == Peso;
        }

        // auto-generated
        public override int GetHashCode()
        {
            var hashCode = -637806382;
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Descripcion);
            hashCode = hashCode * -1521134295 + Peso.GetHashCode();
            return hashCode;
        }
    }

    public class Visitante : IVisitante
    {
        public Visitante(string nombre, params Maleta[] equipaje)
        {
            Nombre = nombre;
            Equipaje = equipaje;
        }
        public string Nombre { get; }
        public IEnumerable<IMaleta> Equipaje { get; }
        public int CantidadAPagar { get; set; }

        public override bool Equals(object obj)
        {
            var other = obj as IVisitante;
            if (other == null)
                return false;

            return other.Nombre == Nombre && other.CantidadAPagar == CantidadAPagar &&
                   other.Equipaje.SequenceEqual(Equipaje);
        }

        // auto-generated
        public override int GetHashCode()
        {
            var hashCode = 452455772;
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Nombre);
            hashCode = hashCode * -1521134295 + EqualityComparer<IEnumerable<IMaleta>>.Default.GetHashCode(Equipaje);
            hashCode = hashCode * -1521134295 + CantidadAPagar.GetHashCode();
            return hashCode;
        }

        public override string ToString()
        {
            return $"{Nombre} (${CantidadAPagar})";
        }
    }
}
