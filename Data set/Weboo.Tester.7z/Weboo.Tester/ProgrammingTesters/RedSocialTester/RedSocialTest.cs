﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Assess.Tester;

namespace RedSocialTester
{
    public class RedSocialTest : TestCase
    {
        private static int CantidadMiembrosGrupoMayor(bool[,] amigos)
        {
            return Solve(amigos, 0, new int[amigos.GetLength(0)], 0);
        }

        private static int Solve(bool[,] friends, int p, int[] selecteds, int len)
        {
            if (p == friends.GetLength(0))
            {
                for (int i = 0; i < len; i++)
                {
                    for (int j = i + 1; j < len; j++)
                    {
                        if (!friends[selecteds[i], selecteds[j]])
                        {
                            return 0;
                        }
                    }
                }

                return len;
            }

            selecteds[len] = p;
            int m1 = Solve(friends, p + 1, selecteds, len + 1);
            int m2 = Solve(friends, p + 1, selecteds, len);

            return Math.Max(m1, m2);
        }

        private static int Student(bool[,] amigos)
        {
            return ReflectionHelper.InvokeStatic<int>("Weboo.Examen.RedSocial", "CantidadMiembrosGrupoMayor", amigos);
        }

        public void Basic0()
        {
            bool[,] input = {
                { true,  false, false, false },
                { false, true,  false, false },
                { false, false, true,  false },
                { false, false, false, true  }
            };
            int expectedOutput = 1;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }

        public void Basic1()
        {
            bool[,] input = {
                { true,  false, false, false },
                { false, true,  true,  false },
                { false, true,  true,  false },
                { false, false, false, true  }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }

        public void Basic2()
        {
            bool[,] input = {
                { true,  true, false, false },
                { true,  true, true,  true  },
                { false, true, true,  true  },
                { false, true, true,  true  }
            };
            int expectedOutput = 3;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }

        public void Basic3()
        {
            bool[,] input = {
                { true, true, true, true, true },
                { true, true, true, true, true },
                { true, true, true, true, true },
                { true, true, true, true, true },
                { true, true, true, true, true }
            };
            int expectedOutput = 5;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }

        public void Basic4()
        {
            bool[,] input = {
                { true,  true,  true,  false, true,  true,  true  },
                { true,  true,  true,  false, true,  true,  false },
                { true,  true,  true,  false, true,  true,  false },
                { false, false, false, true,  true,  false, true  },
                { true,  true,  true,  true,  true,  true,  false },
                { true,  true,  true,  false, true,  true,  false },
                { true,  false, false, true,  false, false, true  }
            };
            int expectedOutput = 5;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }

        public void Case0()
        {
            bool[,] input = {
                { true, false },
                { false, true }
            };
            int expectedOutput = 1;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case1()
        {
            bool[,] input = {
                { true, false, true, true, false, true, true, true, true, false, true, true, true },
                { false, true, true, true, false, true, false, true, false, true, true, true, true },
                { true, true, true, true, true, true, true, true, true, true, true, true, true },
                { true, true, true, true, false, true, true, true, true, true, true, true, true },
                { false, false, true, false, true, true, true, true, true, true, true, true, true },
                { true, true, true, true, true, true, true, true, true, true, true, true, true },
                { true, false, true, true, true, true, true, false, true, true, false, true, true },
                { true, true, true, true, true, true, false, true, true, false, false, true, true },
                { true, false, true, true, true, true, true, true, true, true, true, true, false },
                { false, true, true, true, true, true, true, false, true, true, true, true, true },
                { true, true, true, true, true, true, false, false, true, true, true, true, false },
                { true, true, true, true, true, true, true, true, true, true, true, true, true },
                { true, true, true, true, true, true, true, true, false, true, false, true, true }
            };
            int expectedOutput = 7;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case2()
        {
            bool[,] input = {
                { true, true, false, true, false, false, true, false, true },
                { true, true, true, true, true, true, true, true, false },
                { false, true, true, true, true, true, false, true, true },
                { true, true, true, true, true, true, false, false, true },
                { false, true, true, true, true, true, true, true, true },
                { false, true, true, true, true, true, true, true, true },
                { true, true, false, false, true, true, true, true, true },
                { false, true, true, false, true, true, true, true, false },
                { true, false, true, true, true, true, true, false, true }
            };
            int expectedOutput = 5;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case3()
        {
            bool[,] input = {
                { true, false, false, true, true, false },
                { false, true, true, true, true, false },
                { false, true, true, true, true, false },
                { true, true, true, true, false, false },
                { true, true, true, false, true, false },
                { false, false, false, false, false, true }
            };
            int expectedOutput = 3;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case4()
        {
            bool[,] input = {
                { true, false, false, true, false },
                { false, true, false, false, false },
                { false, false, true, true, true },
                { true, false, true, true, false },
                { false, false, true, false, true }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case5()
        {
            bool[,] input = {
                { true, false, false, false, false, false, false, false, false, false },
                { false, true, false, false, false, true, false, true, true, false },
                { false, false, true, false, true, true, false, false, false, false },
                { false, false, false, true, true, false, false, false, true, false },
                { false, false, true, true, true, false, false, false, false, false },
                { false, true, true, false, false, true, false, false, false, false },
                { false, false, false, false, false, false, true, false, false, false },
                { false, true, false, false, false, false, false, true, false, false },
                { false, true, false, true, false, false, false, false, true, false },
                { false, false, false, false, false, false, false, false, false, true }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case6()
        {
            bool[,] input = {
                { true, false, false, false, false, false, false, false, false, false },
                { false, true, false, false, false, false, false, false, false, false },
                { false, false, true, false, false, false, false, false, false, false },
                { false, false, false, true, false, false, false, false, false, false },
                { false, false, false, false, true, false, false, false, false, false },
                { false, false, false, false, false, true, false, false, false, false },
                { false, false, false, false, false, false, true, false, false, false },
                { false, false, false, false, false, false, false, true, false, false },
                { false, false, false, false, false, false, false, false, true, true },
                { false, false, false, false, false, false, false, false, true, true }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case7()
        {
            bool[,] input = {
                { true, false, false, true, true, false, true, false, false, true, true, true, true, true, true },
                { false, true, true, false, true, true, false, false, false, false, false, false, false, true, true },
                { false, true, true, true, false, false, true, false, false, false, true, false, false, true, false },
                { true, false, true, true, true, false, false, true, true, false, false, false, true, false, false },
                { true, true, false, true, true, false, false, false, false, false, false, false, false, true, true },
                { false, true, false, false, false, true, true, false, false, false, true, true, true, false, false },
                { true, false, true, false, false, true, true, false, false, false, false, false, false, false, true },
                { false, false, false, true, false, false, false, true, true, false, true, false, true, false, true },
                { false, false, false, true, false, false, false, true, true, true, true, true, false, false, true },
                { true, false, false, false, false, false, false, false, true, true, true, true, true, false, false },
                { true, false, true, false, false, true, false, true, true, true, true, false, true, true, true },
                { true, false, false, false, false, true, false, false, true, true, false, true, true, false, true },
                { true, false, false, true, false, true, false, true, false, true, true, true, true, false, false },
                { true, true, true, false, true, false, false, false, false, false, true, false, false, true, false },
                { true, true, false, false, true, false, true, true, true, false, true, true, false, false, true }
            };
            int expectedOutput = 4;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case8()
        {
            bool[,] input = {
                { true, true, true, true },
                { true, true, false, false },
                { true, false, true, false },
                { true, false, false, true }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case9()
        {
            bool[,] input = {
                { true, false, true, false, false, true, true, false, true, true, true },
                { false, true, false, false, false, true, true, true, true, true, true },
                { true, false, true, true, true, false, true, true, true, false, true },
                { false, false, true, true, true, true, false, true, true, true, true },
                { false, false, true, true, true, true, false, true, true, true, true },
                { true, true, false, true, true, true, true, true, true, true, false },
                { true, true, true, false, false, true, true, false, false, true, true },
                { false, true, true, true, true, true, false, true, false, true, false },
                { true, true, true, true, true, true, false, false, true, true, false },
                { true, true, false, true, true, true, true, true, true, true, true },
                { true, true, true, true, true, false, true, false, false, true, true }
            };
            int expectedOutput = 5;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case10()
        {
            bool[,] input = {
                { true, true, true },
                { true, true, true },
                { true, true, true }
            };
            int expectedOutput = 3;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case11()
        {
            bool[,] input = {
                { true, true, true, true, true, true, true, false, true, true, true, true, true, true, true },
                { true, true, true, true, true, true, true, true, false, true, true, true, false, true, true },
                { true, true, true, true, false, true, false, true, true, true, true, false, true, true, true },
                { true, true, true, true, true, true, true, true, false, true, true, false, true, false, true },
                { true, true, false, true, true, true, true, true, false, false, true, true, true, true, true },
                { true, true, true, true, true, true, true, true, true, false, true, true, true, true, true },
                { true, true, false, true, true, true, true, true, true, false, true, true, true, true, true },
                { false, true, true, true, true, true, true, true, true, true, true, true, false, true, true },
                { true, false, true, false, false, true, true, true, true, true, true, true, true, false, true },
                { true, true, true, true, false, false, false, true, true, true, true, true, true, true, true },
                { true, true, true, true, true, true, true, true, true, true, true, true, true, true, true },
                { true, true, false, false, true, true, true, true, true, true, true, true, true, true, true },
                { true, false, true, true, true, true, true, false, true, true, true, true, true, true, true },
                { true, true, true, false, true, true, true, true, false, true, true, true, true, true, true },
                { true, true, true, true, true, true, true, true, true, true, true, true, true, true, true }
            };
            int expectedOutput = 9;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case12()
        {
            bool[,] input = {
                { true, false, false },
                { false, true, true },
                { false, true, true }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case13()
        {
            bool[,] input = {
                { true, false, true, false, true, false, true, false, true, true, false, false, false, false },
                { false, true, false, false, false, false, false, false, false, false, false, false, false, true },
                { true, false, true, false, true, true, false, false, false, false, false, true, true, false },
                { false, false, false, true, false, false, true, false, false, false, false, true, true, false },
                { true, false, true, false, true, false, true, false, false, true, false, false, false, false },
                { false, false, true, false, false, true, false, false, false, false, false, false, false, false },
                { true, false, false, true, true, false, true, false, false, true, false, false, false, false },
                { false, false, false, false, false, false, false, true, false, false, true, false, false, false },
                { true, false, false, false, false, false, false, false, true, false, false, false, false, false },
                { true, false, false, false, true, false, true, false, false, true, false, false, false, false },
                { false, false, false, false, false, false, false, true, false, false, true, false, true, true },
                { false, false, true, true, false, false, false, false, false, false, false, true, false, false },
                { false, false, true, true, false, false, false, false, false, false, true, false, true, true },
                { false, true, false, false, false, false, false, false, false, false, true, false, true, true }
            };
            int expectedOutput = 4;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case14()
        {
            bool[,] input = {
                { true, true, true, false, true },
                { true, true, true, false, true },
                { true, true, true, true, false },
                { false, false, true, true, false },
                { true, true, false, false, true }
            };
            int expectedOutput = 3;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case15()
        {
            bool[,] input = {
                { true, true, true, true, true, true, true, true, true, false },
                { true, true, true, true, true, true, true, true, true, true },
                { true, true, true, true, true, false, true, false, true, true },
                { true, true, true, true, false, false, true, true, true, true },
                { true, true, true, false, true, true, true, false, true, false },
                { true, true, false, false, true, true, true, false, true, false },
                { true, true, true, true, true, true, true, false, true, true },
                { true, true, false, true, false, false, false, true, true, true },
                { true, true, true, true, true, true, true, true, true, true },
                { false, true, true, true, false, false, true, true, true, true }
            };
            int expectedOutput = 6;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case16()
        {
            bool[,] input = {
                { true, true, true, true, true, true, true, true, true, true, true },
                { true, true, true, true, false, false, true, true, true, false, false },
                { true, true, true, true, true, false, true, true, true, true, false },
                { true, true, true, true, true, true, true, true, true, true, true },
                { true, false, true, true, true, true, true, true, true, true, true },
                { true, false, false, true, true, true, true, true, true, true, true },
                { true, true, true, true, true, true, true, true, true, true, true },
                { true, true, true, true, true, true, true, true, true, true, true },
                { true, true, true, true, true, true, true, true, true, true, false },
                { true, false, true, true, true, true, true, true, true, true, true },
                { true, false, false, true, true, true, true, true, false, true, true }
            };
            int expectedOutput = 8;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case17()
        {
            bool[,] input = {
                { true, true, false, true },
                { true, true, false, false },
                { false, false, true, true },
                { true, false, true, true }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case18()
        {
            bool[,] input = {
                { true, true, true, true, true, true, false, true, true, true },
                { true, true, true, false, true, true, true, true, true, true },
                { true, true, true, true, true, true, true, false, true, true },
                { true, false, true, true, true, true, true, true, true, true },
                { true, true, true, true, true, true, true, true, true, true },
                { true, true, true, true, true, true, true, true, true, false },
                { false, true, true, true, true, true, true, false, true, true },
                { true, true, false, true, true, true, false, true, true, true },
                { true, true, true, true, true, true, true, true, true, true },
                { true, true, true, true, true, false, true, true, true, true }
            };
            int expectedOutput = 6;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case19()
        {
            bool[,] input = {
                { true, false, true, false, true, true },
                { false, true, true, false, true, true },
                { true, true, true, true, false, true },
                { false, false, true, true, true, true },
                { true, true, false, true, true, true },
                { true, true, true, true, true, true }
            };
            int expectedOutput = 3;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case20()
        {
            bool[,] input = {
                { true, true, true, false, false, true, false, true, false, false, true, false, true, false },
                { true, true, true, false, true, true, false, false, true, false, true, true, true, false },
                { true, true, true, false, true, true, true, false, false, false, true, true, false, true },
                { false, false, false, true, false, false, true, true, false, false, true, false, true, false },
                { false, true, true, false, true, true, true, true, true, false, false, true, false, false },
                { true, true, true, false, true, true, true, false, true, true, false, true, false, false },
                { false, false, true, true, true, true, true, false, true, true, false, false, false, true },
                { true, false, false, true, true, false, false, true, true, false, false, false, false, false },
                { false, true, false, false, true, true, true, true, true, true, false, true, true, false },
                { false, false, false, false, false, true, true, false, true, true, true, false, false, true },
                { true, true, true, true, false, false, false, false, false, true, true, true, true, false },
                { false, true, true, false, true, true, false, false, true, false, true, true, false, true },
                { true, true, false, true, false, false, false, false, true, false, true, false, true, true },
                { false, false, true, false, false, false, true, false, false, true, false, true, true, true }
            };
            int expectedOutput = 5;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case21()
        {
            bool[,] input = {
                { true, false, false, false, true, true, false, false, true, false },
                { false, true, true, true, true, false, false, true, true, true },
                { false, true, true, false, true, true, true, true, true, false },
                { false, true, false, true, true, false, true, true, true, false },
                { true, true, true, true, true, true, true, true, false, true },
                { true, false, true, false, true, true, false, true, false, true },
                { false, false, true, true, true, false, true, false, false, false },
                { false, true, true, true, true, true, false, true, false, false },
                { true, true, true, true, false, false, false, false, true, true },
                { false, true, false, false, true, true, false, false, true, true }
            };
            int expectedOutput = 4;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case22()
        {
            bool[,] input = {
                { true, false, true, false, true },
                { false, true, false, false, false },
                { true, false, true, false, false },
                { false, false, false, true, true },
                { true, false, false, true, true }
            };
            int expectedOutput = 2;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case23()
        {
            bool[,] input = {
                { true, true, true, false, true, true, false, false, true },
                { true, true, false, true, false, false, false, true, false },
                { true, false, true, true, false, false, true, false, true },
                { false, true, true, true, false, false, true, false, false },
                { true, false, false, false, true, false, false, true, true },
                { true, false, false, false, false, true, false, true, false },
                { false, false, true, true, false, false, true, false, false },
                { false, true, false, false, true, true, false, true, false },
                { true, false, true, false, true, false, false, false, true }
            };
            int expectedOutput = 3;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }


        public void Case24()
        {
            bool[,] input = {
                { true, true, true },
                { true, true, true },
                { true, true, true }
            };
            int expectedOutput = 3;

            Assert.That(Student(input), Is.EqualTo(expectedOutput));
        }
    }
}
