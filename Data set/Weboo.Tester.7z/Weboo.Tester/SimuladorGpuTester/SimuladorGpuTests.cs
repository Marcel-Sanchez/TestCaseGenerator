﻿using SimulacionGPU;
using System.Linq;
using Weboo.Assess.Tester;

namespace SimuladorGpuTester
{
    public abstract class SimuladorGpuTest : InterfaceTester<ISimuladorGpu>
    {
        protected override ISimuladorGpu BuildBenchmark(object[] args)
        {
            return new SimuladorGpu();
        }

        protected override ISimuladorGpu BuildTarget(object[] args)
        {
            return ReflectionHelper.CreateInstance<ISimuladorGpu>();
        }
    }

    public class CantidadDeProcesadores1Test : SimuladorGpuTest
    {
        public void CantidadDeProcesadores1()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));

            Check(m => m.TotalDeNucleos);
        }
    }

    public class CantidadDeProcesadores2Test : SimuladorGpuTest
    {
        public void CantidadDeProcesadores2()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));

            Check(m => m.TotalDeNucleos);
        }
    }

    public class CantidadDeProcesadores3Test : SimuladorGpuTest
    {
        public void CantidadDeProcesadores3()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "S1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "S2" }));
            Perform(m => m.AdicionaShader(2, new Shader { Duracion = 5, Nombre = "S3" }));

            Check(m => m.TotalDeNucleos);
        }
    }

    public class NucleoIngenuo1Test : SimuladorGpuTest
    {
        public void NucleoIngenuo1()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo2Test : SimuladorGpuTest
    {
        public void NucleoIngenuo2()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));

            CheckSequence(m => m.Procesa(5).ToList());
        }
    }

    public class NucleoIngenuo3Test : SimuladorGpuTest
    {
        public void NucleoIngenuo3()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));
            Perform(m => m.Procesa(5).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo4Test : SimuladorGpuTest
    {
        public void NucleoIngenuo4()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));

            CheckSequence(m => m.Procesa(10).ToList());
        }
    }

    public class NucleoIngenuo5Test : SimuladorGpuTest
    {
        public void NucleoIngenuo5()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));
            Perform(m => m.Procesa(10).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo6Test : SimuladorGpuTest
    {
        public void NucleoIngenuo6()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));

            CheckSequence(m => m.Procesa(30).ToList());
        }
    }

    public class NucleoIngenuo7Test : SimuladorGpuTest
    {
        public void NucleoIngenuo7()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));
            Perform(m => m.Procesa(30).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo8Test : SimuladorGpuTest
    {
        public void NucleoIngenuo8()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));

            CheckSequence(m => m.Procesa(55).ToList());
        }
    }

    public class NucleoIngenuo9Test : SimuladorGpuTest
    {
        public void NucleoIngenuo9()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));
            Perform(m => m.Procesa(55).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo10Test : SimuladorGpuTest
    {
        public void NucleoIngenuo10()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));
            Perform(m => m.Procesa(20).ToList());

            CheckSequence(m => m.Procesa(10).ToList());
        }
    }

    public class NucleoIngenuo11Test : SimuladorGpuTest
    {
        public void NucleoIngenuo11()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));
            Perform(m => m.Procesa(20).ToList());
            Perform(m => m.Procesa(10).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo12Test : SimuladorGpuTest
    {
        public void NucleoIngenuo12()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.Procesa(25).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo13Test : SimuladorGpuTest
    {
        public void NucleoIngenuo13()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.Procesa(25).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));

            CheckSequence(m => m.Procesa(10).ToList());
        }
    }

    public class NucleoIngenuo14Test : SimuladorGpuTest
    {
        public void NucleoIngenuo14()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.Procesa(25).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));
            Perform(m => m.Procesa(10).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo15Test : SimuladorGpuTest
    {
        public void NucleoIngenuo15()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));
            Perform(m => m.Procesa(55).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 15, Nombre = "N4" }));

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo16Test : SimuladorGpuTest
    {
        public void NucleoIngenuo16()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));
            Perform(m => m.Procesa(55).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 15, Nombre = "N4" }));

            CheckSequence(m => m.Procesa(10).ToList());
        }
    }

    public class NucleoIngenuo17Test : SimuladorGpuTest
    {
        public void NucleoIngenuo17()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));
            Perform(m => m.Procesa(55).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 15, Nombre = "N4" }));
            Perform(m => m.Procesa(10).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo18Test : SimuladorGpuTest
    {
        public void NucleoIngenuo18()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));
            Perform(m => m.Procesa(55).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 15, Nombre = "N4" }));
            Perform(m => m.Procesa(10).ToList());

            CheckSequence(m => m.Procesa(20).ToList());
        }
    }

    public class NucleoIngenuo19Test : SimuladorGpuTest
    {
        public void NucleoIngenuo19()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N3" }));
            Perform(m => m.Procesa(55).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 15, Nombre = "N4" }));
            Perform(m => m.Procesa(10).ToList());
            Perform(m => m.Procesa(20).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo20Test : SimuladorGpuTest
    {
        public void NucleoIngenuo20()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.Procesa(10).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 15, Nombre = "N2" }));

            CheckSequence(m => m.Procesa(25).ToList());
        }
    }

    public class NucleoIngenuo21Test : SimuladorGpuTest
    {
        public void NucleoIngenuo21()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.Procesa(10).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 15, Nombre = "N2" }));
            Perform(m => m.Procesa(25).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo22Test : SimuladorGpuTest
    {
        public void NucleoIngenuo22()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.Procesa(20).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 15, Nombre = "N2" }));

            CheckSequence(m => m.Procesa(15).ToList());
        }
    }

    public class NucleoIngenuo23Test : SimuladorGpuTest
    {
        public void NucleoIngenuo23()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.Procesa(20).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 15, Nombre = "N2" }));
            Perform(m => m.Procesa(15).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo24Test : SimuladorGpuTest
    {
        public void NucleoIngenuo24()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));

            Check(m => m.ProximoShaderTerminado());
        }
    }

    public class NucleoIngenuo25Test : SimuladorGpuTest
    {
        public void NucleoIngenuo25()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 15, Nombre = "N2" }));

            Check(m => m.ProximoShaderTerminado());
        }
    }

    public class NucleoIngenuo26Test : SimuladorGpuTest
    {
        public void NucleoIngenuo26()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));

            CheckSequence(m => m.Procesa(10).ToList());
        }
    }

    public class NucleoIngenuo27Test : SimuladorGpuTest
    {
        public void NucleoIngenuo27()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.Procesa(10).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo28Test : SimuladorGpuTest
    {
        public void NucleoIngenuo28()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.Procesa(10).ToList());

            CheckSequence(m => m.Procesa(15).ToList());
        }
    }

    public class NucleoIngenuo29Test : SimuladorGpuTest
    {
        public void NucleoIngenuo29()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.Procesa(10).ToList());
            Perform(m => m.Procesa(15).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo30Test : SimuladorGpuTest
    {
        public void NucleoIngenuo30()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Check(m => m.ProximoShaderTerminado());
        }
    }

    public class NucleoIngenuo31Test : SimuladorGpuTest
    {
        public void NucleoIngenuo31()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));

            CheckSequence(m => m.Procesa(5).ToList());
        }
    }

    public class NucleoIngenuo32Test : SimuladorGpuTest
    {
        public void NucleoIngenuo32()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.Procesa(5).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo33Test : SimuladorGpuTest
    {
        public void NucleoIngenuo33()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.ProximoShaderTerminado());

            Check(m => m.ProximoShaderTerminado());
        }
    }

    public class NucleoIngenuo34Test : SimuladorGpuTest
    {
        public void NucleoIngenuo34()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.ProximoShaderTerminado());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo35Test : SimuladorGpuTest
    {
        public void NucleoIngenuo35()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.SuspendeNucleo(0));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));

            Check(m => m.ProximoShaderTerminado());
        }
    }

    public class NucleoIngenuo36Test : SimuladorGpuTest
    {
        public void NucleoIngenuo36()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.SuspendeNucleo(0));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.ProximoShaderTerminado());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo37Test : SimuladorGpuTest
    {
        public void NucleoIngenuo37()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.SuspendeNucleo(0));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));

            CheckSequence(m => m.Procesa(50).ToList());
        }
    }

    public class NucleoIngenuo38Test : SimuladorGpuTest
    {
        public void NucleoIngenuo38()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.SuspendeNucleo(0));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.Procesa(50).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo39Test : SimuladorGpuTest
    {
        public void NucleoIngenuo39()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.SuspendeNucleo(0));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.ActivaNucleo(0));

            CheckSequence(m => m.Procesa(50).ToList());
        }
    }

    public class NucleoIngenuo40Test : SimuladorGpuTest
    {
        public void NucleoIngenuo40()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.SuspendeNucleo(0));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.ActivaNucleo(0));
            Perform(m => m.Procesa(50).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo41Test : SimuladorGpuTest
    {
        public void NucleoIngenuo41()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.SuspendeNucleo(0));
            Perform(m => m.SuspendeNucleo(0));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoIngenuo42Test : SimuladorGpuTest
    {
        public void NucleoIngenuo42()
        {
            Initialize();

            Perform(m => m.CreaNucleo(15, TipoNucleo.Ingenuo));
            Perform(m => m.ActivaNucleo(0));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "N1" }));

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoTorpe1Test : SimuladorGpuTest
    {
        public void TorpeOrdenInverso1()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "C2" }));

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoTorpe2Test : SimuladorGpuTest
    {
        public void TorpeOrdenInverso2()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.Procesa(5).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "C2" }));

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoTorpe3Test : SimuladorGpuTest
    {
        public void TorpeOrdenInverso3()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.Procesa(5).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "C2" }));

            CheckSequence(m => m.Procesa(10).ToList());
        }
    }

    public class NucleoTorpe4Test : SimuladorGpuTest
    {
        public void TorpeOrdenInverso4()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.Procesa(5).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "C2" }));
            Perform(m => m.Procesa(10).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoTorpe5Test : SimuladorGpuTest
    {
        public void TorpeEsperaDobleDescanso1()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "C2" }));

            CheckSequence(m => m.Procesa(25).ToList());
        }
    }

    public class NucleoTorpe6Test : SimuladorGpuTest
    {
        public void TorpeEsperaDobleDescanso2()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "C2" }));
            Perform(m => m.Procesa(25).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoTorpe7Test : SimuladorGpuTest
    {
        public void TorpeEsperaDobleDescanso3()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "C2" }));
            Perform(m => m.Procesa(25).ToList());

            CheckSequence(m => m.Procesa(10).ToList());
        }
    }

    public class NucleoTorpe8Test : SimuladorGpuTest
    {
        public void TorpeEsperaDobleDescanso4()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "C2" }));
            Perform(m => m.Procesa(25).ToList());

            CheckSequence(m => m.Procesa(10).ToList());
        }
    }

    public class NucleoTorpe9Test : SimuladorGpuTest
    {
        public void TorpeEsperaDobleDescanso5()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "C2" }));
            Perform(m => m.Procesa(25).ToList());
            Perform(m => m.Procesa(10).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoTorpe10Test : SimuladorGpuTest
    {
        public void TorpeEsperaDobleDescanso6()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.Procesa(10).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "C2" }));

            CheckSequence(m => m.Procesa(5).ToList());
        }
    }

    public class NucleoTorpe11Test : SimuladorGpuTest
    {
        public void TorpeEsperaDobleDescanso7()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.Procesa(10).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "C2" }));

            CheckSequence(m => m.Procesa(25).ToList());
        }
    }

    public class NucleoTorpe12Test : SimuladorGpuTest
    {
        public void TorpeEsperaDobleDescanso8()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.Procesa(10).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "C2" }));
            Perform(m => m.Procesa(25).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoInteligente1Test : SimuladorGpuTest
    {
        public void InteligenteOrdenPorDuracion1()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 20, Nombre = "S1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "S2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 15, Nombre = "S3" }));

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoInteligente2Test : SimuladorGpuTest
    {
        public void InteligenteOrdenPorDuracion2()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 20, Nombre = "S1" }));
            Perform(m => m.Procesa(5).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 5, Nombre = "S2" }));

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoInteligente3Test : SimuladorGpuTest
    {
        public void InteligenteOrdenPorDuracion3()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 20, Nombre = "S1" }));
            Perform(m => m.Procesa(15).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "S2" }));

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoInteligente4Test : SimuladorGpuTest
    {
        public void InteligenteDescansaAlSegundoShader1()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 20, Nombre = "S1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "S2" }));

            CheckSequence(m => m.Procesa(30).ToList());
        }
    }

    public class NucleoInteligente5Test : SimuladorGpuTest
    {
        public void InteligenteDescansaAlSegundoShader2()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 20, Nombre = "S1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "S2" }));
            Perform(m => m.Procesa(30).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoInteligente6Test : SimuladorGpuTest
    {
        public void InteligenteDescansaAlSegundoShader3()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 20, Nombre = "S1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "S2" }));
            Perform(m => m.Procesa(30).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 15, Nombre = "S3" }));

            CheckSequence(m => m.Procesa(15).ToList());
        }
    }

    public class NucleoInteligente7Test : SimuladorGpuTest
    {
        public void InteligenteDescansaAlSegundoShader4()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 20, Nombre = "S1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "S2" }));
            Perform(m => m.Procesa(30).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 15, Nombre = "S3" }));
            Perform(m => m.Procesa(15).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class NucleoInteligente8Test : SimuladorGpuTest
    {
        public void InteligenteDescansaAlSegundoShader5()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 20, Nombre = "S1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "S2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 15, Nombre = "S3" }));
            Perform(m => m.ProximoShaderTerminado());

            CheckSequence(m => m.Procesa(25).ToList());
        }
    }

    public class NucleoInteligente9Test : SimuladorGpuTest
    {
        public void InteligenteDescansaAlSegundoShader6()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 20, Nombre = "S1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "S2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 15, Nombre = "S3" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.Procesa(25).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
        }
    }

    public class EnParalelo1Test : SimuladorGpuTest
    {
        public void ProcesaEnParalelo1()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 20, Nombre = "C1" }));

            CheckSequence(m => m.Procesa(20).ToList());
        }
    }

    public class EnParalelo2Test : SimuladorGpuTest
    {
        public void ProcesaEnParalelo2()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 20, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 15, Nombre = "C1" }));

            CheckSequence(m => m.Procesa(20).ToList());
        }
    }

    public class EnParalelo3Test : SimuladorGpuTest
    {
        public void ProcesaEnParalelo3()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.CreaNucleo(5, TipoNucleo.Ingenuo));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 20, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 15, Nombre = "C1" }));
            Perform(m => m.AdicionaShader(2, new Shader { Duracion = 25, Nombre = "NN1" }));

            CheckSequence(m => m.Procesa(25).ToList());
        }
    }

    public class EnParalelo4Test : SimuladorGpuTest
    {
        public void TerminanALaVez1()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 20, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 20, Nombre = "C1" }));

            CheckSequence(m => m.Procesa(20).ToList());
        }
    }

    public class EnParalelo5Test : SimuladorGpuTest
    {
        public void TerminanALaVez2()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 50, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 20, Nombre = "C2" }));

            CheckSequence(m => m.Procesa(50).ToList());
        }
    }

    public class EnParalelo6Test : SimuladorGpuTest
    {
        public void TerminanALaVez3()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 50, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 20, Nombre = "C2" }));

            CheckSequence(m => m.Procesa(50).ToList());
        }
    }

    public class EnParalelo7Test : SimuladorGpuTest
    {
        public void TerminanALaVez4()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 50, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 20, Nombre = "C2" }));

            CheckSequence(m => m.Procesa(50).ToList());
        }
    }

    public class EnParalelo8Test : SimuladorGpuTest
    {
        public void TerminanALaVez5()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));

            Check(m => m.ProximoShaderTerminado());
        }
    }

    public class EnParalelo9Test : SimuladorGpuTest
    {
        public void TerminanALaVez6()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.ProximoShaderTerminado());

            CheckSequence(m => m.ShadersEnNucleo(0));
            CheckSequence(m => m.ShadersEnNucleo(1));
        }
    }

    public class EnParalelo10Test : SimuladorGpuTest
    {
        public void TerminanALaVez7()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.AdicionaShader(2, new Shader { Duracion = 10, Nombre = "S1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));

            Check(m => m.ProximoShaderTerminado());
        }
    }

    public class EnParalelo11Test : SimuladorGpuTest
    {
        public void TerminanALaVez8()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.AdicionaShader(2, new Shader { Duracion = 10, Nombre = "S1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.ProximoShaderTerminado());

            CheckSequence(m => m.ShadersEnNucleo(0));
            CheckSequence(m => m.ShadersEnNucleo(1));
            CheckSequence(m => m.ShadersEnNucleo(2));
        }
    }

    public class EnParalelo12Test : SimuladorGpuTest
    {
        public void CeroCiclos1()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C2" }));

            CheckSequence(m => m.ShadersEnNucleo(1));
        }
    }

    public class EnParalelo13Test : SimuladorGpuTest
    {
        public void CeroCiclos2()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));

            Check(m => m.ProximoShaderTerminado());
        }
    }

    public class EnParalelo14Test : SimuladorGpuTest
    {
        public void CeroCiclos3()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.ProximoShaderTerminado());

            CheckSequence(m => m.ShadersEnNucleo(0));
            CheckSequence(m => m.ShadersEnNucleo(1));
        }
    }

    public class EnParalelo15Test : SimuladorGpuTest
    {
        public void CeroCiclos4()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));

            CheckSequence(m => m.Procesa(20).ToList());
        }
    }

    public class EnParalelo16Test : SimuladorGpuTest
    {
        public void CeroCiclos5()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(5, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));

            CheckSequence(m => m.Procesa(20).ToList());
        }
    }

    public class EnParalelo17Test : SimuladorGpuTest
    {
        public void CeroCiclos6()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(5, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.Procesa(20).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
            CheckSequence(m => m.ShadersEnNucleo(1));
        }
    }

    public class EnParalelo18Test : SimuladorGpuTest
    {
        public void CeroCiclos7()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(5, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));

            CheckSequence(m => m.Procesa(21).ToList());
        }
    }

    public class EnParalelo19Test : SimuladorGpuTest
    {
        public void CeroCiclos8()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C2" }));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.Procesa(21).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
            CheckSequence(m => m.ShadersEnNucleo(1));
        }
    }

    public class EnParalelo20Test : SimuladorGpuTest
    {
        public void CeroCiclos9()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.AdicionaShader(2, new Shader { Duracion = 10, Nombre = "S1" }));
            Perform(m => m.ProximoShaderTerminado());

            Check(m => m.ProximoShaderTerminado());
        }
    }

    public class EnParalelo21Test : SimuladorGpuTest
    {
        public void CeroCiclos10()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.AdicionaShader(2, new Shader { Duracion = 10, Nombre = "S1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.ProximoShaderTerminado());

            CheckSequence(m => m.ShadersEnNucleo(0));
            CheckSequence(m => m.ShadersEnNucleo(1));
            CheckSequence(m => m.ShadersEnNucleo(2));
        }
    }

    public class EnParalelo22Test : SimuladorGpuTest
    {
        public void CeroCiclos11()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(5, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C2" }));
            Perform(m => m.ProximoShaderTerminado());

            Check(m => m.ProximoShaderTerminado());
        }
    }

    public class EnParalelo23Test : SimuladorGpuTest
    {
        public void CeroCiclos12()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(5, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C2" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.ProximoShaderTerminado());

            CheckSequence(m => m.ShadersEnNucleo(0));
            CheckSequence(m => m.ShadersEnNucleo(1));
        }
    }

    public class EnParalelo24Test : SimuladorGpuTest
    {
        public void CeroCiclos13()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(5, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C2" }));
            Perform(m => m.ProximoShaderTerminado());

            CheckSequence(m => m.Procesa(10).ToList());
        }
    }

    public class EnParalelo25Test : SimuladorGpuTest
    {
        public void CeroCiclos14()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(5, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N2" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C2" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.Procesa(10).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
            CheckSequence(m => m.ShadersEnNucleo(1));
        }
    }

    public class ExtremeTest : SimuladorGpuTest
    {
        public void UnCiclo1()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(2, new Shader { Duracion = 1, Nombre = "S1" }));

            Check(m => m.ProximoShaderTerminado());
        }

        public void UnCiclo2()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(2, new Shader { Duracion = 1, Nombre = "S1" }));
            Perform(m => m.ProximoShaderTerminado());

            CheckSequence(m => m.ShadersEnNucleo(1));
            CheckSequence(m => m.ShadersEnNucleo(2));
        }

        public void UnCiclo3()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(2, new Shader { Duracion = 1, Nombre = "S1" }));

            CheckSequence(m => m.Procesa(1).ToList());
        }

        public void UnCiclo4()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Torpe));
            Perform(m => m.CreaNucleo(10, TipoNucleo.Inteligente));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(2, new Shader { Duracion = 1, Nombre = "S1" }));
            Perform(m => m.Procesa(1).ToList());

            CheckSequence(m => m.ShadersEnNucleo(0));
            CheckSequence(m => m.ShadersEnNucleo(1));
            CheckSequence(m => m.ShadersEnNucleo(2));
        }

        //    public void UnCiclo5()
        //    {
        //        Initialize();

        //        Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
        //        Perform(m => m.CreaNucleo(5, TipoNucleo.Torpe));
        //        Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
        //        Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
        //        Perform(m => m.ProximoShaderTerminado());
        //        Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C2" }));
        //        Perform(m => m.Procesa(20).ToList());
        //        Perform(m => m.AdicionaShader(0, new Shader { Duracion = 1, Nombre = "N2" }));

        //        Check(m => m.ProximoShaderTerminado());
        //    }

        //    public void UnCiclo6()
        //    {
        //        Initialize();

        //        Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
        //        Perform(m => m.CreaNucleo(5, TipoNucleo.Torpe));
        //        Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
        //        Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
        //        Perform(m => m.ProximoShaderTerminado());
        //        Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C2" }));
        //        Perform(m => m.Procesa(20).ToList());
        //        Perform(m => m.AdicionaShader(0, new Shader { Duracion = 1, Nombre = "N2" }));
        //        Perform(m => m.ProximoShaderTerminado());

        //        CheckSequence(m => m.ShadersEnNucleo(0));
        //        CheckSequence(m => m.ShadersEnNucleo(1));
        //    }

        //    public void UnCiclo7()
        //    {
        //        Initialize();

        //        Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
        //        Perform(m => m.CreaNucleo(5, TipoNucleo.Torpe));
        //        Perform(m => m.CreaNucleo(5, TipoNucleo.Torpe));
        //        Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
        //        Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
        //        Perform(m => m.AdicionaShader(2, new Shader { Duracion = 10, Nombre = "CC1" }));
        //        Perform(m => m.ProximoShaderTerminado());
        //        Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C2" }));
        //        Perform(m => m.AdicionaShader(2, new Shader { Duracion = 10, Nombre = "CC2" }));
        //        Perform(m => m.Procesa(20).ToList());
        //        Perform(m => m.AdicionaShader(0, new Shader { Duracion = 1, Nombre = "N2" }));
        //        Perform(m => m.ProximoShaderTerminado());

        //        Check(m => m.ProximoShaderTerminado());
        //    }

        public void UnCiclo8()
        {
            Initialize();

            Perform(m => m.CreaNucleo(10, TipoNucleo.Ingenuo));
            Perform(m => m.CreaNucleo(5, TipoNucleo.Torpe));
            Perform(m => m.CreaNucleo(5, TipoNucleo.Torpe));
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 10, Nombre = "N1" }));
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C1" }));
            Perform(m => m.AdicionaShader(2, new Shader { Duracion = 10, Nombre = "CC1" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.AdicionaShader(1, new Shader { Duracion = 10, Nombre = "C2" }));
            Perform(m => m.AdicionaShader(2, new Shader { Duracion = 10, Nombre = "CC2" }));
            Perform(m => m.Procesa(20).ToList());
            Perform(m => m.AdicionaShader(0, new Shader { Duracion = 1, Nombre = "N2" }));
            Perform(m => m.ProximoShaderTerminado());
            Perform(m => m.ProximoShaderTerminado());

            CheckSequence(m => m.ShadersEnNucleo(0));
            CheckSequence(m => m.ShadersEnNucleo(1));
            CheckSequence(m => m.ShadersEnNucleo(2));
        }
    }
}
