﻿using SimulacionGPU;
using System.Collections.Generic;
using System.Linq;

namespace SimuladorGpuTester
{
    public class SimuladorGpu : ISimuladorGpu
    {
        private readonly List<GpuCore> _cores;

        public SimuladorGpu()
        {
            _cores = new List<GpuCore>();
        }

        public int TotalDeNucleos
        {
            get { return _cores.Count; }
        }

        public void ActivaNucleo(int nucleo)
        {
            _cores[nucleo].IsActive = true;
        }

        public void AdicionaShader(int nucleo, Shader shader)
        {
            _cores[nucleo].AddShader(shader);
        }

        public void CreaNucleo(int descanso, TipoNucleo tipo)
        {
            switch (tipo)
            {
                case TipoNucleo.Ingenuo:
                    _cores.Add(new NaiveCore(descanso));
                    break;
                case TipoNucleo.Inteligente:
                    _cores.Add(new SmartCore(descanso));
                    break;
                case TipoNucleo.Torpe:
                    _cores.Add(new ClumsyCore(descanso));
                    break;
            }
        }

        public IEnumerable<Shader> Procesa(int ciclos)
        {
            List<Shader> ready = new List<Shader>();
            var activeCores = _cores.Where(m => m.IsActive);
            foreach (var core in activeCores)
            {
                var currentShadersReady = core.FullSimulation(ciclos);
                ready.AddRange(currentShadersReady);
            }

            for (int i = 0; i < ready.Count; i++)
            {
                int minIndex = i;
                for (int j = i + 1; j < ready.Count; j++)
                {
                    if (ready[minIndex].Duracion > ready[j].Duracion)
                    {
                        minIndex = j;
                    }
                }
                var tmp = ready[minIndex];
                ready[minIndex] = ready[i];
                ready[i] = tmp;
            }

            foreach (var shader in ready)
            {
                shader.Duracion = 0;
                yield return shader;
            }
        }

        public Shader ProximoShaderTerminado()
        {
            var activeCores = _cores.Where(m => m.IsActive);
            if (!activeCores.Any())
                return null;

            int minTime = activeCores.Min(m => m.CyclesToFinish());
            GpuCore fastestCore = null;
            int remainingCycles = -1;

            foreach (var core in activeCores)
            {
                int k = minTime;
                if (core.ComputeShader(ref k) && k > remainingCycles)
                {
                    fastestCore = core;
                    remainingCycles = k;
                }
            }

            return fastestCore?.UnloadShader();
        }

        public IEnumerable<Shader> ShadersEnNucleo(int nucleo)
        {
            return _cores[nucleo].Shaders;
        }

        public void SuspendeNucleo(int nucleo)
        {
            _cores[nucleo].IsActive = false;
        }
    }
}
