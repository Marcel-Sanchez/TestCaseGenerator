﻿using System.Collections.Generic;
using SimulacionGPU;

namespace SimuladorGpuTester
{
    class ClumsyCore : GpuCore
    {
        private readonly Stack<Shader> _shaders;

        public ClumsyCore(int restingTime)
            : base(restingTime << 1)
        {
            _shaders = new Stack<Shader>();
        }

        public override IEnumerable<Shader> Shaders
        {
            get { return _shaders; }
        }

        public override void AddShader(Shader shader)
        {
            _shaders.Push(shader);
        }

        public override Shader UnloadShader()
        {
            if (_shaders.Count == 0)
            {
                return null;
            }

            RemainingRest = RestingTime;
            return _shaders.Pop();
        }
    }
}