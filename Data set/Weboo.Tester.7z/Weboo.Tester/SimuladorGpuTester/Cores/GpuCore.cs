﻿using SimulacionGPU;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SimuladorGpuTester
{
    abstract class GpuCore
    {
        protected GpuCore(int restingTime)
        {
            IsActive = true;
            RestingTime = restingTime;
            RemainingRest = 0;
        }

        public bool IsActive { get; set; }

        public int RestingTime { get; private set; }

        public int RemainingRest { get; protected set; }

        public abstract void AddShader(Shader shader);

        public abstract IEnumerable<Shader> Shaders { get; }

        public abstract Shader UnloadShader();

        public int CyclesToFinish()
        {
            if (!Shaders.Any())
                return int.MaxValue;

            var first = Shaders.First();
            return RemainingRest + Math.Max(first.Duracion, 1);
        }

        public bool ComputeShader(ref int cycles)
        {
            bool isShaderReady = cycles >= CyclesToFinish();
            if (RemainingRest > 0)
            {
                int restingCycles = Math.Min(RemainingRest, cycles);
                RemainingRest -= restingCycles;
                cycles -= restingCycles;
            }

            if (Shaders.Any())
            {
                var shader = Shaders.First();
                int shaderCycles = Math.Min(shader.Duracion, cycles);
                shader.Duracion -= shaderCycles;
                cycles -= shaderCycles;
            }

            return isShaderReady;
        }

        public IEnumerable<Shader> FullSimulation(int cycles)
        {
            while (cycles > 0)
            {
                if (!ComputeShader(ref cycles))
                    yield break;

                var shaderReady = UnloadShader();
                shaderReady.Duracion -= cycles;
                yield return shaderReady;
            }
        }
    }
}
