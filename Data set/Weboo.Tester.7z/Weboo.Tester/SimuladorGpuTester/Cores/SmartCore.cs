﻿using System.Collections.Generic;
using SimulacionGPU;

namespace SimuladorGpuTester
{
    class SmartCore : GpuCore
    {
        private readonly SortedSet<Shader> _shaders;
        private int _remainingShadersToRest;

        public SmartCore(int restingTime)
            : base(restingTime)
        {
            _shaders = new SortedSet<Shader>(Comparer<Shader>.Create((s1, s2) => s1.Duracion - s2.Duracion));
            _remainingShadersToRest = 2;
        }

        public override IEnumerable<Shader> Shaders
        {
            get { return _shaders; }
        }

        public override void AddShader(Shader shader)
        {
            _shaders.Add(shader);
        }

        public override Shader UnloadShader()
        {
            if (_shaders.Count == 0)
            {
                return null;
            }

            _remainingShadersToRest--;
            if (_remainingShadersToRest == 0)
            {
                RemainingRest = RestingTime;
                _remainingShadersToRest = 2;
            }
            var min = _shaders.Min;
            _shaders.Remove(min);

            return min;
        }
    }
}
