﻿using System.Collections.Generic;
using SimulacionGPU;

namespace SimuladorGpuTester
{
    class NaiveCore : GpuCore
    {
        private readonly Queue<Shader> _shaders;

        public NaiveCore(int restingTime)
            : base(restingTime)
        {
            _shaders = new Queue<Shader>();
        }

        public override IEnumerable<Shader> Shaders
        {
            get { return _shaders; }
        }

        public override void AddShader(Shader shader)
        {
            _shaders.Enqueue(shader);
        }

        public override Shader UnloadShader()
        {
            if (_shaders.Count == 0)
            {
                return null;
            }

            RemainingRest = RestingTime;
            return _shaders.Dequeue();
        }
    }
}
