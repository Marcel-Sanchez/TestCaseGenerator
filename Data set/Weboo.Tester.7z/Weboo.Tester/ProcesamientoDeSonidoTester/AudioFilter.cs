﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Examen.Interfaces;

namespace ProcesamientoDeSonidoTester
{
    public abstract class AudioFilter
    {
        private int _CheckingTime;
        private int _TransformationTime;

        protected virtual int ComputeCheckingTime(Audio audio)
        {
            return audio.Frecuencias.Length;
        }
        protected abstract int ComputeTransformationTime(Audio audio);
        protected abstract void Transform(Audio audio);

        public Audio InProcess { get; set; }

        public void Load(Audio audio)
        {
            InProcess = audio;
            _CheckingTime = ComputeCheckingTime(audio);
            _TransformationTime = ComputeTransformationTime(audio);
        }

        public int UpdateTime(int time)
        {
            if (_CheckingTime > 0)
            {
                int m = Math.Min(_CheckingTime, time);
                _CheckingTime -= m;
                time -= m;
            }

            if (_CheckingTime == 0 && _TransformationTime > 0)
            {
                int m = Math.Min(_TransformationTime, time);
                _TransformationTime -= m;
                time -= m;
                if (IsDone)
                {
                    Transform(InProcess);
                }
            }

            return time;
        }

        public Audio Unload()
        {
            var audio = InProcess;
            InProcess = null;

            return audio;
        }

        public int CurrentTaskTime
        {
            get
            {
                if (InProcess == null)
                    return -1;

                return _CheckingTime != 0 ? _CheckingTime : _TransformationTime;
            }
        }

        public bool IsDone
        {
            get { return CurrentTaskTime == 0; }
        }

        public Audio Process(int totalTime, int[] availableFrom, int p)
        {
            int t = UpdateTime(totalTime - availableFrom[p]);
            availableFrom[p] += totalTime - availableFrom[p] - t;
            if (IsDone)
            {
                if (NextStage == null)
                    return Unload();

                availableFrom[p] = Math.Max(availableFrom[p], availableFrom[p + 1]);
                availableFrom[p + 1] = availableFrom[p];
                if (NextStage.InProcess == null)
                {
                    NextStage.Load(Unload());
                    return NextStage.Process(totalTime, availableFrom, p + 1);
                }
            }

            return null;
        }

        public AudioFilter NextStage { get; set; }
    }
}
