﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Examen.Interfaces;

namespace ProcesamientoDeSonidoTester.AudioFilters
{
    public class CompressionFilter : AudioFilter
    {
        protected override int ComputeTransformationTime(Audio audio)
        {
            if (audio.Frecuencias.Length % 2 == 1)
                return 0;

            return audio.Frecuencias.Max();
        }

        protected override void Transform(Audio audio)
        {
            int[] newFrequencies = new int[audio.Frecuencias.Length / 2];
            for (int i = 0; i < newFrequencies.Length; i++)
                newFrequencies[i] = (audio.Frecuencias[i * 2] + audio.Frecuencias[i * 2 + 1]) / 2;

            audio.Frecuencias = newFrequencies;
        }
    }
}
