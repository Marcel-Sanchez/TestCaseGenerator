﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Examen.Interfaces;

namespace ProcesamientoDeSonidoTester.AudioFilters
{
    public class NormalizationFilter : AudioFilter
    {
        protected override int ComputeTransformationTime(Audio audio)
        {
            int min = audio.Frecuencias.Min();
            if (audio.Frecuencias.Length == 1 || min == 0)
                return 0;
            return audio.Frecuencias.Sum(m => m - min);
        }

        protected override void Transform(Audio audio)
        {
            int min = audio.Frecuencias.Min();
            for (int i = 0; i < audio.Frecuencias.Length; i++)
                audio.Frecuencias[i] -= min;
        }
    }
}
