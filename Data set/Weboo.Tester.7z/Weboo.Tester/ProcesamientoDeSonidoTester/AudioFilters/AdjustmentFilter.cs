﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Examen.Interfaces;

namespace ProcesamientoDeSonidoTester.AudioFilters
{
    class AdjustmentFilter : AudioFilter
    {
        protected override int ComputeTransformationTime(Audio audio)
        {
            int m = audio.Frecuencias.Min();
            if (audio.Frecuencias[0] == m)
                return 0;

            int i = audio.Frecuencias.Length - 1;
            while (i > -1 && audio.Frecuencias[i] != m)
                i--;
            return audio.Frecuencias.Length - i;
        }

        protected override void Transform(Audio audio)
        {
            int m = audio.Frecuencias.Min();
            int k = audio.Frecuencias.Length - 1;
            while (k > -1 && audio.Frecuencias[k] != m)
                k--;

            var r = audio.Frecuencias.Length - k;
            var newFrequencies = new int[audio.Frecuencias.Length];
            for (int i = 0; i < newFrequencies.Length; i++)
                newFrequencies[(i + r) % newFrequencies.Length] = audio.Frecuencias[i];

            audio.Frecuencias = newFrequencies;
        }
    }
}
