﻿using ProcesamientoDeSonidoTester.AudioFilters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Examen.Interfaces;

namespace ProcesamientoDeSonidoTester
{
    public class ProcesadorDeSonido : IProcesadorDeSonido
    {
        private List<AudioFilter> _AudioFilters;
        private List<Audio> _Pending;

        public ProcesadorDeSonido()
        {
            _AudioFilters = new List<AudioFilter>();
            _Pending = new List<Audio>();
        }

        public int CantidadDeFiltros
        {
            get { return _AudioFilters.Count; }
            set { throw new NotImplementedException(); }
        }

        public IEnumerable<Audio> AudioPorFiltro
        {
            get
            {
                foreach (var audioFilter in _AudioFilters)
                {
                    yield return audioFilter.InProcess;
                }
            }
        }

        public IEnumerable<Audio> AudioEnCola
        {
            get
            {
                for (int i = _Pending.Count - 1; i > -1; i--)
                {
                    yield return _Pending[i];
                }
            }
        }

        public void AgregaAudio(Audio audio)
        {
            if (_AudioFilters[0].InProcess == null)
            {
                _AudioFilters[0].Load(audio);
            }
            else
            {
                _Pending.Add(audio);
            }
        }

        public int AgregaFiltro(TipoDeFiltro tipo)
        {
            AudioFilter newFilter;
            if (tipo == TipoDeFiltro.Compresion)
                newFilter = new CompressionFilter();
            else if (tipo == TipoDeFiltro.Normalizacion)
                newFilter = new NormalizationFilter();
            else
                newFilter = new AdjustmentFilter();

            int index = _AudioFilters.Count - 1;
            if (index > -1)
            {
                _AudioFilters[index].NextStage = newFilter;
            }
            _AudioFilters.Add(newFilter);

            return index;
        }

        public IEnumerable<Audio> ProcesaAudio(int tiempo)
        {
            int[] availableFrom = new int[_AudioFilters.Count];
            for (int i = _AudioFilters.Count - 1; i > -1; i--)
            {
                var audioFilter = _AudioFilters[i];
                var audio = audioFilter.Process(tiempo, availableFrom, i);
                if (audio != null)
                    yield return audio;
            }

            while (_AudioFilters[0].InProcess == null && _Pending.Count > 0)
            {
                var nextAudio = _Pending[0];
                _Pending.RemoveAt(0);
                _AudioFilters[0].Load(nextAudio);

                var audio = _AudioFilters[0].Process(tiempo, availableFrom, 0);
                if (audio != null)
                    yield return audio;
            }
        }

        public int TiempoDeProcesamientoPendiente(int indiceDeFiltro)
        {
            return _AudioFilters[indiceDeFiltro].CurrentTaskTime;
        }
    }
}
