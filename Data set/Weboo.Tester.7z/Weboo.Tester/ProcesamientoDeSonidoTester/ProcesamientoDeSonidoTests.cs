﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Assess.Tester;
using Weboo.Examen.Interfaces;

namespace ProcesamientoDeSonidoTester
{
    public abstract class ProcesamientoDeSonidoTest : InterfaceTester<IProcesadorDeSonido>
    {
        protected override IProcesadorDeSonido BuildBenchmark(object[] args)
        {
            return new ProcesadorDeSonido();
        }

        protected override IProcesadorDeSonido BuildTarget(object[] args)
        {
            return ReflectionHelper.CreateInstance<IProcesadorDeSonido>();
        }
    }

    public class FiltersCount : ProcesamientoDeSonidoTest
    {
        public void FiltersCount1()
        {
            Initialize();

            Check(m => m.CantidadDeFiltros);
        }

        public void FiltersCount2()
        {
            Initialize();

            Perform(m => m.AgregaFiltro(TipoDeFiltro.Compresion));
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Compresion));
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));

            Check(m => m.CantidadDeFiltros);
        }

        public void FiltersCount3()
        {
            Initialize();

            Perform(m => m.AgregaFiltro(TipoDeFiltro.Compresion));
            Perform(m => m.AgregaAudio(new Audio("a.wav", 3, 1, 4, 9)));
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));

            Check(m => m.CantidadDeFiltros);
        }
    }

    public class AudioByFilter : ProcesamientoDeSonidoTest
    {
        public void AudioByFilter1()
        {
            Initialize();

            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));

            CheckSequence(m => m.AudioPorFiltro);
        }

        public void AudioByFilter2()
        {
            Initialize();

            var a = new Audio("a", 4, 1, 3);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaAudio(a));

            CheckSequence(m => m.AudioPorFiltro);
        }

        public void AudioByFilter3()
        {
            Initialize();

            var a = new Audio("a", 4, 1, 3);
            var b = new Audio("b", 3, 2, 3);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));

            CheckSequence(m => m.AudioPorFiltro);
        }

        public void AudioByFilter4()
        {
            Initialize();

            var a = new Audio("a", 4, 1, 3);
            var b = new Audio("b", 3, 2, 3);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));
            Perform(m => m.ProcesaAudio(2).ToList());

            CheckSequence(m => m.AudioPorFiltro);
        }

        public void AudioByFilter5()
        {
            Initialize();

            var a = new Audio("a", 4, 1, 3);
            var b = new Audio("b", 3, 2, 3);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));
            Perform(m => m.ProcesaAudio(5).ToList());

            CheckSequence(m => m.AudioPorFiltro);
        }

        public void AudioByFilter6()
        {
            Initialize();

            var a = new Audio("a", 4, 1, 3);
            var b = new Audio("b", 3, 2, 3);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));
            Perform(m => m.ProcesaAudio(5).ToList());
            Perform(m => m.ProcesaAudio(5).ToList());

            CheckSequence(m => m.AudioPorFiltro);
        }

        public void AudioByFilter7()
        {
            Initialize();

            var a = new Audio("a", 4, 1, 3);
            var b = new Audio("b", 3, 2, 3);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));
            Perform(m => m.ProcesaAudio(5).ToList());
            Perform(m => m.ProcesaAudio(5).ToList());
            Perform(m => m.ProcesaAudio(5).ToList());

            CheckSequence(m => m.AudioPorFiltro);
        }
    }

    class PendingAudio : ProcesamientoDeSonidoTest
    {
        public void PendingAudio1()
        {
            Initialize();

            CheckSequence(m => m.AudioEnCola);
        }

        public void PendingAudio2()
        {
            Initialize();

            var a = new Audio("a", 4, 1, 3);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaAudio(a));

            CheckSequence(m => m.AudioEnCola);
        }

        public void PendingAudio3()
        {
            Initialize();

            var a = new Audio("a", 4, 1, 3);
            var b = new Audio("b", 3, 2, 3);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));

            CheckSequence(m => m.AudioEnCola);
        }

        public void PendingAudio4()
        {
            Initialize();

            var a = new Audio("a", 4, 1, 3);
            var b = new Audio("b", 3, 2, 3);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));
            Perform(m => m.ProcesaAudio(2).ToList());

            CheckSequence(m => m.AudioEnCola);
        }

        public void PendingAudio5()
        {
            Initialize();

            var a = new Audio("a", 4, 1, 3);
            var b = new Audio("b", 3, 2, 3);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));
            Perform(m => m.ProcesaAudio(5).ToList());

            CheckSequence(m => m.AudioEnCola);
        }

        public void PendingAudio6()
        {
            Initialize();

            var a = new Audio("a", 4, 1, 3);
            var b = new Audio("b", 3, 2, 3);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));
            Perform(m => m.ProcesaAudio(5).ToList());
            Perform(m => m.ProcesaAudio(5).ToList());

            CheckSequence(m => m.AudioEnCola);
        }
    }

    class PendingTime : ProcesamientoDeSonidoTest
    {
        public void PendingTime1()
        {
            Initialize();

            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));

            Check(m => m.TiempoDeProcesamientoPendiente(0));
        }

        public void PendingTime2()
        {
            Initialize();

            var a = new Audio("a", 4, 1, 3);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaAudio(a));

            Check(m => m.TiempoDeProcesamientoPendiente(0));
        }

        public void PendingTime3()
        {
            Initialize();

            var a = new Audio("a", 4, 1, 3);
            var b = new Audio("b", 3, 2, 3);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Compresion));
            Perform(m => m.AgregaAudio(a));

            Check(m => m.TiempoDeProcesamientoPendiente(1));
        }

        public void PendingTime4()
        {
            Initialize();

            var a = new Audio("a", 4, 1, 3);
            var b = new Audio("b", 3, 2, 3);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Compresion));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));
            Perform(m => m.ProcesaAudio(3).ToList());

            Check(m => m.TiempoDeProcesamientoPendiente(0));
        }

        public void PendingTime5()
        {
            Initialize();

            var a = new Audio("a", 4, 1, 3);
            var b = new Audio("b", 3, 2, 3);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Compresion));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));
            Perform(m => m.ProcesaAudio(5).ToList());

            Check(m => m.TiempoDeProcesamientoPendiente(0));
        }

        public void PendingTime6()
        {
            Initialize();

            var a = new Audio("a", 4, 1, 3);
            var b = new Audio("b", 3, 2, 3);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Compresion));
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));
            Perform(m => m.ProcesaAudio(3).ToList());

            Check(m => m.TiempoDeProcesamientoPendiente(0));
            Check(m => m.TiempoDeProcesamientoPendiente(1));
        }

        public void PendingTime7()
        {
            Initialize();

            var a = new Audio("a", 18, 2, 15, 5);
            var b = new Audio("b", 3, 2, 3, 4);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Compresion));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));
            Perform(m => m.ProcesaAudio(3).ToList());

            Check(m => m.TiempoDeProcesamientoPendiente(0));
        }

        public void PendingTime8()
        {
            Initialize();

            var a = new Audio("a", 20, 1, 15);
            var b = new Audio("b", 3, 2, 3, 4);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Normalizacion));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));
            Perform(m => m.ProcesaAudio(3).ToList());

            Check(m => m.TiempoDeProcesamientoPendiente(0));
        }

        public void PendingTime9()
        {
            Initialize();

            var a = new Audio("a", 20, 0, 15);
            var b = new Audio("b", 3, 2, 3, 4);
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Normalizacion));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));
            Perform(m => m.ProcesaAudio(3).ToList());

            Check(m => m.TiempoDeProcesamientoPendiente(0));
        }
    }

    class Process : ProcesamientoDeSonidoTest
    {
        public void Process1()
        {
            Initialize();

            var a = new Audio("a", 10, 3, 15);

            Perform(m => m.AgregaFiltro(TipoDeFiltro.Compresion));
            Perform(m => m.AgregaAudio(a));

            CheckSequence(m => m.ProcesaAudio(2).ToList());
        }

        public void Process2()
        {
            Initialize();

            var a = new Audio("a", 10, 3, 15);

            Perform(m => m.AgregaFiltro(TipoDeFiltro.Compresion));
            Perform(m => m.AgregaAudio(a));

            CheckSequence(m => m.ProcesaAudio(3).ToList());
        }

        public void Process3()
        {
            Initialize();

            var a = new Audio("a", 10, 3, 15);

            Perform(m => m.AgregaFiltro(TipoDeFiltro.Compresion));
            Perform(m => m.AgregaAudio(a));

            CheckSequence(m => m.ProcesaAudio(5).ToList());
        }

        public void Process4()
        {
            Initialize();

            var a = new Audio("a", 10, 3, 15);
            var b = new Audio("b", 8, 4, 2);

            Perform(m => m.AgregaFiltro(TipoDeFiltro.Compresion));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));

            CheckSequence(m => m.ProcesaAudio(6).ToList());
        }

        public void Process5()
        {
            Initialize();

            var a = new Audio("a", 10, 3, 15);
            var b = new Audio("b", 8, 4, 2);

            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));

            CheckSequence(m => m.ProcesaAudio(6).ToList());
        }

        public void Process6()
        {
            Initialize();

            var a = new Audio("a", 10, 3, 15);
            var b = new Audio("b", 8, 4, 2);

            Perform(m => m.AgregaFiltro(TipoDeFiltro.Compresion));
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));

            CheckSequence(m => m.ProcesaAudio(6).ToList());
        }

        public void Process7()
        {
            Initialize();

            var a = new Audio("a", 10, 3, 15);
            var b = new Audio("b", 8, 4, 2);

            Perform(m => m.AgregaFiltro(TipoDeFiltro.Compresion));
            Perform(m => m.AgregaFiltro(TipoDeFiltro.Reajuste));
            Perform(m => m.AgregaAudio(a));
            Perform(m => m.AgregaAudio(b));
            Perform(m => m.ProcesaAudio(6).ToList());

            CheckSequence(m => m.ProcesaAudio(1).ToList());
        }
    }
}
