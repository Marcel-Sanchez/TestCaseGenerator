﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Examen.Interfaces;

namespace VentaDelTeatroTester
{
    public class GestorDeTaquillas : IGestorDeTaquillas
    {
        private int _systemTime;
        private readonly LinkedQueue<BoxOffice> _boxOffices;

        public GestorDeTaquillas(int cantidadDeTaquillas)
        {
            _systemTime = 0;
            _boxOffices = new LinkedQueue<BoxOffice>();
            for (int i = 0; i < cantidadDeTaquillas; i++)
            {
                _boxOffices.Enqueue(new BoxOffice());
            }
        }

        public int CantidadDeTaquillas
        {
            get { return _boxOffices.Count; }
        }

        public void AsignaObraATaquilla(string obra, int taquilla)
        {
            _boxOffices[taquilla - 1].Plays.Enqueue(obra);
        }

        public ICliente AtiendeTaquilla(int taquilla)
        {
            if (_boxOffices[taquilla - 1].Clients.Count == 0)
            {
                return null;
            }

            return _boxOffices[taquilla - 1].Clients.Dequeue().Client;
        }

        public IEnumerable<ICliente> ClientesEnTaquilla(int taquilla)
        {
            foreach (var item in _boxOffices[taquilla - 1].Clients)
            {
                yield return item.Client;
            }
        }

        public bool EsSimetrica<T>(int taquilla, Func<ICliente, T> selector)
        {
            IEnumerable<WrapperClient> forward = _boxOffices[taquilla - 1].Clients;
            IEnumerable<WrapperClient> backward = _boxOffices[taquilla - 1].Clients.Reverse();

            var enumeratorForward = forward.GetEnumerator();
            var enumeratorBackward = backward.GetEnumerator();

            while (enumeratorForward.MoveNext() && enumeratorBackward.MoveNext())
            {
                var item1 = selector(enumeratorForward.Current.Client);
                var item2 = selector(enumeratorBackward.Current.Client);
                if (!Equals(item1, item2))
                    return false;
            }

            return true;
        }

        public IEnumerable<string> ObrasEnTaquilla(int taquilla)
        {
            return _boxOffices[taquilla - 1].Plays;
        }

        public IEnumerable<ICliente> PriorizaClientes(int taquilla, Predicate<ICliente> condicion)
        {
            var prioritized = new LinkedQueue<ICliente>();
            var ordinary = new LinkedQueue<WrapperClient>();

            foreach (var item in _boxOffices[taquilla - 1].Clients)
            {
                if (condicion(item.Client))
                {
                    prioritized.Enqueue(item.Client);
                }
                else
                {
                    ordinary.Enqueue(item);
                }
            }

            _boxOffices[taquilla - 1].Clients = ordinary;
            return prioritized;
        }

        public void ReasignaVenta(int taquillaCerrada, int taquillaAbierta)
        {
            var closed = _boxOffices[taquillaCerrada - 1];
            var open = _boxOffices[taquillaAbierta - 1];
            // Obras
            foreach (var item in closed.Plays)
            {
                open.Plays.Enqueue(item);
            }

            var newClients = new LinkedQueue<WrapperClient>();
            var enumeratorClosedClients = closed.Clients.GetEnumerator();
            var enumeratorOpenClients = open.Clients.GetEnumerator();

            bool leftOpen = enumeratorOpenClients.MoveNext();
            bool leftClosed = enumeratorClosedClients.MoveNext();
            while (leftOpen && leftClosed)
            {
                if (enumeratorOpenClients.Current.ArrivalTime < enumeratorClosedClients.Current.ArrivalTime)
                {
                    newClients.Enqueue(enumeratorOpenClients.Current);
                    leftOpen = enumeratorOpenClients.MoveNext();
                }
                else
                {
                    newClients.Enqueue(enumeratorClosedClients.Current);
                    leftClosed = enumeratorClosedClients.MoveNext();
                }
            }

            while (leftOpen)
            {
                newClients.Enqueue(enumeratorOpenClients.Current);
                leftOpen = enumeratorOpenClients.MoveNext();
            }

            while (leftClosed)
            {
                newClients.Enqueue(enumeratorClosedClients.Current);
                leftClosed = enumeratorClosedClients.MoveNext();
            }

            open.Clients = newClients;
            _boxOffices[taquillaCerrada - 1].Plays = new LinkedQueue<string>();
            _boxOffices[taquillaCerrada - 1].Clients = new LinkedQueue<WrapperClient>();
        }

        public IEnumerable<ICliente> RecibenAutografos(string obra)
        {
            foreach (var boxOffice in _boxOffices)
            {
                if (boxOffice.Plays.Contains(obra))
                {
                    foreach (var wrapperClient in boxOffice.Clients.Reverse())
                    {
                        if (wrapperClient.Play == obra)
                            yield return wrapperClient.Client;
                    }

                    yield break;
                }
            }
        }

        public void RegistraCliente(ICliente cliente, string obra)
        {
            _systemTime++;
            foreach (var boxOffice in _boxOffices)
            {
                if (boxOffice.Plays.Contains(obra))
                {
                    boxOffice.Clients.Enqueue(new WrapperClient
                    {
                        ArrivalTime = _systemTime,
                        Client = cliente,
                        Play = obra
                    });
                    break;
                }
            }
        }
    }
}
