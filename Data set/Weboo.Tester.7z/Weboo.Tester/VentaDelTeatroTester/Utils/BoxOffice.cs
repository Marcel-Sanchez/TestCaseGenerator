﻿namespace VentaDelTeatroTester
{
    class BoxOffice
    {
        public BoxOffice()
        {
            Plays = new LinkedQueue<string>();
            Clients = new LinkedQueue<WrapperClient>();
        }

        public LinkedQueue<string> Plays { get; set; }

        public LinkedQueue<WrapperClient> Clients { get; set; }
    }
}
