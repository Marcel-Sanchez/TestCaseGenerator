﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace VentaDelTeatroTester
{
    class LinkedQueue<T> : IEnumerable<T>
    {
        private LinkedNode<T> _first;
        private LinkedNode<T> _last;
        private int _count;

        public LinkedQueue()
        {
            _first = null;
            _last = null;
            _count = 0;
        }

        public int Count
        {
            get { return _count; }
        }

        public void Enqueue(T value)
        {
            _count++;
            if (_first == null)
            {
                _first = _last = new LinkedNode<T> { Value = value };
            }
            else
            {
                _last.Next = new LinkedNode<T> { Value = value };
                _last = _last.Next;
            }
        }

        public T Dequeue()
        {
            if (Count == 0)
            {
                return default(T);
            }

            _count--;
            var value = _first.Value;

            _first = _first.Next;
            if (_first == null)
            {
                _last = null;
            }

            return value;
        }

        public T this[int i]
        {
            get
            {
                int c = 0;
                foreach (var item in this)
                {
                    if (c == i)
                        return item;
                    c++;
                }

                throw new ArgumentOutOfRangeException();
            }
        }

        public bool Contains(T value)
        {
            foreach (var x in this)
            {
                if (Equals(x, value))
                    return true;
            }

            return false;
        }

        public IEnumerable<T> Reverse()
        {
            return Reverse(_first);
        }

        private IEnumerable<T> Reverse(LinkedNode<T> node)
        {
            if (node == null)
                yield break;

            foreach (var item in Reverse(node.Next))
            {
                yield return item;
            }

            yield return node.Value;
        }

        public IEnumerator<T> GetEnumerator()
        {
            for (var current = _first; current != null; current = current.Next)
            {
                yield return current.Value;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }

    class LinkedNode<T>
    {
        public T Value { get; set; }
        public LinkedNode<T> Next { get; set; }
    }
}
