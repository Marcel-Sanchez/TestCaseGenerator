﻿using Weboo.Examen.Interfaces;

namespace VentaDelTeatroTester
{
    class WrapperClient
    {
        public int ArrivalTime { get; set; }

        public string Play { get; set; }

        public ICliente Client { get; set; }
    }
}
