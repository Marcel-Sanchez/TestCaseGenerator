﻿using System.Linq;
using Weboo.Assess.Tester;
using Weboo.Examen.Interfaces;

namespace VentaDelTeatroTester
{
    public abstract class GestorDeTaquillasTest : InterfaceTester<IGestorDeTaquillas>
    {
        protected override IGestorDeTaquillas BuildBenchmark(object[] args)
        {
            return new GestorDeTaquillas((int)args[0]);
        }

        protected override IGestorDeTaquillas BuildTarget(object[] args)
        {
            return ReflectionHelper.CreateInstance<IGestorDeTaquillas>(args);
        }
    }

    class Cliente : ICliente
    {
        public string Nombre { get; set; }

        public int Edad { get; set; }

        public override string ToString()
        {
            return $"{Nombre}({Edad})";
        }
    }

    public class CantidadDeTaquillasTest : GestorDeTaquillasTest
    {
        public void CantidadDeTaquillas1()
        {
            Initialize(1);

            Check(m => m.CantidadDeTaquillas);
        }

        public void CantidadDeTaquillas2()
        {
            Initialize(3);

            Check(m => m.CantidadDeTaquillas);
        }

        public void CantidadDeTaquillas3()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));

            Check(m => m.CantidadDeTaquillas);
        }

        public void CantidadDeTaquillas4()
        {
            Initialize(3);
            var client = new Cliente { Nombre = "C1" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client, "A"));

            Check(m => m.CantidadDeTaquillas);
        }

        public void CantidadDeTaquillas5()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.ReasignaVenta(1, 2));

            Check(m => m.CantidadDeTaquillas);
        }
    }

    public class AsignacionDeObrasTest : GestorDeTaquillasTest
    {
        public void Obras1()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));

            CheckMultiSet(m => m.ObrasEnTaquilla(1).ToList());
        }

        public void Obras2()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 2));

            CheckMultiSet(m => m.ObrasEnTaquilla(2).ToList());
        }

        public void Obras3()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));

            CheckMultiSet(m => m.ObrasEnTaquilla(1).ToList());
        }

        public void Obras4()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));

            CheckMultiSet(m => m.ObrasEnTaquilla(3).ToList());
        }

        public void Obras5()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.AsignaObraATaquilla("C", 1));

            CheckMultiSet(m => m.ObrasEnTaquilla(2).ToList());
        }
    }

    public class ClientesEnTaquillaCorrectaTest : GestorDeTaquillasTest
    {
        public void ClientesEnTaquillaCorrecta1()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 2));
            Perform(m => m.RegistraCliente(client1, "A"));

            CheckSequence(m => m.ClientesEnTaquilla(1).ToList());
        }

        public void ClientesEnTaquillaCorrecta2()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 2));
            Perform(m => m.RegistraCliente(client1, "B"));

            CheckSequence(m => m.ClientesEnTaquilla(1).ToList());
        }
    }

    public class TaquillaConMuchasObrasTest : GestorDeTaquillasTest
    {
        public void TaquillaConMuchasObras1()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.AsignaObraATaquilla("C", 1));
            Perform(m => m.AsignaObraATaquilla("D", 2));
            Perform(m => m.RegistraCliente(client1, "B"));

            CheckSequence(m => m.ClientesEnTaquilla(1).ToList());
        }

        public void TaquillaConMuchasObras2()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.AsignaObraATaquilla("C", 1));
            Perform(m => m.AsignaObraATaquilla("D", 2));
            Perform(m => m.RegistraCliente(client1, "B"));

            CheckSequence(m => m.ClientesEnTaquilla(2).ToList());
        }
    }

    public class VariosClientesTest : GestorDeTaquillasTest
    {
        public void ClientesEnMismaObra()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.RegistraCliente(client1, "B"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client4, "B"));

            CheckSequence(m => m.ClientesEnTaquilla(3).ToList());
        }

        public void ClientesEnDiferentesObras1()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.RegistraCliente(client1, "B"));
            Perform(m => m.RegistraCliente(client2, "A"));

            CheckSequence(m => m.ClientesEnTaquilla(1).ToList());
        }

        public void ClientesEnDiferentesObras2()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.AsignaObraATaquilla("C", 3));
            Perform(m => m.RegistraCliente(client1, "B"));
            Perform(m => m.RegistraCliente(client2, "A"));
            Perform(m => m.RegistraCliente(client3, "C"));

            CheckSequence(m => m.ClientesEnTaquilla(1).ToList());
        }

        public void ClientesEnDiferentesObras3()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.AsignaObraATaquilla("C", 3));
            Perform(m => m.AsignaObraATaquilla("D", 1));
            Perform(m => m.RegistraCliente(client1, "B"));
            Perform(m => m.RegistraCliente(client2, "A"));
            Perform(m => m.RegistraCliente(client3, "C"));
            Perform(m => m.RegistraCliente(client4, "D"));

            CheckSequence(m => m.ClientesEnTaquilla(3).ToList());
        }
    }

    public class AtiendeTaquillaTest : GestorDeTaquillasTest
    {
        public void AtiendeTaquillaBasico()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));

            Check(m => m.AtiendeTaquilla(1));
        }

        public void AtiendeTaquillaSinClientes1()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));

            Check(m => m.AtiendeTaquilla(1));
        }

        public void AtiendeTaquillaSinClientes2()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AtiendeTaquilla(1));

            Check(m => m.AtiendeTaquilla(1));
        }

        public void AtiendeTaquillaSinClientes3()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));

            Check(m => m.AtiendeTaquilla(3));
        }

        public void AtiendeTaquillaMuchosClientes1()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));

            Check(m => m.AtiendeTaquilla(1));
        }

        public void AtiendeTaquillaMuchosClientes2()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));

            Check(m => m.AtiendeTaquilla(1));
        }

        public void AtiendeTaquillaMuchosClientes3()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };

            Perform(m => m.AsignaObraATaquilla("A", 2));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.AsignaObraATaquilla("C", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "C"));

            Check(m => m.AtiendeTaquilla(1));
        }

        public void AtiendeTaquillaMuchosClientes4()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };

            Perform(m => m.AsignaObraATaquilla("A", 2));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.AsignaObraATaquilla("C", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "C"));
            Perform(m => m.AtiendeTaquilla(1));

            Check(m => m.AtiendeTaquilla(1));
        }

        public void AtiendeTaquillaMuchosClientes5()
        {
            Initialize(3);

            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };

            Perform(m => m.AsignaObraATaquilla("A", 2));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.AsignaObraATaquilla("C", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "C"));
            Perform(m => m.AtiendeTaquilla(1));
            Perform(m => m.AtiendeTaquilla(1));

            Check(m => m.AtiendeTaquilla(1));
        }

        public void AtiendeTaquillaMuchosClientes6()
        {
            Initialize(3);

            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };

            Perform(m => m.AsignaObraATaquilla("A", 2));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.AsignaObraATaquilla("C", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "C"));
            Perform(m => m.AtiendeTaquilla(1));

            Check(m => m.AtiendeTaquilla(2));
        }

        public void AtiendeTaquillaMuchosClientes7()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };

            Perform(m => m.AsignaObraATaquilla("A", 2));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.AsignaObraATaquilla("C", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "C"));
            Perform(m => m.AtiendeTaquilla(1));

            Check(m => m.AtiendeTaquilla(2));
        }
    }

    public class PriorizaClientesTest : GestorDeTaquillasTest
    {
        public void PriorizaClientesBasico()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));

            CheckSequence(m => m.PriorizaClientes(1, c => c.Nombre == "P2").ToList());
        }

        public void SinClientesPriorizados1()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));

            CheckSequence(m => m.PriorizaClientes(1, c => c.Nombre == "T").ToList());
        }

        public void SinClientesPriorizados2()
        {
            Initialize(3);

            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));

            CheckSequence(m => m.PriorizaClientes(2, c => true).ToList());
        }

        public void VerificaCondicionEnReferencia()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));

            CheckSequence(m => m.PriorizaClientes(1, c => c == client2).ToList());
        }

        public void EliminaClientesPriorizados()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var prioritizedNames = new[] { client1.Nombre, client3.Nombre };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.PriorizaClientes(1, c => prioritizedNames.Contains(c.Nombre)).ToList());

            CheckSequence(m => m.ClientesEnTaquilla(1).ToList());
        }

        public void OrdenRelativoEnClientesPriorizados1()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var prioritizedNames = new[] { client1.Nombre, client3.Nombre };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));
            Perform(m => m.RegistraCliente(client3, "A"));

            CheckSequence(m => m.PriorizaClientes(1, c => prioritizedNames.Contains(c.Nombre)).ToList());
        }

        public void OrdenRelativoEnClientesPriorizados2()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };
            var prioritizedNames = new[] { client1.Nombre, client3.Nombre, client4.Nombre };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client4, "A"));
            Perform(m => m.RegistraCliente(client5, "A"));

            CheckSequence(m => m.PriorizaClientes(1, c => prioritizedNames.Contains(c.Nombre)).ToList());
        }

        public void OrdenRelativoEnClientesPriorizados3()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };
            var prioritizedNames = new[] { client1.Nombre, client3.Nombre, client4.Nombre };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));
            Perform(m => m.RegistraCliente(client3, "B"));
            Perform(m => m.RegistraCliente(client4, "A"));
            Perform(m => m.RegistraCliente(client5, "A"));

            CheckSequence(m => m.PriorizaClientes(1, c => prioritizedNames.Contains(c.Nombre)).ToList());
        }

        public void PriorizaClientesEnOtraTaquilla1()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };
            var prioritizedNames = new[] { client1.Nombre, client3.Nombre, client4.Nombre };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 2));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));
            Perform(m => m.RegistraCliente(client3, "B"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.RegistraCliente(client5, "A"));

            CheckSequence(m => m.PriorizaClientes(1, c => prioritizedNames.Contains(c.Nombre)).ToList());
        }

        public void PriorizaClientesEnOtraTaquilla2()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };
            var prioritizedNames = new[] { client1.Nombre, client3.Nombre, client4.Nombre };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 2));
            Perform(m => m.RegistraCliente(client1, "B"));
            Perform(m => m.RegistraCliente(client2, "A"));
            Perform(m => m.RegistraCliente(client3, "B"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.RegistraCliente(client5, "A"));

            CheckSequence(m => m.PriorizaClientes(1, c => prioritizedNames.Contains(c.Nombre)).ToList());
        }

        public void PriorizaLosMismosClientes()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };
            var prioritizedNames = new[] { client1.Nombre, client3.Nombre, client4.Nombre };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client4, "A"));
            Perform(m => m.RegistraCliente(client5, "A"));
            Perform(m => m.PriorizaClientes(1, c => prioritizedNames.Contains(c.Nombre)).ToList());

            CheckSequence(m => m.PriorizaClientes(1, c => prioritizedNames.Contains(c.Nombre)).ToList());
        }

        public void PriorizadoElPrimerCliente()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var prioritizedNames = new[] { client1.Nombre, client3.Nombre };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.PriorizaClientes(1, c => prioritizedNames.Contains(c.Nombre)).ToList());

            Check(m => m.AtiendeTaquilla(1));
        }

        public void AtiendeYLuegoPrioriza()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var prioritizedNames = new[] { client1.Nombre, client3.Nombre };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.AtiendeTaquilla(1));

            CheckSequence(m => m.PriorizaClientes(1, c => prioritizedNames.Contains(c.Nombre)).ToList());
        }
    }

    public class ReasignacionDeVentaTest : GestorDeTaquillasTest
    {
        public void LimpiaTaquillaCerrada1()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckMultiSet(m => m.ObrasEnTaquilla(1).ToList());
        }

        public void LimpiaTaquillaCerrada2()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckSequence(m => m.ClientesEnTaquilla(1).ToList());
        }

        public void LimpiaTaquillaCerrada3()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.RegistraCliente(client1, "B"));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckSequence(m => m.ClientesEnTaquilla(1).ToList());
        }

        public void LimpiaTaquillaCerrada4()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.RegistraCliente(client1, "B"));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.ReasignaVenta(1, 3));

            Check(m => m.AtiendeTaquilla(1));
        }

        public void LimpiaTaquillaCerrada5()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var prioritizedNames = new[] { client1.Nombre, client2.Nombre };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.RegistraCliente(client1, "B"));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckSequence(m => m.PriorizaClientes(1, c => prioritizedNames.Contains(c.Nombre)).ToList());
        }

        public void SinModificarOtrasTaquillas()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 2));
            Perform(m => m.AsignaObraATaquilla("C", 1));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckMultiSet(m => m.ObrasEnTaquilla(2).ToList());
        }

        public void ReasignaNada1()
        {
            Initialize(3);

            Perform(m => m.ReasignaVenta(1, 3));

            CheckMultiSet(m => m.ObrasEnTaquilla(3).ToList());
        }

        public void ReasignaNada2()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 3));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckMultiSet(m => m.ObrasEnTaquilla(3).ToList());
        }

        public void ReusandoTaquillaCerrada1()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 2));
            Perform(m => m.ReasignaVenta(1, 3));
            Perform(m => m.AsignaObraATaquilla("C", 1));

            CheckMultiSet(m => m.ObrasEnTaquilla(1).ToList());
        }

        public void ReusandoTaquillaCerrada2()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 2));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.ReasignaVenta(1, 3));
            Perform(m => m.AsignaObraATaquilla("C", 1));
            Perform(m => m.RegistraCliente(client2, "C"));

            CheckSequence(m => m.ClientesEnTaquilla(1).ToList());
        }

        public void ReusandoTaquillaCerrada3()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 2));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.ReasignaVenta(1, 3));
            Perform(m => m.AsignaObraATaquilla("C", 1));
            Perform(m => m.RegistraCliente(client2, "C"));

            Check(m => m.AtiendeTaquilla(1));
        }

        public void UnionDeObras1()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.AsignaObraATaquilla("C", 1));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckMultiSet(m => m.ObrasEnTaquilla(3).ToList());
        }

        public void UnionDeObras2()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.AsignaObraATaquilla("C", 1));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckMultiSet(m => m.ObrasEnTaquilla(3).ToList());
        }

        public void UnionDeObras3()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 3));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.AsignaObraATaquilla("C", 1));
            Perform(m => m.AsignaObraATaquilla("D", 3));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckMultiSet(m => m.ObrasEnTaquilla(3).ToList());
        }

        public void UnionDeObras4()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };

            Perform(m => m.AsignaObraATaquilla("A", 3));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.AsignaObraATaquilla("C", 1));
            Perform(m => m.AsignaObraATaquilla("D", 3));
            Perform(m => m.RegistraCliente(client1, "B"));
            Perform(m => m.RegistraCliente(client2, "D"));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckMultiSet(m => m.ObrasEnTaquilla(3).ToList());
        }

        public void MezclaOrdenadaDeClientes1()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckSequence(m => m.ClientesEnTaquilla(3).ToList());
        }

        public void MezclaOrdenadaDeClientes2()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckSequence(m => m.ClientesEnTaquilla(3).ToList());
        }

        public void MezclaOrdenadaDeClientes3()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckSequence(m => m.ClientesEnTaquilla(3).ToList());
        }

        public void MezclaOrdenadaDeClientes4()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckSequence(m => m.ClientesEnTaquilla(3).ToList());
        }

        public void MezclaOrdenadaDeClientes5()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckSequence(m => m.ClientesEnTaquilla(3).ToList());
        }

        public void MezclaOrdenadaDeClientes6()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckSequence(m => m.ClientesEnTaquilla(3).ToList());
        }

        public void MezclaOrdenadaDeClientes7()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client5, "A"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckSequence(m => m.ClientesEnTaquilla(3).ToList());
        }

        public void MezclaOrdenadaDeClientes8()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.AsignaObraATaquilla("C", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "C"));
            Perform(m => m.RegistraCliente(client5, "A"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckSequence(m => m.ClientesEnTaquilla(3).ToList());
        }

        public void AsignaObraDespuesDeMezcla1()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.ReasignaVenta(1, 3));
            Perform(m => m.AsignaObraATaquilla("C", 3));

            CheckMultiSet(m => m.ObrasEnTaquilla(3).ToList());
        }

        public void RegistraDespuesDeMezcla()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.AsignaObraATaquilla("C", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "C"));
            Perform(m => m.ReasignaVenta(1, 3));
            Perform(m => m.RegistraCliente(client4, "C"));

            CheckSequence(m => m.ClientesEnTaquilla(3).ToList());
        }

        public void AtiendeDespuesDeMezcla1()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client5, "A"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.ReasignaVenta(1, 3));

            Check(m => m.AtiendeTaquilla(3));
        }

        public void AtiendeDespuesDeMezcla2()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client5, "A"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.ReasignaVenta(1, 3));

            Check(m => m.AtiendeTaquilla(3));
        }

        public void PriorizaDespuesDeMezcla1()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };
            var prioritizedNames = new[] { client1.Nombre, client3.Nombre, client4.Nombre };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client5, "A"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckSequence(m => m.PriorizaClientes(3, c => prioritizedNames.Contains(c.Nombre)).ToList());
        }

        public void PriorizaDespuesDeMezcla2()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };
            var prioritizedNames = new[] { client2.Nombre, client3.Nombre, client5.Nombre };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client5, "A"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckSequence(m => m.PriorizaClientes(3, c => prioritizedNames.Contains(c.Nombre)).ToList());
        }

        public void ReasignaReasigna1()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.ReasignaVenta(1, 3));
            Perform(m => m.ReasignaVenta(3, 1));

            CheckMultiSet(m => m.ObrasEnTaquilla(1).ToList());
        }

        public void ReasignaReasigna2()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 2));
            Perform(m => m.AsignaObraATaquilla("C", 3));
            Perform(m => m.ReasignaVenta(1, 3));
            Perform(m => m.ReasignaVenta(3, 2));

            CheckMultiSet(m => m.ObrasEnTaquilla(2).ToList());
        }

        public void ReasignaReasigna3()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 2));
            Perform(m => m.AsignaObraATaquilla("C", 3));
            Perform(m => m.ReasignaVenta(1, 3));
            Perform(m => m.ReasignaVenta(3, 2));

            CheckMultiSet(m => m.ObrasEnTaquilla(3).ToList());
        }

        public void ReasignaReasigna4()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.AsignaObraATaquilla("C", 2));
            Perform(m => m.AsignaObraATaquilla("D", 2));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.ReasignaVenta(1, 3));
            Perform(m => m.ReasignaVenta(3, 2));
            Perform(m => m.AsignaObraATaquilla("E", 2));

            CheckMultiSet(m => m.ObrasEnTaquilla(2).ToList());
        }

        public void ReasignaReasigna5()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.AsignaObraATaquilla("C", 2));
            Perform(m => m.AsignaObraATaquilla("D", 2));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.ReasignaVenta(1, 3));
            Perform(m => m.ReasignaVenta(3, 2));
            Perform(m => m.AsignaObraATaquilla("E", 2));
            Perform(m => m.RegistraCliente(client2, "B"));

            CheckSequence(m => m.ClientesEnTaquilla(2).ToList());
        }

        public void ReasignaReasigna6()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var prioritizedNames = new[] { client2.Nombre, client3.Nombre };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.ReasignaVenta(1, 3));
            Perform(m => m.ReasignaVenta(3, 2));
            Perform(m => m.RegistraCliente(client4, "B"));

            CheckSequence(m => m.PriorizaClientes(2, c => prioritizedNames.Contains(c.Nombre)).ToList());
        }

        public void ReasignaReasigna7()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var prioritizedNames = new[] { client2.Nombre, client3.Nombre };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 3));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.ReasignaVenta(1, 3));
            Perform(m => m.ReasignaVenta(3, 2));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.PriorizaClientes(2, c => prioritizedNames.Contains(c.Nombre)).ToList());

            Check(m => m.AtiendeTaquilla(2));
        }
    }

    public class AutografosTest : GestorDeTaquillasTest
    {
        public void AutografosBasico()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));

            CheckSequence(m => m.RecibenAutografos("A").ToList());
        }

        public void AutografosNoModificaCola()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RecibenAutografos("A").ToList());

            CheckSequence(m => m.ClientesEnTaquilla(1).ToList());
        }

        public void SinAutografos1()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.RegistraCliente(client1, "A"));

            CheckSequence(m => m.RecibenAutografos("B").ToList());
        }

        public void SinAutografos2()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));

            CheckSequence(m => m.RecibenAutografos("A").ToList());
        }

        public void SinAutografos3()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.AtiendeTaquilla(1));

            CheckSequence(m => m.RecibenAutografos("A").ToList());
        }

        public void ReversoOrdenRelativoEnAutografos1()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));
            Perform(m => m.RegistraCliente(client3, "A"));

            CheckSequence(m => m.RecibenAutografos("A").ToList());
        }

        public void ReversoOrdenRelativoEnAutografos2()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));

            CheckSequence(m => m.RecibenAutografos("A").ToList());
        }

        public void ReversoOrdenRelativoEnAutografos3()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.RegistraCliente(client5, "B"));

            CheckSequence(m => m.RecibenAutografos("A").ToList());
        }

        public void ReversoOrdenRelativoEnAutografos4()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.RegistraCliente(client5, "B"));

            CheckSequence(m => m.RecibenAutografos("B").ToList());
        }

        public void AutografosDespuesDeAtendidos()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.RegistraCliente(client5, "B"));
            Perform(m => m.AtiendeTaquilla(1));

            CheckSequence(m => m.RecibenAutografos("A").ToList());
        }

        public void AutografosDespuesDePriorizados()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };
            var prioritizedNames = new[] { client2.Nombre, client3.Nombre };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.RegistraCliente(client5, "B"));
            Perform(m => m.PriorizaClientes(1, c => prioritizedNames.Contains(c.Nombre)).ToList());

            CheckSequence(m => m.RecibenAutografos("A").ToList());
        }

        public void AutografosDespuesDeReasignacion1()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 2));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.RegistraCliente(client5, "B"));
            Perform(m => m.ReasignaVenta(1, 3));

            CheckSequence(m => m.RecibenAutografos("A").ToList());
        }

        public void AutografosDespuesDeReasignacion2()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 2));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.RegistraCliente(client5, "B"));
            Perform(m => m.ReasignaVenta(3, 1));

            CheckSequence(m => m.RecibenAutografos("A").ToList());
        }

        public void AutografosDespuesDeReasignacion3()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 2));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.ReasignaVenta(3, 1));
            Perform(m => m.RegistraCliente(client5, "A"));

            CheckSequence(m => m.RecibenAutografos("A").ToList());
        }

        public void AutografosDespuesDeReasignacion4()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P4" };
            var client5 = new Cliente { Nombre = "P5" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 2));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client4, "B"));
            Perform(m => m.ReasignaVenta(1, 3));
            Perform(m => m.AsignaObraATaquilla("C", 1));

            CheckSequence(m => m.RecibenAutografos("C").ToList());
        }
    }

    public class SimetriaTest : GestorDeTaquillasTest
    {
        public void SimetriaBasico()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));
            Perform(m => m.RegistraCliente(client3, "A"));

            Check(m => m.EsSimetrica(1, c => c.Nombre[0]));
        }

        public void SimetriaNoModificaCola()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.EsSimetrica(1, c => c.Nombre[0]));

            CheckSequence(m => m.ClientesEnTaquilla(1).ToList());
        }

        public void SimetriaEnColaVacia()
        {
            Initialize(3);

            Perform(m => m.AsignaObraATaquilla("A", 1));

            Check(m => m.EsSimetrica(1, c => c.Nombre[0]));
        }

        public void SimetriaConUnCliente()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));

            Check(m => m.EsSimetrica(1, c => c.Nombre[0]));
        }

        public void SimetriaMismaReferencia()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1", Edad = 1 };
            var client2 = new Cliente { Nombre = "P2", Edad = 0 };
            var client3 = new Cliente { Nombre = "P3", Edad = 1 };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.EsSimetrica(1, c => (c as Cliente).Edad));

            CheckSequence(m => m.ClientesEnTaquilla(1).ToList());
        }

        public void SimetriaPar1()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));

            Check(m => m.EsSimetrica(1, c => c.Nombre[0]));
        }

        public void SimetriaPar2()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));

            Check(m => m.EsSimetrica(1, c => c.Nombre));
        }

        public void SimetriaSoloSobreUnaTaquilla()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P1" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 2));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));
            Perform(m => m.RegistraCliente(client3, "B"));

            Check(m => m.EsSimetrica(1, c => c.Nombre));
        }

        public void SimetriaConDiferentesObras()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "B"));

            Check(m => m.EsSimetrica(1, c => c.Nombre[0]));
        }

        public void SimetriaDespuesDeReasignacion()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P2" };
            var client5 = new Cliente { Nombre = "P1" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 2));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "B"));
            Perform(m => m.RegistraCliente(client4, "A"));
            Perform(m => m.RegistraCliente(client5, "B"));
            Perform(m => m.ReasignaVenta(1, 2));

            Check(m => m.EsSimetrica(2, c => c.Nombre));
        }

        public void SimetriaDespuesDeAtiende()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P3" };
            var client5 = new Cliente { Nombre = "P2" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "B"));
            Perform(m => m.RegistraCliente(client4, "A"));
            Perform(m => m.RegistraCliente(client5, "B"));
            Perform(m => m.AtiendeTaquilla(1));

            Check(m => m.EsSimetrica(1, c => c.Nombre));
        }

        public void SimetriaDespuesDePrioriza()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P3" };
            var client5 = new Cliente { Nombre = "P2" };
            var prioritizedNames = new[] { client1.Nombre, client3.Nombre };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "B"));
            Perform(m => m.RegistraCliente(client4, "A"));
            Perform(m => m.RegistraCliente(client5, "B"));
            Perform(m => m.PriorizaClientes(1, c => prioritizedNames.Contains(c.Nombre)).ToList());

            Check(m => m.EsSimetrica(1, c => c.Nombre));
        }

        public void NoSimetrico1()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P3" };
            var client5 = new Cliente { Nombre = "P2" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "B"));
            Perform(m => m.RegistraCliente(client4, "A"));
            Perform(m => m.RegistraCliente(client5, "B"));

            Check(m => m.EsSimetrica(1, c => c.Nombre));
        }

        public void NoSimetrico2()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P1" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.AsignaObraATaquilla("B", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "B"));
            Perform(m => m.RegistraCliente(client3, "B"));

            Check(m => m.EsSimetrica(1, c => c.Nombre[1]));
        }

        public void NoSimetrico3()
        {
            Initialize(3);
            var client1 = new Cliente { Nombre = "P11" };
            var client2 = new Cliente { Nombre = "P2" };
            var client3 = new Cliente { Nombre = "P3" };
            var client4 = new Cliente { Nombre = "P41" };
            var client5 = new Cliente { Nombre = "P51" };

            Perform(m => m.AsignaObraATaquilla("A", 1));
            Perform(m => m.RegistraCliente(client1, "A"));
            Perform(m => m.RegistraCliente(client2, "A"));
            Perform(m => m.RegistraCliente(client3, "A"));
            Perform(m => m.RegistraCliente(client4, "A"));
            Perform(m => m.RegistraCliente(client5, "A"));

            Check(m => m.EsSimetrica(1, c => c.Nombre.Length));
        }
    }
}
