﻿using ArbolBinario;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArbolesIsomorfosTester
{
    public class Utils<T> where T : IComparable<T>
    {
        public static bool AreTreesEqual(ArbolBinario<T> t1, ArbolBinario<T> t2)
        {
            if (t1 == null)
                return t2 == null;
            if (t2 == null)
                return false;

            return Equals(t1.Valor, t2.Valor)
                && AreTreesEqual(t1.HijoIzquierdo, t2.HijoIzquierdo)
                && AreTreesEqual(t1.HijoDerecho, t2.HijoDerecho);
        }

        public static bool EsMenor(ArbolBinario<T> arbol1, ArbolBinario<T> arbol2)
        {
            Func<ArbolBinario<T>, string> tagSelector = t => (t.HijoIzquierdo != null ? "1" : "0") + (t.HijoDerecho != null ? "1" : "0");
            var tagsZipped = Enumerable.Zip(PreOrder(arbol1, tagSelector), PreOrder(arbol2, tagSelector), (t1, t2) => new Tuple<string, string>(t1, t2));
            foreach (var tuple in tagsZipped)
            {
                int cmp = tuple.Item1.CompareTo(tuple.Item2);
                if (cmp != 0)
                {
                    return cmp < 0;
                }
            }

            Func<ArbolBinario<T>, T> valueSelector = t => t.Valor;
            var valuesZipped = Enumerable.Zip(PreOrder(arbol1, valueSelector), PreOrder(arbol2, valueSelector), (t1, t2) => new Tuple<T, T>(t1, t2));
            foreach (var tuple in valuesZipped)
            {
                int cmp = tuple.Item1.CompareTo(tuple.Item2);
                if (cmp != 0)
                {
                    return cmp < 0;
                }
            }

            return false;
        }

        private static IEnumerable<R> PreOrder<R>(ArbolBinario<T> tree, Func<ArbolBinario<T>, R> selector)
        {
            if (tree == null)
                yield break;

            yield return selector(tree);

            foreach (var item in PreOrder(tree.HijoIzquierdo, selector))
                yield return item;

            foreach (var item in PreOrder(tree.HijoDerecho, selector))
                yield return item;
        }

        public static ArbolBinario<T> ObtenerMenorEnFamilia(ArbolBinario<T> arbol)
        {
            if (arbol == null)
                return null;

            if (arbol.HijoIzquierdo == null || arbol.HijoDerecho == null)
            {
                return new ArbolBinario<T>(arbol.Valor, null, ObtenerMenorEnFamilia(arbol.HijoIzquierdo ?? arbol.HijoDerecho));
            }

            var leftMinor = ObtenerMenorEnFamilia(arbol.HijoIzquierdo);
            var rightMinor = ObtenerMenorEnFamilia(arbol.HijoDerecho);
            if (EsMenor(leftMinor, rightMinor))
            {
                return new ArbolBinario<T>(arbol.Valor, leftMinor, rightMinor);
            }
            else
            {
                return new ArbolBinario<T>(arbol.Valor, rightMinor, leftMinor);
            }
        }
    }
}
