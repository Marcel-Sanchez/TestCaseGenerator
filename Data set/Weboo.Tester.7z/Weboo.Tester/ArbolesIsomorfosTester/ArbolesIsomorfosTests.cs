﻿using ArbolBinario;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Assess.Tester;

namespace ArbolesIsomorfosTester
{
    public abstract class ArbolesIsomorfosTest : TestCase
    {
        public static bool AreIsomorphous<T>(ArbolBinario<T> t1, ArbolBinario<T> t2) where T : IComparable<T>
        {
            return ReflectionHelper.InvokeStatic<bool>("Weboo.Examen.ArbolesIsomorfos", new[] { typeof(T) }, "SonIsomorfos", t1, t2);
        }

        public static bool LessThan<T>(ArbolBinario<T> t1, ArbolBinario<T> t2) where T : IComparable<T>
        {
            return ReflectionHelper.InvokeStatic<bool>("Weboo.Examen.ArbolesIsomorfos", new[] { typeof(T) }, "EsMenor", t1, t2);
        }

        public static ArbolBinario<T> LeastInFamily<T>(ArbolBinario<T> t) where T : IComparable<T>
        {
            return ReflectionHelper.InvokeStatic<ArbolBinario<T>>("Weboo.Examen.ArbolesIsomorfos", new[] { typeof(T) }, "ObtenerMenorEnFamilia", t);
        }
    }

    public class ExampleTest : ArbolesIsomorfosTest
    {
        public void Example1()
        {
            ArbolBinario<int> arbol_A = new ArbolBinario<int>(1,
                                        new ArbolBinario<int>(2,
                                            new ArbolBinario<int>(3,
                                                null,
                                                new ArbolBinario<int>(4, null, null)),
                                            new ArbolBinario<int>(5, null, null)),
                                        new ArbolBinario<int>(6,
                                            new ArbolBinario<int>(7, null, null),
                                            new ArbolBinario<int>(8, null, null)
                                            )
                                        );
            ArbolBinario<int> arbol_B = new ArbolBinario<int>(1,
                                        new ArbolBinario<int>(6,
                                            new ArbolBinario<int>(8, null, null),
                                            new ArbolBinario<int>(7, null, null)
                                            ),
                                        new ArbolBinario<int>(2,
                                            new ArbolBinario<int>(5, null, null),
                                            new ArbolBinario<int>(3,
                                               new ArbolBinario<int>(4, null, null),
                                               null)
                                            )
                                        );

            Assert.That(AreIsomorphous(arbol_A, arbol_B), Is.True);
        }

        public void Example2()
        {
            ArbolBinario<int> arbol_A = new ArbolBinario<int>(1,
                                        new ArbolBinario<int>(2,
                                            new ArbolBinario<int>(3,
                                                null,
                                                new ArbolBinario<int>(4, null, null)),
                                            new ArbolBinario<int>(5, null, null)),
                                        new ArbolBinario<int>(6,
                                            new ArbolBinario<int>(7, null, null),
                                            new ArbolBinario<int>(8, null, null)
                                            )
                                        );
            ArbolBinario<int> arbol_B = new ArbolBinario<int>(1,
                                        new ArbolBinario<int>(6,
                                            new ArbolBinario<int>(8, null, null),
                                            new ArbolBinario<int>(7, null, null)
                                            ),
                                        new ArbolBinario<int>(2,
                                            new ArbolBinario<int>(5, null, null),
                                            new ArbolBinario<int>(3,
                                               new ArbolBinario<int>(4, null, null),
                                               null)
                                            )
                                        );

            Assert.That(LessThan(arbol_A, arbol_B), Is.False);
        }

        public void Example3()
        {
            ArbolBinario<int> arbol_A = new ArbolBinario<int>(1,
                                        new ArbolBinario<int>(2,
                                            new ArbolBinario<int>(3,
                                                null,
                                                new ArbolBinario<int>(4, null, null)),
                                            new ArbolBinario<int>(5, null, null)),
                                        new ArbolBinario<int>(6,
                                            new ArbolBinario<int>(7, null, null),
                                            new ArbolBinario<int>(8, null, null)
                                            )
                                        );

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(arbol_A);
            var student = LeastInFamily(arbol_A);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }

        public void Example4()
        {
            ArbolBinario<int> arbol_B = new ArbolBinario<int>(1,
                                        new ArbolBinario<int>(6,
                                            new ArbolBinario<int>(8, null, null),
                                            new ArbolBinario<int>(7, null, null)
                                            ),
                                        new ArbolBinario<int>(2,
                                            new ArbolBinario<int>(5, null, null),
                                            new ArbolBinario<int>(3,
                                               new ArbolBinario<int>(4, null, null),
                                               null)
                                            )
                                        );

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(arbol_B);
            var student = LeastInFamily(arbol_B);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class IsomorphousTest : ArbolesIsomorfosTest
    {
        public void BasicIsomorphous1()
        {
            var t1 = new ArbolBinario<int>(4, null, null);
            var t2 = new ArbolBinario<int>(3, null, null);

            Assert.That(AreIsomorphous(t1, t2), Is.False);
        }
    }

    class IsomorphousTest2 : ArbolesIsomorfosTest
    {
        public void BasicIsomorphous2()
        {
            var t1 = new ArbolBinario<int>(10, null, null);
            var t2 = new ArbolBinario<int>(10, null, null);

            Assert.That(AreIsomorphous(t1, t2), Is.True);
        }
    }

    class IsomorphousTest3 : ArbolesIsomorfosTest
    {
        public void Isomorphous3()
        {
            var t1 = new ArbolBinario<int>(10,
                new ArbolBinario<int>(3, null, null),
                null);
            var t2 = new ArbolBinario<int>(10,
                new ArbolBinario<int>(4, null, null),
                null);

            Assert.That(AreIsomorphous(t1, t2), Is.False);
        }
    }
    class IsomorphousTest4 : ArbolesIsomorfosTest
    {
        public void Isomorphous4()
        {
            var t1 = new ArbolBinario<int>(10,
                new ArbolBinario<int>(3, null, null),
                null);
            var t2 = new ArbolBinario<int>(10,
                new ArbolBinario<int>(3, null, null),
                null);

            Assert.That(AreIsomorphous(t1, t2), Is.True);
        }
    }

    class IsomorphousTest5 : ArbolesIsomorfosTest
    {
        public void Isomorphous5()
        {
            var t1 = new ArbolBinario<int>(10,
                new ArbolBinario<int>(3, null, null),
                null);
            var t2 = new ArbolBinario<int>(10,
                null,
                new ArbolBinario<int>(4, null, null));

            Assert.That(AreIsomorphous(t1, t2), Is.False);
        }
    }

    class IsomorphousTest6 : ArbolesIsomorfosTest
    {
        public void Isomorphous6()
        {
            var t1 = new ArbolBinario<int>(10,
                new ArbolBinario<int>(3, null, null),
                null);
            var t2 = new ArbolBinario<int>(10,
                null,
                new ArbolBinario<int>(3, null, null));

            Assert.That(AreIsomorphous(t1, t2), Is.True);
        }
    }

    class IsomorphousTest7 : ArbolesIsomorfosTest
    {
        public void Isomorphous7()
        {
            var t1 = new ArbolBinario<int>(10,
                new ArbolBinario<int>(3, null, null),
                null);
            var t2 = new ArbolBinario<int>(10,
                null,
                null);

            Assert.That(AreIsomorphous(t1, t2), Is.False);
        }
    }

    class IsomorphousTest8 : ArbolesIsomorfosTest
    {
        public void Isomorphous8()
        {
            var t1 = new ArbolBinario<int>(10,
                null,
                null);
            var t2 = new ArbolBinario<int>(10,
                null,
                new ArbolBinario<int>(3, null, null));

            Assert.That(AreIsomorphous(t1, t2), Is.False);
        }
    }

    class IsomorphousTest9 : ArbolesIsomorfosTest
    {
        public void Isomorphous9()
        {
            var t1 = new ArbolBinario<int>(10,
                new ArbolBinario<int>(3, null, null),
                new ArbolBinario<int>(8, null, null));
            var t2 = new ArbolBinario<int>(10,
                null,
                new ArbolBinario<int>(3, null, null));

            Assert.That(AreIsomorphous(t1, t2), Is.False);
        }
    }

    class IsomorphousTest10 : ArbolesIsomorfosTest
    {
        public void Isomorphous10()
        {
            var t1 = new ArbolBinario<int>(10,
                new ArbolBinario<int>(3, null, null),
                new ArbolBinario<int>(8, null, null));
            var t2 = new ArbolBinario<int>(10,
                null,
                new ArbolBinario<int>(8, null, null));

            Assert.That(AreIsomorphous(t1, t2), Is.False);
        }
    }

    class IsomorphousTest11 : ArbolesIsomorfosTest
    {
        public void Isomorphous11()
        {
            var t1 = new ArbolBinario<int>(10,
                new ArbolBinario<int>(3, null, null),
                new ArbolBinario<int>(8, null, null));
            var t2 = new ArbolBinario<int>(10,
                new ArbolBinario<int>(8, null, null),
                new ArbolBinario<int>(3, null, null));

            Assert.That(AreIsomorphous(t1, t2), Is.True);
        }
    }

    class IsomorphousTest12 : ArbolesIsomorfosTest
    {
        public void Isomorphous12()
        {
            var t1 = new ArbolBinario<int>(10,
                new ArbolBinario<int>(3,
                    new ArbolBinario<int>(8, null, null),
                    null),
                null);
            var t2 = new ArbolBinario<int>(10,
                new ArbolBinario<int>(8,
                    new ArbolBinario<int>(3, null, null),
                    null),
                null);

            Assert.That(AreIsomorphous(t1, t2), Is.False);
        }
    }

    class IsomorphousTest13 : ArbolesIsomorfosTest
    {
        public void Isomorphous13()
        {
            var t1 = new ArbolBinario<int>(10,
                new ArbolBinario<int>(3,
                    new ArbolBinario<int>(8,
                        null,
                        new ArbolBinario<int>(6,
                            null,
                            new ArbolBinario<int>(2, null, null))),
                    null),
                null);
            var t2 = new ArbolBinario<int>(10,
                null,
                new ArbolBinario<int>(3,
                    null,
                    new ArbolBinario<int>(8,
                        null,
                        new ArbolBinario<int>(6,
                            new ArbolBinario<int>(2, null, null),
                            null))));

            Assert.That(AreIsomorphous(t1, t2), Is.True);
        }
    }

    class IsomorphousTest14 : ArbolesIsomorfosTest
    {
        public void Isomorphous14()
        {
            var t1 = new ArbolBinario<int>(10,
                new ArbolBinario<int>(3,
                    new ArbolBinario<int>(8,
                        null,
                        new ArbolBinario<int>(6,
                            null,
                            new ArbolBinario<int>(2, null, null))),
                    null),
                null);
            var t2 = new ArbolBinario<int>(10,
                null,
                new ArbolBinario<int>(3,
                    null,
                    new ArbolBinario<int>(8,
                        null,
                        new ArbolBinario<int>(6,
                            new ArbolBinario<int>(4, null, null),
                            null))));

            Assert.That(AreIsomorphous(t1, t2), Is.False);
        }
    }

    class IsomorphousTest15 : ArbolesIsomorfosTest
    {
        public void Isomorphous15()
        {
            var t1 = new ArbolBinario<int>(10,
                new ArbolBinario<int>(9,
                    null,
                    new ArbolBinario<int>(5,
                        new ArbolBinario<int>(1, null, null),
                        null)),
                new ArbolBinario<int>(3,
                    new ArbolBinario<int>(8,
                        null,
                        new ArbolBinario<int>(6,
                            null,
                            new ArbolBinario<int>(2, null, null))),
                    null));
            var t2 = new ArbolBinario<int>(10,
                new ArbolBinario<int>(3,
                    null,
                    new ArbolBinario<int>(8,
                        null,
                        new ArbolBinario<int>(6,
                            new ArbolBinario<int>(2, null, null),
                            null))),
                new ArbolBinario<int>(9,
                    new ArbolBinario<int>(5,
                        new ArbolBinario<int>(1, null, null),
                        null),
                    null));

            Assert.That(AreIsomorphous(t1, t2), Is.True);
        }
    }

    class IsomorphousTest16 : ArbolesIsomorfosTest
    {
        public void Isomorphous16()
        {
            var t1 = new ArbolBinario<int>(20,
                new ArbolBinario<int>(9,
                    null,
                    new ArbolBinario<int>(5,
                        new ArbolBinario<int>(1, null, null),
                        null)),
                new ArbolBinario<int>(3,
                    new ArbolBinario<int>(8,
                        null,
                        new ArbolBinario<int>(6,
                            null,
                            new ArbolBinario<int>(2, null, null))),
                    null));
            var t2 = new ArbolBinario<int>(10,
                new ArbolBinario<int>(3,
                    null,
                    new ArbolBinario<int>(8,
                        null,
                        new ArbolBinario<int>(6,
                            new ArbolBinario<int>(4, null, null),
                            null))),
                new ArbolBinario<int>(9,
                    new ArbolBinario<int>(5,
                        new ArbolBinario<int>(1, null, null),
                        null),
                    null));

            Assert.That(AreIsomorphous(t1, t2), Is.False);
        }
    }

    class IsomorphousTest17 : ArbolesIsomorfosTest
    {
        public void NoCountByLevel1()
        {
            var t1 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3, null, null),
                    new ArbolBinario<int>(4, null, null)),
                new ArbolBinario<int>(5,
                    null,
                    null));
            var t2 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3, null, null),
                    null),
                new ArbolBinario<int>(5,
                    new ArbolBinario<int>(4, null, null),
                    null));

            Assert.That(AreIsomorphous(t1, t2), Is.False);
        }
    }

    class IsomorphousTest18 : ArbolesIsomorfosTest
    {
        public void NoCountByLevel2()
        {
            var t1 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3, null, null),
                    new ArbolBinario<int>(4, null, null)),
                new ArbolBinario<int>(5,
                    null,
                    null));
            var t2 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    null,
                    null),
                new ArbolBinario<int>(5,
                    new ArbolBinario<int>(3, null, null),
                    new ArbolBinario<int>(4, null, null)));

            Assert.That(AreIsomorphous(t1, t2), Is.False);
        }
    }

    class IsomorphousTest19 : ArbolesIsomorfosTest
    {
        public void IsomorphousComparable1()
        {
            var t1 = new ArbolBinario<string>("1",
                new ArbolBinario<string>("2",
                    new ArbolBinario<string>("3", null, null),
                    new ArbolBinario<string>("4", null, null)),
                new ArbolBinario<string>("5",
                    null,
                    null));
            var t2 = new ArbolBinario<string>("1",
                new ArbolBinario<string>("5",
                    null,
                    null),
                new ArbolBinario<string>("2",
                    new ArbolBinario<string>("3", null, null),
                    new ArbolBinario<string>("4", null, null)));

            Assert.That(AreIsomorphous(t1, t2), Is.True);
        }
    }

    class IsomorphousTest20 : ArbolesIsomorfosTest
    {
        public void IsomorphousComparable2()
        {
            var t1 = new ArbolBinario<bool>(true,
                new ArbolBinario<bool>(true,
                    new ArbolBinario<bool>(true, null, null),
                    new ArbolBinario<bool>(false, null, null)),
                null);
            var t2 = new ArbolBinario<bool>(true,
                null,
                new ArbolBinario<bool>(true,
                    new ArbolBinario<bool>(false, null, null),
                    new ArbolBinario<bool>(true, null, null)));

            Assert.That(AreIsomorphous(t1, t2), Is.True);
        }
    }

    public class LessThanTree : ArbolesIsomorfosTest
    {
        public void LessThanBasic1()
        {
            var t1 = new ArbolBinario<int>(1, null, null);
            var t2 = new ArbolBinario<int>(1, null, null);

            Assert.That(LessThan(t1, t2), Is.False);
        }
    }

    public class LessThanTree2 : ArbolesIsomorfosTest
    {
        public void LessThanBasic2()
        {
            var t1 = new ArbolBinario<int>(1,
                null,
                new ArbolBinario<int>(2, null, null));
            var t2 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2, null, null),
                null);

            Assert.That(LessThan(t1, t2), Is.True);
        }
    }

    public class LessThanTree3 : ArbolesIsomorfosTest
    {
        public void LessThanBasic3()
        {
            var t1 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2, null, null),
                null);
            var t2 = new ArbolBinario<int>(1,
                null,
                new ArbolBinario<int>(2, null, null));

            Assert.That(LessThan(t1, t2), Is.False);
        }
    }

    public class LessThanTree4 : ArbolesIsomorfosTest
    {
        public void LessThanBasic4()
        {
            var t1 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2, null, null),
                new ArbolBinario<int>(3, null, null));
            var t2 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(3, null, null),
                new ArbolBinario<int>(2, null, null));

            Assert.That(LessThan(t1, t2), Is.True);
        }
    }

    public class LessThanTree5 : ArbolesIsomorfosTest
    {
        public void LessThan5()
        {
            var t1 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3,
                        new ArbolBinario<int>(4, null, null),
                        null),
                    null),
                null);

            var t2 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3,
                        null,
                        new ArbolBinario<int>(4, null, null)),
                    null),
                null);

            Assert.That(LessThan(t1, t2), Is.False);
        }
    }

    public class LessThanTree6 : ArbolesIsomorfosTest
    {
        public void LessThan6()
        {
            var t1 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3,
                        null,
                        new ArbolBinario<int>(4, null, null)),
                    null),
                null);

            var t2 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3,
                        new ArbolBinario<int>(4, null, null),
                        null),
                    null),
                null);

            Assert.That(LessThan(t1, t2), Is.True);
        }
    }

    public class LessThanTree7 : ArbolesIsomorfosTest
    {
        public void LessThan7()
        {
            var t1 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3,
                        new ArbolBinario<int>(4, null, null),
                        null),
                    new ArbolBinario<int>(5,
                        null,
                        new ArbolBinario<int>(6, null, null))),
                null);

            var t2 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3,
                        new ArbolBinario<int>(4, null, null),
                        null),
                    new ArbolBinario<int>(5,
                        new ArbolBinario<int>(6, null, null),
                        null)),
                null);

            Assert.That(LessThan(t1, t2), Is.True);
        }
    }

    public class LessThanTree8 : ArbolesIsomorfosTest
    {
        public void SameStructure1()
        {
            var t1 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(4,
                        new ArbolBinario<int>(6, null, null),
                        null),
                    new ArbolBinario<int>(3,
                        new ArbolBinario<int>(5, null, null),
                        null)),
                null);

            var t2 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3,
                        new ArbolBinario<int>(5, null, null),
                        null),
                    new ArbolBinario<int>(4,
                        new ArbolBinario<int>(6, null, null),
                        null)),
                null);

            Assert.That(LessThan(t1, t2), Is.False);
        }
    }

    public class LessThanTree9 : ArbolesIsomorfosTest
    {
        public void SameStructure2()
        {
            var t1 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3,
                        new ArbolBinario<int>(5, null, null),
                        null),
                    new ArbolBinario<int>(4,
                        new ArbolBinario<int>(6, null, null),
                        null)),
                null);

            var t2 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(4,
                        new ArbolBinario<int>(6, null, null),
                        null),
                    new ArbolBinario<int>(3,
                        new ArbolBinario<int>(5, null, null),
                        null)),
                null);

            Assert.That(LessThan(t1, t2), Is.True);
        }
    }

    public class LessThanTree10 : ArbolesIsomorfosTest
    {
        public void SameStructure3()
        {
            var t1 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3, null, null),
                    null),
                new ArbolBinario<int>(4,
                    new ArbolBinario<int>(5, null, null),
                    null));

            var t2 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(4,
                    new ArbolBinario<int>(5, null, null),
                    null),
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3, null, null),
                    null));

            Assert.That(LessThan(t1, t2), Is.True);
        }
    }

    public class LessThanTree11 : ArbolesIsomorfosTest
    {
        public void SameStructure4()
        {
            var t1 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3, null, null),
                    null),
                new ArbolBinario<int>(4,
                    new ArbolBinario<int>(5, null, null),
                    null));

            var t2 = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3, null, null),
                    null),
                new ArbolBinario<int>(4,
                    new ArbolBinario<int>(5, null, null),
                    null));

            Assert.That(LessThan(t1, t2), Is.False);
        }
    }

    public class LessThanTree12 : ArbolesIsomorfosTest
    {
        public void LessThanComparable1()
        {
            var t1 = new ArbolBinario<string>("1",
                new ArbolBinario<string>("2",
                    new ArbolBinario<string>("3",
                        new ArbolBinario<string>("4", null, null),
                        null),
                    new ArbolBinario<string>("5",
                        null,
                        new ArbolBinario<string>("6", null, null))),
                null);

            var t2 = new ArbolBinario<string>("1",
                new ArbolBinario<string>("2",
                    new ArbolBinario<string>("3",
                        new ArbolBinario<string>("4", null, null),
                        null),
                    new ArbolBinario<string>("5",
                        new ArbolBinario<string>("6", null, null),
                        null)),
                null);

            Assert.That(LessThan(t1, t2), Is.True);
        }
    }

    public class LessThanTree13 : ArbolesIsomorfosTest
    {
        public void LessThanComparable2()
        {
            var t1 = new ArbolBinario<string>("1",
                new ArbolBinario<string>("2",
                    new ArbolBinario<string>("3",
                        new ArbolBinario<string>("4", null, null),
                        null),
                    new ArbolBinario<string>("5",
                        null,
                        new ArbolBinario<string>("6", null, null))),
                null);

            var t2 = new ArbolBinario<string>("1",
                new ArbolBinario<string>("2",
                    new ArbolBinario<string>("5",
                        new ArbolBinario<string>("6", null, null),
                        null),
                    new ArbolBinario<string>("3",
                        null,
                        new ArbolBinario<string>("4", null, null))),
                null);

            Assert.That(LessThan(t1, t2), Is.True);
        }
    }

    public class LessThanTree14 : ArbolesIsomorfosTest
    {
        public void LessThanComparable3()
        {
            var t1 = new ArbolBinario<string>("1",
                new ArbolBinario<string>("2",
                    new ArbolBinario<string>("5",
                        new ArbolBinario<string>("6", null, null),
                        null),
                    new ArbolBinario<string>("3",
                        null,
                        new ArbolBinario<string>("4", null, null))),
                null);

            var t2 = new ArbolBinario<string>("1",
                new ArbolBinario<string>("2",
                    new ArbolBinario<string>("3",
                        new ArbolBinario<string>("4", null, null),
                        null),
                    new ArbolBinario<string>("5",
                        null,
                        new ArbolBinario<string>("6", null, null))),
                null);

            Assert.That(LessThan(t1, t2), Is.False);
        }
    }

    public class LessThanTree15 : ArbolesIsomorfosTest
    {
        public void LessThanComparable4()
        {
            var t1 = new ArbolBinario<bool>(true,
                new ArbolBinario<bool>(false, null, null),
                new ArbolBinario<bool>(true, null, null));

            var t2 = new ArbolBinario<bool>(true,
                new ArbolBinario<bool>(true, null, null),
                new ArbolBinario<bool>(false, null, null));

            Assert.That(LessThan(t1, t2), Is.True);
        }
    }

    public class LeastInFamily : ArbolesIsomorfosTest
    {
        public void LeastInFamilyBasic1()
        {
            ArbolBinario<int> t = new ArbolBinario<int>(1, null, null);

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily2 : ArbolesIsomorfosTest
    {
        public void LeastInFamilyBasic2()
        {
            ArbolBinario<int> t = new ArbolBinario<int>(1,
                null,
                new ArbolBinario<int>(2, null, null));

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily3 : ArbolesIsomorfosTest
    {
        public void LeastInFamilyBasic3()
        {
            ArbolBinario<int> t = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2, null, null),
                null);

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily4 : ArbolesIsomorfosTest
    {
        public void LeastInFamilyBasic4()
        {
            ArbolBinario<int> t = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2, null, null),
                new ArbolBinario<int>(3, null, null));

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily5 : ArbolesIsomorfosTest
    {
        public void LeastInFamilyBasic5()
        {
            ArbolBinario<int> t = new ArbolBinario<int>(1,
                new ArbolBinario<int>(3, null, null),
                new ArbolBinario<int>(2, null, null));

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily6 : ArbolesIsomorfosTest
    {
        public void Degenerated1()
        {
            ArbolBinario<int> t = new ArbolBinario<int>(1,
                null,
                new ArbolBinario<int>(2,
                    null,
                    new ArbolBinario<int>(3,
                        null,
                        new ArbolBinario<int>(4, null, null))));

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily7 : ArbolesIsomorfosTest
    {
        public void Degenerated2()
        {
            ArbolBinario<int> t = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3,
                        new ArbolBinario<int>(4, null, null),
                        null),
                    null),
                null);

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily8 : ArbolesIsomorfosTest
    {
        public void Degenerated3()
        {
            ArbolBinario<int> t = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    null,
                    new ArbolBinario<int>(3,
                        new ArbolBinario<int>(4, null, null),
                        null)),
                null);

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily9 : ArbolesIsomorfosTest
    {
        public void Complex1()
        {
            ArbolBinario<int> t = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    null,
                    new ArbolBinario<int>(3, null, null)),
                new ArbolBinario<int>(4,
                    null,
                    new ArbolBinario<int>(5, null, null)));

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily10 : ArbolesIsomorfosTest
    {
        public void Complex2()
        {
            ArbolBinario<int> t = new ArbolBinario<int>(1,
                new ArbolBinario<int>(4,
                    null,
                    new ArbolBinario<int>(5, null, null)),
                new ArbolBinario<int>(2,
                    null,
                    new ArbolBinario<int>(3, null, null)));

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily11 : ArbolesIsomorfosTest
    {
        public void Complex3()
        {
            ArbolBinario<int> t = new ArbolBinario<int>(1,
                new ArbolBinario<int>(4,
                    new ArbolBinario<int>(5, null, null),
                    null),
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3, null, null),
                    null));

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily12 : ArbolesIsomorfosTest
    {
        public void Complex4()
        {
            ArbolBinario<int> t = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(4, null, null),
                    new ArbolBinario<int>(3, null, null)),
                new ArbolBinario<int>(5, null, null));

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily13 : ArbolesIsomorfosTest
    {
        public void Complex5()
        {
            ArbolBinario<int> t = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(4, null, null),
                    new ArbolBinario<int>(3, null, null)),
                new ArbolBinario<int>(5,
                    new ArbolBinario<int>(6, null, null),
                    null));

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily14 : ArbolesIsomorfosTest
    {
        public void Complex6()
        {
            ArbolBinario<int> t = new ArbolBinario<int>(1,
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3,
                        null,
                        new ArbolBinario<int>(8,
                            null,
                            new ArbolBinario<int>(10, null, null))),
                    new ArbolBinario<int>(4, null, null)),
                new ArbolBinario<int>(5,
                    new ArbolBinario<int>(6, null, null),
                    null));

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily15 : ArbolesIsomorfosTest
    {
        public void Complex7()
        {
            ArbolBinario<int> t = new ArbolBinario<int>(1,
                new ArbolBinario<int>(5,
                    null,
                    new ArbolBinario<int>(6, null, null)),
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(4, null, null),
                    new ArbolBinario<int>(3,
                        null,
                        new ArbolBinario<int>(8,
                            null,
                            new ArbolBinario<int>(10, null, null)))));

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily16 : ArbolesIsomorfosTest
    {
        public void Complex8()
        {
            ArbolBinario<int> t = new ArbolBinario<int>(1,
                new ArbolBinario<int>(5,
                    null,
                    new ArbolBinario<int>(6,
                        new ArbolBinario<int>(7, null, null),
                        null)),
                new ArbolBinario<int>(2,
                    new ArbolBinario<int>(3,
                        new ArbolBinario<int>(4, null, null),
                        null),
                    null));

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily17 : ArbolesIsomorfosTest
    {
        public void Complex9()
        {
            ArbolBinario<int> t = null;
            for (int i = 0; i < 29; i++)
            {
                ArbolBinario<int> left = i % 2 == 0 ? null : t;
                ArbolBinario<int> right = i % 2 != 0 ? null : t;
                t = new ArbolBinario<int>(i, left, right);
            }

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily18 : ArbolesIsomorfosTest
    {
        public void Complex10()
        {
            ArbolBinario<int> t = null;
            for (int i = 0; i < 1000; i++)
            {
                ArbolBinario<int> left = i % 2 == 0 ? null : t;
                ArbolBinario<int> right = i % 2 != 0 ? null : t;
                t = new ArbolBinario<int>(i, left, right);
            }

            var benchmark = Utils<int>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<int>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily19 : ArbolesIsomorfosTest
    {
        public void LeastInFamilyComparable1()
        {
            ArbolBinario<string> t = new ArbolBinario<string>("1",
                new ArbolBinario<string>("5",
                    null,
                    new ArbolBinario<string>("6",
                        new ArbolBinario<string>("7", null, null),
                        null)),
                new ArbolBinario<string>("2",
                    new ArbolBinario<string>("3",
                        new ArbolBinario<string>("4", null, null),
                        null),
                    null));

            var benchmark = Utils<string>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<string>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily20 : ArbolesIsomorfosTest
    {
        public void LeastInFamilyComparable2()
        {
            ArbolBinario<string> t = new ArbolBinario<string>("1",
                new ArbolBinario<string>("2",
                    new ArbolBinario<string>("3",
                        null,
                        new ArbolBinario<string>("8",
                            null,
                            new ArbolBinario<string>("10", null, null))),
                    new ArbolBinario<string>("4", null, null)),
                new ArbolBinario<string>("5",
                    new ArbolBinario<string>("6", null, null),
                    null));

            var benchmark = Utils<string>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<string>.AreTreesEqual(benchmark, student), Is.True);
        }
    }

    public class LeastInFamily21 : ArbolesIsomorfosTest
    {
        public void LeastInFamilyComparable3()
        {
            ArbolBinario<bool> t = new ArbolBinario<bool>(true,
                new ArbolBinario<bool>(true, null, null),
                new ArbolBinario<bool>(false,
                    new ArbolBinario<bool>(true, null, null),
                    null));

            var benchmark = Utils<bool>.ObtenerMenorEnFamilia(t);
            var student = LeastInFamily(t);
            Assert.That(Utils<bool>.AreTreesEqual(benchmark, student), Is.True);
        }
    }
}
