﻿using System;
using System.Linq;
using Weboo.Assess.Tester;

namespace ElContenedorTester
{
    public abstract class ContenedorTest : TestCase
    {
        public int[] Student(int[] contenedor, int k)
        {
            return ReflectionHelper.InvokeStatic<int[]>("Weboo.Examen.Contenedor", "Rota", contenedor, k);
        }

        public int[] Benchmark(int[] contenedor, int k)
        {
            if (k == 0)
                return contenedor;

            int[] boxes = new int[contenedor.Length];
            Array.Copy(contenedor, 0, boxes, 0, contenedor.Length);
            Array.Sort(boxes, (a, b) => b - a);
            if (k % 2 == 1)
            {
                int[] rotedContainer = new int[boxes.Max()];
                int index = 0;
                for (int i = boxes.Length - 1; i > -1; i--)
                {
                    while (index < boxes[i])
                    {
                        rotedContainer[index] = i + 1;
                        index++;
                    }
                }
                boxes = rotedContainer;
            }

            return boxes;
        }

        public void Check(int[] container, int k)
        {
            int[] studentContainer = (int[])container.Clone();
            int[] benchmarkContainer = (int[])container.Clone();

            Assert.That(Student(studentContainer, k), Is.SequenceEqualTo(Benchmark(benchmarkContainer, k)));
        }
    }

    public class ExampleTests : ContenedorTest
    {
        public void Example1()
        {
            int[] container = { 4 };
            Check(container, 1);
        }

        public void Example2()
        {
            int[] container = { 2, 4, 2, 1, 3 };
            Check(container, 1);
        }

        public void Example3()
        {
            int[] container = { 1, 2, 3, 2 };
            Check(container, 2);
        }

        public void Example4()
        {
            int[] container = { 2, 0, 0, 0, 3 };
            Check(container, 2);
        }
    }

    public class BasicTests : ContenedorTest
    {
        public void Basic1()
        {
            int[] container = { 1, 1, 1 };
            Check(container, 1);
        }

        public void Basic2()
        {
            int[] container = { 1, 1, 1 };
            Check(container, 2);
        }

        public void Basic3()
        {
            int[] container = { 3, 2, 1 };
            Check(container, 3);
        }

        public void Basic4()
        {
            int[] container = { 3, 2, 1 };
            Check(container, 6);
        }

        public void Basic5()
        {
            int[] container = { 3, 8, 1, 2 };
            Check(container, 3);
        }

        public void Basic6()
        {
            int[] container = { 3, 8, 1, 2 };
            Check(container, 2);
        }

        public void Basic7()
        {
            int[] container = { 3, 100, 1, 1 };
            Check(container, 6);
        }

        public void Basic8()
        {
            int[] container = { 3, 1, 5, 1 };
            Check(container, 6);
        }

        public void Basic9()
        {
            int[] container = { 3, 1, 10, 1, 3, 1, 8 };
            Check(container, 6);
        }

        public void Basic10()
        {
            int[] container = { 3, 1, 10, 1, 3, 1, 8 };
            Check(container, 1);
        }

        public void Inverted1()
        {
            int[] container = { 3, 4, 5, 10 };
            Check(container, 3);
        }

        public void Inverted2()
        {
            int[] container = { 3, 4, 5, 10 };
            Check(container, 4);
        }

        public void AllEquals1()
        {
            int[] container = { 7, 7, 7, 7 };
            Check(container, 1);
        }

        public void AllEquals2()
        {
            int[] container = { 7, 7, 7, 7 };
            Check(container, 2);
        }
    }

    public class NoRotationTests : ContenedorTest
    {
        public void NoRotation1()
        {
            int[] container = { 1, 2 };
            Check(container, 0);
        }

        public void NoRotation2()
        {
            int[] container = { 1, 8, 10, 2 };
            Check(container, 0);
        }

        public void NoRotation3()
        {
            int[] container = { 4, 3, 1 };
            Check(container, 0);
        }

        public void NoRotation4()
        {
            int[] container = { 4, 0, 8, 1 };
            Check(container, 0);
        }
    }

    public class AlternatedZeroTests : ContenedorTest
    {

        public void AlternatedZeros1()
        {
            int[] container = { 1, 0, 2 };
            Check(container, 1);
        }

        public void AlternatedZeros2()
        {
            int[] container = { 1, 0, 2 };
            Check(container, 6);
        }

        public void AlternatedZeros3()
        {
            int[] container = { 0, 8, 1 };
            Check(container, 3);
        }

        public void AlternatedZeros4()
        {
            int[] container = { 0, 8, 1 };
            Check(container, 2);
        }

        public void AlternatedZeros5()
        {
            int[] container = { 10, 0, 0, 0, 1 };
            Check(container, 2);
        }

        public void AlternatedZeros6()
        {
            int[] container = { 10, 0, 0, 0, 1 };
            Check(container, 5);
        }

        public void AlternatedZeros7()
        {
            int[] container = { 0, 10, 0, 8, 1, 0 };
            Check(container, 1);
        }

        public void AlternatedZeros8()
        {
            int[] container = { 0, 10, 0, 8, 1, 0 };
            Check(container, 10);
        }

        public void AlternatedZeros9()
        {
            int[] container = { 0, 0, 0, 0, 1, 0, 0, 0 };
            Check(container, 1);
        }

        public void AlternatedZeros10()
        {
            int[] container = { 0, 0, 0, 0, 1, 0, 0, 0 };
            Check(container, 4);
        }
    }

    public class BigTests : ContenedorTest
    {
        public void Big1()
        {
            int[] container = { 1000, 1, 100 };
            Check(container, 1);
        }

        public void Big2()
        {
            int[] container = { 1, 5, 2 };
            Check(container, 10000);
        }

        public void Big3()
        {
            int[] container = Enumerable.Range(0, 500).Select(m => Math.Abs(250 - m)).ToArray();
            Check(container, 5);
        }
    }
}
