﻿using GuerraDeTribus;
using System.Collections.Generic;
using System.Linq;

namespace GuerraTribusTester
{
    public class GuerraTribus : IGuerraDeTribus
    {
        private class Tribe
        {
            public string Name;
            public List<Guerrero> Warriors;
        }

        private List<Tribe> _tribes;

        public GuerraTribus()
        {
            _tribes = new List<Tribe>();
        }

        public string Combate(string tribu1, string tribu2)
        {
            var winnerTribe = _tribes.First(m => m.Name == tribu1);
            var loserT = _tribes.First(m => m.Name == tribu2);

            while (true)
            {
                var warriorFromWinnerTeam = GetHealthiest(winnerTribe);
                var warriorFromLoserTeam = GetHealthiest(loserT);
                if (warriorFromWinnerTeam.VidaActual < 10 || warriorFromLoserTeam.VidaActual < 10)
                    break;

                while (true)
                {
                    warriorFromLoserTeam.VidaActual -= warriorFromWinnerTeam.Fuerza;
                    if (warriorFromLoserTeam.VidaActual < 10)
                    {
                        break;
                    }

                    warriorFromWinnerTeam.VidaActual -= warriorFromLoserTeam.Fuerza;
                    if (warriorFromWinnerTeam.VidaActual < 10)
                    {
                        var tmp = winnerTribe;
                        winnerTribe = loserT;
                        loserT = tmp;
                        break;
                    }
                }
            }

            winnerTribe.Warriors.RemoveAll(m => m.VidaActual < 5);
            loserT.Warriors.RemoveAll(m => m.VidaActual < 5);

            winnerTribe.Warriors.ForEach(m =>
            {
                m.Fuerza++;
                m.VidaTotal += 5;
            });
            winnerTribe.Warriors.AddRange(loserT.Warriors);
            winnerTribe.Warriors.ForEach(m =>
            {
                m.VidaActual = m.VidaTotal;
            });

            _tribes.Remove(loserT);
            return winnerTribe.Name;
        }

        public IEnumerable<Guerrero> GuerrerosMasFuertes()
        {
            foreach (var tribe in _tribes)
            {
                var strongestWarrior = tribe.Warriors[0];
                foreach (var warrior in tribe.Warriors)
                {
                    if (strongestWarrior.Fuerza < warrior.Fuerza || (strongestWarrior.Fuerza == warrior.Fuerza && strongestWarrior.VidaActual < warrior.VidaActual))
                    {
                        strongestWarrior = warrior;
                    }
                }

                yield return strongestWarrior;
            }
        }

        public IEnumerable<Guerrero> GuerrerosMasResistentes()
        {
            foreach (var tribe in _tribes)
            {
                yield return GetHealthiest(tribe);
            }
        }

        public IEnumerable<Guerrero> Miembros(string tribu)
        {
            return _tribes.FirstOrDefault(m => m.Name == tribu)?.Warriors;
        }

        private Guerrero GetHealthiest(Tribe tribe)
        {
            var healthiestWarrior = tribe.Warriors[0];
            foreach (var warrior in tribe.Warriors)
            {
                if (healthiestWarrior.VidaActual < warrior.VidaActual || (healthiestWarrior.VidaActual == warrior.VidaActual && healthiestWarrior.Fuerza < warrior.Fuerza))
                {
                    healthiestWarrior = warrior;
                }
            }

            return healthiestWarrior;
        }

        public string PerteneceATribu(Guerrero guerrero)
        {
            return _tribes.FirstOrDefault(m => m.Warriors.Any(w => w == guerrero))?.Name;
        }

        public void RegistraTribu(string nombre, IEnumerable<Guerrero> grupo)
        {
            _tribes.Add(new Tribe() { Name = nombre, Warriors = new List<Guerrero>(grupo) });
        }
    }
}
