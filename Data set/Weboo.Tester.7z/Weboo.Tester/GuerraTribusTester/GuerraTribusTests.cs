﻿using GuerraDeTribus;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Assess.Tester;

namespace GuerraTribusTester
{
    public abstract class GuerraTribuTests : InterfaceTester<IGuerraDeTribus>
    {
        protected override IGuerraDeTribus BuildBenchmark(object[] args)
        {
            return new GuerraTribus();
        }

        protected override IGuerraDeTribus BuildTarget(object[] args)
        {
            return ReflectionHelper.CreateInstance<IGuerraDeTribus>();
        }

        IDictionary<Guerrero, (Guerrero, Guerrero)> warriorsMap = new Dictionary<Guerrero, (Guerrero, Guerrero)>();

        public void IsNullOrEmpty<T>(Func<IGuerraDeTribus, IEnumerable<T>> func)
        {
            var targetResult = func(Target);
            Assert.That(targetResult, new NullOrEmpty());
        }

        internal class NullOrEmpty : IAssertion<IEnumerable>
        {
            public bool Assert(IEnumerable item)
            {
                return item == null || !item.GetEnumerator().MoveNext();
            }

            public override string ToString()
            {
                return "is null or empty";
            }
        }

        protected void RegisterTribe(string name, IEnumerable<Guerrero> warriors)
        {
            var studentWarriorList = new List<Guerrero>();
            var benchmarkWarriorList = new List<Guerrero>();
            foreach (var warrior in warriors)
            {
                if (!warriorsMap.TryGetValue(warrior, out (Guerrero, Guerrero) tuple))
                {
                    tuple = (warrior.Clone() as Guerrero, warrior.Clone() as Guerrero);
                    warriorsMap.Add(warrior, tuple);
                }

                benchmarkWarriorList.Add(tuple.Item1);
                studentWarriorList.Add(tuple.Item2);
            }

            PerformTarget(m => m.RegistraTribu(name, studentWarriorList));
            PerformBenchmark(m => m.RegistraTribu(name, benchmarkWarriorList));
        }

        protected void CheckMembership(Guerrero warrior)
        {
            if (warriorsMap.TryGetValue(warrior, out (Guerrero, Guerrero) tuple))
            {
                string benchmarkTribeName = Benchmark.PerteneceATribu(tuple.Item1);
                string targetTribeName = Target.PerteneceATribu(tuple.Item2);

                Assert.That(targetTribeName, Is.EqualTo(benchmarkTribeName));
            }
            else
            {
                string targetTribeName = Target.PerteneceATribu(tuple.Item2);
                Assert.That(targetTribeName, Is.Null);
            }
        }
    }

    public class Ejemplo1Test : GuerraTribuTests
    {
        public void Ejemplo1()
        {
            Initialize();

            CheckMultiSet(m => m.GuerrerosMasFuertes());
            CheckMultiSet(m => m.GuerrerosMasResistentes());
            CheckMembership(new Guerrero() { Nombre = "Vikingo1" });
        }
    }

    public class Ejemplo2Test : GuerraTribuTests
    {
        public void Ejemplo2()
        {
            Initialize();

            Guerrero vikingo1 = new Guerrero() { Nombre = "Vikingo1", Fuerza = 12, VidaActual = 50, VidaTotal = 50 };
            Guerrero vikingo2 = new Guerrero() { Nombre = "Vikingo2", Fuerza = 15, VidaActual = 40, VidaTotal = 40 };
            Guerrero vikingo3 = new Guerrero() { Nombre = "Vikingo3", Fuerza = 10, VidaActual = 35, VidaTotal = 35 };
            RegisterTribe("Vikingos", new[] { vikingo1, vikingo2, vikingo3 });

            Guerrero amazona1 = new Guerrero() { Nombre = "Amazona1", Fuerza = 15, VidaActual = 60, VidaTotal = 60 };
            Guerrero amazona2 = new Guerrero() { Nombre = "Amazona2", Fuerza = 18, VidaActual = 30, VidaTotal = 30 };
            Guerrero amazona3 = new Guerrero() { Nombre = "Amazona3", Fuerza = 8, VidaActual = 30, VidaTotal = 30 };
            RegisterTribe("Amazonas", new[] { amazona1, amazona2, amazona3 });

            Guerrero tartaro1 = new Guerrero() { Nombre = "Tartaro1", Fuerza = 16, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro2 = new Guerrero() { Nombre = "Tartaro2", Fuerza = 10, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro3 = new Guerrero() { Nombre = "Tartaro3", Fuerza = 10, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro4 = new Guerrero() { Nombre = "Tartaro4", Fuerza = 8, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro5 = new Guerrero() { Nombre = "Tartaro5", Fuerza = 15, VidaActual = 25, VidaTotal = 25 };
            RegisterTribe("Tártaros", new[] { tartaro1, tartaro2, tartaro3, tartaro4, tartaro5 });

            CheckMultiSet(m => m.GuerrerosMasFuertes());
            CheckMultiSet(m => m.GuerrerosMasResistentes());
        }
    }

    public class Ejemplo3Test : GuerraTribuTests
    {
        public void Ejemplo3()
        {
            Initialize();

            Guerrero vikingo1 = new Guerrero() { Nombre = "Vikingo1", Fuerza = 12, VidaActual = 50, VidaTotal = 50 };
            Guerrero vikingo2 = new Guerrero() { Nombre = "Vikingo2", Fuerza = 15, VidaActual = 40, VidaTotal = 40 };
            Guerrero vikingo3 = new Guerrero() { Nombre = "Vikingo3", Fuerza = 10, VidaActual = 35, VidaTotal = 35 };
            RegisterTribe("Vikingos", new[] { vikingo1, vikingo2, vikingo3 });

            Guerrero amazona1 = new Guerrero() { Nombre = "Amazona1", Fuerza = 15, VidaActual = 60, VidaTotal = 60 };
            Guerrero amazona2 = new Guerrero() { Nombre = "Amazona2", Fuerza = 18, VidaActual = 30, VidaTotal = 30 };
            Guerrero amazona3 = new Guerrero() { Nombre = "Amazona3", Fuerza = 8, VidaActual = 30, VidaTotal = 30 };
            RegisterTribe("Amazonas", new[] { amazona1, amazona2, amazona3 });

            Guerrero tartaro1 = new Guerrero() { Nombre = "Tartaro1", Fuerza = 16, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro2 = new Guerrero() { Nombre = "Tartaro2", Fuerza = 10, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro3 = new Guerrero() { Nombre = "Tartaro3", Fuerza = 10, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro4 = new Guerrero() { Nombre = "Tartaro4", Fuerza = 8, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro5 = new Guerrero() { Nombre = "Tartaro5", Fuerza = 15, VidaActual = 25, VidaTotal = 25 };
            RegisterTribe("Tártaros", new[] { tartaro1, tartaro2, tartaro3, tartaro4, tartaro5 });

            CheckMultiSet(m => m.Miembros("Tártaros"));
        }
    }

    public class Ejemplo4Test : GuerraTribuTests
    {
        public void Ejemplo4()
        {
            Initialize();

            Guerrero vikingo1 = new Guerrero() { Nombre = "Vikingo1", Fuerza = 12, VidaActual = 50, VidaTotal = 50 };
            Guerrero vikingo2 = new Guerrero() { Nombre = "Vikingo2", Fuerza = 15, VidaActual = 40, VidaTotal = 40 };
            Guerrero vikingo3 = new Guerrero() { Nombre = "Vikingo3", Fuerza = 10, VidaActual = 35, VidaTotal = 35 };
            RegisterTribe("Vikingos", new[] { vikingo1, vikingo2, vikingo3 });

            Guerrero amazona1 = new Guerrero() { Nombre = "Amazona1", Fuerza = 15, VidaActual = 60, VidaTotal = 60 };
            Guerrero amazona2 = new Guerrero() { Nombre = "Amazona2", Fuerza = 18, VidaActual = 30, VidaTotal = 30 };
            Guerrero amazona3 = new Guerrero() { Nombre = "Amazona3", Fuerza = 8, VidaActual = 30, VidaTotal = 30 };
            RegisterTribe("Amazonas", new[] { amazona1, amazona2, amazona3 });

            Guerrero tartaro1 = new Guerrero() { Nombre = "Tartaro1", Fuerza = 16, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro2 = new Guerrero() { Nombre = "Tartaro2", Fuerza = 10, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro3 = new Guerrero() { Nombre = "Tartaro3", Fuerza = 10, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro4 = new Guerrero() { Nombre = "Tartaro4", Fuerza = 8, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro5 = new Guerrero() { Nombre = "Tartaro5", Fuerza = 15, VidaActual = 25, VidaTotal = 25 };
            RegisterTribe("Tártaros", new[] { tartaro1, tartaro2, tartaro3, tartaro4, tartaro5 });

            Perform(m => m.Combate("Vikingos", "Amazonas"));
            CheckMultiSet(m => m.Miembros("Amazonas"));
            IsNullOrEmpty(m => m.Miembros("Vikingos"));
        }
    }

    public class Ejemplo5Test : GuerraTribuTests
    {
        public void Ejemplo5()
        {
            Initialize();

            Guerrero vikingo1 = new Guerrero() { Nombre = "Vikingo1", Fuerza = 12, VidaActual = 50, VidaTotal = 50 };
            Guerrero vikingo2 = new Guerrero() { Nombre = "Vikingo2", Fuerza = 15, VidaActual = 40, VidaTotal = 40 };
            Guerrero vikingo3 = new Guerrero() { Nombre = "Vikingo3", Fuerza = 10, VidaActual = 35, VidaTotal = 35 };
            RegisterTribe("Vikingos", new[] { vikingo1, vikingo2, vikingo3 });

            Guerrero amazona1 = new Guerrero() { Nombre = "Amazona1", Fuerza = 15, VidaActual = 60, VidaTotal = 60 };
            Guerrero amazona2 = new Guerrero() { Nombre = "Amazona2", Fuerza = 18, VidaActual = 30, VidaTotal = 30 };
            Guerrero amazona3 = new Guerrero() { Nombre = "Amazona3", Fuerza = 8, VidaActual = 30, VidaTotal = 30 };
            RegisterTribe("Amazonas", new[] { amazona1, amazona2, amazona3 });

            Guerrero tartaro1 = new Guerrero() { Nombre = "Tartaro1", Fuerza = 16, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro2 = new Guerrero() { Nombre = "Tartaro2", Fuerza = 10, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro3 = new Guerrero() { Nombre = "Tartaro3", Fuerza = 10, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro4 = new Guerrero() { Nombre = "Tartaro4", Fuerza = 8, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro5 = new Guerrero() { Nombre = "Tartaro5", Fuerza = 15, VidaActual = 25, VidaTotal = 25 };
            RegisterTribe("Tártaros", new[] { tartaro1, tartaro2, tartaro3, tartaro4, tartaro5 });

            Perform(m => m.Combate("Vikingos", "Amazonas"));
            CheckMembership(vikingo1);
            CheckMembership(vikingo2);
            CheckMembership(amazona3);
        }
    }

    public class Ejemplo6Test : GuerraTribuTests
    {
        public void Ejemplo6()
        {
            Initialize();

            Guerrero vikingo1 = new Guerrero() { Nombre = "Vikingo1", Fuerza = 12, VidaActual = 50, VidaTotal = 50 };
            Guerrero vikingo2 = new Guerrero() { Nombre = "Vikingo2", Fuerza = 15, VidaActual = 40, VidaTotal = 40 };
            Guerrero vikingo3 = new Guerrero() { Nombre = "Vikingo3", Fuerza = 10, VidaActual = 35, VidaTotal = 35 };
            RegisterTribe("Vikingos", new[] { vikingo1, vikingo2, vikingo3 });

            Guerrero amazona1 = new Guerrero() { Nombre = "Amazona1", Fuerza = 15, VidaActual = 60, VidaTotal = 60 };
            Guerrero amazona2 = new Guerrero() { Nombre = "Amazona2", Fuerza = 18, VidaActual = 30, VidaTotal = 30 };
            Guerrero amazona3 = new Guerrero() { Nombre = "Amazona3", Fuerza = 8, VidaActual = 30, VidaTotal = 30 };
            RegisterTribe("Amazonas", new[] { amazona1, amazona2, amazona3 });

            Guerrero tartaro1 = new Guerrero() { Nombre = "Tartaro1", Fuerza = 16, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro2 = new Guerrero() { Nombre = "Tartaro2", Fuerza = 10, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro3 = new Guerrero() { Nombre = "Tartaro3", Fuerza = 10, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro4 = new Guerrero() { Nombre = "Tartaro4", Fuerza = 8, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro5 = new Guerrero() { Nombre = "Tartaro5", Fuerza = 15, VidaActual = 25, VidaTotal = 25 };
            RegisterTribe("Tártaros", new[] { tartaro1, tartaro2, tartaro3, tartaro4, tartaro5 });

            Perform(m => m.Combate("Vikingos", "Amazonas"));
            Perform(m => m.Combate("Amazonas", "Tártaros"));
            CheckMultiSet(m => m.Miembros("Amazonas"));
            IsNullOrEmpty(m => m.Miembros("Tártaros"));
        }
    }

    public class Ejemplo7Test : GuerraTribuTests
    {
        public void Ejemplo7()
        {
            Initialize();

            Guerrero vikingo1 = new Guerrero() { Nombre = "Vikingo1", Fuerza = 12, VidaActual = 50, VidaTotal = 50 };
            Guerrero vikingo2 = new Guerrero() { Nombre = "Vikingo2", Fuerza = 15, VidaActual = 40, VidaTotal = 40 };
            Guerrero vikingo3 = new Guerrero() { Nombre = "Vikingo3", Fuerza = 10, VidaActual = 35, VidaTotal = 35 };
            RegisterTribe("Vikingos", new[] { vikingo1, vikingo2, vikingo3 });

            Guerrero amazona1 = new Guerrero() { Nombre = "Amazona1", Fuerza = 15, VidaActual = 60, VidaTotal = 60 };
            Guerrero amazona2 = new Guerrero() { Nombre = "Amazona2", Fuerza = 18, VidaActual = 30, VidaTotal = 30 };
            Guerrero amazona3 = new Guerrero() { Nombre = "Amazona3", Fuerza = 8, VidaActual = 30, VidaTotal = 30 };
            RegisterTribe("Amazonas", new[] { amazona1, amazona2, amazona3 });

            Guerrero tartaro1 = new Guerrero() { Nombre = "Tartaro1", Fuerza = 16, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro2 = new Guerrero() { Nombre = "Tartaro2", Fuerza = 10, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro3 = new Guerrero() { Nombre = "Tartaro3", Fuerza = 10, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro4 = new Guerrero() { Nombre = "Tartaro4", Fuerza = 8, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro5 = new Guerrero() { Nombre = "Tartaro5", Fuerza = 15, VidaActual = 25, VidaTotal = 25 };
            RegisterTribe("Tártaros", new[] { tartaro1, tartaro2, tartaro3, tartaro4, tartaro5 });

            Perform(m => m.Combate("Vikingos", "Amazonas"));
            Perform(m => m.Combate("Amazonas", "Tártaros"));
            CheckMembership(tartaro1);
            CheckMembership(tartaro4);
            CheckMembership(vikingo1);
        }
    }

    public class Ejemplo8Test : GuerraTribuTests
    {
        public void Ejemplo8()
        {
            Initialize();

            Guerrero vikingo1 = new Guerrero() { Nombre = "Vikingo1", Fuerza = 12, VidaActual = 50, VidaTotal = 50 };
            Guerrero vikingo2 = new Guerrero() { Nombre = "Vikingo2", Fuerza = 15, VidaActual = 40, VidaTotal = 40 };
            Guerrero vikingo3 = new Guerrero() { Nombre = "Vikingo3", Fuerza = 10, VidaActual = 35, VidaTotal = 35 };
            RegisterTribe("Vikingos", new[] { vikingo1, vikingo2, vikingo3 });

            Guerrero amazona1 = new Guerrero() { Nombre = "Amazona1", Fuerza = 15, VidaActual = 60, VidaTotal = 60 };
            Guerrero amazona2 = new Guerrero() { Nombre = "Amazona2", Fuerza = 18, VidaActual = 30, VidaTotal = 30 };
            Guerrero amazona3 = new Guerrero() { Nombre = "Amazona3", Fuerza = 8, VidaActual = 30, VidaTotal = 30 };
            RegisterTribe("Amazonas", new[] { amazona1, amazona2, amazona3 });

            Guerrero tartaro1 = new Guerrero() { Nombre = "Tartaro1", Fuerza = 16, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro2 = new Guerrero() { Nombre = "Tartaro2", Fuerza = 10, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro3 = new Guerrero() { Nombre = "Tartaro3", Fuerza = 10, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro4 = new Guerrero() { Nombre = "Tartaro4", Fuerza = 8, VidaActual = 30, VidaTotal = 30 };
            Guerrero tartaro5 = new Guerrero() { Nombre = "Tartaro5", Fuerza = 15, VidaActual = 25, VidaTotal = 25 };
            RegisterTribe("Tártaros", new[] { tartaro1, tartaro2, tartaro3, tartaro4, tartaro5 });

            Perform(m => m.Combate("Vikingos", "Amazonas"));
            Perform(m => m.Combate("Amazonas", "Tártaros"));
            CheckMultiSet(m => m.GuerrerosMasFuertes());
            CheckMultiSet(m => m.GuerrerosMasResistentes());
        }
    }

    public class GuerrerosMasFuertes1Test : GuerraTribuTests
    {
        public void GuerrerosMasFuertes1()
        {
            Initialize();

            CheckMultiSet(m => m.GuerrerosMasFuertes());
        }
    }

    public class GuerrerosMasFuertes2Test : GuerraTribuTests
    {
        public void GuerrerosMasFuertes2()
        {
            Initialize();

            var v1 = new[] { new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 } };
            var w1 = new[] { new Guerrero { Nombre = "W1", Fuerza = 1, VidaActual = 10, VidaTotal = 10 } };
            RegisterTribe("V", v1);
            RegisterTribe("W", w1);

            CheckMultiSet(m => m.GuerrerosMasFuertes());
        }
    }

    public class GuerrerosMasFuertes3Test : GuerraTribuTests
    {
        public void GuerrerosMasFuertes3()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 }
            };
            RegisterTribe("V", v);

            CheckMultiSet(m => m.GuerrerosMasFuertes());
        }
    }

    public class GuerrerosMasFuertes4Test : GuerraTribuTests
    {
        public void GuerrerosMasFuertes4()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 }
            };
            RegisterTribe("V", v);

            CheckMultiSet(m => m.GuerrerosMasFuertes());
        }
    }

    public class GuerrerosMasFuertes5Test : GuerraTribuTests
    {
        public void GuerrerosMasFuertes5()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 }
            };
            RegisterTribe("V", v);

            CheckMultiSet(m => m.GuerrerosMasFuertes());
        }
    }

    public class GuerrerosMasFuertes6Test : GuerraTribuTests
    {
        public void GuerrerosMasFuertes6()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 15, VidaActual = 40, VidaTotal = 40 }
            };
            RegisterTribe("V", v);

            CheckMultiSet(m => m.GuerrerosMasFuertes());
        }
    }

    public class GuerrerosMasFuertes7Test : GuerraTribuTests
    {
        public void GuerrerosMasFuertes7()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 40, VidaTotal = 40 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            Perform(m => m.Combate("V", "W"));

            CheckMultiSet(m => m.GuerrerosMasFuertes());
        }
    }

    public class GuerrerosMasFuertes8Test : GuerraTribuTests
    {
        public void GuerrerosMasFuertes8()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 40, VidaTotal = 40 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            Perform(m => m.Combate("W", "V"));

            CheckMultiSet(m => m.GuerrerosMasFuertes());
        }
    }

    public class GuerrerosMasFuertes9Test : GuerraTribuTests
    {
        public void GuerrerosMasFuertes9()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 40, VidaTotal = 40 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };
            var z = new[] {
                new Guerrero { Nombre = "Z1", Fuerza = 40, VidaActual = 30, VidaTotal = 30 },
                new Guerrero { Nombre = "Z2", Fuerza = 80, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "Z3", Fuerza = 100, VidaActual = 12, VidaTotal = 12 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            RegisterTribe("Z", z);
            Perform(m => m.Combate("W", "V"));
            Perform(m => m.Combate("Z", "W"));

            CheckMultiSet(m => m.GuerrerosMasFuertes());
        }
    }

    public class GuerrerosMasFuertes10Test : GuerraTribuTests
    {
        public void GuerrerosMasFuertes10()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 45, VidaTotal = 45 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };
            var z = new[] {
                new Guerrero { Nombre = "Z1", Fuerza = 40, VidaActual = 30, VidaTotal = 30 },
                new Guerrero { Nombre = "Z2", Fuerza = 80, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "Z3", Fuerza = 100, VidaActual = 12, VidaTotal = 12 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            RegisterTribe("Z", z);
            Perform(m => m.Combate("W", "V"));

            CheckMultiSet(m => m.GuerrerosMasFuertes());
        }
    }

    public class GuerrerosMasResistentes1Test : GuerraTribuTests
    {
        public void GuerrerosMasResistentes1()
        {
            Initialize();

            CheckMultiSet(m => m.GuerrerosMasResistentes());
        }
    }

    public class GuerrerosMasResistentes2Test : GuerraTribuTests
    {
        public void GuerrerosMasResistentes2()
        {
            Initialize();

            var v = new[] { new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 } };
            var w = new[] { new Guerrero { Nombre = "W1", Fuerza = 4, VidaActual = 40, VidaTotal = 40 } };
            RegisterTribe("V", v);
            RegisterTribe("W", w);

            CheckMultiSet(m => m.GuerrerosMasResistentes());
        }
    }

    public class GuerrerosMasResistentes3Test : GuerraTribuTests
    {
        public void GuerrerosMasResistentes3()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 }
            };
            RegisterTribe("V", v);

            CheckMultiSet(m => m.GuerrerosMasResistentes());
        }
    }

    public class GuerrerosMasResistentes4Test : GuerraTribuTests
    {
        public void GuerrerosMasResistentes4()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 15, VidaTotal = 15 },
                new Guerrero { Nombre = "V3", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 }
            };
            RegisterTribe("V", v);

            CheckMultiSet(m => m.GuerrerosMasResistentes());
        }
    }

    public class GuerrerosMasResistentes5Test : GuerraTribuTests
    {
        public void GuerrerosMasResistentes5()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 }
            };
            RegisterTribe("V", v);

            CheckMultiSet(m => m.GuerrerosMasResistentes());
        }
    }

    public class GuerrerosMasResistentes6Test : GuerraTribuTests
    {
        public void GuerrerosMasResistentes6()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V5", Fuerza = 10, VidaActual = 40, VidaTotal = 40 }
            };
            RegisterTribe("V", v);

            CheckMultiSet(m => m.GuerrerosMasFuertes());
        }
    }

    public class GuerrerosMasResistentes7Test : GuerraTribuTests
    {
        public void GuerrerosMasResistentes7()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 40, VidaTotal = 40 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            Perform(m => m.Combate("V", "W"));

            CheckMultiSet(m => m.GuerrerosMasResistentes());
        }
    }

    public class GuerrerosMasResistentes8Test : GuerraTribuTests
    {
        public void GuerrerosMasResistentes8()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 40, VidaTotal = 40 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            Perform(m => m.Combate("W", "V"));

            CheckMultiSet(m => m.GuerrerosMasResistentes());
        }
    }

    public class GuerrerosMasResistentes9Test : GuerraTribuTests
    {
        public void GuerrerosMasResistentes9()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 40, VidaTotal = 40 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };
            var z = new[] {
                new Guerrero { Nombre = "Z1", Fuerza = 40, VidaActual = 30, VidaTotal = 30 },
                new Guerrero { Nombre = "Z2", Fuerza = 80, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "Z3", Fuerza = 100, VidaActual = 12, VidaTotal = 12 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            RegisterTribe("Z", z);
            Perform(m => m.Combate("W", "V"));
            Perform(m => m.Combate("Z", "W"));

            CheckMultiSet(m => m.GuerrerosMasResistentes());
        }
    }

    public class GuerrerosMasResistentes10Test : GuerraTribuTests
    {
        public void GuerrerosMasResistentes10()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 29, VidaTotal = 29 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 30, VidaTotal = 30 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 30, VidaActual = 15, VidaTotal = 15 }
            };
            var z = new[] {
                new Guerrero { Nombre = "Z1", Fuerza = 40, VidaActual = 30, VidaTotal = 30 },
                new Guerrero { Nombre = "Z2", Fuerza = 80, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "Z3", Fuerza = 100, VidaActual = 12, VidaTotal = 12 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            RegisterTribe("Z", z);
            Perform(m => m.Combate("W", "V"));

            CheckMultiSet(m => m.GuerrerosMasResistentes());
        }
    }

    public class Miembros1Test : GuerraTribuTests
    {
        public void Miembros1()
        {
            Initialize();

            IsNullOrEmpty(m => m.Miembros("A"));
        }
    }

    public class Miembros2Test : GuerraTribuTests
    {
        public void Miembros2()
        {
            Initialize();

            var v = new[] { new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 } };
            var w = new[] { new Guerrero { Nombre = "W1", Fuerza = 4, VidaActual = 40, VidaTotal = 40 } };
            RegisterTribe("V", v);
            RegisterTribe("W", w);

            CheckMultiSet(m => m.Miembros("V"));
            CheckMultiSet(m => m.Miembros("W"));
        }
    }

    public class Miembros3Test : GuerraTribuTests
    {
        public void Miembros3()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 }
            };
            RegisterTribe("V", v);

            CheckMultiSet(m => m.Miembros("V"));
        }
    }

    public class Miembros4Test : GuerraTribuTests
    {
        public void Miembros4()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 40, VidaTotal = 40 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            Perform(m => m.Combate("V", "W"));

            IsNullOrEmpty(m => m.Miembros("V"));
            CheckMultiSet(m => m.Miembros("W"));
        }
    }

    public class Miembros5Test : GuerraTribuTests
    {
        public void Miembros5()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 40, VidaTotal = 40 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            Perform(m => m.Combate("W", "V"));

            IsNullOrEmpty(m => m.Miembros("V"));
            CheckMultiSet(m => m.Miembros("W"));
        }
    }

    public class Miembros6Test : GuerraTribuTests
    {
        public void Miembros6()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 40, VidaTotal = 40 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };
            var z = new[] {
                new Guerrero { Nombre = "Z1", Fuerza = 40, VidaActual = 30, VidaTotal = 30 },
                new Guerrero { Nombre = "Z2", Fuerza = 80, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "Z3", Fuerza = 100, VidaActual = 12, VidaTotal = 12 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            RegisterTribe("Z", z);
            Perform(m => m.Combate("W", "V"));
            Perform(m => m.Combate("Z", "W"));

            IsNullOrEmpty(m => m.Miembros("V"));
            CheckMultiSet(m => m.Miembros("W"));
            IsNullOrEmpty(m => m.Miembros("Z"));
        }
    }

    public class Miembros7Test : GuerraTribuTests
    {
        public void Miembros7()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 29, VidaTotal = 29 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 30, VidaTotal = 30 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 30, VidaActual = 15, VidaTotal = 15 }
            };
            var z = new[] {
                new Guerrero { Nombre = "Z1", Fuerza = 40, VidaActual = 30, VidaTotal = 30 },
                new Guerrero { Nombre = "Z2", Fuerza = 80, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "Z3", Fuerza = 100, VidaActual = 12, VidaTotal = 12 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            RegisterTribe("Z", z);
            Perform(m => m.Combate("W", "V"));

            IsNullOrEmpty(m => m.Miembros("V"));
            CheckMultiSet(m => m.Miembros("W"));
            CheckMultiSet(m => m.Miembros("Z"));
        }
    }

    public class Miembros8Test : GuerraTribuTests
    {
        public void Miembros8()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 45, VidaTotal = 45 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };
            var z = new[] {
                new Guerrero { Nombre = "Z1", Fuerza = 40, VidaActual = 30, VidaTotal = 30 },
                new Guerrero { Nombre = "Z2", Fuerza = 80, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "Z3", Fuerza = 100, VidaActual = 12, VidaTotal = 12 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            RegisterTribe("Z", z);
            Perform(m => m.Combate("W", "V"));

            IsNullOrEmpty(m => m.Miembros("V"));
            CheckMultiSet(m => m.Miembros("W"));
            CheckMultiSet(m => m.Miembros("Z"));
        }
    }

    public class Miembros9Test : GuerraTribuTests
    {
        public void Miembros9()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 45, VidaTotal = 45 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 80, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            Perform(m => m.Combate("W", "V"));

            IsNullOrEmpty(m => m.Miembros("V"));
            CheckMultiSet(m => m.Miembros("W"));
        }
    }

    public class Miembros10Test : GuerraTribuTests
    {
        public void Miembros10()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 29, VidaTotal = 29 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 20, VidaActual = 30, VidaTotal = 30 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 20, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 15, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 30, VidaActual = 15, VidaTotal = 15 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            Perform(m => m.Combate("W", "V"));

            IsNullOrEmpty(m => m.Miembros("V"));
            CheckMultiSet(m => m.Miembros("W"));
        }
    }

    public class PerteneceATribu1Test : GuerraTribuTests
    {
        public void PerteneceATribu1()
        {
            Initialize();

            CheckMembership(new Guerrero { Nombre = "A" });
        }
    }

    public class PerteneceATribu2Test : GuerraTribuTests
    {
        public void PerteneceATribu2()
        {
            Initialize();

            var v = new[] { new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 } };
            var w = new[] { new Guerrero { Nombre = "W1", Fuerza = 4, VidaActual = 40, VidaTotal = 40 } };
            var z = new[] { new Guerrero { Nombre = "Z1", Fuerza = 8, VidaActual = 15, VidaTotal = 15 } };
            RegisterTribe("V", v);
            RegisterTribe("W", w);
            RegisterTribe("W", z);

            CheckMembership(z[0]);
        }
    }

    public class PerteneceATribu3Test : GuerraTribuTests
    {
        public void PerteneceATribu3()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 25, VidaTotal = 25 }
            };
            var w1 = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 4, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 15, VidaActual = 10, VidaTotal = 10 }
            };
            RegisterTribe("V", v);

            CheckMembership(v[2]);
        }
    }

    public class PerteneceATribu4Test : GuerraTribuTests
    {
        public void PerteneceATribu4()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 40, VidaTotal = 40 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            Perform(m => m.Combate("V", "W"));

            CheckMembership(w[1]);
        }
    }

    public class PerteneceATribu5Test : GuerraTribuTests
    {
        public void PerteneceATribu5()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 40, VidaTotal = 40 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            Perform(m => m.Combate("V", "W"));

            CheckMembership(w[2]);
        }
    }

    public class PerteneceATribu6Test : GuerraTribuTests
    {
        public void PerteneceATribu6()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 40, VidaTotal = 40 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            Perform(m => m.Combate("W", "V"));

            CheckMembership(v[3]);
        }
    }

    public class PerteneceATribu7Test : GuerraTribuTests
    {
        public void PerteneceATribu7()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 40, VidaTotal = 40 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };
            var z = new[] {
                new Guerrero { Nombre = "Z1", Fuerza = 40, VidaActual = 30, VidaTotal = 30 },
                new Guerrero { Nombre = "Z2", Fuerza = 80, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "Z3", Fuerza = 100, VidaActual = 12, VidaTotal = 12 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            RegisterTribe("Z", z);
            Perform(m => m.Combate("W", "V"));
            Perform(m => m.Combate("Z", "W"));

            CheckMembership(z[1]);
        }
    }

    public class PerteneceATribu8Test : GuerraTribuTests
    {
        public void PerteneceATribu8()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 40, VidaTotal = 40 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };
            var z = new[] {
                new Guerrero { Nombre = "Z1", Fuerza = 40, VidaActual = 30, VidaTotal = 30 },
                new Guerrero { Nombre = "Z2", Fuerza = 80, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "Z3", Fuerza = 100, VidaActual = 12, VidaTotal = 12 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            RegisterTribe("Z", z);
            Perform(m => m.Combate("Z", "W"));

            CheckMembership(w[0]);
        }
    }

    public class PerteneceATribu9Test : GuerraTribuTests
    {
        public void PerteneceATribu9()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 29, VidaTotal = 29 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 30, VidaTotal = 30 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 30, VidaActual = 15, VidaTotal = 15 }
            };
            var z = new[] {
                new Guerrero { Nombre = "Z1", Fuerza = 40, VidaActual = 30, VidaTotal = 30 },
                new Guerrero { Nombre = "Z2", Fuerza = 80, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "Z3", Fuerza = 100, VidaActual = 12, VidaTotal = 12 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            RegisterTribe("Z", z);
            Perform(m => m.Combate("W", "V"));

            CheckMembership(v[1]);
        }
    }

    public class PerteneceATribu10Test : GuerraTribuTests
    {
        public void PerteneceATribu10()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 45, VidaTotal = 45 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 20, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };
            var z = new[] {
                new Guerrero { Nombre = "Z1", Fuerza = 40, VidaActual = 30, VidaTotal = 30 },
                new Guerrero { Nombre = "Z2", Fuerza = 80, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "Z3", Fuerza = 100, VidaActual = 12, VidaTotal = 12 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            RegisterTribe("Z", z);
            Perform(m => m.Combate("W", "V"));

            CheckMembership(v[0]);
        }
    }

    public class PerteneceATribu11Test : GuerraTribuTests
    {
        public void PerteneceATribu11()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 45, VidaTotal = 45 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 80, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            Perform(m => m.Combate("W", "V"));

            CheckMembership(v[2]);
        }
    }

    public class PerteneceATribu12Test : GuerraTribuTests
    {
        public void PerteneceATribu12()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 15, VidaActual = 10, VidaTotal = 10 },
                new Guerrero { Nombre = "V5", Fuerza = 30, VidaActual = 45, VidaTotal = 45 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 15, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 80, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 50, VidaActual = 15, VidaTotal = 15 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            Perform(m => m.Combate("W", "V"));

            CheckMembership(w[1]);
        }
    }

    public class PerteneceATribu13Test : GuerraTribuTests
    {
        public void PerteneceATribu13()
        {
            Initialize();

            var v = new[] {
                new Guerrero { Nombre = "V1", Fuerza = 10, VidaActual = 29, VidaTotal = 29 },
                new Guerrero { Nombre = "V2", Fuerza = 5, VidaActual = 25, VidaTotal = 25 },
                new Guerrero { Nombre = "V3", Fuerza = 15, VidaActual = 20, VidaTotal = 20 },
                new Guerrero { Nombre = "V4", Fuerza = 20, VidaActual = 30, VidaTotal = 30 }
            };
            var w = new[] {
                new Guerrero { Nombre = "W1", Fuerza = 20, VidaActual = 40, VidaTotal = 40 },
                new Guerrero { Nombre = "W2", Fuerza = 15, VidaActual = 60, VidaTotal = 60 },
                new Guerrero { Nombre = "W3", Fuerza = 30, VidaActual = 15, VidaTotal = 15 }
            };

            RegisterTribe("V", v);
            RegisterTribe("W", w);
            Perform(m => m.Combate("W", "V"));

            CheckMembership(w[1]);
        }
    }
}
