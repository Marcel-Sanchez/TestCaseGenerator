﻿using Weboo.Assess.Tester;

namespace AnagramasTester
{
    public abstract class AnagramasTest : TestCase
    {
        public int Student(string cadena)
        {
            return ReflectionHelper.InvokeStatic<int>("Weboo.Prueba.Anagramas", "CantidadEnCadena", cadena);
        }

        private static bool AreAnagrams(string a, string b)
        {
            int[] map = new int[27];
            for (int i = 0; i < a.Length; i++)
            {
                map[a[i] - 'a']++;
                map[b[i] - 'a']--;
            }

            for (int i = 0; i < map.Length; i++)
            {
                if (map[i] != 0)
                    return false;
            }

            return true;
        }

        public static int CantidadEnCadena(string cadena)
        {
            int solution = 0;
            for (int len = 1; len < cadena.Length; len++)
            {
                for (int i = 0; i <= cadena.Length - len; i++)
                {
                    for (int j = i + 1; j <= cadena.Length - len; j++)
                    {
                        if (AreAnagrams(cadena.Substring(i, len), cadena.Substring(j, len)))
                        {
                            solution++;
                        }
                    }
                }
            }

            return solution;
        }
    }

    public class TestCase1 : AnagramasTest
    {
        public void Ejemplo1()
        {
            string str = "mom";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }

    public class TestCase2 : AnagramasTest
    {
        public void Ejemplo2()
        {
            string str = "abba";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }

    public class TestCase3 : AnagramasTest
    {
        public void Ejemplo3()
        {
            string str = "abcd";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }

    public class TestCase4 : AnagramasTest
    {
        public void Ejemplo4()
        {
            string str = "ifailuhkqq";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }

    public class TestCase5 : AnagramasTest
    {
        public void Ejemplo5()
        {
            string str = "kkkk";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }

    public class TestCase6 : AnagramasTest
    {
        public void Ejemplo6()
        {
            string str = "cdcd";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }

    public class TestCase7 : AnagramasTest
    {
        public void Ejemplo7()
        {
            string str = "z";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }

    public class TestCase8 : AnagramasTest
    {
        public void Ejemplo8()
        {
            string str = "";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }

    public class TestCase9 : AnagramasTest
    {
        public void FancyCase1()
        {
            string str = "maryarmy";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase10 : AnagramasTest
    {
        public void FancyCase2()
        {
            string str = "tommarvoloeiddleiamlordvoldemort";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase11 : AnagramasTest
    {
        public void FancyCase3()
        {
            string str = "imaginedragonsraggedinsomnia";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase12 : AnagramasTest
    {
        public void FancyCase4()
        {
            string str = "thealiasmenalansmithee";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase13 : AnagramasTest
    {
        public void NoAnagrams1()
        {
            string str = "ab";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase14 : AnagramasTest
    {
        public void NoAnagrams2()
        {
            string str = "abc";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase15 : AnagramasTest
    {
        public void NoAnagrams3()
        {
            string str = "azklp";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase16 : AnagramasTest
    {
        public void NoAnagrams4()
        {
            string str = "abcdefghijklmnopqrstuvwxyz";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase17 : AnagramasTest
    {
        public void Borders1()
        {
            string str = "zz";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase18 : AnagramasTest
    {
        public void Borders2()
        {
            string str = "wow";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase19 : AnagramasTest
    {
        public void Borders3()
        {
            string str = "ffolertfffffff";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase20 : AnagramasTest
    {
        public void Borders4()
        {
            string str = "pppppppppptpppppppppp";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase21 : AnagramasTest
    {
        public void Borders5()
        {
            string str = "ddddddddddddddddazrdd";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase22 : AnagramasTest
    {
        public void Borders6()
        {
            string str = "aaaaaqwertyuioplkjhgfdszxcvbnmaaa";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase23 : AnagramasTest
    {
        public void Borders7()
        {
            string str = "aklpqwertyuiolkpa";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase24 : AnagramasTest
    {
        public void Borders8()
        {
            string str = "zxcvuytrewqsdfghjklzvvzxc";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase25 : AnagramasTest
    {
        public void Borders9()
        {
            string str = "qwertywrteyq";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase26 : AnagramasTest
    {
        public void OneChar1()
        {
            string str = "a";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase27 : AnagramasTest
    {
        public void OneChar2()
        {
            string str = "aaaaa";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase28 : AnagramasTest
    {
        public void OneChar3()
        {
            string str = "qqqqqqqqqqqq";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase29 : AnagramasTest
    {
        public void OneChar4()
        {
            string str = "ttttttttttttttttttttttttttttt";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase30 : AnagramasTest
    {
        public void OneChar5()
        {
            string str = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase31 : AnagramasTest
    {
        public void Random1()
        {
            string str = "foalxogwxbpzgrdjitzqe";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase32 : AnagramasTest
    {
        public void Random2()
        {
            string str = "aialvlymfrizcfwecgr";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase33 : AnagramasTest
    {
        public void Random3()
        {
            string str = "fqapfilmhronrxljoyrf";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase34 : AnagramasTest
    {
        public void Random4()
        {
            string str = "updoqzzierxxyvzxiia";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase35 : AnagramasTest
    {
        public void Random5()
        {
            string str = "bzopjfvawplfuppmsssjdslyxmcdfk";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase36 : AnagramasTest
    {
        public void Random6()
        {
            string str = "dtdsqxuqhgenqtazzuq";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase37 : AnagramasTest
    {
        public void Random7()
        {
            string str = "duqjhgktvcrjyhlnyyfpinfhwfklc";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase38 : AnagramasTest
    {
        public void Random8()
        {
            string str = "jyvnqsdhdjsvmrfgvcwlgjd";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase39 : AnagramasTest
    {
        public void Random9()
        {
            string str = "qeldtsvdrsmtlxaosjq";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase40 : AnagramasTest
    {
        public void Random10()
        {
            string str = "abjlmibectfaklcrjcbfbfqryww";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase41 : AnagramasTest
    {
        public void Random11()
        {
            string str = "xlagakkabxzhouh";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase42 : AnagramasTest
    {
        public void Random12()
        {
            string str = "bgeskevixtubbfzfnlhizuwszpq";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase43 : AnagramasTest
    {
        public void Random13()
        {
            string str = "tlggtvoerdlzyhrzkzpretxf";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase44 : AnagramasTest
    {
        public void Random14()
        {
            string str = "lalehmziqazufmyudlnhbhk";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase45 : AnagramasTest
    {
        public void Random15()
        {
            string str = "jopppvabypokztvabhmtmpa";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase46 : AnagramasTest
    {
        public void Random16()
        {
            string str = "jfbjhumvjewipwfpiahn";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase47 : AnagramasTest
    {
        public void Random17()
        {
            string str = "snrnksyatnszegiyobghvkld";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase48 : AnagramasTest
    {
        public void Random18()
        {
            string str = "qmtsvdkjltgwmfrbklr";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase49 : AnagramasTest
    {
        public void Random19()
        {
            string str = "lvuleqifweqecfspstnnbppsp";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase50 : AnagramasTest
    {
        public void Random20()
        {
            string str = "gzlfjfcegqcevwayueg";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase51 : AnagramasTest
    {
        public void Random21()
        {
            string str = "rcxwtgrtafxxwefi";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase52 : AnagramasTest
    {
        public void Random22()
        {
            string str = "hpcbrhgnnrifheatwhivywegjsl";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase53 : AnagramasTest
    {
        public void Random23()
        {
            string str = "pgzzkzlltoonjgoktomvi";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase54 : AnagramasTest
    {
        public void Random24()
        {
            string str = "eaadrtgueevuqmvvrfxe";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase55 : AnagramasTest
    {
        public void Random25()
        {
            string str = "ttyvofotmzsayivevmmyqqitsam";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase56 : AnagramasTest
    {
        public void Random26()
        {
            string str = "recntnxxdfnxnubuqgocslmd";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase57 : AnagramasTest
    {
        public void Random27()
        {
            string str = "okhatbbptohwuvypkk";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase58 : AnagramasTest
    {
        public void Random28()
        {
            string str = "tnkwhwcetndtqzxsbaapbbjqv";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase59 : AnagramasTest
    {
        public void Random29()
        {
            string str = "mxemuqqfkdzchrftpggqolv";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase60 : AnagramasTest
    {
        public void Random30()
        {
            string str = "aodffmybdbabsivcdsay";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase61 : AnagramasTest
    {
        public void Random31()
        {
            string str = "xzfdjgfwxirxpzt";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase62 : AnagramasTest
    {
        public void Random32()
        {
            string str = "tromtxjvtnonuyvlaacapkmrbi";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase63 : AnagramasTest
    {
        public void Random33()
        {
            string str = "srrnjvsuciyeczbiqycjrcj";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase64 : AnagramasTest
    {
        public void Random34()
        {
            string str = "amvkwtexpmtppkl";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase65 : AnagramasTest
    {
        public void Random35()
        {
            string str = "vzfgubszytocabqkircmusriutn";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase66 : AnagramasTest
    {
        public void Random36()
        {
            string str = "hbpbevzuotqdizpumkgxa";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase67 : AnagramasTest
    {
        public void Random37()
        {
            string str = "dezqnkcjamdzjdozxterjv";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase68 : AnagramasTest
    {
        public void Random38()
        {
            string str = "gvfvnhejxnuyrmcn";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase69 : AnagramasTest
    {
        public void Random39()
        {
            string str = "usdomvkivgkopaqavnz";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
    public class TestCase70 : AnagramasTest
    {
        public void Random40()
        {
            string str = "kdivzkuzmychmiegwtuhvls";
            Assert.That(Student(str), Is.EqualTo(CantidadEnCadena(str)));
        }
    }
}
