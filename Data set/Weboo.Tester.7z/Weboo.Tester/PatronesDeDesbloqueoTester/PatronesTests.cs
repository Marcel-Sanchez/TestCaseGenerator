﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Assess.Tester;

namespace PatronesDeDesbloqueoTester
{
    public abstract class PatronesTests : TestCase
    {
        protected int Student(int k, int filas, int columnas)
        {
            return ReflectionHelper.InvokeStatic<int>("Weboo.Examen.Patrones", "CantidadValidos", k, filas, columnas);
        }

        protected void CheckSolution(int k, int filas, int columnas, int sol)
        {
            Assert.That(Student(k, filas, columnas), Is.EqualTo(sol));
        }
    }

    public class Test1 : PatronesTests
    {
        public void Ejemplo1()
        {
            CheckSolution(1, 2, 2, 12);
        }
    }

    public class Test2 : PatronesTests
    {
        public void Ejemplo2()
        {
            CheckSolution(2, 2, 2, 24);
        }
    }

    public class Test3 : PatronesTests
    {
        public void Ejemplo3()
        {
            CheckSolution(1, 2, 3, 26);
        }
    }

    public class Test4 : PatronesTests
    {
        public void Ejemplo4()
        {
            CheckSolution(1, 4, 4, 172);
        }
    }

    public class Test5 : PatronesTests
    {
        public void Ejemplo5()
        {
            CheckSolution(2, 4, 4, 1744);
        }
    }

    public class Test6 : PatronesTests
    {
        public void Ejemplo6()
        {
            CheckSolution(3, 4, 4, 16880);
        }
    }

    public class Test7 : PatronesTests
    {
        public void Ejemplo7()
        {
            CheckSolution(4, 4, 4, 154680);
        }
    }

    public class Test8 : PatronesTests
    {
        public void Basico1()
        {
            CheckSolution(1, 1, 4, 6);
        }
    }

    public class Test9 : PatronesTests
    {
        public void Basico2()
        {
            CheckSolution(1, 2, 4, 44);
        }
    }

    public class Test10 : PatronesTests
    {
        public void Basico3()
        {
            CheckSolution(1, 3, 4, 98);
        }
    }

    public class Test11 : PatronesTests
    {
        public void Basico4()
        {
            CheckSolution(1, 4, 4, 172);
        }
    }

    public class Test12 : PatronesTests
    {
        public void Basico5()
        {
            CheckSolution(1, 4, 3, 98);
        }
    }

    public class Test13 : PatronesTests
    {
        public void Basico5()
        {
            CheckSolution(1, 4, 2, 44);
        }
    }

    public class Test14 : PatronesTests
    {
        public void Basico6()
        {
            CheckSolution(1, 4, 1, 6);
        }
    }

    public class Test15 : PatronesTests
    {
        public void Basico7()
        {
            CheckSolution(2, 4, 1, 8);
        }
    }

    public class Test16 : PatronesTests
    {
        public void Basico8()
        {
            CheckSolution(2, 4, 2, 208);
        }
    }

    public class Test17 : PatronesTests
    {
        public void Basico9()
        {
            CheckSolution(2, 4, 3, 744);
        }
    }

    public class Test18 : PatronesTests
    {
        public void Basico10()
        {
            CheckSolution(2, 4, 4, 1744);
        }
    }

    public class Test19 : PatronesTests
    {
        public void Basico11()
        {
            CheckSolution(3, 1, 4, 8);
        }
    }

    public class Test20 : PatronesTests
    {
        public void Basico12()
        {
            CheckSolution(3, 2, 4, 872);
        }
    }

    public class Test21 : PatronesTests
    {
        public void Basico13()
        {
            CheckSolution(3, 3, 4, 5268);
        }
    }

    public class Test22 : PatronesTests
    {
        public void Basico14()
        {
            CheckSolution(3, 4, 4, 16880);
        }
    }

    public class Test23 : PatronesTests
    {
        public void Basico15()
        {
            CheckSolution(4, 4, 1, 0);
        }
    }

    public class Test24 : PatronesTests
    {
        public void Basico16()
        {
            CheckSolution(4, 4, 2, 3056);
        }
    }

    public class Test25 : PatronesTests
    {
        public void Basico17()
        {
            CheckSolution(4, 4, 3, 34276);
        }
    }

    public class Test26 : PatronesTests
    {
        public void Basico18()
        {
            CheckSolution(4, 4, 4, 154680);
        }
    }

    public class Test27 : PatronesTests
    {
        public void Basico19()
        {
            CheckSolution(5, 2, 4, 8432);
        }
    }

    public class Test28 : PatronesTests
    {
        public void Basico20()
        {
            CheckSolution(5, 3, 4, 201412);
        }
    }

    public class Test29 : PatronesTests
    {
        public void Basico21()
        {
            CheckSolution(5, 4, 4, 1331944);
        }
    }

    public class Test30 : PatronesTests
    {
        public void Basico22()
        {
            CheckSolution(6, 4, 2, 16096);
        }
    }

    public class Test31 : PatronesTests
    {
        public void Basico23()
        {
            CheckSolution(6, 4, 3, 1046052);
        }
    }

    public class Test32 : PatronesTests
    {
        public void Basico24()
        {
            CheckSolution(8, 3, 3, 140704);
        }
    }

    //public class Test8 : PatronesTests
    //{
    //    public void SinTrazos1()
    //    {
    //        CheckSolution(0, 1, 1, 1);
    //    }
    //}

    //public class Test9 : PatronesTests
    //{
    //    public void SinTrazos2()
    //    {
    //        CheckSolution(0, 2, 2, 4);
    //    }
    //}

    //public class Test10 : PatronesTests
    //{
    //    public void SinTrazos3()
    //    {
    //        CheckSolution(0, 4, 1, 4);
    //    }
    //}

    //public class Test11 : PatronesTests
    //{
    //    public void SinTrazos4()
    //    {
    //        CheckSolution(0, 1, 8, 8);
    //    }
    //}

    //public class Test12 : PatronesTests
    //{
    //    public void SinTrazos5()
    //    {
    //        CheckSolution(0, 4, 8, 32);
    //    }
    //}

    //public class Test13 : PatronesTests
    //{
    //    public void SinTrazos6()
    //    {
    //        CheckSolution(0, 25, 20, 500);
    //    }
    //}

    //public class Test14 : PatronesTests
    //{
    //    public void SinTrazos7()
    //    {
    //        CheckSolution(0, 1000, 1000, 1000000);
    //    }
    //}

    //public class Test15 : PatronesTests
    //{
    //    public void UnTrazo1()
    //    {
    //        CheckSolution(1, 1, 1, 0);
    //    }
    //}

    //public class Test16 : PatronesTests
    //{
    //    public void UnTrazo2()
    //    {
    //        CheckSolution(1, 8, 1, 14);
    //    }
    //}

    //public class Test17 : PatronesTests
    //{
    //    public void UnTrazo3()
    //    {
    //        CheckSolution(1, 1, 12, 22);
    //    }
    //}

    //public class Test18 : PatronesTests
    //{
    //    public void UnTrazo4()
    //    {
    //        CheckSolution(1, 2, 10, 236);
    //    }
    //}

    //public class Test19 : PatronesTests
    //{
    //    public void UnTrazo5()
    //    {
    //        CheckSolution(1, 15, 8, 8882);
    //    }
    //}

    //public class Test20 : PatronesTests
    //{
    //    public void UnTrazo6()
    //    {
    //        CheckSolution(1, 12, 18, 28620);
    //    }
    //}

    //public class Test21 : PatronesTests
    //{
    //    public void PocosTrazos1()
    //    {
    //        CheckSolution(2, 2, 4, 208);
    //    }
    //}

    //public class Test22 : PatronesTests
    //{
    //    public void PocosTrazos2()
    //    {
    //        CheckSolution(2, 8, 6, 43400);
    //    }
    //}

    //public class Test23 : PatronesTests
    //{
    //    public void PocosTrazos3()
    //    {
    //        CheckSolution(3, 6, 3, 24924);
    //    }
    //}

    //public class Test24 : PatronesTests
    //{
    //    public void PocosTrazos4()
    //    {
    //        CheckSolution(4, 2, 6, 23920);
    //    }
    //}

    //public class Test25 : PatronesTests
    //{
    //    public void PocosTrazos5()
    //    {
    //        CheckSolution(4, 8, 3, 1017284);
    //    }
    //}

    //public class Test26 : PatronesTests
    //{
    //    public void MuchosTrazos1()
    //    {
    //        CheckSolution(10, 4, 2, 0);
    //    }
    //}

    //public class Test27 : PatronesTests
    //{
    //    public void MuchosTrazos2()
    //    {
    //        CheckSolution(8, 3, 3, 140704);
    //    }
    //}

    //public class Test28 : PatronesTests
    //{
    //    public void MuchosTrazos3()
    //    {
    //        CheckSolution(5, 3, 4, 201412);
    //    }
    //}

    //public class Test29 : PatronesTests
    //{
    //    public void MuchosTrazos4()
    //    {
    //        CheckSolution(15, 1, 16, 32768);
    //    }
    //}

    //public class Test30 : PatronesTests
    //{
    //    public void MuchosTrazos5()
    //    {
    //        CheckSolution(100, 1, 1, 0);
    //    }
    //}

    //public class Test31 : PatronesTests
    //{
    //    public void MuchosTrazos6()
    //    {
    //        CheckSolution(5, 7, 2, 322888);
    //    }
    //}

    //public class Test32 : PatronesTests
    //{
    //    public void MuchosTrazos7()
    //    {
    //        CheckSolution(6, 4, 2, 16096);
    //    }
    //}

    //public class Test33 : PatronesTests
    //{
    //    public void MuchosTrazos8()
    //    {
    //        CheckSolution(7, 4, 2, 16096);
    //    }
    //}

    //public class Test34 : PatronesTests
    //{
    //    public void MuchosTrazos9()
    //    {
    //        CheckSolution(7, 3, 3, 140704);
    //    }
    //}

    //public class Test35 : PatronesTests
    //{
    //    public void MuchosTrazos10()
    //    {
    //        CheckSolution(100, 1, 10, 0);
    //    }
    //}

    //public class Test36 : PatronesTests
    //{
    //    public void Random1()
    //    {
    //        CheckSolution(1, 5, 3, 148);
    //    }
    //}

    //public class Test37 : PatronesTests
    //{
    //    public void Random2()
    //    {
    //        CheckSolution(1, 7, 3, 280);
    //    }
    //}

    //public class Test38 : PatronesTests
    //{
    //    public void Random3()
    //    {
    //        CheckSolution(1, 9, 8, 3234);
    //    }
    //}

    //public class Test39 : PatronesTests
    //{
    //    public void Random4()
    //    {
    //        CheckSolution(1, 2, 7, 122);
    //    }
    //}

    //public class Test40 : PatronesTests
    //{
    //    public void Random5()
    //    {
    //        CheckSolution(1, 4, 13, 1670);
    //    }
    //}

    //public class Test41 : PatronesTests
    //{
    //    public void Random6()
    //    {
    //        CheckSolution(1, 6, 18, 7200);
    //    }
    //}

    //public class Test42 : PatronesTests
    //{
    //    public void Random7()
    //    {
    //        CheckSolution(1, 8, 12, 5712);
    //    }
    //}

    //public class Test43 : PatronesTests
    //{
    //    public void Random8()
    //    {
    //        CheckSolution(1, 18, 12, 28620);
    //    }
    //}

    //public class Test44 : PatronesTests
    //{
    //    public void Random9()
    //    {
    //        CheckSolution(1, 15, 18, 44670);
    //    }
    //}

    //public class Test45 : PatronesTests
    //{
    //    public void Random10()
    //    {
    //        CheckSolution(1, 2, 12, 332);
    //    }
    //}

    //public class Test46 : PatronesTests
    //{
    //    public void Random11()
    //    {
    //        CheckSolution(2, 2, 9, 1928);
    //    }
    //}

    //public class Test47 : PatronesTests
    //{
    //    public void Random12()
    //    {
    //        CheckSolution(2, 10, 3, 9996);
    //    }
    //}

    //public class Test48 : PatronesTests
    //{
    //    public void Random13()
    //    {
    //        CheckSolution(2, 5, 9, 34840);
    //    }
    //}

    //public class Test49 : PatronesTests
    //{
    //    public void Random14()
    //    {
    //        CheckSolution(2, 7, 3, 3604);
    //    }
    //}

    //public class Test50 : PatronesTests
    //{
    //    public void Random15()
    //    {
    //        CheckSolution(2, 8, 9, 143156);
    //    }
    //}

    //public class Test51 : PatronesTests
    //{
    //    public void Random16()
    //    {
    //        CheckSolution(2, 11, 5, 62508);
    //    }
    //}

    //public class Test52 : PatronesTests
    //{
    //    public void Random17()
    //    {
    //        CheckSolution(2, 5, 8, 24728);
    //    }
    //}

    //public class Test53 : PatronesTests
    //{
    //    public void Random18()
    //    {
    //        CheckSolution(3, 4, 9, 392552);
    //    }
    //}
}
