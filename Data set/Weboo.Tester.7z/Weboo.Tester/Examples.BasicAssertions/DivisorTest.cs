﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Assess.Tester;

namespace Examples.BasicAssertions
{
    public class DivisorTest : TestCase
    {
        public void CheckDivisors()
        {
            int k = Input();

            // Método cuya correctitud se desea evaluar
            int[] divisors = GetDivisorsOf(k);

            // Definición de la correctitud mediante una expresión declarativa
            Assert.That(Each.ElementIn(divisors, Is.SuchThat((int i) => k % i == 0)));
        }

        private int[] GetDivisorsOf(int k)
        {
            throw new NotImplementedException();
        }

        private int Input()
        {
            throw new NotImplementedException();
        }
    }

    public class SortTester : TestBuilder<int[]>
    {
        protected override void Test(int[] input)
        {
            Assert.That(ReflectionHelper.InvokeStatic<int[]>("Sorter", "Sort", input), Is.Sorted<int>());
        }

        protected override IBuilder<int[]> Argument
        {
            get
            {
                return Create.ArrayOf<int>()
                        .WithMinLengthOf(1)
                        .WithMaxLengthOf(100)
                        .WithElementsFrom(Enumerable.Range(1, 10000))
                        .Random(100);
            }
        }
    }

    public class ListTestBuilder : TesterFor<IList<int>>
    {
        protected override Generator<IList<int>> BuildCases()
        {
            var input = Create.Integer().InRange(1, 1000);

            var g = new Generator<IList<int>>(totalCases: 100);

            return g
                .PerformMany(l => l.Add(input.Next()), out int timesAdded, maxTimes: 100)
                .Then(
                    g.Assert(l => l.Count, Is.EqualTo(timesAdded)),
                    g.While(l => l.Count > 0).Do(
                       g.PerformOnce(l => l.RemoveAt(Api.Random.Next(0, l.Count))))
                .Then(g.Assert(l => l.Count, Is.EqualTo(0))));
        }
    }

}
