﻿using InterfacesArbolSuma;
using System.Collections.Generic;
using System.Linq;
using Weboo.Assess.Tester;

namespace ArbolesDeSumaTester
{
    public abstract class ArbolSumaTest : InterfaceTester<IArbolSuma>
    {
        protected override IArbolSuma BuildBenchmark(object[] args)
        {
            int[] valores = args.Select(m => (int)m).ToArray();
            return new ArbolSuma(valores);
        }

        protected override IArbolSuma BuildTarget(object[] args)
        {
            int[] valores = args.Select(m => (int)m).ToArray();
            return ReflectionHelper.CreateInstance<IArbolSuma>(valores);
        }

        class ArbolEquality : IEqualityComparer<IArbol<int>>
        {
            public bool Equals(IArbol<int> x, IArbol<int> y)
            {
                if (x == null)
                    return y == null;
                if (y == null)
                    return false;

                if (x.Valor != y.Valor)
                    return false;

                if (x.Hijos == null)
                    return y.Hijos == null;
                if (y.Hijos == null)
                    return false;

                return x.Hijos.Count() == y.Hijos.Count() && Enumerable.Zip(x.Hijos, y.Hijos, (a, b) => Equals(a, b)).All(m => m);
            }

            public int GetHashCode(IArbol<int> obj)
            {
                return obj.Valor + (obj.Hijos?.Sum(m => GetHashCode(m)) ?? 0);
            }
        }

        protected void CheckPreOrder()
        {
            CheckSequence(m => m.PreOrden(), new ArbolEquality());
        }

        protected void CheckPostOrder()
        {
            CheckSequence(m => m.PostOrden(), new ArbolEquality());
        }

        protected void CheckLeafs()
        {
            CheckSequence(m => m.Hojas(), new ArbolEquality());
        }

        protected void CheckChildren()
        {
            CheckSequence(m => m.Hijos, new ArbolEquality());
        }
    }

    public class Test1 : ArbolSumaTest
    {
        public void Ejemplo1()
        {
            Initialize(1, 2, 3, 4);

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test2 : ArbolSumaTest
    {
        public void Ejemplo2()
        {
            Initialize(1, 2, 3, 4);

            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test3 : ArbolSumaTest
    {
        public void Ejemplo3()
        {
            Initialize(1, 2, 3, 4);

            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPostOrden(1, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPostOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(10)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test4 : ArbolSumaTest
    {
        public void Ejemplo4()
        {
            Initialize(1, 2, 3, 4);

            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPostOrden(1, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPostOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarKHoja(1, new ArbolSuma(-10)));
            PerformTarget(m => m.InsertarKHoja(1, ReflectionHelper.CreateInstance<IArbolSuma>(-10)));
            PerformBenchmark(m => m.InsertarKHoja(4, new ArbolSuma(-20)));
            PerformTarget(m => m.InsertarKHoja(4, ReflectionHelper.CreateInstance<IArbolSuma>(-20)));

            CheckPreOrder();
            CheckPostOrder();
            CheckChildren();
            CheckLeafs();
        }
    }

    public class Test5 : ArbolSumaTest
    {
        public void InsertarPreOrden1()
        {
            Initialize(1, 2);

            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(1)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(1)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test6 : ArbolSumaTest
    {
        public void InsertarPreOrden2()
        {
            Initialize(1, -3);

            PerformBenchmark(m => m.InsertarPreOrden(2, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(2, ReflectionHelper.CreateInstance<IArbolSuma>(10)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test7 : ArbolSumaTest
    {
        public void InsertarPreOrden3()
        {
            Initialize(1, -3, 9, 5);

            PerformBenchmark(m => m.InsertarPreOrden(3, new ArbolSuma(1)));
            PerformTarget(m => m.InsertarPreOrden(3, ReflectionHelper.CreateInstance<IArbolSuma>(1)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test8 : ArbolSumaTest
    {
        public void InsertarPreOrden4()
        {
            Initialize(1, -3, 9, 5);

            PerformBenchmark(m => m.InsertarPreOrden(4, new ArbolSuma(4)));
            PerformTarget(m => m.InsertarPreOrden(4, ReflectionHelper.CreateInstance<IArbolSuma>(4)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test9 : ArbolSumaTest
    {
        public void InsertarPreOrden5()
        {
            Initialize(1);

            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(9)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(9)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test10 : ArbolSumaTest
    {
        public void InsertarPreOrden6()
        {
            Initialize(1, 2, -9);

            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(5)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test11 : ArbolSumaTest
    {
        public void InsertarPreOrden7()
        {
            Initialize(1, 2, -9);

            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(2, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(2, ReflectionHelper.CreateInstance<IArbolSuma>(5)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test12 : ArbolSumaTest
    {
        public void InsertarPreOrden8()
        {
            Initialize(1, 2, -9);

            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(2, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(2, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPreOrden(4, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPreOrden(4, ReflectionHelper.CreateInstance<IArbolSuma>(3)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test13 : ArbolSumaTest
    {
        public void InsertarPreOrden9()
        {
            Initialize(1, 2, -9);

            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(2, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(2, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPreOrden(4, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPreOrden(4, ReflectionHelper.CreateInstance<IArbolSuma>(3)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test14 : ArbolSumaTest
    {
        public void InsertarPreOrden10()
        {
            Initialize(1, 2, -9);

            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(2, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(2, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPreOrden(6, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPreOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(3)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test15 : ArbolSumaTest
    {
        public void InsertarPreOrden11()
        {
            Initialize(1, 2, -9);

            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(2, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(2, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPreOrden(6, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPreOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(3)));
            PerformBenchmark(m => m.InsertarPreOrden(9, new ArbolSuma(8)));
            PerformTarget(m => m.InsertarPreOrden(9, ReflectionHelper.CreateInstance<IArbolSuma>(8)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test16 : ArbolSumaTest
    {
        public void InsertarPreOrden12()
        {
            Initialize(1, 2, -9);

            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(2, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(2, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPreOrden(6, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPreOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(3)));
            PerformBenchmark(m => m.InsertarPreOrden(7, new ArbolSuma(-3)));
            PerformTarget(m => m.InsertarPreOrden(7, ReflectionHelper.CreateInstance<IArbolSuma>(-3)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test17 : ArbolSumaTest
    {
        public void InsertarPreOrden13()
        {
            Initialize(1, 2, -9);

            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(2, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(2, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPreOrden(6, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPreOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(3)));
            PerformBenchmark(m => m.InsertarPreOrden(6, new ArbolSuma(-5)));
            PerformTarget(m => m.InsertarPreOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(-5)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test18 : ArbolSumaTest
    {
        public void InsertarPreOrden14()
        {
            Initialize(1, 2, -9);

            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(2, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(2, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPreOrden(6, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPreOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(3)));
            PerformBenchmark(m => m.InsertarPreOrden(4, new ArbolSuma(-16)));
            PerformTarget(m => m.InsertarPreOrden(4, ReflectionHelper.CreateInstance<IArbolSuma>(-16)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test19 : ArbolSumaTest
    {
        public void InsertarPreOrden15()
        {
            Initialize(1, 2, -9);

            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(2, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(2, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPreOrden(6, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPreOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(3)));
            PerformBenchmark(m => m.InsertarPreOrden(3, new ArbolSuma(-12)));
            PerformTarget(m => m.InsertarPreOrden(3, ReflectionHelper.CreateInstance<IArbolSuma>(-12)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test20 : ArbolSumaTest
    {
        public void InsertarPreOrden16()
        {
            Initialize(1, 2, -9);

            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(2, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(2, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPreOrden(6, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPreOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(3)));
            PerformBenchmark(m => m.InsertarPreOrden(2, new ArbolSuma(0)));
            PerformTarget(m => m.InsertarPreOrden(2, ReflectionHelper.CreateInstance<IArbolSuma>(0)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test21 : ArbolSumaTest
    {
        public void InsertarPreOrden17()
        {
            Initialize(1, 2, -9);

            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(2, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(2, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPreOrden(6, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPreOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(3)));
            PerformBenchmark(m => m.InsertarPreOrden(3, new ArbolSuma(0)));
            PerformTarget(m => m.InsertarPreOrden(3, ReflectionHelper.CreateInstance<IArbolSuma>(0)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test22 : ArbolSumaTest
    {
        public void InsertarPreOrden18()
        {
            Initialize(1, 2, -9);

            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(2, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(2, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPreOrden(6, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPreOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(3)));

            CheckLeafs();
        }
    }

    public class Test23 : ArbolSumaTest
    {
        public void InsertarPreOrden19()
        {
            Initialize(1, 2, -9);

            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(2, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(2, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPreOrden(6, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPreOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(3)));

            CheckChildren();
        }
    }

    public class Test24 : ArbolSumaTest
    {
        public void InsertarPreOrden20()
        {
            Initialize(1, 2, -9);

            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(2, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(2, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPreOrden(20, new ArbolSuma(15)));
            PerformTarget(m => m.InsertarPreOrden(20, ReflectionHelper.CreateInstance<IArbolSuma>(15)));

            CheckPreOrder();
        }
    }

    public class Test25 : ArbolSumaTest
    {
        public void InsertarPostOrden1()
        {
            Initialize(-1);

            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test26 : ArbolSumaTest
    {
        public void InsertarPostOrden2()
        {
            Initialize(-1);

            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(5)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test27 : ArbolSumaTest
    {
        public void InsertarPostOrden3()
        {
            Initialize(-1);

            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(2)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test28 : ArbolSumaTest
    {
        public void InsertarPostOrden4()
        {
            Initialize(-1);

            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarPostOrden(6, new ArbolSuma(8)));
            PerformTarget(m => m.InsertarPostOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(8)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test29 : ArbolSumaTest
    {
        public void InsertarPostOrden5()
        {
            Initialize(-1);

            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarPostOrden(6, new ArbolSuma(8)));
            PerformTarget(m => m.InsertarPostOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(8)));
            PerformBenchmark(m => m.InsertarPostOrden(5, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPostOrden(5, ReflectionHelper.CreateInstance<IArbolSuma>(3)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test30 : ArbolSumaTest
    {
        public void InsertarPostOrden6()
        {
            Initialize(-1);

            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarPostOrden(6, new ArbolSuma(8)));
            PerformTarget(m => m.InsertarPostOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(8)));
            PerformBenchmark(m => m.InsertarPostOrden(5, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPostOrden(5, ReflectionHelper.CreateInstance<IArbolSuma>(3)));
            PerformBenchmark(m => m.InsertarPostOrden(5, new ArbolSuma(-10)));
            PerformTarget(m => m.InsertarPostOrden(5, ReflectionHelper.CreateInstance<IArbolSuma>(-10)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test31 : ArbolSumaTest
    {
        public void InsertarPostOrden7()
        {
            Initialize(-1);

            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarPostOrden(6, new ArbolSuma(8)));
            PerformTarget(m => m.InsertarPostOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(8)));
            PerformBenchmark(m => m.InsertarPostOrden(5, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPostOrden(5, ReflectionHelper.CreateInstance<IArbolSuma>(3)));
            PerformBenchmark(m => m.InsertarPostOrden(3, new ArbolSuma(-20)));
            PerformTarget(m => m.InsertarPostOrden(3, ReflectionHelper.CreateInstance<IArbolSuma>(-20)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test32 : ArbolSumaTest
    {
        public void InsertarPostOrden8()
        {
            Initialize(-1);

            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarPostOrden(6, new ArbolSuma(8)));
            PerformTarget(m => m.InsertarPostOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(8)));
            PerformBenchmark(m => m.InsertarPostOrden(5, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPostOrden(5, ReflectionHelper.CreateInstance<IArbolSuma>(3)));
            PerformBenchmark(m => m.InsertarPostOrden(8, new ArbolSuma(-27)));
            PerformTarget(m => m.InsertarPostOrden(8, ReflectionHelper.CreateInstance<IArbolSuma>(-27)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test33 : ArbolSumaTest
    {
        public void InsertarPostOrden9()
        {
            Initialize(-1);

            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarPostOrden(6, new ArbolSuma(8)));
            PerformTarget(m => m.InsertarPostOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(8)));
            PerformBenchmark(m => m.InsertarPostOrden(5, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPostOrden(5, ReflectionHelper.CreateInstance<IArbolSuma>(3)));
            PerformBenchmark(m => m.InsertarPostOrden(3, new ArbolSuma(-27)));
            PerformTarget(m => m.InsertarPostOrden(3, ReflectionHelper.CreateInstance<IArbolSuma>(-27)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test34 : ArbolSumaTest
    {
        public void InsertarPostOrden10()
        {
            Initialize(-1);

            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarPostOrden(6, new ArbolSuma(8)));
            PerformTarget(m => m.InsertarPostOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(8)));
            PerformBenchmark(m => m.InsertarPostOrden(5, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPostOrden(5, ReflectionHelper.CreateInstance<IArbolSuma>(3)));
            PerformBenchmark(m => m.InsertarPostOrden(10, new ArbolSuma(-27)));
            PerformTarget(m => m.InsertarPostOrden(10, ReflectionHelper.CreateInstance<IArbolSuma>(-27)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test35 : ArbolSumaTest
    {
        public void InsertarPostOrden11()
        {
            Initialize(-1);

            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarPostOrden(6, new ArbolSuma(8)));
            PerformTarget(m => m.InsertarPostOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(8)));
            PerformBenchmark(m => m.InsertarPostOrden(5, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPostOrden(5, ReflectionHelper.CreateInstance<IArbolSuma>(3)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(0)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(0)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test36 : ArbolSumaTest
    {
        public void InsertarPostOrden12()
        {
            Initialize(-1);

            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarPostOrden(6, new ArbolSuma(8)));
            PerformTarget(m => m.InsertarPostOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(8)));
            PerformBenchmark(m => m.InsertarPostOrden(5, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPostOrden(5, ReflectionHelper.CreateInstance<IArbolSuma>(3)));
            PerformBenchmark(m => m.InsertarPostOrden(4, new ArbolSuma(0)));
            PerformTarget(m => m.InsertarPostOrden(4, ReflectionHelper.CreateInstance<IArbolSuma>(0)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test37 : ArbolSumaTest
    {
        public void InsertarPostOrden13()
        {
            Initialize(-1);

            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarPostOrden(6, new ArbolSuma(8)));
            PerformTarget(m => m.InsertarPostOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(8)));

            CheckChildren();
        }
    }

    public class Test38 : ArbolSumaTest
    {
        public void InsertarPostOrden14()
        {
            Initialize(-1);

            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarPostOrden(6, new ArbolSuma(8)));
            PerformTarget(m => m.InsertarPostOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(8)));

            CheckLeafs();
        }
    }

    public class Test39 : ArbolSumaTest
    {
        public void InsertarPostOrden15()
        {
            Initialize(-1);

            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarPostOrden(6, new ArbolSuma(8)));
            PerformTarget(m => m.InsertarPostOrden(6, ReflectionHelper.CreateInstance<IArbolSuma>(8)));

            Check(m => m.Valor);
        }
    }

    public class Test40 : ArbolSumaTest
    {
        public void InsertarKHojas1()
        {
            Initialize(2);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));

            CheckPostOrder();
            CheckPreOrder();
        }
    }

    public class Test41 : ArbolSumaTest
    {
        public void InsertarKHojas2()
        {
            Initialize(2);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));

            CheckPostOrder();
            CheckPreOrder();
        }
    }

    public class Test42 : ArbolSumaTest
    {
        public void InsertarKHojas3()
        {
            Initialize(2);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));
            PerformBenchmark(m => m.InsertarKHoja(2, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarKHoja(2, ReflectionHelper.CreateInstance<IArbolSuma>(2)));

            CheckPostOrder();
            CheckPreOrder();
        }
    }

    public class Test43 : ArbolSumaTest
    {
        public void InsertarKHojas4()
        {
            Initialize(2);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));
            PerformBenchmark(m => m.InsertarKHoja(2, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarKHoja(2, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(8)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(8)));

            CheckPostOrder();
            CheckPreOrder();
        }
    }

    public class Test44 : ArbolSumaTest
    {
        public void InsertarKHojas5()
        {
            Initialize(2);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));
            PerformBenchmark(m => m.InsertarKHoja(2, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarKHoja(2, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(9)));

            CheckPostOrder();
            CheckPreOrder();
        }
    }

    public class Test45 : ArbolSumaTest
    {
        public void InsertarKHojas6()
        {
            Initialize(2);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));
            PerformBenchmark(m => m.InsertarKHoja(2, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarKHoja(2, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarKHoja(3, new ArbolSuma(-4)));
            PerformTarget(m => m.InsertarKHoja(3, ReflectionHelper.CreateInstance<IArbolSuma>(-4)));

            CheckPostOrder();
            CheckPreOrder();
        }
    }

    public class Test46 : ArbolSumaTest
    {
        public void InsertarKHojas7()
        {
            Initialize(2);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));
            PerformBenchmark(m => m.InsertarKHoja(2, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarKHoja(2, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarKHoja(2, new ArbolSuma(-5)));
            PerformTarget(m => m.InsertarKHoja(2, ReflectionHelper.CreateInstance<IArbolSuma>(-5)));

            CheckPostOrder();
            CheckPreOrder();
        }
    }

    public class Test47 : ArbolSumaTest
    {
        public void InsertarKHojas8()
        {
            Initialize(2);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));
            PerformBenchmark(m => m.InsertarKHoja(2, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarKHoja(2, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarKHoja(2, new ArbolSuma(0)));
            PerformTarget(m => m.InsertarKHoja(2, ReflectionHelper.CreateInstance<IArbolSuma>(0)));

            CheckPostOrder();
            CheckPreOrder();
        }
    }

    public class Test48 : ArbolSumaTest
    {
        public void InsertarKHojas9()
        {
            Initialize(2);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));
            PerformBenchmark(m => m.InsertarKHoja(2, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarKHoja(2, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarKHoja(4, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarKHoja(4, ReflectionHelper.CreateInstance<IArbolSuma>(5)));

            CheckPostOrder();
            CheckPreOrder();
        }
    }

    public class Test49 : ArbolSumaTest
    {
        public void InsertarKHojas10()
        {
            Initialize(2);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));
            PerformBenchmark(m => m.InsertarKHoja(2, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarKHoja(2, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarKHoja(4, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarKHoja(4, ReflectionHelper.CreateInstance<IArbolSuma>(5)));

            CheckPostOrder();
            CheckPreOrder();
        }
    }

    public class Test50 : ArbolSumaTest
    {
        public void InsertarKHojas11()
        {
            Initialize(2);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));
            PerformBenchmark(m => m.InsertarKHoja(2, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarKHoja(2, ReflectionHelper.CreateInstance<IArbolSuma>(2)));

            CheckChildren();
        }
    }

    public class Test51 : ArbolSumaTest
    {
        public void InsertarKHojas12()
        {
            Initialize(2);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));
            PerformBenchmark(m => m.InsertarKHoja(2, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarKHoja(2, ReflectionHelper.CreateInstance<IArbolSuma>(2)));

            CheckLeafs();
        }
    }

    public class Test52 : ArbolSumaTest
    {
        public void InsertarKHojas13()
        {
            Initialize(2);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));
            PerformBenchmark(m => m.InsertarKHoja(2, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarKHoja(2, ReflectionHelper.CreateInstance<IArbolSuma>(2)));

            Check(m => m.Valor);
        }
    }

    public class Test53 : ArbolSumaTest
    {
        public void Constructor1()
        {
            Initialize(0);

            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(3)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test54 : ArbolSumaTest
    {
        public void Constructor2()
        {
            Initialize(2, 0, 3);

            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(3)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test55 : ArbolSumaTest
    {
        public void Constructor3()
        {
            Initialize(3, -3);

            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(3)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test56 : ArbolSumaTest
    {
        public void Constructor4()
        {
            Initialize(1, -3, 0, -1, -1, 8, 0, -4);

            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(3)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test57 : ArbolSumaTest
    {
        public void Constructor4()
        {
            Initialize(1, -3, 0, -1, -1, 8, 0, -4);

            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarPreOrden(1, new ArbolSuma(5)));
            PerformTarget(m => m.InsertarPreOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(5)));
            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(3)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(3)));

            CheckPreOrder();
            CheckPostOrder();
        }
    }

    public class Test58 : ArbolSumaTest
    {
        public void Constructor5()
        {
            Initialize(1, -3, 0, -1, -1, 8, 0, -4);

            CheckChildren();
        }
    }

    public class Test59 : ArbolSumaTest
    {
        public void Constructor6()
        {
            Initialize(1, -3, 0, -1, -1, 8, 0, -4);

            CheckLeafs();
        }
    }

    public class Test60 : ArbolSumaTest
    {
        public void Constructor7()
        {
            Initialize(1);

            CheckLeafs();
        }
    }

    public class Test61 : ArbolSumaTest
    {
        public void Constructor8()
        {
            Initialize(1);

            Check(m => m.Valor);
        }
    }

    public class Test62 : ArbolSumaTest
    {
        public void Constructor9()
        {
            Initialize(1, -3, 0, -1, -1, 8, 0, -4);

            Check(m => m.Valor);
        }
    }

    public class Test63 : ArbolSumaTest
    {
        public void Constructor10()
        {
            Initialize(8);

            CheckChildren();
        }
    }

    public class Test64 : ArbolSumaTest
    {
        public void Mix1()
        {
            Initialize(4);

            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));
            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(2)));

            CheckPostOrder();
            CheckPreOrder();
        }
    }

    public class Test65 : ArbolSumaTest
    {
        public void Mix2()
        {
            Initialize(4);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(10)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(10)));

            CheckPostOrder();
            CheckPreOrder();
        }
    }

    public class Test66 : ArbolSumaTest
    {
        public void Mix3()
        {
            Initialize(4, 1);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));
            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(-2)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(-2)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(2)));

            CheckPostOrder();
            CheckPreOrder();
        }
    }

    public class Test67 : ArbolSumaTest
    {
        public void Mix4()
        {
            Initialize(4, 1, 0);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));
            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(-2)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(-2)));
            PerformBenchmark(m => m.InsertarPostOrden(0, new ArbolSuma(2)));
            PerformTarget(m => m.InsertarPostOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(2)));
            PerformBenchmark(m => m.InsertarKHoja(2, new ArbolSuma(6)));
            PerformTarget(m => m.InsertarKHoja(2, ReflectionHelper.CreateInstance<IArbolSuma>(6)));

            CheckPostOrder();
            CheckPreOrder();
        }
    }

    public class Test68 : ArbolSumaTest
    {
        public void Mix5()
        {
            Initialize(4, 1, -4);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));
            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(-2)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(-2)));
            PerformBenchmark(m => m.InsertarKHoja(2, new ArbolSuma(6)));
            PerformTarget(m => m.InsertarKHoja(2, ReflectionHelper.CreateInstance<IArbolSuma>(6)));
            PerformBenchmark(m => m.InsertarPostOrden(1, new ArbolSuma(0)));
            PerformTarget(m => m.InsertarPostOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(0)));

            CheckPostOrder();
            CheckPreOrder();
        }
    }

    public class Test69 : ArbolSumaTest
    {
        public void Mix6()
        {
            Initialize(4, 0, -4);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));
            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(-2)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(-2)));
            PerformBenchmark(m => m.InsertarKHoja(2, new ArbolSuma(6)));
            PerformTarget(m => m.InsertarKHoja(2, ReflectionHelper.CreateInstance<IArbolSuma>(6)));
            PerformBenchmark(m => m.InsertarPostOrden(8, new ArbolSuma(0)));
            PerformTarget(m => m.InsertarPostOrden(8, ReflectionHelper.CreateInstance<IArbolSuma>(0)));

            CheckLeafs();
        }
    }

    public class Test70 : ArbolSumaTest
    {
        public void Mix7()
        {
            Initialize(9);

            PerformBenchmark(m => m.InsertarKHoja(0, new ArbolSuma(-9)));
            PerformTarget(m => m.InsertarKHoja(0, ReflectionHelper.CreateInstance<IArbolSuma>(-9)));
            PerformBenchmark(m => m.InsertarPreOrden(0, new ArbolSuma(-2)));
            PerformTarget(m => m.InsertarPreOrden(0, ReflectionHelper.CreateInstance<IArbolSuma>(-2)));
            PerformBenchmark(m => m.InsertarKHoja(2, new ArbolSuma(6)));
            PerformTarget(m => m.InsertarKHoja(2, ReflectionHelper.CreateInstance<IArbolSuma>(6)));
            PerformBenchmark(m => m.InsertarPostOrden(1, new ArbolSuma(4)));
            PerformTarget(m => m.InsertarPostOrden(1, ReflectionHelper.CreateInstance<IArbolSuma>(4)));

            CheckChildren();
        }
    }
}
