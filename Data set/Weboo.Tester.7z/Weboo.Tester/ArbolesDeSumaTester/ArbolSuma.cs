﻿using InterfacesArbolSuma;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ArbolesDeSumaTester
{
    public class ArbolSuma : IArbolSuma
    {
        private IList<IArbolSuma> _children;
        private int _value;

        public ArbolSuma(params int[] values)
        {
            _children = new List<IArbolSuma>();
            _value = values.Sum();

            if (_value != 0 && values.Length > 1)
            {
                foreach (var value in values.Where(m => m != 0))
                    _children.Add(new ArbolSuma(value));
            }
        }

        public IEnumerable<IArbol<int>> PostOrden()
        {
            foreach (var child in _children)
                foreach (var tree in child.PostOrden())
                    yield return tree;

            yield return this;
        }

        public IEnumerable<IArbol<int>> PreOrden()
        {
            yield return this;

            foreach (var child in _children)
                foreach (var tree in child.PreOrden())
                    yield return tree;
        }

        public IEnumerable<IArbol<int>> Hojas()
        {
            if (!_children.Any())
            {
                yield return this;
                yield break;
            }

            foreach (var child in _children)
                foreach (var tree in child.Hojas())
                    yield return tree;
        }

        public int Valor
        {
            get { return _value; }
        }

        public IEnumerable<IArbol<int>> Hijos
        {
            get { return _children; }
        }

        private void Insert(IArbolSuma newChild)
        {
            if (!_children.Any())
            {
                _children.Add(new ArbolSuma(_value));
            }

            _children.Insert(0, newChild);
        }

        private void Sanitize()
        {
            if (!_children.Any())
                return;

            _children = _children
                .Where(m => m.Valor != 0)
                .ToList();
            _value = _children.Sum(m => m.Valor);
            if (_value == 0)
            {
                _children = new List<IArbolSuma>();
            }
        }

        public void InsertarPreOrden(int k, IArbolSuma nuevo)
        {
            if (k == 0)
            {
                Insert(nuevo);
            }
            else
            {
                k--;
                foreach (var child in _children)
                {
                    int curr = child.PreOrden().Count();
                    if (k < curr)
                    {
                        child.InsertarPreOrden(k, nuevo);
                        break;
                    }

                    k -= curr;
                }
            }

            Sanitize();
        }

        public void InsertarPostOrden(int k, IArbolSuma nuevo)
        {
            if (k == PostOrden().Count() - 1)
            {
                Insert(nuevo);
            }
            else
            {
                foreach (var child in _children)
                {
                    int curr = child.PostOrden().Count();
                    if (k < curr)
                    {
                        child.InsertarPostOrden(k, nuevo);
                        break;
                    }

                    k -= curr;
                }
            }

            Sanitize();
        }

        public void InsertarKHoja(int k, IArbolSuma nuevo)
        {
            if (!this.Hijos.Any())
            {
                if (k == 0)
                {
                    Insert(nuevo);
                }
            }
            else
            {
                foreach (var child in _children)
                {
                    int curr = child.Hojas().Count();
                    if (k < curr)
                    {
                        child.InsertarKHoja(k, nuevo);
                        break;
                    }

                    k -= curr;
                }
            }

            Sanitize();
        }

        public void Imprimir(string indent = "", bool last = false)
        {
            Console.Write(indent);
            Console.Write("| ");
            indent += "  ";

            Console.WriteLine(Valor);

            for (int i = 0; i < Hijos.Count(); i++)
            {
                (Hijos.ElementAt(i) as ArbolSuma).Imprimir(indent, i == Hijos.Count() - 1);
            }
        }
    }
}
