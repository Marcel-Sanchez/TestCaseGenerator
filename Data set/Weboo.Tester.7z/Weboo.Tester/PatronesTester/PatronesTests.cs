﻿using Weboo.Assess.Tester;

namespace PatronesTester
{
    public abstract class PatronesTests : TestCase
    {
        public string Student(string str, int[] openCosts, int[] closeCosts)
        {
            return ReflectionHelper.InvokeStatic<string>("Weboo.Mundial.Balanceando", "Balanceada", str, openCosts, closeCosts);
        }

        protected static int? GetCost(string original, string solution, int[] openCost, int[] closeCost)
        {
            if (solution == null)
                return null;

            int cost = 0;
            int p = 0;
            for (int i = 0; i < original.Length; i++)
            {
                if (original[i] == '?')
                {
                    cost += solution[i] == '(' ? openCost[p] : closeCost[p];
                    p++;
                }
            }

            return cost;
        }
    }

    public class TestCase1 : PatronesTests
    {
        public void Test1()
        {
            string str = "(??)";
            int[] openCosts = new int[] { 1, 2 };
            int[] closeCosts = new int[] { 2, 8 };
            int? expectedCost = 4; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase2 : PatronesTests
    {
        public void Test2()
        {
            string str = "??";
            int[] openCosts = new int[] { 1, 1 };
            int[] closeCosts = new int[] { 1, 1 };
            int? expectedCost = 2; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase3 : PatronesTests
    {
        public void Test3()
        {
            string str = "(???";
            int[] openCosts = new int[] { 1, 1, 1 };
            int[] closeCosts = new int[] { 1, 1, 1 };
            int? expectedCost = 3; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase4 : PatronesTests
    {
        public void Test4()
        {
            string str = "(??)";
            int[] openCosts = new int[] { 2, 1 };
            int[] closeCosts = new int[] { 1, 1 };
            int? expectedCost = 2; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase5 : PatronesTests
    {
        public void Test5()
        {
            string str = "(???)?";
            int[] openCosts = new int[] { 3, 3, 3, 2 };
            int[] closeCosts = new int[] { 3, 1, 3, 3 };
            int? expectedCost = 10; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase6 : PatronesTests
    {
        public void Test6()
        {
            string str = "((????";
            int[] openCosts = new int[] { 3, 3, 1, 2 };
            int[] closeCosts = new int[] { 2, 2, 1, 3 };
            int? expectedCost = 8; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase7 : PatronesTests
    {
        public void Test7()
        {
            string str = "???())";
            int[] openCosts = new int[] { 2, 3, 4 };
            int[] closeCosts = new int[] { 4, 3, 1 };
            int? expectedCost = 6; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase8 : PatronesTests
    {
        public void Test8()
        {
            string str = "((????";
            int[] openCosts = new int[] { 3, 4, 2, 1 };
            int[] closeCosts = new int[] { 5, 1, 2, 5 };
            int? expectedCost = 11; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase9 : PatronesTests
    {
        public void Test9()
        {
            string str = "?(?)(???";
            int[] openCosts = new int[] { 2, 2, 3, 3, 3 };
            int[] closeCosts = new int[] { 3, 2, 2, 1, 1 };
            int? expectedCost = 8; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase10 : PatronesTests
    {
        public void Test10()
        {
            string str = "(??????)";
            int[] openCosts = new int[] { 1, 3, 3, 3, 1, 3 };
            int[] closeCosts = new int[] { 1, 3, 3, 2, 3, 3 };
            int? expectedCost = 13; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase11 : PatronesTests
    {
        public void Test11()
        {
            string str = "?????)??";
            int[] openCosts = new int[] { 2, 2, 1, 5, 3, 1, 3 };
            int[] closeCosts = new int[] { 3, 1, 3, 1, 3, 3, 2 };
            int? expectedCost = 11; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase12 : PatronesTests
    {
        public void Test12()
        {
            string str = "?)???(??";
            int[] openCosts = new int[] { 1, 3, 2, 2, 3, 3 };
            int[] closeCosts = new int[] { 4, 4, 4, 5, 3, 1 };
            int? expectedCost = 14; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase13 : PatronesTests
    {
        public void Test13()
        {
            string str = "???(??))";
            int[] openCosts = new int[] { 2, 2, 2, 1, 2 };
            int[] closeCosts = new int[] { 1, 1, 1, 2, 1 };
            int? expectedCost = 7; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase14 : PatronesTests
    {
        public void Test14()
        {
            string str = "??(()??)";
            int[] openCosts = new int[] { 3, 3, 1, 2 };
            int[] closeCosts = new int[] { 2, 3, 3, 2 };
            int? expectedCost = 9; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase15 : PatronesTests
    {
        public void Test15()
        {
            string str = "????(???";
            int[] openCosts = new int[] { 2, 1, 1, 3, 4, 4, 2 };
            int[] closeCosts = new int[] { 2, 3, 3, 3, 1, 4, 4 };
            int? expectedCost = 16; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase16 : PatronesTests
    {
        public void Test16()
        {
            string str = "?(??????";
            int[] openCosts = new int[] { 1, 2, 4, 4, 4, 5, 2 };
            int[] closeCosts = new int[] { 5, 4, 4, 3, 5, 4, 3 };
            int? expectedCost = 21; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase17 : PatronesTests
    {
        public void Test17()
        {
            string str = "???????)";
            int[] openCosts = new int[] { 6, 5, 4, 1, 4, 2, 4 };
            int[] closeCosts = new int[] { 3, 3, 1, 4, 1, 6, 3 };
            int? expectedCost = 19; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase18 : PatronesTests
    {
        public void Test18()
        {
            string str = "??????)?";
            int[] openCosts = new int[] { 2, 4, 3, 3, 7, 6, 1 };
            int[] closeCosts = new int[] { 2, 2, 5, 2, 4, 2, 6 };
            int? expectedCost = 24; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase19 : PatronesTests
    {
        public void Test19()
        {
            string str = "?((?)?)?";
            int[] openCosts = new int[] { 1, 4, 1, 1 };
            int[] closeCosts = new int[] { 2, 2, 3, 2 };
            int? expectedCost = 6; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase20 : PatronesTests
    {
        public void Test20()
        {
            string str = "??(????)";
            int[] openCosts = new int[] { 3, 1, 4, 2, 2, 2 };
            int[] closeCosts = new int[] { 2, 4, 4, 3, 3, 4 };
            int? expectedCost = 16; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    //public class TestCase21 : PatronesTests
    //{
    //    public void Test21()
    //    {
    //        string str = "???(?)??(??)?)(?(?????????(?()????)(????(?)????)???)??))(?(?????????))???(??)?????))???????(????????";
    //        int[] openCosts = new int[] { 9, 6, 8, 9, 9, 6, 8, 6, 2, 7, 6, 1, 1, 10, 10, 8, 5, 9, 3, 1, 8, 8, 4, 6, 4, 4, 5, 5, 7, 7, 10, 1, 5, 3, 2, 8, 6, 8, 3, 8, 8, 7, 10, 5, 2, 2, 2, 5, 9, 1, 10, 4, 8, 2, 6, 3, 4, 2, 3, 4, 6, 4, 3, 5, 8, 6, 5, 6, 8, 5, 8, 7, 1 };
    //        int[] closeCosts = new int[] { 10, 3, 2, 10, 3, 2, 5, 7, 6, 8, 10, 7, 7, 7, 7, 4, 9, 3, 10, 10, 2, 8, 8, 6, 10, 5, 2, 6, 7, 3, 1, 4, 10, 2, 8, 9, 5, 6, 4, 6, 5, 7, 9, 5, 1, 7, 3, 10, 7, 9, 9, 5, 2, 5, 7, 6, 2, 5, 9, 4, 3, 9, 1, 7, 7, 9, 3, 4, 3, 8, 4, 6, 4 };
    //        int? expectedCost = 309; string solution = Student(str, openCosts, closeCosts);
    //        Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
    //    }
    //}
    //public class TestCase22 : PatronesTests
    //{
    //    public void Test22()
    //    {
    //        string str = "(?(((???))(??)?)?))))(?)????(()()???(?)????(??(??????)()(????(?)))))??(???(??)?(??)????????(????(?()";
    //        int[] openCosts = new int[] { 39, 1, 2, 28, 53, 96, 16, 43, 25, 8, 57, 15, 47, 23, 97, 38, 68, 38, 62, 61, 84, 71, 12, 97, 16, 72, 55, 88, 49, 39, 51, 41, 97, 71, 21, 1, 22, 42, 88, 57, 57, 59, 56, 18, 43, 75, 34, 62, 62, 67, 91, 49, 97, 75, 20, 55, 12 };
    //        int[] closeCosts = new int[] { 78, 83, 35, 89, 53, 67, 46, 28, 73, 97, 41, 25, 49, 18, 77, 33, 80, 98, 8, 79, 50, 48, 16, 95, 70, 58, 85, 42, 56, 63, 100, 15, 17, 63, 44, 41, 14, 65, 33, 95, 28, 8, 42, 99, 6, 93, 23, 57, 71, 92, 60, 58, 14, 68, 9, 98, 3 };
    //        int? expectedCost = 2140; string solution = Student(str, openCosts, closeCosts);
    //        Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
    //    }
    //}
    public class TestCase23 : PatronesTests
    {
        public void Test23()
        {
            string str = "?(?(??";
            int[] openCosts = new int[] { 1, 2, 1, 1 };
            int[] closeCosts = new int[] { 1, 2, 1, 1 };
            int? expectedCost = 5; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase24 : PatronesTests
    {
        public void Test24()
        {
            string str = "(????(";
            int[] openCosts = new int[] { 1, 2, 2, 3 };
            int[] closeCosts = new int[] { 1, 1, 1, 3 };
            int? expectedCost = null; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase25 : PatronesTests
    {
        public void Test25()
        {
            string str = "(?(???";
            int[] openCosts = new int[] { 2, 1, 3, 1 };
            int[] closeCosts = new int[] { 3, 1, 3, 4 };
            int? expectedCost = 10; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase26 : PatronesTests
    {
        public void Test26()
        {
            string str = "))))))";
            int[] openCosts = new int[] { };
            int[] closeCosts = new int[] { };
            int? expectedCost = null; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase27 : PatronesTests
    {
        public void Test27()
        {
            string str = ")?)??)";
            int[] openCosts = new int[] { 4, 3, 3 };
            int[] closeCosts = new int[] { 4, 5, 6 };
            int? expectedCost = null; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase28 : PatronesTests
    {
        public void Test28()
        {
            string str = "((((((";
            int[] openCosts = new int[] { };
            int[] closeCosts = new int[] { };
            int? expectedCost = null; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase29 : PatronesTests
    {
        public void Test29()
        {
            string str = "()()()";
            int[] openCosts = new int[] { };
            int[] closeCosts = new int[] { };
            int? expectedCost = 0; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase30 : PatronesTests
    {
        public void Test30()
        {
            string str = "????((";
            int[] openCosts = new int[] { 7, 1, 9, 4 };
            int[] closeCosts = new int[] { 6, 10, 8, 4 };
            int? expectedCost = null; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase31 : PatronesTests
    {
        public void Test31()
        {
            string str = "((()))";
            int[] openCosts = new int[] { };
            int[] closeCosts = new int[] { };
            int? expectedCost = 0; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase32 : PatronesTests
    {
        public void Test32()
        {
            string str = "?))?))";
            int[] openCosts = new int[] { 9, 8 };
            int[] closeCosts = new int[] { 13, 11 };
            int? expectedCost = null; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase33 : PatronesTests
    {
        public void Test33()
        {
            string str = "))))))";
            int[] openCosts = new int[] { };
            int[] closeCosts = new int[] { };
            int? expectedCost = null; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase34 : PatronesTests
    {
        public void Test34()
        {
            string str = "?(?)?)";
            int[] openCosts = new int[] { 6, 8, 4 };
            int[] closeCosts = new int[] { 14, 6, 3 };
            int? expectedCost = 16; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
    public class TestCase35 : PatronesTests
    {
        public void Test35()
        {
            string str = "?(?(((";
            int[] openCosts = new int[] { 8, 17 };
            int[] closeCosts = new int[] { 7, 15 };
            int? expectedCost = null; string solution = Student(str, openCosts, closeCosts);
            Assert.That(GetCost(str, solution, openCosts, closeCosts), Is.EqualTo(expectedCost));
        }
    }
}
