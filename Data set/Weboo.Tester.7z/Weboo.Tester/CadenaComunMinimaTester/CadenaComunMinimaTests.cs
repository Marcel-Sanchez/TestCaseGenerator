﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Weboo.Assess.Tester;

namespace CadenaComunMinimaTester
{
    public abstract class CadenaComunMinimaTest : TestCase
    {
        public string Student(string p1, string p2, string alpha)
        {
            return ReflectionHelper.InvokeStatic<string>("Weboo.Examen.Patrones", "CadenaComunMinima", p1, p2, alpha);
        }

        protected string Alphabet = "abcdefghijklmnopqrstuvwxyz";

        public void Check(string p1, string p2, string alpha, string str)
        {
            if (str == null)
                return;

            Func<string, string> regexPattern = (string p) => p.Replace("?", $"[{alpha}]").Replace("*", $"[{alpha}]*").Replace("+", $"[{alpha}]+");
            if (!Regex.IsMatch(str, regexPattern(p1)))
            {
                Assert.Fail($"The pattern {p1} doesn't match the string {str}.");
            }
            if (!Regex.IsMatch(str, regexPattern(p2)))
            {
                Assert.Fail("The string returned is not");
            }
        }
    }

    public class Example1Test : CadenaComunMinimaTest
    {
        public void Example1()
        {
            string p1 = "a*";
            string p2 = "+ab*";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str.Length, Is.EqualTo(3));
        }
    }

    public class Example2Test : CadenaComunMinimaTest
    {
        public void Example2()
        {
            string p1 = "?*?";
            string p2 = "+*+";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str.Length, Is.EqualTo(2));
        }
    }

    public class Example3Test : CadenaComunMinimaTest
    {
        public void Example3()
        {
            string p1 = "abc";
            string p2 = "*?";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str.Length, Is.EqualTo(3));
        }
    }

    public class Example4Test : CadenaComunMinimaTest
    {
        public void Example4()
        {
            string p1 = "c++";
            string p2 = "?*****";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str.Length, Is.EqualTo(3));
        }
    }

    public class Example5Test : CadenaComunMinimaTest
    {
        public void Example5()
        {
            string p1 = "*++?";
            string p2 = "ba*";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str.Length, Is.EqualTo(3));
        }
    }

    public class Example6Test : CadenaComunMinimaTest
    {
        public void Example6()
        {
            string p1 = "*";
            string p2 = "*";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str.Length, Is.EqualTo(0));
        }
    }

    public class Example7Test : CadenaComunMinimaTest
    {
        public void Example7()
        {
            string p1 = "a?b";
            string p2 = "??";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str, Is.Null);
        }
    }

    public class Example8Test : CadenaComunMinimaTest
    {
        public void Example8()
        {
            string p1 = "+";
            string p2 = "ab+";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str.Length, Is.EqualTo(3));
        }
    }

    public class Basic1Test : CadenaComunMinimaTest
    {
        public void Basic1()
        {
            string p1 = "*";
            string p2 = "****";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str.Length, Is.EqualTo(0));
        }
    }

    public class Basic2Test : CadenaComunMinimaTest
    {
        public void Basic2()
        {
            string p1 = "a";
            string p2 = "b";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str, Is.Null);
        }
    }

    public class Basic3Test : CadenaComunMinimaTest
    {
        public void Basic3()
        {
            string p1 = "a";
            string p2 = "*";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str.Length, Is.EqualTo(1));
        }
    }

    public class Basic4Test : CadenaComunMinimaTest
    {
        public void Basic4()
        {
            string p1 = "k";
            string p2 = "+";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str.Length, Is.EqualTo(1));
        }
    }

    public class Basic5Test : CadenaComunMinimaTest
    {
        public void Basic5()
        {
            string p1 = "z";
            string p2 = "?";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str.Length, Is.EqualTo(1));
        }
    }

    public class Basic6Test : CadenaComunMinimaTest
    {
        public void Basic6()
        {
            string p1 = "+";
            string p2 = "?";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str.Length, Is.EqualTo(1));
        }
    }

    public class Basic7Test : CadenaComunMinimaTest
    {
        public void Basic7()
        {
            string p1 = "*";
            string p2 = "+";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str.Length, Is.EqualTo(1));
        }
    }

    public class Basic8Test : CadenaComunMinimaTest
    {
        public void Basic8()
        {
            string p1 = "?";
            string p2 = "?";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str.Length, Is.EqualTo(1));
        }
    }

    public class Basic9Test : CadenaComunMinimaTest
    {
        public void Basic9()
        {
            string p1 = "+";
            string p2 = "+";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str.Length, Is.EqualTo(1));
        }
    }

    public class Basic10Test : CadenaComunMinimaTest
    {
        public void Basic10()
        {
            string p1 = "abt+";
            string p2 = "abp*?";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str, Is.Null);
        }
    }

    public class Basic11Test : CadenaComunMinimaTest
    {
        public void Basic11()
        {
            string p1 = "+qtyu";
            string p2 = "*?xtyu";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str, Is.Null);
        }
    }

    public class Basic12Test : CadenaComunMinimaTest
    {
        public void Basic12()
        {
            string p1 = "+ab?";
            string p2 = "*?acq";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str, Is.Null);
        }
    }

    public class Basic13Test : CadenaComunMinimaTest
    {
        public void Basic13()
        {
            string p1 = "+ab+";
            string p2 = "??act";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str, Is.Null);
        }
    }

    public class Basic14Test : CadenaComunMinimaTest
    {
        public void Basic14()
        {
            string p1 = "zdf+ab?";
            string p2 = "??ac+";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str, Is.Null);
        }
    }

    public class Basic15Test : CadenaComunMinimaTest
    {
        public void Basic15()
        {
            string p1 = "+ab";
            string p2 = "ab+";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str.Length, Is.EqualTo(4));
        }
    }

    public class Basic16Test : CadenaComunMinimaTest
    {
        public void Basic16()
        {
            string p1 = "+ab*";
            string p2 = "*ab+";
            string str = Student(p1, p2, Alphabet);

            Check(p1, p2, Alphabet, str);
            Assert.That(str.Length, Is.EqualTo(4));
        }
    }
}
