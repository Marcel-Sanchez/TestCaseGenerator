using System;
using System.Collections.Generic;

namespace Weboo.Assess.Tester
{
    public static class Each
    {
        public static IAssertion ElementIn<T>(IEnumerable<T> sequence, IAssertion<T> assertion)
        {
            if (sequence == null)
                throw new ArgumentNullException("sequence");

            if (assertion == null)
                throw new ArgumentNullException("assertion");

            return new EachAssertion<T>(sequence, assertion);
        }

        private class EachAssertion<T> : IAssertion
        {
            private readonly IEnumerable<T> sequence;
            private readonly IAssertion<T> assertion;

            public EachAssertion(IEnumerable<T> sequence, IAssertion<T> assertion)
            {
                this.sequence = sequence;
                this.assertion = assertion;
            }

            public bool Assert()
            {
                foreach (var item in sequence)
                    if (!assertion.Assert(item))
                        return false;

                return true;
            }

            public override string ToString()
            {
                return string.Format("Each element in {0} {1}", Api.ToString(sequence), assertion);
            }
        }
    }
}