using System;
using System.Collections.Generic;


namespace Weboo.Assess.Tester
{
    public abstract class TestBuilder<T1, T2> : TestBuilder
    {
        protected BuilderMode Mode { get; set; }

        protected T1 CurrentArgument1 { get; private set; }
        protected T2 CurrentArgument2 { get; private set; }

        internal sealed override IEnumerable<TestCase> Build()
        {
            if (SeparatedCases)
            {
                foreach (var tuple in BuildInputs())
                    yield return new SingleTestCase(tuple.Item1, tuple.Item2, this);
            }
            else
            {
                yield return new MultipleTestCase(BuildInputs(), this);
            }
        }

        private IEnumerable<Tuple<T1, T2>> BuildInputs()
        {
            var arg1 = Argument1;
            var arg2 = Argument2;

            switch (Mode)
            {
                case BuilderMode.Sequential:
                    var iter1 = arg1.Build().GetEnumerator();
                    var iter2 = arg2.Build().GetEnumerator();

                    while (true)
                    {
                        if (!iter1.MoveNext()) break;
                        CurrentArgument1 = iter1.Current;

                        if (!iter2.MoveNext()) break;
                        CurrentArgument2 = iter2.Current;

                        yield return Tuple.Create(CurrentArgument1, CurrentArgument2);
                    }

                    break;
                case BuilderMode.Combinatorial:

                    var items1 = new List<T1>(arg1.Build());
                    var items2 = new List<T2>(arg2.Build());

                    foreach (var t1 in items1)
                    {
                        CurrentArgument1 = t1;
                        foreach (var t2 in items2)
                        {
                            CurrentArgument2 = t2;
                            yield return Tuple.Create(t1, t2);
                        }
                    }

                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }

            CurrentArgument1 = default(T1);
            CurrentArgument2 = default(T2);
        }

        protected abstract void Test(T1 a, T2 b);

        protected abstract IBuilder<T1> Argument1 { get; }

        protected abstract IBuilder<T2> Argument2 { get; }

        private class SingleTestCase : TestCase
        {
            private readonly T1 input1;
            private readonly T2 input2;
            private readonly TestBuilder<T1, T2> parent;

            public SingleTestCase(T1 input1, T2 input2, TestBuilder<T1, T2> parent)
            {
                this.input1 = input1;
                this.input2 = input2;
                this.parent = parent;
            }

            public void Test()
            {
                parent.Test(input1, input2);
            }
        }

        private class MultipleTestCase : TestCase
        {
            private readonly IEnumerable<Tuple<T1, T2>> inputs;
            private readonly TestBuilder<T1, T2> parent;

            public MultipleTestCase(IEnumerable<Tuple<T1, T2>> inputs, TestBuilder<T1, T2> parent)
            {
                this.inputs = inputs;
                this.parent = parent;
            }

            public void Test()
            {
                foreach (var input in inputs)
                {
                    parent.Test(input.Item1, input.Item2);
                }
            }
        }
    }
}