namespace Weboo.Assess.Tester
{
    internal class NegateAssertion<T> : IAssertion<T>
    {
        protected readonly IAssertion<T> InnerAssertion;

        protected NegateAssertion(IAssertion<T> innerAssertion)
        {
            this.InnerAssertion = innerAssertion;
        }

        public virtual bool Assert(T item)
        {
            return !InnerAssertion.Assert(item);
        }
    }
}