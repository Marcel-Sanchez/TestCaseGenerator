using System;
using System.Collections.Generic;

namespace Weboo.Assess.Tester
{
    [Serializable]
    public class TestSuiteResult
    {
        private  int passedTests;
        private  int totalTests;
        private  int score;
        private  int maxScore;

        private readonly List<TestCaseResult> cases;

        public TestSuiteResult(int passedTests, int totalTests, int score, int maxScore, List<TestCaseResult> cases)
        {
            this.passedTests = passedTests;
            this.totalTests = totalTests;
            this.score = score;
            this.maxScore = maxScore;
            this.cases = cases;
        }

        public TestSuiteResult()
        {
            cases = new List<TestCaseResult>();
        }

        public void Add(TestCaseResult result)
        {
            passedTests += result.PassedTests;
            totalTests += result.TotalTests;
            score += result.PassedTests * result.Weight;
            maxScore += result.TotalTests * result.Weight;

            cases.Add(result);
        }

        public IEnumerable<TestCaseResult> TestCases
        {
            get { return cases; }
        } 

        public int PassedTests
        {
            get { return passedTests; }
        }

        public int TotalTests
        {
            get { return totalTests; }
        }

        public int Score
        {
            get { return score; }
        }

        public int MaxScore
        {
            get { return maxScore; }
        }

        public double Percentage { get { return Score * 100.0 / MaxScore; } }

        public int CasesCount { get { return cases.Count; } }

        public override string ToString()
        {
            int maxScoreDigits = (int)Math.Floor(Math.Log10(MaxScore)) + 1;
            int scoreDigits = (int)Math.Floor(Math.Log10(Math.Max(Score, 1))) + 1;
            int zeros = maxScoreDigits - scoreDigits;
            return $"{new string('0', zeros)}{Score}/{MaxScore} ({Percentage:00.00}%)";
        }
    }
}
