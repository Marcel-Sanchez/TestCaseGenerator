using System;
using System.Collections.Generic;
using System.Linq;

namespace Weboo.Assess.Tester
{
    public class ArrayBuilder<T> : IBuilder<T[]>
    {
        private int _minLength = 0;
        private int _maxLength = 10;
        private T[] _selection = { default(T) };
        private bool _exahustive;
        private int _cases = 1;
        private Func<int> _specificLength;
        private Func<T[], int, bool> _predicate;
        private bool _earlyCut;

        public ArrayBuilder<T> WithMinLengthOf(int count)
        {
            _minLength = count;
            return this;
        }

        public ArrayBuilder<T> WithMaxLengthOf(int count)
        {
            _maxLength = count;
            return this;
        }

        public ArrayBuilder<T> WithElementsFrom(params T[] elements)
        {
            _selection = elements;
            return this;
        }

        public ArrayBuilder<T> WithElementsFrom(IEnumerable<T> elements)
        {
            _selection = elements.ToArray();
            return this;
        }

        public ArrayBuilder<T> WithSpecificLength(Func<int> length)
        {
            if (length == null) throw new ArgumentNullException("length");
            _specificLength = length;
            return this;
        }

        public ArrayBuilder<T> Random(int count)
        {
            _exahustive = false;
            _cases = count;
            return this;
        }

        public ArrayBuilder<T> Exhaustive()
        {
            _exahustive = true;
            return this;
        }

        public ArrayBuilder<T> WithEarlyCut()
        {
            this._earlyCut = true;
            return this;
        }

        public ArrayBuilder<T> SuchThat(Func<T[], int, bool> predicate)
        {
            this._predicate = predicate;
            return this;
        }

        IEnumerable<T[]> IBuilder<T[]>.Build()
        {
            int total = 0;

            if (_exahustive)
            {

            }
            else
            {
                while (total < _cases)
                {
                    int length = _specificLength == null ? Api.Random.Next(_minLength, _maxLength + 1) : _specificLength();
                    var input = new T[length];

                    for (int i = 0; i < input.Length; i++)
                    {
                        if (_predicate != null && _earlyCut && !_predicate(input, i))
                            break;

                        input[i] = _selection[Api.Random.Next(_selection.Length)];
                    }

                    if (_predicate == null || _predicate(input, input.Length))
                    {
                        total++;
                        yield return input;
                    }
                }
            }
        }

        public T[] Next()
        {
            throw new NotImplementedException();
        }
    }
}
