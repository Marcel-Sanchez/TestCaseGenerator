using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading;

namespace Weboo.Assess.Tester
{
    public abstract class TestCase
    {
        internal static TestCase CurrentTest;

        internal List<string> PassedAssertions;
        internal List<string> FailedAssertions;

        public int Timeout = 10000;

        public int Weight { get; set; }

        protected TestCase()
        {
            Weight = 1;
        }

        protected virtual void SetUp()
        {

        }

        protected virtual void SetUpClass()
        {

        }

        protected virtual void TearDown()
        {

        }

        protected virtual void TearDownClass()
        {

        }

        internal TestCaseResult Run()
        {
            Api.Seed(0);

            if (CurrentTest != null)
                throw new InvalidOperationException("TestCases cannot be run concurrently!");

            CurrentTest = this;
            PassedAssertions = new List<string>();
            FailedAssertions = new List<string>();

            int totalTests = 0;
            int passedTests = 0;

            SetUpClass();

            foreach (var methodInfo in GetType().GetMethods())
            {
                if (methodInfo.ReturnType == typeof(void) && methodInfo.GetParameters().Length == 0)
                {
                    MethodInfo info = methodInfo;

                    var attr = info.GetCustomAttribute<WeightedCaseAttribute>();
                    int weight = attr != null ? attr.Weight : 1;

                    var thread = new Thread(o =>
                    {
                        try
                        {
                            SetUp();

                            totalTests += weight;
                            info.Invoke(this, null);
                            passedTests += weight;
                        }
                        catch (TargetInvocationException e)
                        {
                            if (e.InnerException is AssertionFailedException)
                                FailedAssertions.Add($"(x{weight}) [{info.Name}] {(e.InnerException as AssertionFailedException).Assertion}");
                            else
                            {
                                var excp = e.InnerException;

                                while (excp is TargetInvocationException)
                                    excp = excp.InnerException;

                                FailedAssertions.Add($"(x{weight}) [{info.Name}] {excp.Message}");
                            }
                        }
                        finally
                        {
                            TearDown();
                        }
                    });

                    thread.IsBackground = true;
                    thread.Start();

                    if (Timeout > 0 && !thread.Join(Timeout))
                    {
                        thread.Abort();
                        FailedAssertions.Add($"(x{weight}) [{info.Name}] Timeout ({Timeout})");
                    }
                    else
                    {
                        thread.Join();
                    }
                }
            }

            TearDownClass();

            CurrentTest = null;

            return new TestCaseResult(Weight, passedTests, totalTests, PassedAssertions, FailedAssertions);
        }

        internal void FailCurrentTest(string assertion)
        {
            throw new AssertionFailedException(assertion);
        }
    }

    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false)]
    public class WeightedCaseAttribute : Attribute
    {
        public int Weight { get; private set; }

        public WeightedCaseAttribute(int weight)
        {
            Weight = weight;
        }
    }
}
