using System;
using System.Linq;
using System.Reflection;

namespace Weboo.Assess.Tester
{
    public static class ReflectionHelper
    {
        public static Assembly ReflectiveAssembly;

        public static dynamic CreateDynamicInstance(string typeName, params object[] args)
        {
            foreach (var type in ReflectiveAssembly.GetTypes())
                if (type.FullName.Equals(typeName))
                    return Activator.CreateInstance(type, args);

            throw new InvalidOperationException("No matching type was found");
        }

        public static dynamic CreateDynamicInstance<T>(string typeName, params object[] args)
        {
            foreach (var type in ReflectiveAssembly.GetTypes())
            {
                var fullName = type.FullName;

                if (fullName.Contains("`"))
                    fullName = fullName.Remove(fullName.IndexOf("`", StringComparison.Ordinal));

                if (fullName.Equals(typeName) && type.IsGenericTypeDefinition)
                    return Activator.CreateInstance(type.MakeGenericType(typeof(T)), args);
            }

            throw new InvalidOperationException("No matching type was found");
        }

        public static R InvokeStatic<R>(string className, string methodName, params object[] args)
        {
            if (ReflectiveAssembly == null)
                throw new InvalidOperationException("ReflectiveAssembly cannot be null.");

            var type = ReflectiveAssembly.GetType(className);
            if (type == null) throw new ArgumentException("The type was not found in the assembly.");

            var method = type.GetMethod(methodName, args.Select(a => a.GetType()).ToArray());
            if (method == null) throw new ArgumentException("The method was not found in the assembly.");

            var result = method.Invoke(null, args);

            return (R)result;
        }

        public static R InvokeStatic<R>(string className, Type[] classTypeArguments, string methodName, params object[] args)
        {
            if (ReflectiveAssembly == null)
                throw new InvalidOperationException("ReflectiveAssembly cannot be null.");

            var type = ReflectiveAssembly.GetTypes()
                .FirstOrDefault(m => m.FullName.StartsWith(className) && m.GetGenericArguments().Length == classTypeArguments.Length);
            if (type == null) throw new ArgumentException("The type was not found in the assembly.");

            var method = type.MakeGenericType(classTypeArguments)
                .GetMethod(methodName, args.Select(a => a.GetType()).ToArray());
            if (method == null) throw new ArgumentException("The method was not found in the assembly.");

            var result = method.Invoke(null, args);

            return (R)result;
        }

        public static R InvokeStatic<R, T>(string className, string methodName, params object[] args)
        {
            if (ReflectiveAssembly == null)
                throw new InvalidOperationException("ReflectiveAssembly cannot be null.");

            var type = ReflectiveAssembly.GetType(className);
            if (type == null) throw new ArgumentException("The type was not found in the assembly.");

            foreach (var method in type.GetMethods())
            {
                if (method.Name == methodName && method.IsGenericMethodDefinition && method.GetGenericArguments().Length == 1)
                {
                    try
                    {
                        var builtMethod = method.MakeGenericMethod(new[] {typeof (T)});
                        return (R) builtMethod.Invoke(null, args);
                    }
                    catch (TargetInvocationException e)
                    {
                        throw e.InnerException;
                    }
                    catch (Exception)
                    {
                        continue;
                    }
                } 
            }

            throw new ArgumentException("The method was not found in the assembly.");
        }

        public static T CreateInstance<T>(params object[] args)
        {
            if (ReflectiveAssembly == null)
                throw new InvalidOperationException("ReflectiveAssembly cannot be null.");

            if (typeof(T).IsGenericType)
            {
                var baseType = typeof(T).GetGenericTypeDefinition();

                if (typeof(T).IsInterface)
                {
                    foreach (var type in ReflectiveAssembly.GetTypes())
                        foreach (var inter in type.GetInterfaces())
                            if (inter.GUID == baseType.GUID)
                                return (T)Activator.CreateInstance(type.MakeGenericType(typeof(T).GetGenericArguments()), args);
                }
                else
                {
                    foreach (var type in ReflectiveAssembly.GetTypes())
                        if (baseType.IsAssignableFrom(type))
                            return (T)Activator.CreateInstance(type.MakeGenericType(typeof(T).GetGenericArguments()), args);
                }
            }
            else
            {
                foreach (var type in ReflectiveAssembly.GetTypes())
                    if (typeof(T).IsAssignableFrom(type))
                        return (T)Activator.CreateInstance(type, args);
            }

            throw new InvalidOperationException("No matching type was found");
        }
    }
}
