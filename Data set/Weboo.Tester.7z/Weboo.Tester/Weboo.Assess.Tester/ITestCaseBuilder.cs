namespace Weboo.Assess.Tester
{
    public interface ITestCaseBuilder<T>
    {
        void Apply(ref T item);
    }
}