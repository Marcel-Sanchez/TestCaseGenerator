using System;
using System.Collections.Generic;


namespace Weboo.Assess.Tester
{
    public static class Some
    {
        public static IAssertion ElementIn<T>(IEnumerable<T> sequence, IAssertion<T> assertion)
        {
            if (sequence == null)
                throw new ArgumentNullException("sequence");

            if (assertion == null)
                throw new ArgumentNullException("assertion");

            return new AnyAssertion<T>(sequence, assertion);
        }

        private class AnyAssertion<T> : IAssertion
        {
            private readonly IEnumerable<T> sequence;
            private readonly IAssertion<T> assertion;

            public AnyAssertion(IEnumerable<T> sequence, IAssertion<T> assertion)
            {
                this.sequence = sequence;
                this.assertion = assertion;
            }

            public bool Assert()
            {
                foreach (var item in sequence)
                    if (assertion.Assert(item))
                        return true;

                return false;
            }

            public override string ToString()
            {
                return string.Format("Some element in {0} {1}", Api.ToString(sequence), assertion);
            }
        }
    }
}