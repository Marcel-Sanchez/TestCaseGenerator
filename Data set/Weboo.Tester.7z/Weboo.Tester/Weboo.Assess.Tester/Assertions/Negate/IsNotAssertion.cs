﻿namespace Weboo.Assess.Tester.Assertions.Negate
{
    internal class IsNotAssertion<T> : NegateAssertion<T>
    {
        public IsNotAssertion(IAssertion<T> innerAssertion) : base(innerAssertion) { }

        public override string ToString()
        {
            return "is not" + InnerAssertion.ToString().Substring(2);
        }
    }
}
