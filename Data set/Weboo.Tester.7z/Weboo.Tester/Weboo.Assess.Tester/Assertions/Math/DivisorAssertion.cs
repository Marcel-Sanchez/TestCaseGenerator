﻿namespace Weboo.Assess.Tester.Assertions.Math
{
    internal sealed class DivisorAssertion : IAssertion<int>
    {
        private readonly int _n;

        public DivisorAssertion(int n)
        {
            _n = n;
        }

        public bool Assert(int item)
        {
            return _n % item == 0;
        }

        public override string ToString()
        {
            return "is divisor of " + _n;
        }
    }
}
