﻿namespace Weboo.Assess.Tester.Assertions.Math
{
    internal sealed class CongruentAssertion : IAssertion<int>
    {
        private readonly int _n;
        private readonly int _mod;

        public CongruentAssertion(int n, int mod)
        {
            _n = n;
            _mod = mod;
        }

        public bool Assert(int item)
        {
            return item % _mod == _n % _mod;
        }

        public override string ToString()
        {
            return $"is congruent with {_n} (mod {_mod})";
        }
    }
}
