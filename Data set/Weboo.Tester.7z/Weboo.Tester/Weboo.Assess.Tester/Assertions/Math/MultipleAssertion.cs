﻿namespace Weboo.Assess.Tester.Assertions.Math
{
    internal sealed class MultipleAssertion : IAssertion<int>
    {
        private readonly int _n;

        public MultipleAssertion(int n)
        {
            _n = n;
        }

        public bool Assert(int item)
        {
            return item % _n == 0;
        }

        public override string ToString()
        {
            return "is multiple of " + _n;
        }
    }
}
