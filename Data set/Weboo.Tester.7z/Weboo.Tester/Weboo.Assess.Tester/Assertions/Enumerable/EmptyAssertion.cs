﻿using System.Collections;

namespace Weboo.Assess.Tester.Assertions.Enumerable
{
    internal sealed class EmptyAssertion : IAssertion<IEnumerable>
    {
        public bool Assert(IEnumerable item)
        {
            return !item.GetEnumerator().MoveNext();
        }

        public override string ToString()
        {
            return "is empty";
        }
    }
}
