﻿using System.Collections.Generic;
using System.Linq;

namespace Weboo.Assess.Tester.Assertions.Enumerable
{
    internal sealed class InAssertion<T> : IAssertion<T>
    {
        private readonly IEnumerable<T> _sequence;
        private readonly IEqualityComparer<T> _equalityComparer;

        public InAssertion(IEnumerable<T> sequence, IEqualityComparer<T> equalityComparer)
        {
            _sequence = sequence;
            _equalityComparer = equalityComparer ?? EqualityComparer<T>.Default;
        }

        public bool Assert(T item)
        {
            return _sequence.Contains(item, _equalityComparer);
        }

        public override string ToString()
        {
            return $"is in {Api.ToString(_sequence)}";
        }
    }
}
