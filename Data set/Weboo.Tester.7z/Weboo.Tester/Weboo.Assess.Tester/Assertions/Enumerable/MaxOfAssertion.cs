﻿using System.Collections.Generic;
using System.Linq;

namespace Weboo.Assess.Tester.Assertions.Enumerable
{
    internal sealed class MaxOfAssertion<T> : IAssertion<T>
    {
        private readonly IEnumerable<T> _items;

        public MaxOfAssertion(IEnumerable<T> items)
        {
            _items = items;
        }

        public bool Assert(T item)
        {
            return Equals(item, _items.Max());
        }

        public override string ToString()
        {
            return $"is max of {Api.ToString(_items)}";
        }
    }
}
