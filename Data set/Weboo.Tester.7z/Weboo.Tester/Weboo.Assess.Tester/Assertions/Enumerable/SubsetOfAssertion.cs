﻿using System.Collections.Generic;

namespace Weboo.Assess.Tester.Assertions.Enumerable
{
    internal sealed class SubsetOfAssertion<T> : IAssertion<IEnumerable<T>>
    {
        private readonly HashSet<T> _parent;
        private readonly IEqualityComparer<T> _equalityComparer;

        public SubsetOfAssertion(IEnumerable<T> parent, IEqualityComparer<T> equalityComparer)
        {
            _equalityComparer = equalityComparer ?? EqualityComparer<T>.Default;
            _parent = new HashSet<T>(parent, _equalityComparer);
        }

        public bool Assert(IEnumerable<T> item)
        {
            if (_parent == null)
                return item == null;
            if (item == null)
                return false;


            foreach (var x in item)
            {
                if (!_parent.Contains(x))
                    return false;
            }

            return true;
        }

        public override string ToString()
        {
            return $"is subset of {Api.ToString(_parent)}";
        }
    }
}
