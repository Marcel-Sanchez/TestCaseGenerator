﻿using System.Collections.Generic;

namespace Weboo.Assess.Tester.Assertions.Enumerable
{
    internal sealed class SupersetOfAssertion<T> : IAssertion<IEnumerable<T>>
    {
        private readonly IEnumerable<T> _children;
        private readonly IEqualityComparer<T> _equalityComparer;

        public SupersetOfAssertion(IEnumerable<T> children, IEqualityComparer<T> equalityComparer)
        {
            _children = children;
            _equalityComparer = equalityComparer ?? EqualityComparer<T>.Default;
        }

        public bool Assert(IEnumerable<T> item)
        {
            if (_children == null)
                return item == null;
            if (item == null)
                return false;

            var parent = new HashSet<T>(item, _equalityComparer);

            foreach (var x in _children)
            {
                if (!parent.Contains(x))
                    return false;
            }

            return true;
        }

        public override string ToString()
        {
            return $"is superset of {Api.ToString(_children)}";
        }
    }
}
