﻿using System.Collections.Generic;
using System.Linq;

namespace Weboo.Assess.Tester.Assertions.Enumerable
{
    internal sealed class MultisetEqualToAssertion<T> : IAssertion<IEnumerable<T>>
    {
        private readonly IEnumerable<T> _parent;
        private readonly IEqualityComparer<T> _equalityComparer;

        public MultisetEqualToAssertion(IEnumerable<T> parent, IEqualityComparer<T> equalityComparer)
        {
            _parent = parent;
            _equalityComparer = equalityComparer ?? EqualityComparer<T>.Default;
        }

        public bool Assert(IEnumerable<T> item)
        {
            if (_parent == null)
                return item == null;
            if (item == null)
                return false;

            var expected = _parent
                .GroupBy(m => m)
                .ToDictionary(m => m.Key, m => m.Count(), _equalityComparer);

            var result = item
                .GroupBy(m => m)
                .ToDictionary(m => m.Key, m => m.Count(), _equalityComparer);

            if (expected.Count != result.Count)
                return false;

            foreach (var kvp in result)
            {
                if (!expected.TryGetValue(kvp.Key, out int count) || count != kvp.Value)
                    return false;
            }

            return true;
        }

        public override string ToString()
        {
            return "is set equal to " + Api.ToString(_parent);
        }
    }
}
