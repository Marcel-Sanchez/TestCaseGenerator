﻿using System.Collections.Generic;

namespace Weboo.Assess.Tester.Assertions.Enumerable
{
    internal sealed class SequenceEqualToAssertion<T> : IAssertion<IEnumerable<T>>
    {
        private readonly IEnumerable<T> _parent;
        private readonly IEqualityComparer<T> _equalityComparer;

        public SequenceEqualToAssertion(IEnumerable<T> parent, IEqualityComparer<T> equalityComparer)
        {
            _parent = parent;
            _equalityComparer = equalityComparer ?? EqualityComparer<T>.Default;
        }

        public bool Assert(IEnumerable<T> item)
        {
            if (_parent == null)
                return item == null;
            if (item == null)
                return false;

            var e1 = item.GetEnumerator();
            var e2 = _parent.GetEnumerator();

            while (true)
            {
                bool moveNext1 = e1.MoveNext();
                bool moveNext2 = e2.MoveNext();

                if (moveNext1 != moveNext2)
                    return false;

                if (!moveNext1)
                    return true;

                if (!_equalityComparer.Equals(e1.Current, e2.Current))
                    return false;
            }
        }

        public override string ToString()
        {
            return $"is sequence equal to {Api.ToString(_parent)}";
        }
    }
}
