﻿using System.Collections.Generic;
using System.Linq;

namespace Weboo.Assess.Tester.Assertions.Enumerable
{
    internal sealed class MinOfAssertion<T> : IAssertion<T>
    {
        private readonly IEnumerable<T> _items;

        public MinOfAssertion(IEnumerable<T> items)
        {
            _items = items;
        }

        public bool Assert(T item)
        {
            return Equals(item, _items.Min());
        }

        public override string ToString()
        {
            return "is min of " + Api.ToString(_items);
        }
    }
}
