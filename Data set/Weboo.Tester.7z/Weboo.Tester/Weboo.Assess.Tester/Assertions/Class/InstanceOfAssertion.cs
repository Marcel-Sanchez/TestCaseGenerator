﻿namespace Weboo.Assess.Tester.Assertions.Class
{
    internal sealed class InstanceOfAssertion<T> : IAssertion<object>
    {
        public bool Assert(object item)
        {
            return item is T;
        }

        public override string ToString()
        {
            return "is instance of " + Api.ToString(typeof(T));
        }
    }
}
