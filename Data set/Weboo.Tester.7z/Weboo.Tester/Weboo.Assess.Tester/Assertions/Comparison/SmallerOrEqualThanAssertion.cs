﻿using System;

namespace Weboo.Assess.Tester.Assertions.Comparison
{
    internal sealed class SmallerOrEqualThanAssertion<T> : IAssertion<T> where T : IComparable<T>
    {
        private readonly T _other;

        public SmallerOrEqualThanAssertion(T other)
        {
            _other = other;
        }

        public bool Assert(T item)
        {
            return item.CompareTo(_other) <= 0;
        }

        public override string ToString()
        {
            return "is smaller or equal than " + Api.ToString(_other);
        }
    }
}
