﻿using System;

namespace Weboo.Assess.Tester.Assertions.Comparison
{
    internal sealed class SmallerThanAssertion<T> : IAssertion<T> where T : IComparable<T>
    {
        private readonly T _other;

        public SmallerThanAssertion(T other)
        {
            _other = other;
        }

        public bool Assert(T item)
        {
            return item.CompareTo(_other) < 0;
        }

        public override string ToString()
        {
            return "is smaller than " + Api.ToString(_other);
        }
    }
}
