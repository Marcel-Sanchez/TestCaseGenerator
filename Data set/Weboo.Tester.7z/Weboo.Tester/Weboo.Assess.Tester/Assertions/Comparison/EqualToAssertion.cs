﻿using System.Collections.Generic;

namespace Weboo.Assess.Tester.Assertions.Comparison
{
    internal sealed class EqualToAssertion<T> : IAssertion<T>
    {
        private readonly T _other;
        private readonly IEqualityComparer<T> _equalityComparer;

        public EqualToAssertion(T other, IEqualityComparer<T> equalityComparer)
        {
            _other = other;
            _equalityComparer = equalityComparer ?? EqualityComparer<T>.Default;
        }

        public bool Assert(T item)
        {
            return _equalityComparer.Equals(item, _other);
        }

        public override string ToString()
        {
            return $"is equal to {Api.ToString(_other)}(Expected)";
        }
    }
}
