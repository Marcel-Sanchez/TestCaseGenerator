﻿using System;

namespace Weboo.Assess.Tester.Assertions.Comparison
{
    internal sealed class EqualToDoubleAssertion : IAssertion<double>
    {
        private readonly double _value;
        private readonly double _error;

        public EqualToDoubleAssertion(double value, double error)
        {
            _value = value;
            _error = error;
        }

        public bool Assert(double item)
        {
            return System.Math.Abs(item - _value) < _error;
        }

        public override string ToString()
        {
            return "is equal (within " + Api.ToString(_error) + ") to " + Api.ToString(_value);
        }
    }
}
