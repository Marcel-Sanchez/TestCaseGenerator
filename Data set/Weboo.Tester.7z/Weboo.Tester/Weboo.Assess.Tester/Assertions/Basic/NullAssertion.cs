﻿namespace Weboo.Assess.Tester.Assertions.Basic
{
    internal sealed class NullAssertion : IAssertion<object>
    {
        public bool Assert(object item)
        {
            return ReferenceEquals(item, null);
        }

        public override string ToString()
        {
            return "is null";
        }
    }
}
