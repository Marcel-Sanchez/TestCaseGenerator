﻿namespace Weboo.Assess.Tester.Assertions.Basic
{
    internal sealed class FalseAssertion : IAssertion<bool>
    {
        public bool Assert(bool item)
        {
            // I prefer to make this explicit here, rather than just `return !item`.
            return item == false;
        }

        public override string ToString()
        {
            return "is false";
        }
    }
}
