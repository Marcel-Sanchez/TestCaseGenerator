using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;


namespace Weboo.Assess.Tester
{
    public class TestSuite : IEnumerable<TestCase>
    {
        private readonly List<TestCase> testCases;

        public TestSuite()
        {
            testCases = new List<TestCase>();
        }

        public IEnumerable<TestCase> Cases
        {
            get
            {
                return testCases;
            }
        }

        public int CasesCount { get { return testCases.Count; } }

        public void Add(TestCase testCase)
        {
            testCases.Add(testCase);
        }

        public TestCaseResult Run(int testCase)
        {
            return testCases[testCase].Run();
        }

        public TestSuiteResult Run()
        {
            var result = new TestSuiteResult();

            foreach (var testCase in testCases)
                result.Add(testCase.Run());

            return result;
        }

        public override string ToString()
        {
            return string.Join("\n", testCases.Select(t => t.ToString()).ToArray());
        }

        public IEnumerator<TestCase> GetEnumerator()
        {
            return testCases.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public static TestSuite AutoDiscover()
        {
            return AutoDiscover(Assembly.GetCallingAssembly());
        }

        public static TestSuite AutoDiscover(params Assembly[] assemblies)
        {
            var suite = new TestSuite();

            foreach (var assembly in assemblies)
                foreach (var type in assembly.GetTypes())
                    if (type.IsSubclassOf(typeof(TestCase)) && !type.IsAbstract)
                        suite.Add((TestCase)Activator.CreateInstance(type));
                    else if (type.IsSubclassOf(typeof(TestBuilder)))
                        foreach (var testCase in ((TestBuilder)Activator.CreateInstance(type)).Build())
                            suite.Add(testCase);

            return suite;
        }
    }
}