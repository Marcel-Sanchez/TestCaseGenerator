using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;


namespace Weboo.Assess.Tester
{
    public static partial class Has
    {
        #region Enumerable Assertions

        private sealed class ItemAssertion<T> : IAssertion<IEnumerable<T>>
        {
            private readonly T item;

            public ItemAssertion(T item)
            {
                this.item = item;
            }

            public bool Assert(IEnumerable<T> sequence)
            {
                return sequence.Contains(item);
            }

            public override string ToString()
            {
                return "has item " + Api.ToString(item);
            }
        }

        private sealed class AnyOfAssertion<T> : IAssertion<IEnumerable<T>>
        {
            private readonly IEnumerable<T> items;

            public AnyOfAssertion(IEnumerable<T> items)
            {
                this.items = items;
            }

            public bool Assert(IEnumerable<T> sequence)
            {
                var set = new HashSet<T>(sequence);

                foreach (var item in items)
                    if (set.Contains(item))
                        return true;

                return false;
            }

            public override string ToString()
            {
                return "has any of " + Api.ToString(items);
            }
        }

        private sealed class AllOfAssertion<T> : IAssertion<IEnumerable<T>>
        {
            private readonly IEnumerable<T> items;

            public AllOfAssertion(IEnumerable<T> items)
            {
                this.items = items;
            }

            public bool Assert(IEnumerable<T> sequence)
            {
                var set = new HashSet<T>(sequence);

                foreach (var item in items)
                    if (!set.Contains(item))
                        return false;

                return true;
            }

            public override string ToString()
            {
                return "has all of " + Api.ToString(items);
            }
        }

        private sealed class NoneOfAssertion<T> : IAssertion<IEnumerable<T>>
        {
            private readonly IEnumerable<T> items;

            public NoneOfAssertion(IEnumerable<T> items)
            {
                this.items = items;
            }

            public bool Assert(IEnumerable<T> sequence)
            {
                var set = new HashSet<T>(sequence);

                foreach (var item in items)
                    if (set.Contains(item))
                        return false;

                return true;
            }

            public override string ToString()
            {
                return "has none of " + Api.ToString(items);
            }
        }

        private sealed class CountAssertion : IAssertion<IEnumerable>
        {
            private readonly int count;

            public CountAssertion(int count)
            {
                this.count = count;
            }

            public bool Assert(IEnumerable item)
            {
                var array = item as Array;
                if (array != null) return array.Length == count;

                var collection = item as ICollection;
                if (collection != null) return collection.Count == count;

                return item.Cast<object>().Count() == count;
            }

            public override string ToString()
            {
                return "has count " + count;
            }
        }

        #endregion

        #region Negate

        private static HasNotAssertion<T> Negate<T>(IAssertion<T> assertion)
        {
            return new HasNotAssertion<T>(assertion);
        }

        private sealed class HasNotAssertion<T> : NegateAssertion<T>
        {
            public HasNotAssertion(IAssertion<T> innerAssertion) : base(innerAssertion) { }

            public override string ToString()
            {
                return "has not" + InnerAssertion.ToString().Substring(3);
            }
        }

        #endregion
    }
}