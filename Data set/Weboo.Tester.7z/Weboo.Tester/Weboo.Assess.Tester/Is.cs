using System;
using System.Collections;
using System.Collections.Generic;
using Weboo.Assess.Tester.Assertions.Basic;
using Weboo.Assess.Tester.Assertions.Class;
using Weboo.Assess.Tester.Assertions.Comparison;
using Weboo.Assess.Tester.Assertions.Enumerable;
using Weboo.Assess.Tester.Assertions.Math;
using Weboo.Assess.Tester.Assertions.Negate;

namespace Weboo.Assess.Tester
{
    /// <summary>
    /// Contains methods to build generic assertions about an object.
    /// </summary>
    public static class Is
    {
        #region Basic Assertions

        /// <summary>
        /// Asserts that a boolean value is True.
        /// </summary>
        public static IAssertion<bool> True
        {
            get { return new TrueAssertion(); }
        }

        /// <summary>
        /// Asserts that a boolean value is False.
        /// </summary>
        public static IAssertion<bool> False
        {
            get { return new FalseAssertion(); }
        }

        /// <summary>
        /// Asserts that an object is null.
        /// </summary>
        public static IAssertion<object> Null
        {
            get { return new NullAssertion(); }
        }

        #endregion

        #region Comparison Assertions

        /// <summary>
        /// Asserts that an object is equal to another.
        /// </summary>
        /// <typeparam name="T">The type of the objects to compare.</typeparam>
        /// <param name="other">The other object with whom to compare.</param>
        /// <returns>An assertion of equality.</returns>
        public static IAssertion<T> EqualTo<T>(T other, IEqualityComparer<T> equalityComparer = null)
        {
            return new EqualToAssertion<T>(other, equalityComparer);
        }

        internal static IAssertion<IEnumerable> Negate(IAssertion<IEnumerable> empty)
        {
            throw new NotImplementedException();
        }

        public static IAssertion<double> EqualTo(double other, double error)
        {
            return new EqualToDoubleAssertion(other, error);
        }

        /// <summary>
        /// Asserts that an object is greater than other.
        /// </summary>
        /// <typeparam name="T">The type of the objects to compare.</typeparam>
        /// <param name="other">The other object with whom to compare.</param>
        /// <returns>An assertion of comparison.</returns>
        public static IAssertion<T> GreaterThan<T>(T other) where T : IComparable<T>
        {
            return new GreaterThanAssertion<T>(other);
        }

        /// <summary>
        /// Asserts that an object is smaller than other.
        /// </summary>
        /// <typeparam name="T">The type of the objects to compare.</typeparam>
        /// <param name="other">The other object with whom to compare.</param>
        /// <returns>An assertion of comparison.</returns>
        public static IAssertion<T> SmallerThan<T>(T other) where T : IComparable<T>
        {
            return new SmallerThanAssertion<T>(other);
        }

        /// <summary>
        /// Asserts that an object is greater than or equal to another.
        /// </summary>
        /// <typeparam name="T">The type of the objects to compare.</typeparam>
        /// <param name="other">The other object with whom to compare.</param>
        /// <returns>An assertion of comparison.</returns>
        public static IAssertion<T> GreaterOrEqualThan<T>(T other) where T : IComparable<T>
        {
            return new GreaterOrEqualThanAssertion<T>(other);
        }

        /// <summary>
        /// Asserts that an object is smaller than or equal to another.
        /// </summary>
        /// <typeparam name="T">The type of the objects to compare.</typeparam>
        /// <param name="other">The other object with whom to compare.</param>
        /// <returns>An assertion of comparison.</returns>
        public static IAssertion<T> SmallerOrEqualThan<T>(T other) where T : IComparable<T>
        {
            return new SmallerOrEqualThanAssertion<T>(other);
        }

        #endregion

        #region Enumerable Assertions

        /// <summary>
        /// Asserts that a sequence is empty.
        /// </summary>
        public static IAssertion<IEnumerable> Empty
        {
            get { return new EmptyAssertion(); }
        }

        public static IAssertion<IEnumerable<T>> Sorted<T>() where T : IComparable<T>
        {
            return null;
        }

        /// <summary>
        /// Asserts that a sequence is subset of another sequence.
        /// </summary>
        /// <typeparam name="T">The type of the elements of the sequences.</typeparam>
        /// <param name="sequence">The supposed superset sequence.</param>
        /// <returns>An assertion.</returns>
        public static IAssertion<IEnumerable<T>> SubsetOf<T>(IEnumerable<T> sequence, IEqualityComparer<T> equalityComparer = null)
        {
            return new SubsetOfAssertion<T>(sequence, equalityComparer);
        }

        /// <summary>
        /// Asserts that a sequence is superset of another sequence.
        /// </summary>
        /// <typeparam name="T">The type of the elements of the sequences.</typeparam>
        /// <param name="sequence">The supposed subset sequence.</param>
        /// <returns>An assertion.</returns>
        public static IAssertion<IEnumerable<T>> SupersetOf<T>(IEnumerable<T> sequence, IEqualityComparer<T> equalityComparer = null)
        {
            return new SupersetOfAssertion<T>(sequence, equalityComparer);
        }

        /// <summary>
        /// Asserts that a sequence is equal as a set to another sequence.
        /// </summary>
        /// <typeparam name="T">The type of the elements of the sequences.</typeparam>
        /// <param name="set">The supposed equal sequence.</param>
        /// <returns>An assertion.</returns>
        public static IAssertion<IEnumerable<T>> MultisetEqualTo<T>(IEnumerable<T> set, IEqualityComparer<T> equalityComparer = null)
        {
            return new MultisetEqualToAssertion<T>(set, equalityComparer);
        }

        public static IAssertion<IEnumerable<T>> SequenceEqualTo<T>(IEnumerable<T> sequence, IEqualityComparer<T> equalityComparer = null)
        {
            return new SequenceEqualToAssertion<T>(sequence, equalityComparer);
        }

        /// <summary>
        /// Asserts that an element is in a sequence.
        /// </summary>
        /// <typeparam name="T">The type of the element and the sequence.</typeparam>
        /// <param name="sequence">The supposedly containing sequence.</param>
        /// <returns>An assertion.</returns>
        public static IAssertion<T> In<T>(IEnumerable<T> sequence, IEqualityComparer<T> equalityComparer = null)
        {
            return new InAssertion<T>(sequence, equalityComparer);
        }

        /// <summary>
        /// Asserts that an element is in a sequence. This overload is a shortcut that
        /// accepts a sequence built with the <code>params</code> idiom.
        /// </summary>
        /// <typeparam name="T">The type of the element and the sequence.</typeparam>
        /// <param name="sequence">The supposedly containing sequence.</param>
        /// <returns>An assertion.</returns>
        public static IAssertion<T> OneOf<T>(IEqualityComparer<T> equalityComparer = null, params T[] sequence)
        {
            return new InAssertion<T>(sequence, equalityComparer);
        }

        public static IAssertion<T> MaxOf<T>(IEnumerable<T> items) where T : IComparable<T>
        {
            return new MaxOfAssertion<T>(items);
        }

        public static IAssertion<T> MaxOf<T>(params T[] items) where T : IComparable<T>
        {
            return new MaxOfAssertion<T>(items);
        }

        public static IAssertion<T> MinOf<T>(IEnumerable<T> items) where T : IComparable<T>
        {
            return new MinOfAssertion<T>(items);
        }

        public static IAssertion<T> MinOf<T>(params T[] items) where T : IComparable<T>
        {
            return new MinOfAssertion<T>(items);
        }

        #endregion

        #region Class Assertions

        /// <summary>
        /// Asserts that an object is instance of some type or interface.
        /// </summary>
        /// <typeparam name="T">The type to test for subtype.</typeparam>
        /// <returns>An assertion.</returns>
        public static IAssertion<object> InstanceOf<T>()
        {
            return new InstanceOfAssertion<T>();
        }

        #endregion

        #region Math Assertions

        public static IAssertion<int> DivisorOf(int n)
        {
            return new DivisorAssertion(n);
        }

        public static IAssertion<int> MultipleOf(int n)
        {
            return new MultipleAssertion(n);
        }

        public static IAssertion<int> CongruentWith(int n, int mod)
        {
            return new CongruentAssertion(n, mod);
        }

        #endregion

        /// <summary>
        /// Builds negative assertions.
        /// </summary>
        public static class Not
        {
            #region Basic Assertions

            public static IAssertion<bool> True
            {
                get { return Negate(Is.True); }
            }

            public static IAssertion<bool> False
            {
                get { return Negate(Is.False); }
            }

            public static IAssertion<object> Null
            {
                get { return Negate(Is.Null); }
            }

            #endregion

            #region Comparison Assertions

            public static IAssertion<T> EqualTo<T>(T item)
            {
                return Negate(Is.EqualTo(item));
            }

            public static IAssertion<double> EqualTo(double item, double error)
            {
                return Negate(Is.EqualTo(item, error));
            }

            public static IAssertion<T> GreaterThan<T>(T item) where T : IComparable<T>
            {
                return Negate(Is.GreaterThan(item));
            }

            public static IAssertion<T> SmallerThan<T>(T item) where T : IComparable<T>
            {
                return Negate(Is.SmallerThan(item));
            }

            public static IAssertion<T> GreaterOrEqualThan<T>(T item) where T : IComparable<T>
            {
                return Negate(Is.GreaterOrEqualThan(item));
            }

            public static IAssertion<T> SmallerOrEqualThan<T>(T item) where T : IComparable<T>
            {
                return Negate(Is.SmallerOrEqualThan(item));
            }

            #endregion

            #region Enumerable Assertions

            public static IAssertion<IEnumerable> Empty
            {
                get { return Negate(Is.Empty); }
            }

            public static IAssertion<IEnumerable<T>> SubsetOf<T>(IEnumerable<T> sequence)
            {
                return Negate(Is.SubsetOf(sequence));
            }

            public static IAssertion<IEnumerable<T>> SupersetOf<T>(IEnumerable<T> sequence)
            {
                return Negate(Is.SupersetOf(sequence));
            }

            public static IAssertion<IEnumerable<T>> SetEqualTo<T>(IEnumerable<T> set)
            {
                return Negate(Is.MultisetEqualTo(set));
            }

            public static IAssertion<IEnumerable<T>> SequenceEqualTo<T>(IEnumerable<T> sequence)
            {
                return Negate(Is.SequenceEqualTo(sequence));
            }

            public static IAssertion<T> In<T>(IEnumerable<T> sequence, IEqualityComparer<T> equalityComparer = null)
            {
                return Negate(Is.In(sequence, equalityComparer));
            }

            public static IAssertion<T> OneOf<T>(IEqualityComparer<T> equalityComparer = null, params T[] sequence)
            {
                return Negate(Is.In(sequence, equalityComparer));
            }

            public static IAssertion<T> MaxOf<T>(IEnumerable<T> sequence) where T : IComparable<T>
            {
                return Negate(Is.MaxOf(sequence));
            }

            public static IAssertion<T> MaxOf<T>(params T[] sequence) where T : IComparable<T>
            {
                return Negate(Is.MaxOf(sequence));
            }

            public static IAssertion<T> MinOf<T>(IEnumerable<T> sequence) where T : IComparable<T>
            {
                return Negate(Is.MinOf(sequence));
            }

            public static IAssertion<T> MinOf<T>(params T[] sequence) where T : IComparable<T>
            {
                return Negate(Is.MinOf(sequence));
            }

            #endregion

            #region Class Assertions 

            public static IAssertion<object> InstanceOf<T>()
            {
                return Negate(Is.InstanceOf<T>());
            }

            #endregion

            #region Math Assertions

            public static IAssertion<int> DivisorOf(int n)
            {
                return Negate(Is.DivisorOf(n));
            }

            public static IAssertion<int> MultipleOf(int n)
            {
                return Negate(Is.MultipleOf(n));
            }

            public static IAssertion<int> CongruentWith(int n, int mod)
            {
                return Negate(Is.CongruentWith(n, mod));
            }

            #endregion

            internal static IsNotAssertion<T> Negate<T>(IAssertion<T> assertion)
            {
                return new IsNotAssertion<T>(assertion);
            }
        }

        public static IAssertion<T> SuchThat<T>(Func<T, bool> func)
        {
            throw new NotImplementedException();
        }
    }
}
