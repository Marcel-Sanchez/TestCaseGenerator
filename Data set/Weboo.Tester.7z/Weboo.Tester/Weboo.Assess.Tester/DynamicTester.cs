﻿namespace Weboo.Assess.Tester
{
    public abstract class DynamicTester : InterfaceTester<dynamic>
    {
        
    }
}