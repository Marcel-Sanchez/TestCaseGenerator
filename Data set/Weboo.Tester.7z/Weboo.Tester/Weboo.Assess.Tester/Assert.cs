using System;

namespace Weboo.Assess.Tester
{
    /// <summary>
    /// Builds generic assertions for an object.
    /// </summary>
    public static class Assert
    {
        /// <summary>
        /// Builds a generic assertion for an specific object, together with the <see cref="Is"/> and <see cref="Has"/> static classes.
        /// </summary>
        /// <typeparam name="T">The type of the assertion.</typeparam>
        /// <param name="item">The about which to make the assertion.</param>
        /// <param name="assertion">The assertion construction. Use <see cref="Is"/> and <see cref="Has"/> for building assertions.</param>
        public static void That<T>(T item, IAssertion<T> assertion)
        {
            if (assertion == null)
                throw new ArgumentNullException("assertion");

            if (TestCase.CurrentTest == null)
                throw new InvalidOperationException("Assert.That can only be called inside a TestCase method!");

            string format = $"{Api.ToString(item)} {assertion}";

            if (assertion.Assert(item))
                TestCase.CurrentTest.PassedAssertions.Add(format);
            else
                TestCase.CurrentTest.FailCurrentTest(format);
        }

        /// <summary>
        /// Builds a global assertion. See <see cref="Each"/> and <see cref="Some"/> for building assertions.
        /// </summary>
        /// <param name="assertion">The assertion instance.</param>
        public static void That(IAssertion assertion)
        {
            if (assertion == null)
                throw new ArgumentNullException("assertion");

            if (TestCase.CurrentTest == null)
                throw new InvalidOperationException("Assert.That can only be called inside a TestCase method!");

            string format = assertion.ToString();

            if (assertion.Assert())
                TestCase.CurrentTest.PassedAssertions.Add(format);
            else
                TestCase.CurrentTest.FailCurrentTest(format);
        }

        public static void ThrowsException<T>(Action action) where T : Exception
        {
            throw new NotImplementedException();
        }

        public static void Fail(string message)
        {
            if (message == null)
                throw new ArgumentNullException("message");

            if (TestCase.CurrentTest == null)
                throw new InvalidOperationException("Assert.That can only be called inside a TestCase method!");

            TestCase.CurrentTest.FailCurrentTest(message);
        }
    }
}
