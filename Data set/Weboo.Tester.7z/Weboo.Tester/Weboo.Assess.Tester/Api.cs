using System;
using System.Collections;
using System.Linq;

namespace Weboo.Assess.Tester
{
    public static class Api
    {
        private static Random _Random;

        static Api()
        {
            MaxPrintCount = 20;
        }

        public static void Seed(int seed)
        {
            _Random = new Random(seed);
        }

        public static Random Random
        {
            get { return _Random ?? (_Random = new Random(0)); }
        }

        public static int MaxPrintCount { get; set; }

        public static string ToString(object obj)
        {
            if (obj is string)
                return obj.ToString();

            var type = obj as Type;
            if (type != null)
            {
                if (type.IsGenericType)
                    return $"{type.Name.Split('`')[0]}<{string.Join(", ", type.GetGenericArguments().Select(ToString).ToArray())}>";

                return type.Name;
            }

            if (obj is IEnumerable enumerable)
            {
                var items = new ArrayList();
                bool broke = false;

                foreach (object item in enumerable)
                {
                    if (items.Count >= MaxPrintCount)
                    {
                        broke = true;
                        break;
                    }

                    items.Add(item);
                }

                return $"[{string.Join(", ", items.Cast<object>().Select(ToString).ToArray())}{(broke ? "..." : "")}]";
            }

            return obj != null ? obj.ToString() : "Null";
        }
    }

    public static class ArrayHelper
    {
        public static T[] Scramble<T>(T[] input)
        {
            if (input == null) throw new ArgumentNullException("input");
            T[] result = (T[])input.Clone();

            for (int i = result.Length - 1; i >= 0; i--)
                Swap(result, i, Api.Random.Next(0, i));

            return result;
        }

        private static void Swap<T>(T[] result, int i, int j)
        {
            var temp = result[i];
            result[i] = result[j];
            result[j] = temp;
        }
    }
}
