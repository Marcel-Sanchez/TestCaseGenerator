﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Weboo.Assess.Tester
{
    public abstract class InterfaceTester<T> : TestCase
    {
        private T _benchmark;
        private T _target;

        protected T Benchmark => _benchmark;

        protected T Target => _target;

        protected void Initialize(params object[] args)
        {
            _target = BuildTarget(args);
            _benchmark = BuildBenchmark(args);
        }

        protected abstract T BuildTarget(object[] args);

        protected abstract T BuildBenchmark(object[] args);

        protected void Perform(Action<T> action)
        {
            PerformTarget(action);
            PerformBenchmark(action);
        }

        protected void PerformTarget(Action<T> action)
        {
            action(Target);
        }

        protected void PerformBenchmark(Action<T> action)
        {
            action(Benchmark);
        }

        protected virtual R Check<R>(Func<T, R> function, IEqualityComparer<R> equalityComparer = null)
        {
            var result = function(Target);
            var bench = function(Benchmark);

            Assert.That(result, Is.EqualTo(bench, equalityComparer));
            return bench;
        }

        protected virtual IEnumerable<R> CheckSequence<R>(Func<T, IEnumerable<R>> function, IEqualityComparer<R> equalityComparer = null)
        {
            var result = function(_target);
            var bench = function(_benchmark);

            Assert.That(result, Is.SequenceEqualTo(bench, equalityComparer));
            return bench;
        }

        protected virtual IEnumerable<R> CheckMultiSet<R>(Func<T, IEnumerable<R>> function, IEqualityComparer<R> equalityComparer = null)
        {
            var result = function(_target);
            var bench = function(_benchmark);

            Assert.That(result, Is.MultisetEqualTo(bench, equalityComparer));
            return bench;
        }

        protected IEnumerable<R> CheckOrdering<R>(Func<T, IEnumerable<R>> function, Comparison<R> cmp)
        {
            var resultEnum = function(_target);
            var benchEnum = function(_benchmark);
            if (benchEnum == null)
            {
                Assert.That(resultEnum, Is.Null);
                return benchEnum;
            }
            if (resultEnum == null)
            {
                Assert.That(resultEnum, Is.Not.Null);
                return benchEnum;
            }

            var result = resultEnum.ToList();
            var bench = benchEnum.ToList();
            var dict = bench
                .GroupBy(m => m)
                .ToDictionary(m => m.Key, m => m.Count());

            bool ordered = true;
            for (int i = 1; i < result.Count; i++)
            {
                ordered &= cmp(result[i], result[i - 1]) >= 0;
            }

            bool allElements = true;
            for (int i = 0; i < result.Count; i++)
            {
                if (!dict.ContainsKey(result[i]) || dict[result[i]] == 0)
                {
                    allElements = false;
                    continue;
                }

                dict[result[i]] -= 1;
            }

            Assert.That(ordered && allElements, Is.True);
            return bench;
        }
    }
}
