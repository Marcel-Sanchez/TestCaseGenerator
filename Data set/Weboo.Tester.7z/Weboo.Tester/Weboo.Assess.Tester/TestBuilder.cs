using System;
using System.Collections.Generic;


namespace Weboo.Assess.Tester
{
    public abstract class TestBuilder<T1, T2, T3> : TestBuilder
    {
        protected BuilderMode Mode { get; set; }

        protected T1 CurrentArgument1 { get; private set; }
        protected T2 CurrentArgument2 { get; private set; }
        protected T3 CurrentArgument3 { get; private set; }

        internal sealed override IEnumerable<TestCase> Build()
        {
            if (SeparatedCases)
            {
                foreach (var tuple in BuildInputs())
                    yield return new SingleTestCase(tuple.Item1, tuple.Item2, tuple.Item3, this);
            }
            else
            {
                yield return new MultipleTestCase(BuildInputs(), this);
            }
        }

        private IEnumerable<Tuple<T1, T2, T3>> BuildInputs()
        {
            var arg1 = Argument1;
            var arg2 = Argument2;
            var arg3 = Argument3;

            switch (Mode)
            {
                case BuilderMode.Sequential:
                    var iter1 = arg1.Build().GetEnumerator();
                    var iter2 = arg2.Build().GetEnumerator();
                    var iter3 = arg3.Build().GetEnumerator();

                    while (true)
                    {
                        if (!iter1.MoveNext()) break;
                        CurrentArgument1 = iter1.Current;

                        if (!iter2.MoveNext()) break;
                        CurrentArgument2 = iter2.Current;

                        if (!iter3.MoveNext()) break;
                        CurrentArgument3 = iter3.Current;

                        yield return Tuple.Create(CurrentArgument1, CurrentArgument2, CurrentArgument3);
                    }

                    break;
                case BuilderMode.Combinatorial:

                    var items1 = new List<T1>(arg1.Build());
                    var items2 = new List<T2>(arg2.Build());
                    var items3 = new List<T3>(arg3.Build());

                    foreach (var t1 in items1)
                    {
                        CurrentArgument1 = t1;
                        foreach (var t2 in items2)
                        {
                            CurrentArgument2 = t2;
                            foreach (var t3 in items3)
                            {
                                CurrentArgument3 = t3;
                                yield return Tuple.Create(t1, t2, t3);
                            }
                        }
                    }

                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }

            CurrentArgument1 = default(T1);
            CurrentArgument2 = default(T2);
            CurrentArgument3 = default(T3);
        }

        protected abstract void Test(T1 a, T2 b, T3 c);

        protected abstract IBuilder<T1> Argument1 { get; }

        protected abstract IBuilder<T2> Argument2 { get; }

        protected abstract IBuilder<T3> Argument3 { get; }

        private class SingleTestCase : TestCase
        {
            private readonly T1 input1;
            private readonly T2 input2;
            private readonly T3 input3;
            private readonly TestBuilder<T1, T2, T3> parent;

            public SingleTestCase(T1 input1, T2 input2, T3 input3, TestBuilder<T1, T2, T3> parent)
            {
                this.input1 = input1;
                this.input2 = input2;
                this.input3 = input3;
                this.parent = parent;
            }

            public void Test()
            {
                parent.Test(input1, input2, input3);
            }
        }

        private class MultipleTestCase : TestCase
        {
            private readonly IEnumerable<Tuple<T1, T2, T3>> inputs;
            private readonly TestBuilder<T1, T2, T3> parent;

            public MultipleTestCase(IEnumerable<Tuple<T1, T2, T3>> inputs, TestBuilder<T1, T2, T3> parent)
            {
                this.inputs = inputs;
                this.parent = parent;
            }

            public void Test()
            {
                foreach (var input in inputs)
                {
                    parent.Test(input.Item1, input.Item2, input.Item3);
                }
            }
        }
    }

    public abstract class TestBuilder
    {
        internal abstract IEnumerable<TestCase> Build();

        protected bool SeparatedCases { get; set; }
    }

    public abstract class TesterFor<T>
    {
        protected abstract Generator<T> BuildCases();
    }

    public class Generator<T>
    {
        public Generator(int totalCases)
        {
            
        }

        public Generator<T> Then(params Generator<T>[] obj)
        {
            throw new NotImplementedException();
        }

        public Generator<T> Do(params Generator<T>[] obj)
        {
            throw new NotImplementedException();
        }

        public Generator<T> If(Predicate<T> predicate)
        {
            throw new NotImplementedException();
        }

        public Generator<T> While(Predicate<T> predicate)
        {
            throw new NotImplementedException();
        }

        public Generator<T> Check<R>(Func<T, R> func, out R result)
        {
            throw new NotImplementedException();
        }

        public Generator<T> Assert<R>(Func<T, R> item, IAssertion<R> assertion)
        {
            throw new NotImplementedException();
        }

        public Generator<T> PerformOnce(Action<T> action)
        {
            throw new NotImplementedException();
        }

        public Generator<T> PerformMany(Action<T> action, out int timesAdded, int minTimes = 0, int maxTimes = int.MaxValue)
        {
            throw new NotImplementedException();
        }

        public Generator<T> OneOf(params Generator<T>[] args)
        {
            throw new NotImplementedException();
        }

        public Generator<T> PerformMany(Action<T> action)
        {
            throw new NotImplementedException();
        }

        public Generator<T> Repeat(int minTimes, int maxTimes, params Generator<T>[]  actions)
        {
            throw new NotImplementedException();
        }

        public Generator<T> Check<R>(Func<T, R> func)
        {
            throw new NotImplementedException();
        }
    }
}