using System.Collections.Generic;

namespace Weboo.Assess.Tester
{
    public class IntegerBuilder : IBuilder<int>
    {
        private int min = int.MinValue;
        private int max = int.MaxValue;
        private bool exhaustive = false;
        private int cases = 10;

        public int Last { get; private set; }

        public IEnumerable<int> GeneratedItems { get; private set; }

        public IEnumerable<int> Build()
        {
            if (exhaustive)
            {
                for (int i = min; i <= max; i++)
                    yield return i;
            }
            else
            {
                for (int i = 0; i < cases; i++)
                    yield return Api.Random.Next(min, max + 1);
            }
        }

        public int Next()
        {
            throw new System.NotImplementedException();
        }

        public IntegerBuilder InRange(int min, int max)
        {
            this.min = min;
            this.max = max;
            return this;
        }

        public IntegerBuilder Random(int count)
        {
            cases = count;
            exhaustive = false;
            return this;
        }

        public IntegerBuilder Exhaustive()
        {
            exhaustive = true;
            return this;
        }
    }
}