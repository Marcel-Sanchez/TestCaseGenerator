namespace Weboo.Assess.Tester
{
    public interface IAssertion
    {
        bool Assert();
    }

    public interface IAssertion<in T>
    {
        bool Assert(T item);
    }
}