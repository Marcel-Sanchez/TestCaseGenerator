using System.Collections;
using System.Collections.Generic;

namespace Weboo.Assess.Tester
{
    public static partial class Has
    {
        #region Enumerable Assertions

        public static IAssertion<IEnumerable<T>> Item<T>(T item)
        {
            return new ItemAssertion<T>(item);
        }

        public static IAssertion<IEnumerable<T>> AnyOf<T>(IEnumerable<T> items)
        {
            return new AnyOfAssertion<T>(items);
        }

        public static IAssertion<IEnumerable<T>> AllOf<T>(IEnumerable<T> items)
        {
            return new AllOfAssertion<T>(items);
        }

        public static IAssertion<IEnumerable<T>> NoneOf<T>(IEnumerable<T> items)
        {
            return new NoneOfAssertion<T>(items);
        }

        public static IAssertion<IEnumerable<T>> AnyOf<T>(params T[] items)
        {
            return new AnyOfAssertion<T>(items);
        }

        public static IAssertion<IEnumerable<T>> AllOf<T>(params T[] items)
        {
            return new AllOfAssertion<T>(items);
        }

        public static IAssertion<IEnumerable<T>> NoneOf<T>(params T[] items)
        {
            return new NoneOfAssertion<T>(items);
        }

        public static IAssertion<IEnumerable> Count(int count)
        {
            return new CountAssertion(count);
        }

        public static IAssertion<IEnumerable> Something
        {
            get { return Is.Negate(Is.Empty); }
        }

        public static IAssertion<IEnumerable> Nothing
        {
            get { return Is.Empty; }
        }

        #endregion

        public static class Not
        {
            #region Enumerable Assertions

            public static IAssertion<IEnumerable<T>> Item<T>(T item)
            {
                return Negate(Has.Item(item));
            }

            public static IAssertion<IEnumerable<T>> AllOf<T>(IEnumerable<T> items)
            {
                return Negate(Has.AllOf(items));
            }

            public static IAssertion<IEnumerable<T>> AllOf<T>(params T[] items)
            {
                return Negate(Has.AllOf(items));
            }

            public static IAssertion<IEnumerable> Count(int count)
            {
                return Negate(Has.Count(count));
            }

            #endregion
        }
    }
}