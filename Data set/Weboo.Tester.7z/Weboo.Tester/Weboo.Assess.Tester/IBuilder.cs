using System.Collections.Generic;

namespace Weboo.Assess.Tester
{
    public interface IBuilder<T>
    {
        IEnumerable<T> Build();
        T Next();
    }
}