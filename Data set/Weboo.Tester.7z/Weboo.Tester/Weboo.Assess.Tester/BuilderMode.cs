namespace Weboo.Assess.Tester
{
    public enum BuilderMode
    {
        Sequential,
        Combinatorial,
    }
}