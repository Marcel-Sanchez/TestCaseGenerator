using System;
using System.Collections.Generic;
using System.Linq;


namespace Weboo.Assess.Tester
{
    [Serializable]
    public class TestCaseResult
    {
        public int Weight;
        public int PassedTests;
        public int TotalTests;
        public string[] PassedAssertions;
        public string[] FailedAssertions;

        public TestCaseResult()
        {
            
        }

        public TestCaseResult(int weight, int passedTests, int totalTests, IEnumerable<string> passedAssertions, IEnumerable<string> failedAssertions)
        {
            Weight = weight;
            PassedTests = passedTests;
            PassedAssertions = passedAssertions.ToArray();
            TotalTests = totalTests;
            FailedAssertions = failedAssertions.ToArray();
        }

        public override string ToString()
        {
            return string.Format("{0}/{1} ({2:0.00}%) x{3}", PassedTests, TotalTests, PassedTests * 100.0 / TotalTests, Weight);
        }
    }
}