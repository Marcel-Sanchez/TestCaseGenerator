using System.Collections.Generic;


namespace Weboo.Assess.Tester
{
    public abstract class TestBuilder<T> : TestBuilder
    {
        private List<T> cases;

        protected abstract void Test(T input);
        protected abstract IBuilder<T> Argument { get; }

        public IEnumerable<T> Cases
        {
            get { return cases;  }
        } 

        internal sealed override IEnumerable<TestCase> Build()
        {
            var arg = Argument;

            cases = new List<T>(arg.Build());

            if (SeparatedCases)
            {
                foreach (var input in cases)
                    yield return new SingleTestCase(input, this);
            }
            else
            {
                yield return new MultipleTestCase(cases, this);
            }
        }

        private class SingleTestCase : TestCase
        {
            private readonly T input;
            private readonly TestBuilder<T> parent;

            public SingleTestCase(T input, TestBuilder<T> parent)
            {
                this.input = input;
                this.parent = parent;
            }

            public void Test()
            {
                parent.Test(input);
            }

            public override string ToString()
            {
                return Api.ToString(input);
            }
        }

        private class MultipleTestCase : TestCase
        {
            private readonly IEnumerable<T> inputs;
            private readonly TestBuilder<T> parent;

            public MultipleTestCase(IEnumerable<T> inputs, TestBuilder<T> parent)
            {
                this.inputs = inputs;
                this.parent = parent;
            }

            public void Test()
            {
                foreach (var input in inputs)
                {
                    parent.Test(input);
                }
            }
        }
    }
}