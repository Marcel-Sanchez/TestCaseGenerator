using System;

namespace Weboo.Assess.Tester
{
    internal class AssertionFailedException : Exception
    {
        private readonly string assertion;

        public AssertionFailedException(string assertion)
        {
            this.assertion = assertion;
        }

        public string Assertion
        {
            get { return assertion; }
        }
    }
}