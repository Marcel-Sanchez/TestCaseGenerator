using System;
using System.Collections.Generic;

namespace Weboo.Assess.Tester
{
    public static class Create
    {
        public static ArrayBuilder<T> ArrayOf<T>()
        {
            return new ArrayBuilder<T>();
        }

        public static IntegerBuilder Integer()
        {
            return new IntegerBuilder();
        }

        public static ExplicitBuilder<T> ListOf<T>(params T[] items)
        {
            return new ExplicitBuilder<T>(items);
        }

        public static ExplicitBuilder<T> ListOf<T>(IEnumerable<T> items)
        {
            return new ExplicitBuilder<T>(items);
        }
    }

    public class ExplicitBuilder<T> : IBuilder<T>
    {
        private readonly IEnumerable<T> items;

        public ExplicitBuilder(IEnumerable<T> items)
        {
            if (items == null) throw new ArgumentNullException("items");
            this.items = items;
        }

        public IEnumerable<T> Build()
        {
            return this.items;
        }

        public T Next()
        {
            throw new NotImplementedException();
        }
    }
}