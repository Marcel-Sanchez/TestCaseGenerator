﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Data.Common;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Newtonsoft.Json;
using Weboo.Assess.Tester;
//using Weboo.ExamenFinal.Interfaces;

namespace TestRunner
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var testerAssembly = Assembly.LoadFile(args[0]);
            var studentAssembly = Assembly.LoadFile(args[1]);
            var testCase = int.Parse(args[2]);

            ReflectionHelper.ReflectiveAssembly = studentAssembly;

            var suite = TestSuite.AutoDiscover(testerAssembly);
            var result = suite.Run(testCase);

            //var formatter = new JsonSerializer();
            //var sw = new StreamWriter(Console.OpenStandardError());
            //formatter.Serialize(sw, result);

            var formatter = new XmlSerializer(typeof(TestCaseResult));
            formatter.Serialize(Console.OpenStandardError(), result);
        }
    }
}
