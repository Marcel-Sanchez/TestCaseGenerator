﻿using Weboo.Assess.Tester;

namespace RanasSuizasTester
{
    public abstract class RanasSuizasTest : TestCase
    {
        public bool T = true;
        public bool F = false;
        public int Student(bool[,] charco, int[] posiciones)
        {
            return ReflectionHelper.InvokeStatic<int>("Weboo.Examen.Charco", "ComiendoChocolates", charco, posiciones);
        }
    }

    public class Ejemplo1Test : RanasSuizasTest
    {
        public void Ejemplo1()
        {
            bool[,] charco = {
                { F, F, F, F, F, F, F, F },
                { F, F, T, F, F, T, F, F },
                { F, T, F, F, T, F, T, F },
                { F, F, T, F, F, F, F, T }
            };
            int[] posiciones = { 1, 3, 6 };
            int sol = 7;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class Ejemplo2Test : RanasSuizasTest
    {
        public void Ejemplo2()
        {
            bool[,] charco = {
                { F, F, F, F, F, F, F, F },
                { F, F, T, F, F, T, F, F },
                { F, T, F, F, T, F, T, F },
                { T, F, T, F, F, F, F, T }
            };
            int[] posiciones = { 1, 3, 6 };
            int sol = 7;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class Ejemplo3Test : RanasSuizasTest
    {
        public void Ejemplo3()
        {
            bool[,] charco = {
                { F, F, F, F, F, F, F, F },
                { F, F, F, F, F, T, F, T },
                { F, F, F, F, F, F, T, F },
                { F, F, F, F, F, F, F, T }
            };
            int[] posiciones = { 1, 3 };
            int sol = 0;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    //public class PrimeraFila1Test : RanasSuizasTest
    //{
    //    public void PrimeraFila1()
    //    {
    //        bool[,] charco = {
    //            { F, T, F, F },
    //            { F, F, F, F },
    //            { F, F, F, F },
    //            { F, F, F, F }
    //        };
    //        int[] posiciones = { 1, 3 };
    //        int sol = 1;

    //        Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
    //    }
    //}

    //public class PrimeraFila2Test : RanasSuizasTest
    //{
    //    public void PrimeraFila2()
    //    {
    //        bool[,] charco = {
    //            { F, T, F, T },
    //            { F, F, F, F },
    //            { F, F, F, F },
    //            { F, F, F, F }
    //        };
    //        int[] posiciones = { 1, 3 };
    //        int sol = 2;

    //        Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
    //    }
    //}

    //public class PrimeraFila3Test : RanasSuizasTest
    //{
    //    public void PrimeraFila3()
    //    {
    //        bool[,] charco = {
    //            { T, F, F, F },
    //            { F, F, F, F },
    //            { F, F, F, F },
    //            { F, F, F, F }
    //        };
    //        int[] posiciones = { 3 };
    //        int sol = 0;

    //        Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
    //    }
    //}

    //public class PrimeraFila4Test : RanasSuizasTest
    //{
    //    public void PrimeraFila4()
    //    {
    //        bool[,] charco = {
    //            { T, T, T, F },
    //            { F, F, F, F },
    //            { F, F, F, F },
    //            { F, F, F, F }
    //        };
    //        int[] posiciones = { 3 };
    //        int sol = 0;

    //        Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
    //    }
    //}

    //public class PrimeraFila5Test : RanasSuizasTest
    //{
    //    public void PrimeraFila5()
    //    {
    //        bool[,] charco = {
    //            { T, T, T, T },
    //            { F, F, F, F },
    //            { F, F, F, F },
    //            { F, F, F, F }
    //        };
    //        int[] posiciones = { 3 };
    //        int sol = 1;

    //        Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
    //    }
    //}

    public class NoChocolate1Test : RanasSuizasTest
    {
        public void NoChocolate1()
        {
            bool[,] charco = {
                { F, F, F, F },
                { F, F, F, F },
                { F, F, F, F },
                { F, F, F, F }
            };
            int[] posiciones = { 0, 1, 2, 3 };
            int sol = 0;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class NoChocolate2Test : RanasSuizasTest
    {
        public void NoChocolate2()
        {
            bool[,] charco = {
                { F, T, T, T },
                { F, F, T, T },
                { F, F, F, T },
                { F, F, F, F }
            };
            int[] posiciones = { 0 };
            int sol = 0;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class NoChocolate3Test : RanasSuizasTest
    {
        public void NoChocolate3()
        {
            bool[,] charco = {
                { F, F, F, F },
                { F, F, F, T },
                { F, F, F, F },
                { F, F, F, F }
            };
            int[] posiciones = { 1 };
            int sol = 0;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class NoChocolate4Test : RanasSuizasTest
    {
        public void NoChocolate4()
        {
            bool[,] charco = {
                { F, F, F, F },
                { F, F, F, T },
                { F, F, F, F },
                { F, F, F, F }
            };
            int[] posiciones = { 0, 1 };
            int sol = 0;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class NoChocolate5Test : RanasSuizasTest
    {
        public void NoChocolate5()
        {
            bool[,] charco = {
                { T, F, F, T },
                { F, F, F, F },
                { F, F, F, F },
                { F, F, F, F }
            };
            int[] posiciones = { 1, 2 };
            int sol = 0;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class NoChocolate6Test : RanasSuizasTest
    {
        public void NoChocolate6()
        {
            bool[,] charco = {
                { F, F, F, F, F, F, F, F, F, F },
                { F, F, F, T, T, T, T, F, F, F },
                { F, F, F, T, T, T, T, F, F, F },
                { F, F, F, F, T, T, F, F, F, F }
            };
            int[] posiciones = { 0, 9 };
            int sol = 0;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class NoChocolate7Test : RanasSuizasTest
    {
        public void NoChocolate7()
        {
            bool[,] charco = {
                { F, F, F, F, F },
                { F, F, T, F, F },
                { F, F, F, F, F },
                { F, F, F, F, F },
                { F, F, F, F, F },
                { F, F, F, F, F },
                { F, F, F, F, F },
                { F, F, F, F, F },
            };
            int[] posiciones = { 0, 4 };
            int sol = 0;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class NoChocolate8Test : RanasSuizasTest
    {
        public void NoChocolate8()
        {
            bool[,] charco = {
                { F, F, F, F, F },
                { F, F, T, F, F },
                { F, F, F, F, F },
                { F, F, F, F, F },
                { F, F, F, F, F },
                { F, F, F, F, F },
                { F, F, F, F, F },
                { F, F, F, F, F },
            };
            int[] posiciones = { 0, 4 };
            int sol = 0;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class Sacrificarse1Test : RanasSuizasTest
    {
        public void Sacrificarse1()
        {
            bool[,] charco = {
                { F, F, F, F, F },
                { F, F, T, F, F },
                { F, F, F, F, F }
            };
            int[] posiciones = { 1, 3 };
            int sol = 1;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class Sacrificarse2Test : RanasSuizasTest
    {
        public void Sacrificarse2()
        {
            bool[,] charco = {
                { F, F, F, F, F },
                { F, F, T, T, F },
                { F, F, T, F, F }
            };
            int[] posiciones = { 1, 3 };
            int sol = 3;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class Sacrificarse3Test : RanasSuizasTest
    {
        public void Sacrificarse3()
        {
            bool[,] charco = {
                { F, F, F, F, F },
                { F, F, T, F, F },
                { F, F, T, F, F }
            };
            int[] posiciones = { 0, 4 };
            int sol = 1;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class Sacrificarse4Test : RanasSuizasTest
    {
        public void Sacrificarse4()
        {
            bool[,] charco = {
                { F, F, F, F, F },
                { F, T, T, T, F },
                { F, F, T, F, F }
            };
            int[] posiciones = { 1, 2, 3 };
            int sol = 4;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class Sacrificarse5Test : RanasSuizasTest
    {
        public void Sacrificarse5()
        {
            bool[,] charco = {
                { F, F, F, F, F },
                { F, F, T, F, F },
                { F, T, T, F, F }
            };
            int[] posiciones = { 2, 3 };
            int sol = 3;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class Sacrificarse6Test : RanasSuizasTest
    {
        public void Sacrificarse6()
        {
            bool[,] charco = {
                { F, F, F, F, F, F },
                { F, F, F, T, F, T },
                { F, T, T, T, F, F },
                { T, T, T, F, F, F }
            };
            int[] posiciones = { 2, 3, 4 };
            int sol = 7;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class Sacrificarse7Test : RanasSuizasTest
    {
        public void Sacrificarse7()
        {
            bool[,] charco = {
                { F, F, F, F, F, F },
                { T, F, T, F, F, F },
                { F, F, T, T, T, F },
                { F, F, F, T, T, T }
            };
            int[] posiciones = { 1, 2, 3 };
            int sol = 7;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class Sacrificarse8Test : RanasSuizasTest
    {
        public void Sacrificarse8()
        {
            bool[,] charco = {
                { F, F, F, F, F, F },
                { F, F, T, F, F, F },
                { F, F, T, F, F, F },
                { F, F, T, F, F, F },
                { F, F, T, F, F, F },
                { F, F, T, F, F, F }
            };
            int[] posiciones = { 0, 1, 2, 3, 4 };
            int sol = 5;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class Sacrificarse9Test : RanasSuizasTest
    {
        public void Sacrificarse9()
        {
            bool[,] charco = {
                { F, F, F, F, F, F },
                { F, F, T, T, F, F },
                { F, T, F, F, T, F },
                { T, F, F, F, F, T },
                { F, F, T, T, F, F },
            };
            int[] posiciones = { 2, 3, 4 };
            int sol = 7;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class Sacrificarse10Test : RanasSuizasTest
    {
        public void Sacrificarse10()
        {
            bool[,] charco = {
                { F, F, F, F, F, F },
                { T, F, F, T, T, T },
                { F, T, F, F, T, F },
                { T, F, F, F, F, T },
                { F, F, T, T, F, F },
            };
            int[] posiciones = { 2, 3, 4 };
            int sol = 7;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class VariosCaminos1Test : RanasSuizasTest
    {
        public void VariosCaminos1()
        {
            bool[,] charco = {
                { F, F, F, F, F },
                { T, T, F, T, F },
                { T, T, F, T, F },
                { T, T, F, F, T }
            };
            int[] posiciones = { 1, 3 };
            int sol = 6;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class VariosCaminos2Test : RanasSuizasTest
    {
        public void VariosCaminos2()
        {
            bool[,] charco = {
                { F, F, F, F, F },
                { T, F, F, F, T },
                { F, F, F, T, T },
                { F, F, F, T, T }
            };
            int[] posiciones = { 1, 3 };
            int sol = 5;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class VariosCaminos3Test : RanasSuizasTest
    {
        public void VariosCaminos3()
        {
            bool[,] charco = {
                { F, F, F, F, F, F },
                { T, F, F, T, F, T },
                { F, F, T, F, F, F },
                { F, F, F, F, T, F },
                { F, T, T, F, T, T },
            };
            int[] posiciones = { 0, 3, 4 };
            int sol = 8;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class VariosCaminos4Test : RanasSuizasTest
    {
        public void VariosCaminos4()
        {
            bool[,] charco = {
                { F, F, F, F, F, F },
                { T, F, T, T, F, T },
                { F, F, T, F, T, F },
                { T, T, T, F, T, F },
                { F, T, T, F, T, T },
            };
            int[] posiciones = { 0, 3, 4 };
            int sol = 11;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class VariosCaminos5Test : RanasSuizasTest
    {
        public void VariosCaminos5()
        {
            bool[,] charco = {
                { F, F, F, F, F, F },
                { T, F, T, T, F, T },
                { F, F, T, F, T, T },
                { T, T, T, F, T, F },
                { F, T, T, F, T, T },
            };
            int[] posiciones = { 1, 5 };
            int sol = 8;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class VariosCaminos6Test : RanasSuizasTest
    {
        public void VariosCaminos6()
        {
            bool[,] charco = {
                { F, F, F, F, F, F },
                { F, T, F, F, F, F },
                { F, F, T, F, T, T },
                { T, T, T, F, T, F },
                { F, T, T, F, T, T },
            };
            int[] posiciones = { 1, 2, 4, 5 };
            int sol = 11;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class VariosCaminos7Test : RanasSuizasTest
    {
        public void VariosCaminos7()
        {
            bool[,] charco = {
                { F, F, F, F, F, F },
                { F, T, F, F, F, F },
                { T, F, T, F, F, T },
                { T, F, F, F, T, F },
                { T, T, F, F, T, T },
                { F, F, F, F, F, F },
            };
            int[] posiciones = { 3 };
            int sol = 3;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class VariosCaminos8Test : RanasSuizasTest
    {
        public void VariosCaminos8()
        {
            bool[,] charco = {
                { F, F, F, F, F, F },
                { T, T, T, T, T, T },
                { T, T, T, T, T, T },
                { T, T, T, T, T, T },
                { T, T, T, T, T, T },
            };
            int[] posiciones = { 5 };
            int sol = 4;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class VariosCaminos9Test : RanasSuizasTest
    {
        public void VariosCaminos9()
        {
            bool[,] charco = {
                { F, F, F, F, F, F },
                { F, F, T, F, T, T },
                { T, F, F, T, F, T },
            };
            int[] posiciones = { 1, 5 };
            int sol = 4;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    //public class VariosCaminos10Test : RanasSuizasTest
    //{
    //    public void VariosCaminos10()
    //    {
    //        bool[,] charco = {
    //            { T, T, T, T, T },
    //            { T, T, T, T, T },
    //            { T, T, T, T, T }
    //        };
    //        int[] posiciones = { 0, 1, 2, 3, 4 };
    //        int sol = 15;

    //        Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
    //    }
    //}

    public class Grande1Test : RanasSuizasTest
    {
        public void Grande1()
        {
            bool[,] charco = {
                { F, F, F, F, F, F, F, F },
                { T, T, T, T, T, T, T, T },
                { T, T, T, T, T, T, T, T },
                { T, T, T, T, T, T, T, T },
                { T, T, T, T, T, T, T, T },
            };
            int[] posiciones = { 0, 1, 2, 3, 4, 5, 6, 7 };
            int sol = 32;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class Grande2Test : RanasSuizasTest
    {
        public void Grande2()
        {
            bool[,] charco = {
                { F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F },
                { F, F, F, F, F, F, F, F, F, F }
            };
            int[] posiciones = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            int sol = 0;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class Grande3Test : RanasSuizasTest
    {
        public void Grande3()
        {
            bool[,] charco = {
                { F, F, F, F, F, F, F, F, F, F },
                { T, T, T, T, T, T, T, T, T, T },
                { T, T, T, T, T, T, T, T, T, T },
                { T, T, T, T, T, T, T, T, T, T },
                { T, T, T, T, T, T, T, T, T, T },
                { T, T, T, T, T, T, T, T, T, T },
                { T, T, T, T, T, T, T, T, T, T },
            };
            int[] posiciones = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            int sol = 60;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class Grande4Test : RanasSuizasTest
    {
        public void Grande4()
        {
            bool[,] charco = {
                { F, F, F, F, F, F, F, F, F, F },
                { T, T, T, T, T, T, T, T, T, T },
                { T, T, F, T, T, F, F, T, F, T },
                { T, T, T, F, T, F, T, T, T, T },
                { T, T, T, T, T, F, F, F, F, T },
            };
            int[] posiciones = { 3, 6, 7 };
            int sol = 12;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }

    public class Grande5Test : RanasSuizasTest
    {
        public void Grande5()
        {
            bool[,] charco = {
                { F, F, F, F, F, F, F, F },
                { T, T, T, T, T, T, T, T },
                { T, T, F, T, T, F, F, T },
                { T, F, T, F, T, F, T, T },
                { F, F, F, T, F, T, F, F },
                { T, T, T, T, T, F, F, F },
                { F, T, F, T, F, F, T, T },
            };
            int[] posiciones = { 1, 5 };
            int sol = 12;

            Assert.That(Student(charco, posiciones), Is.EqualTo(sol));
        }
    }
}
