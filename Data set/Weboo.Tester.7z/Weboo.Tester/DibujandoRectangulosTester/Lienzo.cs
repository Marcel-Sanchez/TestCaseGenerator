﻿using System;
using Weboo.Examen.Interfaces;

namespace DibujandoRectangulosTester
{
    public class Lienzo : ILienzo
    {
        private QuadTreeNode _root;

        public Lienzo(int N)
        {
            _root = new QuadTreeNode() { N = N };
        }

        public int Resolucion => (1 << _root.N) * (1 << _root.N);

        public int CantidadDeNodosBlancos => _root.WhiteNodes;

        public int CantidadDeNodosNegros => _root.BlackNodes;

        public int CantidadDeNodosGrises => _root.GrayNodes;

        public void Dibuja(int fila, int columna, int ancho, int alto)
        {
            _root.Fill(fila, columna, fila + alto - 1, columna + ancho - 1);
        }

        public bool EstaPintado(int fila, int columna)
        {
            return _root.Contains(fila, columna);
        }
    }

    class QuadTreeNode
    {
        public int Value { get; set; }

        public int N { get; set; }

        public int WhiteNodes
        {
            get
            {
                if (Value == 0)
                    return 1;
                if (Value == 2)
                    return 0;
                return NW.WhiteNodes + NE.WhiteNodes + SW.WhiteNodes + SE.WhiteNodes;
            }
        }

        public int BlackNodes
        {
            get
            {
                if (Value == 2)
                    return 1;
                if (Value == 0)
                    return 0;
                return NW.BlackNodes + NE.BlackNodes + SW.BlackNodes + SE.BlackNodes;
            }
        }

        public int GrayNodes
        {
            get
            {
                if (Value == 0 || Value == 2)
                    return 0;
                return 1 + NW.GrayNodes + NE.GrayNodes + SW.GrayNodes + SE.GrayNodes;
            }
        }

        public QuadTreeNode NW { get; set; }

        public QuadTreeNode NE { get; set; }

        public QuadTreeNode SW { get; set; }

        public QuadTreeNode SE { get; set; }

        public void Fill(int r1, int c1, int r2, int c2)
        {
            int size = 1 << N;
            int half = size >> 1;

            if (size == 1)
            {
                Value = 2;
                return;
            }

            if (Value == 2)
                return;

            if (Value == 0)
            {
                Value = 1;
                NW = new QuadTreeNode() { N = N - 1 };
                NE = new QuadTreeNode() { N = N - 1 };
                SW = new QuadTreeNode() { N = N - 1 };
                SE = new QuadTreeNode() { N = N - 1 };
            }

            if (Overlap(r1, c1, r2, c2, 0, 0, half - 1, half - 1))
                NW.Fill(Math.Max(0, r1 - 0), Math.Max(0, c1 - 0), Math.Min(r2 - 0, half - 1), Math.Min(c2 - 0, half - 1));

            if (Overlap(r1, c1, r2, c2, 0, half, half - 1, size - 1))
                NE.Fill(Math.Max(0, r1 - 0), Math.Max(0, c1 - half), Math.Min(r2 - 0, half - 1), Math.Min(c2 - half, half - 1));

            if (Overlap(r1, c1, r2, c2, half, 0, size - 1, half - 1))
                SW.Fill(Math.Max(0, r1 - half), Math.Max(0, c1 - 0), Math.Min(r2 - half, half - 1), Math.Min(c2 - 0, half - 1));

            if (Overlap(r1, c1, r2, c2, half, half, size - 1, size - 1))
                SE.Fill(Math.Max(0, r1 - half), Math.Max(0, c1 - half), Math.Min(r2 - half, half - 1), Math.Min(c2 - half, half - 1));

            if (NW.Value == 2 && NE.Value == 2 && SW.Value == 2 && SE.Value == 2)
            {
                Value = 2;
                NW = NE = SW = SE = null;
            }
        }

        public bool Contains(int r, int c)
        {
            int size = 1 << N;
            int half = size >> 1;

            if (Value == 0)
                return false;

            if (Value == 2)
                return true;

            if (Overlap(r, c, r, c, 0, 0, half - 1, half - 1))
                return NW.Contains(Math.Max(0, r - 0), Math.Max(0, c - 0));

            if (Overlap(r, c, r, c, 0, half, half - 1, size - 1))
                return NE.Contains(Math.Max(0, r - 0), Math.Max(0, c - half));

            if (Overlap(r, c, r, c, half, 0, size - 1, half - 1))
                return SW.Contains(Math.Max(0, r - half), Math.Max(0, c - 0));

            if (Overlap(r, c, r, c, half, half, size - 1, size - 1))
                return SE.Contains(Math.Max(0, r - half), Math.Max(0, c - half));

            throw new Exception();
        }

        private bool SegmentOverlap(int a1, int a2, int b1, int b2)
        {
            return !(b2 < a1 || a2 < b1);
        }

        private bool Overlap(int rl1, int cl1, int rr1, int cr1, int rl2, int cl2, int rr2, int cr2)
        {
            return SegmentOverlap(rl1, rr1, rl2, rr2) && SegmentOverlap(cl1, cr1, cl2, cr2);
        }
    }
}
