﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Assess.Tester;
using Weboo.Examen.Interfaces;

namespace DibujandoRectangulosTester
{
    public abstract class DibujandoRectangulosTest : InterfaceTester<ILienzo>
    {
        protected override ILienzo BuildBenchmark(object[] args)
        {
            int N = (int)args[0];
            return new Lienzo(N);
        }

        protected override ILienzo BuildTarget(object[] args)
        {
            int N = (int)args[0];
            return ReflectionHelper.CreateInstance<ILienzo>(N);
        }
    }

    public class Test1 : DibujandoRectangulosTest
    {
        public void Ejemplo1()
        {
            Initialize(4);

            Check(m => m.CantidadDeNodosBlancos);
            Check(m => m.CantidadDeNodosGrises);
            Check(m => m.CantidadDeNodosNegros);
            Check(m => m.Resolucion);
        }
    }

    public class Test2 : DibujandoRectangulosTest
    {
        public void Ejemplo2()
        {
            Initialize(4);

            Perform(m => m.Dibuja(8, 4, 2, 2));
            Check(m => m.CantidadDeNodosBlancos);
            Check(m => m.CantidadDeNodosGrises);
            Check(m => m.CantidadDeNodosNegros);
            Check(m => m.Resolucion);
        }
    }

    public class Test3 : DibujandoRectangulosTest
    {
        public void Ejemplo3()
        {
            Initialize(4);

            Perform(m => m.Dibuja(8, 4, 2, 2));
            Check(m => m.CantidadDeNodosBlancos);
            Check(m => m.CantidadDeNodosGrises);
            Check(m => m.CantidadDeNodosNegros);
            Check(m => m.EstaPintado(8, 5));
        }
    }

    public class Test4 : DibujandoRectangulosTest
    {
        public void Ejemplo4()
        {
            Initialize(4);

            Perform(m => m.Dibuja(8, 4, 2, 2));
            Perform(m => m.Dibuja(8, 6, 2, 4));
            Check(m => m.CantidadDeNodosBlancos);
            Check(m => m.CantidadDeNodosGrises);
            Check(m => m.CantidadDeNodosNegros);
            Check(m => m.EstaPintado(10, 7));
        }
    }

    public class Test5 : DibujandoRectangulosTest
    {
        public void Ejemplo5()
        {
            Initialize(4);

            Perform(m => m.Dibuja(8, 4, 2, 2));
            Perform(m => m.Dibuja(8, 6, 2, 4));
            Perform(m => m.Dibuja(10, 4, 2, 2));
            Check(m => m.CantidadDeNodosBlancos);
            Check(m => m.CantidadDeNodosGrises);
            Check(m => m.CantidadDeNodosNegros);
            Check(m => m.EstaPintado(8, 7));
        }
    }

    public class Test6 : DibujandoRectangulosTest
    {
        public void Ejemplo6()
        {
            Initialize(4);

            Perform(m => m.Dibuja(8, 4, 2, 2));
            Perform(m => m.Dibuja(8, 6, 2, 4));
            Perform(m => m.Dibuja(10, 4, 2, 2));
            Perform(m => m.Dibuja(4, 12, 1, 1));
            Check(m => m.CantidadDeNodosBlancos);
            Check(m => m.CantidadDeNodosGrises);
            Check(m => m.CantidadDeNodosNegros);
            Check(m => m.EstaPintado(4, 13));
        }
    }

    public class Test7 : DibujandoRectangulosTest
    {
        public void Ejemplo7()
        {
            Initialize(4);

            Perform(m => m.Dibuja(8, 4, 2, 2));
            Perform(m => m.Dibuja(8, 6, 2, 4));
            Perform(m => m.Dibuja(10, 4, 2, 2));
            Perform(m => m.Dibuja(4, 12, 1, 1));
            Perform(m => m.Dibuja(4, 12, 2, 2));
            Check(m => m.CantidadDeNodosBlancos);
            Check(m => m.CantidadDeNodosGrises);
            Check(m => m.CantidadDeNodosNegros);
            Check(m => m.EstaPintado(10, 10));
        }
    }

    public class Test8 : DibujandoRectangulosTest
    {
        public void Resolucion1()
        {
            Initialize(8);

            Check(m => m.Resolucion);
        }
    }

    public class Test9 : DibujandoRectangulosTest
    {
        public void Resolucion2()
        {
            Initialize(14);

            Check(m => m.Resolucion);
        }
    }

    public class Test10 : DibujandoRectangulosTest
    {
        public void NodosBlancos1()
        {
            Initialize(6);

            Perform(m => m.Dibuja(10, 10, 1, 1));
            Check(m => m.CantidadDeNodosBlancos);
        }
    }

    public class Test11 : DibujandoRectangulosTest
    {
        public void NodosBlancos2()
        {
            Initialize(6);

            Perform(m => m.Dibuja(10, 10, 1, 1));
            Perform(m => m.Dibuja(0, 0, 1, 1));
            Check(m => m.CantidadDeNodosBlancos);
        }
    }

    public class Test12 : DibujandoRectangulosTest
    {
        public void NodosBlancos3()
        {
            Initialize(6);

            Perform(m => m.Dibuja(10, 10, 1, 1));
            Perform(m => m.Dibuja(0, 0, 1, 1));
            Perform(m => m.Dibuja(0, 0, 10, 10));
            Check(m => m.CantidadDeNodosBlancos);
        }
    }

    public class Test13 : DibujandoRectangulosTest
    {
        public void NodosBlancos4()
        {
            Initialize(6);

            Perform(m => m.Dibuja(10, 10, 1, 1));
            Perform(m => m.Dibuja(0, 0, 1, 1));
            Perform(m => m.Dibuja(0, 0, 64, 64));
            Check(m => m.CantidadDeNodosBlancos);
        }
    }

    public class Test14 : DibujandoRectangulosTest
    {
        public void NodosBlancos5()
        {
            Initialize(6);

            Perform(m => m.Dibuja(31, 31, 2, 2));
            Check(m => m.CantidadDeNodosBlancos);
        }
    }

    public class Test15 : DibujandoRectangulosTest
    {
        public void NodosBlancos6()
        {
            Initialize(6);

            Perform(m => m.Dibuja(31, 31, 2, 2));
            Perform(m => m.Dibuja(31, 31, 1, 1));
            Check(m => m.CantidadDeNodosBlancos);
        }
    }

    public class Test16 : DibujandoRectangulosTest
    {
        public void NodosGrises1()
        {
            Initialize(5);

            Perform(m => m.Dibuja(31, 31, 1, 1));
            Check(m => m.CantidadDeNodosGrises);
        }
    }

    public class Test17 : DibujandoRectangulosTest
    {
        public void NodosGrises2()
        {
            Initialize(5);

            Perform(m => m.Dibuja(0, 0, 1, 1));
            Perform(m => m.Dibuja(0, 31, 1, 1));
            Perform(m => m.Dibuja(31, 0, 1, 1));
            Perform(m => m.Dibuja(31, 31, 1, 1));
            Check(m => m.CantidadDeNodosGrises);
        }
    }

    public class Test18 : DibujandoRectangulosTest
    {
        public void NodosGrises3()
        {
            Initialize(5);

            Perform(m => m.Dibuja(0, 0, 1, 1));
            Perform(m => m.Dibuja(0, 31, 1, 1));
            Perform(m => m.Dibuja(31, 0, 1, 1));
            Perform(m => m.Dibuja(31, 31, 1, 1));
            Check(m => m.CantidadDeNodosGrises);
        }
    }

    public class Test19 : DibujandoRectangulosTest
    {
        public void NodosGrises4()
        {
            Initialize(5);

            Perform(m => m.Dibuja(15, 15, 2, 2));
            Check(m => m.CantidadDeNodosGrises);
        }
    }

    public class Test20 : DibujandoRectangulosTest
    {
        public void NodosGrises5()
        {
            Initialize(5);

            Perform(m => m.Dibuja(15, 15, 2, 2));
            Perform(m => m.Dibuja(10, 10, 20, 20));
            Check(m => m.CantidadDeNodosGrises);
        }
    }

    public class Test21 : DibujandoRectangulosTest
    {
        public void NodosGrises6()
        {
            Initialize(5);

            Perform(m => m.Dibuja(0, 0, 16, 16));
            Check(m => m.CantidadDeNodosGrises);
        }
    }

    public class Test22 : DibujandoRectangulosTest
    {
        public void NodosGrises7()
        {
            Initialize(5);

            Perform(m => m.Dibuja(0, 0, 16, 16));
            Perform(m => m.Dibuja(0, 8, 8, 8));
            Check(m => m.CantidadDeNodosGrises);
        }
    }

    public class Test23 : DibujandoRectangulosTest
    {
        public void NodosNegros1()
        {
            Initialize(10);

            Perform(m => m.Dibuja((1 << 10) - 1, (1 << 10) - 1, 1, 1));
            Check(m => m.CantidadDeNodosNegros);
        }
    }

    public class Test24 : DibujandoRectangulosTest
    {
        public void NodosNegros2()
        {
            Initialize(10);

            Perform(m => m.Dibuja((1 << 10) - 1, (1 << 10) - 1, 1, 1));
            Perform(m => m.Dibuja(0, 0, 1 << 10, 1 << 10));
            Check(m => m.CantidadDeNodosNegros);
        }
    }

    public class Test25 : DibujandoRectangulosTest
    {
        public void NodosNegros3()
        {
            Initialize(10);

            Perform(m => m.Dibuja((1 << 10) - 1, (1 << 10) - 1, 1, 1));
            Perform(m => m.Dibuja(0, 0, 1 << 10, 1 << 10));
            Perform(m => m.Dibuja(1, 1, 1 << 10 - 1, 1 << 10 - 1));
            Check(m => m.CantidadDeNodosNegros);
        }
    }

    public class Test26 : DibujandoRectangulosTest
    {
        public void NodosNegros4()
        {
            Initialize(12);

            Perform(m => m.Dibuja(1 << 10, 0, 4, 400));
            Perform(m => m.Dibuja(2412, 332, 543, 23));
            Perform(m => m.Dibuja(423, 3008, 50, 1));
            Check(m => m.CantidadDeNodosNegros);
        }
    }

    public class Test27 : DibujandoRectangulosTest
    {
        public void NodosNegros5()
        {
            Initialize(12);

            Perform(m => m.Dibuja(1 << 10, 0, 4, 400));
            Perform(m => m.Dibuja(2412, 332, 543, 23));
            Perform(m => m.Dibuja(423, 3008, 50, 1));
            Perform(m => m.Dibuja(1 << 10, 0, 4, 400));
            Check(m => m.CantidadDeNodosNegros);
        }
    }

    public class Test28 : DibujandoRectangulosTest
    {
        public void NodosNegros6()
        {
            Initialize(12);

            Perform(m => m.Dibuja((1 << 12) - 1, 0, 1 << 12, 1));
            Check(m => m.CantidadDeNodosNegros);
        }
    }

    public class Test29 : DibujandoRectangulosTest
    {
        public void NodosNegros7()
        {
            Initialize(3);

            Perform(m => m.Dibuja(0, 0, 8, 8));
            Check(m => m.CantidadDeNodosNegros);
        }
    }

    public class Test30 : DibujandoRectangulosTest
    {
        public void Nodos1()
        {
            Initialize(0);

            Perform(m => m.Dibuja(0, 0, 1, 1));
            Check(m => m.CantidadDeNodosBlancos);
            Check(m => m.CantidadDeNodosGrises);
            Check(m => m.CantidadDeNodosNegros);
        }
    }

    public class Test31 : DibujandoRectangulosTest
    {
        public void Nodos2()
        {
            Initialize(1);

            Perform(m => m.Dibuja(0, 0, 2, 1));
            Check(m => m.CantidadDeNodosBlancos);
            Check(m => m.CantidadDeNodosGrises);
            Check(m => m.CantidadDeNodosNegros);
        }
    }

    public class Test32 : DibujandoRectangulosTest
    {
        public void Nodos3()
        {
            Initialize(1);

            Perform(m => m.Dibuja(0, 0, 1, 2));
            Check(m => m.CantidadDeNodosBlancos);
            Check(m => m.CantidadDeNodosGrises);
            Check(m => m.CantidadDeNodosNegros);
        }
    }

    public class Test33 : DibujandoRectangulosTest
    {
        public void Nodos4()
        {
            Initialize(2);

            Perform(m => m.Dibuja(3, 3, 1, 1));
            Check(m => m.CantidadDeNodosBlancos);
            Check(m => m.CantidadDeNodosGrises);
            Check(m => m.CantidadDeNodosNegros);
        }
    }

    public class Test34 : DibujandoRectangulosTest
    {
        public void Nodos5()
        {
            Initialize(3);

            Perform(m => m.Dibuja(3, 3, 5, 5));
            Check(m => m.CantidadDeNodosBlancos);
            Check(m => m.CantidadDeNodosGrises);
            Check(m => m.CantidadDeNodosNegros);
        }
    }

    public class Test35 : DibujandoRectangulosTest
    {
        public void EstaPintado1()
        {
            Initialize(8);

            Perform(m => m.Dibuja(3, 3, 5, 5));
            Check(m => m.EstaPintado(3, 3));
        }
    }

    public class Test36 : DibujandoRectangulosTest
    {
        public void EstaPintado2()
        {
            Initialize(8);

            Perform(m => m.Dibuja(3, 3, 5, 5));
            Check(m => m.EstaPintado(9, 8));
        }
    }

    public class Test37 : DibujandoRectangulosTest
    {
        public void EstaPintado3()
        {
            Initialize(8);

            Perform(m => m.Dibuja(3, 3, 5, 5));
            Perform(m => m.Dibuja(0, 0, 1 << 7, 1 << 7));
            Check(m => m.EstaPintado((1 << 7) + 1, 8));
        }
    }

    public class Test38 : DibujandoRectangulosTest
    {
        public void EstaPintado4()
        {
            Initialize(11);

            Perform(m => m.Dibuja(4, 8, 1 << 10, 1 << 9));
            Check(m => m.EstaPintado(800, 10));
        }
    }

    public class Test39 : DibujandoRectangulosTest
    {
        public void EstaPintado5()
        {
            Initialize(10);

            Perform(m => m.Dibuja(0, 0, 1, 1 << 10));
            Perform(m => m.Dibuja(0, 10, 1, 1 << 9));
            Perform(m => m.Dibuja(0, 521, 1, 1 << 8));
            Check(m => m.EstaPintado(423, 1));
        }
    }

    public class Test40 : DibujandoRectangulosTest
    {
        public void EstaPintado6()
        {
            Initialize(12);

            Perform(m => m.Dibuja(0, (1 << 12) - 1, 1 << 12, 1));
            Check(m => m.EstaPintado((1 << 12) - 2, 1));
        }
    }

    public class Test41 : DibujandoRectangulosTest
    {
        public void EstaPintado7()
        {
            Initialize(0);

            Perform(m => m.Dibuja(0, 0, 1, 1));
            Check(m => m.EstaPintado(0, 0));
        }
    }

    public class Test42 : DibujandoRectangulosTest
    {
        public void EstaPintado8()
        {
            Initialize(1);

            Check(m => m.EstaPintado(0, 1));
        }
    }

    public class Test43 : DibujandoRectangulosTest
    {
        public void EstaPintado9()
        {
            Initialize(10);

            Perform(m => m.Dibuja(123, 134, 30, 40));
            Check(m => m.EstaPintado(100, 180));
        }
    }

    public class Test44 : DibujandoRectangulosTest
    {
        public void EstaPintado10()
        {
            Initialize(10);

            Perform(m => m.Dibuja(1 << 9, (1 << 9) + 20, 30, 40));
            Check(m => m.EstaPintado(100, 1 << 9));
        }
    }
}
