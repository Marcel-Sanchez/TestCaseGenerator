﻿using Arboles;
using System.Collections.Generic;
using Weboo.Assess.Tester;

namespace CaminosCruzadosTester
{
    public abstract class CaminosCruzadosTest : TestCase
    {
        public int Student(INodoArbol arbol)
        {
            return ReflectionHelper.InvokeStatic<int>("Weboo.Examen.CaminosCruzados", "MayorLongitud", arbol);
        }

        protected class DummyTree : INodoArbol
        {
            string _value;
            DummyTree[] _children;

            public DummyTree(string value, params DummyTree[] children)
            {
                _value = value;
                _children = children;
            }

            int INodoArbol.CantidadDeHijos => _children.Length;

            IEnumerable<INodoArbol> INodoArbol.Hijos => _children;
        }
    }

    public class Example1Test : CaminosCruzadosTest
    {
        public void Example1()
        {
            var tree =
            new DummyTree("A",
                new DummyTree("B",
                    new DummyTree("E",
                        new DummyTree("L")
                    ),
                    new DummyTree("F")
                ),
                new DummyTree("C",
                    new DummyTree("G",
                        new DummyTree("M")
                    ),
                    new DummyTree("H"),
                    new DummyTree("I")
                ),
                new DummyTree("D",
                    new DummyTree("J"),
                    new DummyTree("K")
                )
            );

            Assert.That(Student(tree), Is.EqualTo(9));
        }
    }

    public class Example2Test : CaminosCruzadosTest
    {
        public void Example2()
        {
            var tree =
            new DummyTree("A",
                new DummyTree("B",
                    new DummyTree("E",
                        new DummyTree("L")
                    )
                ),
                new DummyTree("C",
                    new DummyTree("G",
                        new DummyTree("M")
                ))
            );

            Assert.That(Student(tree), Is.EqualTo(7));
        }
    }

    public class Example3Test : CaminosCruzadosTest
    {
        public void Example3()
        {
            var tree =
            new DummyTree("A",
                new DummyTree("B",
                    new DummyTree("E",
                        new DummyTree("L")
                    ),
                    new DummyTree("F")
                ),
                new DummyTree("C",
                    new DummyTree("G",
                        new DummyTree("M")
                    ),
                    new DummyTree("H"),
                    new DummyTree("I")
                ),
                new DummyTree("D",
                    new DummyTree("J"),
                    new DummyTree("K")
                ),
                new DummyTree("X",
                    new DummyTree("Y",
                        new DummyTree("W",
                            new DummyTree("Z",
                                new DummyTree("O",
                                    new DummyTree("P"))))),
                    new DummyTree("K")
                ),
                new DummyTree("U")
            );

            Assert.That(Student(tree), Is.EqualTo(15));
        }
    }

    public class Example4Test : CaminosCruzadosTest
    {
        public void Example4()
        {
            var tree =
            new DummyTree("A");

            Assert.That(Student(tree), Is.EqualTo(1));
        }
    }

    public class Example5Test : CaminosCruzadosTest
    {
        public void Example5()
        {
            var tree =
            new DummyTree("A", new DummyTree("B", new DummyTree("C", new DummyTree("D", new DummyTree("E")))));

            Assert.That(Student(tree), Is.EqualTo(5));
        }
    }

    public class Basic1Test : CaminosCruzadosTest
    {
        public void Basic1()
        {
            var tree =
                new DummyTree("A",
                    new DummyTree("B")
                );

            Assert.That(Student(tree), Is.EqualTo(2));
        }
    }

    public class Basic2Test : CaminosCruzadosTest
    {
        public void Basic2()
        {
            var tree =
                new DummyTree("A",
                    new DummyTree("B"),
                    new DummyTree("C")
                );

            Assert.That(Student(tree), Is.EqualTo(3));
        }
    }

    public class Basic3Test : CaminosCruzadosTest
    {
        public void Basic3()
        {
            var tree =
                new DummyTree("A",
                    new DummyTree("B"),
                    new DummyTree("C"),
                    new DummyTree("D")
                );

            Assert.That(Student(tree), Is.EqualTo(4));
        }
    }

    public class Basic4Test : CaminosCruzadosTest
    {
        public void Basic4()
        {
            var tree =
                new DummyTree("A",
                    new DummyTree("B"),
                    new DummyTree("C"),
                    new DummyTree("D"),
                    new DummyTree("E"),
                    new DummyTree("F"),
                    new DummyTree("G"),
                    new DummyTree("H")
                );

            Assert.That(Student(tree), Is.EqualTo(5));
        }
    }

    public class Basic5Test : CaminosCruzadosTest
    {
        public void Basic5()
        {
            var tree =
                new DummyTree("A",
                    new DummyTree("B",
                        new DummyTree("C"),
                        new DummyTree("D"),
                        new DummyTree("E"))
                );

            Assert.That(Student(tree), Is.EqualTo(5));
        }
    }

    public class Basic6Test : CaminosCruzadosTest
    {
        public void Basic6()
        {
            var tree =
                new DummyTree("A",
                    new DummyTree("B",
                        new DummyTree("C",
                            new DummyTree("D"),
                            new DummyTree("E"),
                            new DummyTree("F"),
                            new DummyTree("G")))
                );

            Assert.That(Student(tree), Is.EqualTo(6));
        }
    }

    public class Basic7Test : CaminosCruzadosTest
    {
        public void Basic7()
        {
            var tree =
                new DummyTree("A",
                    new DummyTree("B",
                        new DummyTree("C",
                            new DummyTree("D"),
                            new DummyTree("E"),
                            new DummyTree("F"),
                            new DummyTree("G"))),
                    new DummyTree("H")
                );

            Assert.That(Student(tree), Is.EqualTo(7));
        }
    }

    public class Basic8Test : CaminosCruzadosTest
    {
        public void Basic8()
        {
            var tree =
                new DummyTree("A",
                    new DummyTree("B",
                        new DummyTree("C",
                            new DummyTree("D"),
                            new DummyTree("E"),
                            new DummyTree("F")),
                        new DummyTree("G"))
                );

            Assert.That(Student(tree), Is.EqualTo(6));
        }
    }

    public class Basic9Test : CaminosCruzadosTest
    {
        public void Basic9()
        {
            var tree =
                new DummyTree("A",
                    new DummyTree("B",
                        new DummyTree("C",
                            new DummyTree("D"),
                            new DummyTree("E"),
                            new DummyTree("F")),
                        new DummyTree("H")),
                    new DummyTree("G")
                );

            Assert.That(Student(tree), Is.EqualTo(7));
        }
    }

    public class Basic10Test : CaminosCruzadosTest
    {
        public void Basic10()
        {
            var tree =
                new DummyTree("A",
                    new DummyTree("B",
                        new DummyTree("C",
                            new DummyTree("D",
                                new DummyTree("E")),
                            new DummyTree("F",
                                new DummyTree("G")),
                            new DummyTree("H",
                                new DummyTree("I"))),
                        new DummyTree("J",
                            new DummyTree("K",
                                new DummyTree("L")))),
                    new DummyTree("M")
                );

            Assert.That(Student(tree), Is.EqualTo(11));
        }
    }

    public class Basic11Test : CaminosCruzadosTest
    {
        public void Basic11()
        {
            var tree =
                new DummyTree("A",
                    new DummyTree("B",
                        new DummyTree("J",
                            new DummyTree("K",
                                new DummyTree("L"))),
                        new DummyTree("C",
                            new DummyTree("D",
                                new DummyTree("E")),
                            new DummyTree("F",
                                new DummyTree("G")),
                            new DummyTree("H",
                                new DummyTree("I")))),
                    new DummyTree("M")
                );

            Assert.That(Student(tree), Is.EqualTo(11));
        }
    }

    public class Basic12Test : CaminosCruzadosTest
    {
        public void Basic12()
        {
            var tree =
                new DummyTree("A",
                    new DummyTree("B",
                        new DummyTree("C",
                            new DummyTree("D")),
                        new DummyTree("E",
                            new DummyTree("F")),
                        new DummyTree("G",
                            new DummyTree("I")),
                        new DummyTree("J",
                            new DummyTree("K")))
                );

            Assert.That(Student(tree), Is.EqualTo(9));
        }
    }

    public class Basic13Test : CaminosCruzadosTest
    {
        public void Basic13()
        {
            var tree =
                new DummyTree("A",
                    new DummyTree("B",
                        new DummyTree("C",
                            new DummyTree("D"))),
                    new DummyTree("E",
                        new DummyTree("F"),
                        new DummyTree("G"))
                );

            Assert.That(Student(tree), Is.EqualTo(7));
        }
    }

    public class Basic14Test : CaminosCruzadosTest
    {
        public void Basic14()
        {
            var tree =
                new DummyTree("0",
                    new DummyTree("A",
                        new DummyTree("B",
                            new DummyTree("C",
                                new DummyTree("D"))),
                        new DummyTree("E",
                            new DummyTree("F")),
                        new DummyTree("G",
                            new DummyTree("H",
                                new DummyTree("I",
                                    new DummyTree("J",
                                        new DummyTree("K"))))),
                        new DummyTree("L",
                            new DummyTree("M",
                                new DummyTree("N",
                                    new DummyTree("O")))),
                        new DummyTree("P",
                            new DummyTree("Q",
                                new DummyTree("R",
                                    new DummyTree("S",
                                        new DummyTree("T",
                                            new DummyTree("U",
                                                new DummyTree("V"))))))),
                        new DummyTree("W",
                            new DummyTree("X",
                                new DummyTree("Y",
                                    new DummyTree("Z")))))
                );

            Assert.That(Student(tree), Is.EqualTo(21));
        }
    }

    public class Basic15Test : CaminosCruzadosTest
    {
        public void Basic15()
        {
            var leftWing = new DummyTree("L12");
            var rightWing = new DummyTree("R12");
            var innerChildren = new[] { new DummyTree("I1-9"), new DummyTree("I2-9"), new DummyTree("I3-9"), new DummyTree("I4-9") };
            for (int i = 11; i > 0; i--)
            {
                leftWing = new DummyTree($"L{i}", leftWing);
                rightWing = new DummyTree($"R{i}", rightWing);
                if (i < 9)
                {
                    for (int j = 0; j < 4; j++)
                        innerChildren[j] = new DummyTree($"I{j}-{i}", innerChildren[j]);
                }
            }

            var middleWing = new DummyTree("I1", new DummyTree("I2", innerChildren));
            var tree = new DummyTree("NSymmetric", leftWing, middleWing, rightWing);

            Assert.That(Student(tree), Is.EqualTo(42));
        }
    }
}
