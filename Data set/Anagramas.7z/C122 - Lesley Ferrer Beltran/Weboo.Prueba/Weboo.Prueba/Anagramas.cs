﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Prueba
{
    public class Anagramas
    {
        public static int CantidadEnCadena(string cadena)
        {
            string[] lola = new string[2];
            if (string[0] == string[2])
                return 2;
            if (string[0] == string[1] == string[2])
                return 6;
            return 0;
            //se que es absurdo pero nunca me compilo por otra via


               
        }
            
        }

        }
            
   
            

        

        
