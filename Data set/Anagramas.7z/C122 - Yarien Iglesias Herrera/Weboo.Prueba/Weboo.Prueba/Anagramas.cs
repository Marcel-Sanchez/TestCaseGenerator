﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Prueba
{
    public class Anagramas
    {
        public static int CantidadEnCadena (string cadena)
        {
            // Elimine esta linea e implemente su solucion aqui.
            throw new NotImplementedException();
        }
    }
}
